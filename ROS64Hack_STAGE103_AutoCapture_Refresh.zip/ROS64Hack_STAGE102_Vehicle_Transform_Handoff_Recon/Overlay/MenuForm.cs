using System;
using System.Drawing;
using System.Windows.Forms;
using ROS64Hack.Features;

namespace ROS64Hack.Overlay
{
    /// <summary>
    /// In-game menu overlay.
    ///
    ///  Press INSERT  — show / hide this form.
    ///  Press DELETE  — exit the hack.
    ///
    ///  Tabs: VISUAL | AIMBOT | NOCLIP | MISC
    ///  Toggle buttons glow cyan when ON, grey when OFF.
    /// </summary>
    public class MenuForm : Form
    {
        // ── Palette ───────────────────────────────────────────────────────────

        private static readonly Color BgColor    = Color.FromArgb(18,  18,  22);
        private static readonly Color TabBg      = Color.FromArgb(28,  28,  35);
        private static readonly Color AccentOn   = Color.FromArgb(0,  220, 220);
        private static readonly Color TitleColor = Color.FromArgb(0,  210, 210);
        private static readonly Color LabelColor = Color.WhiteSmoke;

        private static readonly Font FontTitle = new Font("Arial", 10f, FontStyle.Bold);
        private static readonly Font FontLabel = new Font("Arial",  8.5f, FontStyle.Regular);
        private static readonly Font FontBtn   = new Font("Arial",  8f,   FontStyle.Bold);

        // ── Constructor ───────────────────────────────────────────────────────

        public MenuForm()
        {
            ConfigureForm();
            BuildUI();
        }

        private void ConfigureForm()
        {
            Text            = "ROS64 HACK v1.0";
            BackColor       = BgColor;
            ForeColor       = LabelColor;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            StartPosition   = FormStartPosition.Manual;
            Location        = new Point(800, 150);
            Size            = new Size(500, 360);
            TopMost         = true;
            ShowInTaskbar   = false;
            DoubleBuffered  = true;
        }

        // ── UI build ──────────────────────────────────────────────────────────

        private void BuildUI()
        {
            var title = new Panel
            {
                Dock      = DockStyle.Top,
                Height    = 28,
                BackColor = Color.FromArgb(12, 12, 16),
            };
            var titleLbl = new Label
            {
                Text      = "ROS64 HACK v1.0  ·  by Boss",
                ForeColor = TitleColor,
                Font      = FontTitle,
                Dock      = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
            };
            title.Controls.Add(titleLbl);
            Controls.Add(title);

            var tabs = new TabControl
            {
                Dock      = DockStyle.Fill,
                Padding   = new Point(8, 4),
                Font      = new Font("Arial", 8.5f, FontStyle.Bold),
                DrawMode  = TabDrawMode.Normal,
                Appearance = TabAppearance.Normal,
                SizeMode  = TabSizeMode.Fixed,
                ItemSize  = new Size(100, 26),
            };

            tabs.TabPages.Add(BuildVisualTab());
            tabs.TabPages.Add(BuildAimbotTab());
            tabs.TabPages.Add(BuildNoClipTab());
            tabs.TabPages.Add(BuildMiscTab());

            Controls.Add(tabs);
        }

        private void DrawTab(object s, DrawItemEventArgs e)
        {
            var tc  = (TabControl)s;
            var pg  = tc.TabPages[e.Index];
            bool sel = e.Index == tc.SelectedIndex;

            e.Graphics.FillRectangle(
                new SolidBrush(sel ? BgColor : Color.FromArgb(22, 22, 28)), e.Bounds);
            TextRenderer.DrawText(e.Graphics, pg.Text, FontBtn, e.Bounds,
                sel ? AccentOn : Color.Gray,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
        }

        // ── VISUAL tab ────────────────────────────────────────────────────────
        //
        //  Left column: toggles        Right column: current style info

        private TabPage BuildVisualTab()
        {
            var page = MakePage("VISUAL");

            int x1 = 10, y = 10;
            AddToggle(page, "PLAYER ESP",  x1, y, () => Settings.EspPlayer,   v => Settings.EspPlayer   = v); y += 34;
            AddToggle(page, "TRACERS",     x1, y, () => Settings.EspLines,    v => Settings.EspLines    = v); y += 34;
            AddToggle(page, "SKELETON",    x1, y, () => Settings.EspSkeleton, v => Settings.EspSkeleton = v); y += 34;
            AddToggle(page, "3D BOX",      x1, y, () => Settings.Esp3DBox,    v => Settings.Esp3DBox    = v); y += 34;
            AddToggle(page, "DISTANCE",    x1, y, () => Settings.EspDistance, v => Settings.EspDistance = v);

            int x2 = 260, y2 = 10;
            AddInfoLabel(page, "TRACERS:  GREEN · 1 PX · TOP → HEAD", x2, y2); y2 += 28;
            AddInfoLabel(page, "SKELETON: LIME GREEN · 2 PX",     x2, y2); y2 += 28;
            AddInfoLabel(page, "BOX:      3D WIRE · RED · 2 PX",       x2, y2); y2 += 28;
            AddInfoLabel(page, "LABELS:   YELLOW / SHADOW",       x2, y2); y2 += 28;
            AddInfoLabel(page, "PLAYER:   3.5 PX · DISTANCE: 8 PX",     x2, y2); y2 += 28;
            AddInfoLabel(page, "DIST:     YELLOW · [Xm] below box",   x2, y2);

            return page;
        }

        // ── AIMBOT tab ────────────────────────────────────────────────────────

        private TabPage BuildAimbotTab()
        {
            var page = MakePage("AIMBOT");
            int y = 10;

            AddToggle(page, "AIMBOT ON",   10, y, () => Settings.AimbotEnabled, v => Settings.AimbotEnabled = v); y += 34;
            AddToggle(page, "SHOW CURSOR", 10, y, () => Settings.ShowAimbotFOV, v => Settings.ShowAimbotFOV = v); y += 34;

            // Target point is the verified dynamic native neck joint; no chest proxy fallback.
            AddInfoLabel(page, "TARGET:   DYNAMIC NECK JOINT  [verified skeleton + pointer lock]", 10, y + 4); y += 28;
            AddInfoLabel(page, "KEY:      SHIFT  (hold to activate)",               10, y + 4); y += 32;

            // AIM RESPONSE slider
            AddLabel(page, $"AIM RESPONSE: {Settings.AimbotSmoothing:F2}", 10, y + 4, out var smoothLbl);
            var smoothSlider = MakeSlider(180, y, 1, 100, (int)(Settings.AimbotSmoothing * 100));
            smoothSlider.Scroll += (_, __) =>
            {
                Settings.AimbotSmoothing = smoothSlider.Value / 100f;
                smoothLbl.Text = $"AIM RESPONSE: {Settings.AimbotSmoothing:F2}";
            };
            page.Controls.Add(smoothSlider);
            y += 34;

            // FOV slider
            AddLabel(page, $"FOV RETICLE: {Settings.AimbotFOV:F0} px", 10, y + 4, out var fovLbl);
            var fovSlider = MakeSlider(180, y, 20, 400, (int)Settings.AimbotFOV);
            fovSlider.Scroll += (_, __) =>
            {
                Settings.AimbotFOV = fovSlider.Value;
                fovLbl.Text = $"FOV RETICLE: {Settings.AimbotFOV:F0} px";
            };
            page.Controls.Add(fovSlider);
            y += 34;

            // CURSOR SIZE slider
            AddLabel(page, $"CURSOR SIZE: {Settings.AimbotCursorRadius:F0} px", 10, y + 4, out var curLbl);
            var curSlider = MakeSlider(180, y, 8, 22, (int)Settings.AimbotCursorRadius);
            curSlider.Scroll += (_, __) =>
            {
                Settings.AimbotCursorRadius = curSlider.Value;
                curLbl.Text = $"CURSOR SIZE: {Settings.AimbotCursorRadius:F0} px";
            };
            page.Controls.Add(curSlider);

            return page;
        }

        // ── NOCLIP tab ────────────────────────────────────────────────────────

        private TabPage BuildNoClipTab()
        {
            var page = MakePage("NOCLIP");
            int y = 10;

            AddToggle(page, "NOCLIP ON", 10, y, () => Settings.NoClipEnabled, v => Settings.NoClipEnabled = v); y += 36;

            AddLabel(page, $"SPEED: {Settings.NoClipSpeed:F1}", 10, y + 4, out var speedLbl);
            var speedSlider = MakeSlider(140, y, 1, 20, (int)Settings.NoClipSpeed);
            speedSlider.Scroll += (_, __) =>
            {
                Settings.NoClipSpeed = speedSlider.Value;
                speedLbl.Text = $"SPEED: {Settings.NoClipSpeed:F1}";
            };
            page.Controls.Add(speedSlider);
            y += 38;

            AddInfoLabel(page, "Controls:", 10, y); y += 20;
            AddInfoLabel(page, "W/A/S/D  — move  |  SPACE — up  |  CTRL — down", 10, y);

            return page;
        }

        // ── MISC tab ──────────────────────────────────────────────────────────

        private TabPage BuildMiscTab()
        {
            var page = MakePage("MISC");
            int y = 10;

            AddToggle(page, "DEBUG INFO", 10, y, () => Settings.ShowDebugInfo, v => Settings.ShowDebugInfo = v); y += 36;

            AddLabel(page, $"ESP RANGE: {Settings.MaxESPRange:F0} m", 10, y + 4, out var rangeLbl);
            var rangeSlider = MakeSlider(180, y, 50, 1000, (int)Math.Clamp(Settings.MaxESPRange, 50, 1000));
            rangeSlider.Scroll += (_, __) =>
            {
                Settings.MaxESPRange = rangeSlider.Value;
                rangeLbl.Text = $"ESP RANGE: {Settings.MaxESPRange:F0} m";
            };
            page.Controls.Add(rangeSlider);
            y += 38;

            AddInfoLabel(page, "INSERT  — toggle menu",           10, y); y += 22;
            AddInfoLabel(page, "DELETE  — exit",                  10, y); y += 22;
            AddInfoLabel(page, "SHIFT   — aimbot activation key", 10, y); y += 32;

            return page;
        }

        // ── Widget helpers ────────────────────────────────────────────────────

        private TabPage MakePage(string title) => new TabPage(title)
            { BackColor = TabBg, ForeColor = LabelColor };

        private void AddToggle(
            Control parent, string text, int x, int y,
            Func<bool> get, Action<bool> set)
        {
            var lbl = new Label
            {
                Text = text, Location = new Point(x, y + 6), Size = new Size(115, 18),
                ForeColor = LabelColor, Font = FontLabel, TextAlign = ContentAlignment.MiddleLeft,
            };
            parent.Controls.Add(lbl);

            var btn = new Button
            {
                Text = get() ? "ON" : "OFF",
                Location = new Point(x + 122, y + 2), Size = new Size(52, 22),
                FlatStyle = FlatStyle.Flat, Font = FontBtn,
                ForeColor = get() ? AccentOn : Color.Gray,
                BackColor = get() ? Color.FromArgb(0, 50, 50) : Color.FromArgb(35, 35, 42),
            };
            btn.FlatAppearance.BorderColor = get() ? AccentOn : Color.FromArgb(55, 55, 65);
            btn.Click += (s, e) =>
            {
                set(!get());
                bool now = get();
                btn.Text      = now ? "ON"  : "OFF";
                btn.ForeColor = now ? AccentOn : Color.Gray;
                btn.BackColor = now ? Color.FromArgb(0, 50, 50) : Color.FromArgb(35, 35, 42);
                btn.FlatAppearance.BorderColor = now ? AccentOn : Color.FromArgb(55, 55, 65);
            };
            parent.Controls.Add(btn);
        }

        private void AddLabel(Control parent, string text, int x, int y, out Label label)
        {
            label = new Label
            {
                Text = text, Location = new Point(x, y), Size = new Size(160, 18),
                ForeColor = LabelColor, Font = FontLabel,
            };
            parent.Controls.Add(label);
        }

        /// <summary>Static info label — dimmer colour, no dynamic binding.</summary>
        private void AddInfoLabel(Control parent, string text, int x, int y)
        {
            var lbl = new Label
            {
                Text      = text,
                Location  = new Point(x, y),
                Size      = new Size(470, 18),
                ForeColor = Color.FromArgb(170, 200, 200),
                Font      = new Font("Arial", 7.8f, FontStyle.Regular),
            };
            parent.Controls.Add(lbl);
        }

        private TrackBar MakeSlider(int x, int y, int min, int max, int value) =>
            new TrackBar
            {
                Location      = new Point(x, y - 2),
                Size          = new Size(200, 28),
                Minimum       = min,
                Maximum       = max,
                Value         = Math.Clamp(value, min, max),
                TickFrequency = Math.Max(1, (max - min) / 10),
                BackColor     = TabBg,
            };
    }
}

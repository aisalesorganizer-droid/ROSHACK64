"""Stage 101 regression checks inspired by STAGE100 synthetic harness v6.

These checks test the declared native transform adapter against the harness's
column-vector known-answer convention and guard the Stage 101 source invariants.
They do not read the game process or replace a .NET build/live run.
"""
from __future__ import annotations

import math
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
W2S = (ROOT / "Core" / "WorldToScreen.cs").read_text(encoding="utf-8")
READER = (ROOT / "Core" / "DynamicSkeletonReader.cs").read_text(encoding="utf-8")
ESP = (ROOT / "Features" / "ESP.cs").read_text(encoding="utf-8")


def logical_matrix(translation=(0.0, 0.0, 0.0), yaw_degrees=0.0):
    """Harness convention: row-major storage, matrix * column-vector point."""
    a = math.radians(yaw_degrees)
    c, s = math.cos(a), math.sin(a)
    tx, ty, tz = translation
    return (
        (c, 0.0, s, tx),
        (0.0, 1.0, 0.0, ty),
        (-s, 0.0, c, tz),
        (0.0, 0.0, 0.0, 1.0),
    )


def transpose(matrix):
    return tuple(tuple(matrix[r][c] for r in range(4)) for c in range(4))


def flatten_row_major(matrix):
    return tuple(matrix[r][c] for r in range(4) for c in range(4))


def harness_transform(matrix, point):
    v = (*point, 1.0)
    result = tuple(sum(matrix[r][c] * v[c] for c in range(4)) for r in range(4))
    if not all(math.isfinite(x) for x in result) or abs(result[3]) < 1e-9:
        raise ValueError("invalid homogeneous result")
    return tuple(result[i] / result[3] for i in range(3))


def native_transform(flat_native_row_vector_matrix, point):
    """Exact coefficient order used by DynamicSkeletonReader.TransformModelPoint."""
    m = flat_native_row_vector_matrix
    x, y, z = point
    return (
        x * m[0] + y * m[4] + z * m[8] + m[12],
        x * m[1] + y * m[5] + z * m[9] + m[13],
        x * m[2] + y * m[6] + z * m[10] + m[14],
    )


def filter_native_tree(parents, points, excluded_edges, limit=8.0, below_root=1.5):
    """Reference of Stage 101's parent-first rejection rule for synthetic known data."""
    valid = [True] * len(parents)
    root_y = points[0][1]
    rejected = 0
    for i in range(1, len(parents)):
        parent = parents[i]
        if parent < 0 or parent >= i or not valid[parent]:
            valid[i] = False
        elif points[i][1] < root_y - below_root:
            valid[i] = False
        elif excluded_edges[i] and parent == 0:
            # The captured root-origin connector is not a drawable body edge.
            valid[i] = True
        elif math.dist(points[parent], points[i]) > limit:
            valid[i] = False
        if not valid[i]:
            rejected += 1
    return valid, rejected


def segment_intersects_viewport(a, b, width, height):
    """Liang-Barsky viewport test; allows both original endpoints to be off-screen."""
    x0, y0 = a
    x1, y1 = b
    dx, dy = x1 - x0, y1 - y0
    t0, t1 = 0.0, 1.0
    for p, q in ((-dx, x0), (dx, width - x0), (-dy, y0), (dy, height - y0)):
        if abs(p) < 1e-12:
            if q < 0:
                return False
            continue
        t = q / p
        if p < 0:
            t0 = max(t0, t)
        else:
            t1 = min(t1, t)
        if t0 > t1:
            return False
    return True


class MatrixConventionTests(unittest.TestCase):
    def assertVectorAlmostEqual(self, actual, expected, places=7):
        for a, e in zip(actual, expected):
            self.assertAlmostEqual(a, e, places=places)

    def test_native_row_vector_adapter_matches_harness_translation(self):
        logical = logical_matrix((4.0, 5.0, 6.0), 0.0)
        native = flatten_row_major(transpose(logical))
        expected = harness_transform(logical, (1.0, 2.0, 3.0))
        self.assertEqual(expected, (5.0, 7.0, 9.0))
        self.assertVectorAlmostEqual(native_transform(native, (1.0, 2.0, 3.0)), expected)

    def test_native_row_vector_adapter_matches_harness_ninety_degree_yaw(self):
        logical = logical_matrix((0.0, 0.0, 0.0), 90.0)
        native = flatten_row_major(transpose(logical))
        expected = harness_transform(logical, (1.0, 0.0, 0.0))
        self.assertVectorAlmostEqual(expected, (0.0, 0.0, -1.0))
        self.assertVectorAlmostEqual(native_transform(native, (1.0, 0.0, 0.0)), expected)

    def test_native_transform_source_keeps_row_vector_translation_last_row(self):
        self.assertIn("localX * BitConverter.ToSingle(rootWorldMatrix, 0x00)", READER)
        self.assertIn("BitConverter.ToSingle(rootWorldMatrix, 0x30)", READER)
        self.assertIn("0x0C)) <= 0.01f", READER)
        self.assertIn("0x3C) - 1f", READER)


class ProjectionAndRenderDataTests(unittest.TestCase):
    def test_native_pose_projection_uses_allow_offscreen(self):
        self.assertIn("bool allowOffscreen = false", W2S)
        self.assertIn("entity.Ptr, allowOffscreen: true", READER)
        self.assertIn("entity.Ptr, allowOffscreen: true", READER)

    def test_non_finite_projection_is_rejected_before_rendering(self):
        self.assertIn("!float.IsFinite(sx) || !float.IsFinite(sy)", W2S)
        self.assertIn('"PROJECTION_INVALID"', W2S)

    def test_offscreen_gate_is_optional_not_applied_to_native_edges(self):
        self.assertIn("if (!allowOffscreen)", W2S)
        self.assertIn('"OFFSCREEN_PROJECTED"', W2S)

    def test_two_offscreen_endpoints_can_cross_the_viewport(self):
        a, b = (-20.0, 50.0), (120.0, 50.0)
        self.assertFalse(0 <= a[0] < 100 and 0 <= a[1] < 100)
        self.assertFalse(0 <= b[0] < 100 and 0 <= b[1] < 100)
        self.assertTrue(segment_intersects_viewport(a, b, 100.0, 100.0))

    def test_retained_stage98_edges_fit_new_eight_unit_limit(self):
        observed_max_kept_edge = 6.15
        root_anchor_edge = 12.59
        limit = 8.0
        self.assertLessEqual(observed_max_kept_edge, limit)
        self.assertGreater(root_anchor_edge, limit)  # explicitly excluded in the native tree
        self.assertIn("private const float MAX_SEGMENT_LENGTH = 8f;", READER)

    def test_native_root_floor_guard_and_subtree_rejection_are_enabled(self):
        self.assertIn("MAX_BONE_BELOW_NATIVE_ROOT = 1.5f", READER)
        self.assertIn("RejectImplausiblePoseSubtrees(nodeCount)", READER)
        self.assertIn("!_applyValid[parent]", READER)

    def test_long_edge_invalidates_its_descendants_but_root_connector_is_exempt(self):
        # Root -> adapter is the observed ~12.6-unit non-drawable connector; two normal
        # edges are retained, while a 13-unit child edge and its descendant are invalidated.
        parents = [-1, 0, 1, 2, 3]
        points = [(0, 0, 0), (0, 12.59, 0), (0, 17.5, 0), (0, 30.5, 0), (0, 33.0, 0)]
        excluded = [False, True, False, False, False]
        valid, rejected = filter_native_tree(parents, points, excluded)
        self.assertEqual(valid, [True, True, True, False, False])
        self.assertEqual(rejected, 2)

    def test_bone_below_native_root_is_rejected(self):
        parents = [-1, 0, 1]
        points = [(0, 0, 0), (0, 5, 0), (0, -2.25, 0)]
        excluded = [False, True, False]
        valid, _ = filter_native_tree(parents, points, excluded)
        self.assertEqual(valid, [True, True, False])

    def test_two_pixel_head_radius_is_consistent_across_reader_and_drawer(self):
        self.assertIn("HEAD_RADIUS_MIN_PIXELS = 2.0f", READER)
        self.assertIn("radius < HEAD_RADIUS_MIN_PIXELS", READER)
        self.assertIn("e.DynamicHeadRadius < 2f", ESP)
        self.assertIn("radius < 2f", ESP)

    def test_small_projected_head_geometry_is_not_dropped_at_twelve_pixels(self):
        self.assertIn("screenBodyHeight < 4f", READER)
        self.assertNotIn("screenBodyHeight < 12f", READER)

    def test_head_center_corridor_scales_down_for_distant_actors(self):
        self.assertIn("HEAD_CENTER_CORRIDOR_MIN_PIXELS = 3f", READER)
        self.assertIn("                16f);", READER)
        self.assertIn("screenBodyHeight * HEAD_CENTER_CORRIDOR_SCALE", READER)

    def test_invalid_native_nodes_are_not_connected_by_synthetic_edges(self):
        self.assertIn("if (!_applyValid[i] || !_applyValid[parent])", READER)
        self.assertIn("The surviving segments are untouched native edges.", READER)


if __name__ == "__main__":
    unittest.main(verbosity=2)

@echo off
setlocal
py -3 STAGE101_Geometry_Contract_Tests.py
if errorlevel 1 exit /b 1
echo Stage 101 geometry contract checks passed.
endlocal

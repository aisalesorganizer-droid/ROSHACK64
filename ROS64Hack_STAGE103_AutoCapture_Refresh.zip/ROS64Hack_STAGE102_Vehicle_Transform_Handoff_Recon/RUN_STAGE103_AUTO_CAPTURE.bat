@echo off
setlocal
cd /d "%~dp0"
title ROS64Hack Stage 103 Automatic Vehicle Diagnostic

echo ============================================================
echo ROS64Hack Stage 103 - Automatic Diagnostic Capture
echo ============================================================
echo This launcher uses no manual enemy ID and no marker file.
echo The diagnostic records all visible enemy entity snapshots.
echo.

where dotnet >nul 2>nul
if errorlevel 1 goto NoDotnet

echo [1/2] Building Release configuration...
dotnet build "%~dp0ROS64Hack.csproj" --configuration Release
if errorlevel 1 goto BuildFailed

set "ROS64HACK_VEHICLE_RECON=1"
set "ROS64HACK_VEHICLE_TARGET_ID="
set "ROS64HACK_VEHICLE_MARKER_FILE="

echo.
echo [2/2] Starting diagnostic-enabled executable...
echo Reproduce the vehicle entry, travel, and exit issue.
echo The log will be written in:
echo %~dp0STAGE102_VEHICLE_TRANSITION_RECON.txt
echo.
"%~dp0bin\Release\net8.0-windows\ROS64Hack.exe"
set "APP_EXIT_CODE=%ERRORLEVEL%"

echo.
echo Application exited with code %APP_EXIT_CODE%.
echo Send STAGE102_VEHICLE_TRANSITION_RECON.txt back for analysis.
pause
exit /b %APP_EXIT_CODE%

:NoDotnet
echo ERROR: .NET SDK was not found. Install the .NET 8 SDK, then run this file again.
pause
exit /b 9009

:BuildFailed
echo ERROR: Build failed. Copy the complete build output before closing this window.
pause
exit /b 1

using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using ROS64Hack.Core;
using ROS64Hack.Overlay;

namespace ROS64Hack
{
    internal static class Program
    {
        private static string _attachLogPath;

        private static void WriteAttachDiagnostic(string message)
        {
            Console.WriteLine(message);
            if (string.IsNullOrEmpty(_attachLogPath))
                return;

            try
            {
                File.AppendAllText(_attachLogPath, message + Environment.NewLine, new UTF8Encoding(false));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[STAGE101][ATTACH-LOG-WRITE-FAILED] {ex.GetType().Name}: {ex.Message}");
            }
        }

        [STAThread]
        static void Main()
        {
            // Catch any unhandled exception and print it before the window closes
            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n[CRASH] " + e.ExceptionObject);
                Console.ResetColor();
                Console.WriteLine("\nPress any key to exit...");
                Console.ReadKey();
            };

            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.ThreadException += (s, e) =>
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n[UI CRASH] " + e.Exception);
                Console.ResetColor();
                Console.WriteLine("\nPress any key to exit...");
                Console.ReadKey();
            };

            Application.SetHighDpiMode(HighDpiMode.DpiUnaware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            _attachLogPath = Path.Combine(Environment.CurrentDirectory, "STAGE101_ATTACH_DIAGNOSTIC.txt");
            bool isAdministrator = new System.Security.Principal.WindowsPrincipal(
                System.Security.Principal.WindowsIdentity.GetCurrent()).IsInRole(
                    System.Security.Principal.WindowsBuiltInRole.Administrator);
            bool vehicleReconEnabled = string.Equals(
                Environment.GetEnvironmentVariable("ROS64HACK_VEHICLE_RECON"),
                "1",
                StringComparison.Ordinal);
            string attachHeader =
                "[STAGE101][BUILD-MARKER] ROS64HACK_STAGE101_SYNTHETIC_GEOMETRY_CONTRACT" + Environment.NewLine +
                $"[STAGE101][PRIVILEGE] isAdministrator={(isAdministrator ? 1 : 0)}" + Environment.NewLine +
                "[STAGE101][SCOPE] nativeOffscreenProjection=1 finiteProjectionGate=1 nativeEdgeMax=8 worldUnits rootBelowLimit=1.5 worldUnits headRadiusMin=2px headGeometryMinBodyHeight=4px headCenterCorridorMax=16px projectedHeadFallback=0 nativeMatrixLayoutUnchanged=1 nativeHierarchyUnchanged=1" + Environment.NewLine +
                "[STAGE101][EXECUTABLE] " + System.Reflection.Assembly.GetExecutingAssembly().Location + Environment.NewLine +
                "[STAGE101][CWD] " + Environment.CurrentDirectory + Environment.NewLine +
                "[STAGE101][TARGET] processName=ros64 (expected executable ros64.exe; .exe is omitted for Windows process lookup)" + Environment.NewLine +
                "[STAGE101][CAPTURE] native skeleton vertices preserve finite offscreen projections for viewport clipping; non-finite projections rejected; native edges >8 world units and nodes >1.5 below native root are rejected as whole subtrees; 2px head markers supported; head geometry minimum screen height 4px; native matrix layout and hierarchy unchanged" + Environment.NewLine +
                $"[STAGE102][VEHICLE-RECON] enabled={(vehicleReconEnabled ? 1 : 0)} env=ROS64HACK_VEHICLE_RECON; diagnostic-only=1; renderer/aimbot/memory-writes unchanged" + Environment.NewLine;
            try
            {
                File.WriteAllText(_attachLogPath, attachHeader, new UTF8Encoding(false));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[STAGE101][ATTACH-LOG-OPEN-FAILED] {ex.GetType().Name}: {ex.Message}");
            }
            Console.Write(attachHeader);

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("  ROS64 Hack v1.0  |  BigWorld Engine  |  RE: 100%");
            Console.ResetColor();
            Console.WriteLine();

            var mem = new Mem();

            Console.WriteLine("  [*] Waiting for target process. Attach failures will be identified below.");
            int attempts = 0;
            string previousAttachStatus = null;
            while (!mem.Attach("ros64"))
            {
                attempts++;
                string status = mem.LastAttachStatus ?? "UNKNOWN_ATTACH_FAILURE";
                if (attempts == 1 || !string.Equals(status, previousAttachStatus, StringComparison.Ordinal) || attempts % 5 == 0)
                {
                    string detail = $"[STAGE101][ATTACH-WAIT] elapsed~{attempts}s attempt={attempts} result={status}";
                    WriteAttachDiagnostic(detail);
                    if (status.Contains("win32=5", StringComparison.OrdinalIgnoreCase))
                    {
                        WriteAttachDiagnostic("[STAGE101][ATTACH-HINT] Windows denied OpenProcess access (ERROR_ACCESS_DENIED). Check that ROS64Hack and the game are running at the same privilege level; do not change memory offsets for this error.");
                    }
                    else if (status.StartsWith("PROCESS_NOT_FOUND", StringComparison.Ordinal))
                    {
                        WriteAttachDiagnostic("[STAGE101][ATTACH-HINT] The exact process name was not found. Compare the similarProcesses list above with the game process name shown in Task Manager > Details.");
                    }
                }
                previousAttachStatus = status;
                Thread.Sleep(1000);
            }
            Console.WriteLine();
            WriteAttachDiagnostic($"[STAGE101][ATTACH-SUCCESS] elapsed~{attempts}s {mem.LastAttachStatus}");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"  [+] Attached! PID={mem.LastAttachPid}.");
            Console.ResetColor();
            Console.WriteLine($"  [+] Base address : 0x{mem.BaseAddress:X}");
            Console.WriteLine($"  [+] EM ptr VA    : 0x{mem.BaseAddress + Offsets.EM_STATIC_PTR:X}");
            Console.WriteLine($"  [+] Cam anchor VA: 0x{mem.BaseAddress + Offsets.CAM_ANCHOR_OFFSET:X}");
            Console.WriteLine();

            // Quick sanity — read the EM ptr right now
            try
            {
                long emTest = mem.Read<long>(mem.BaseAddress + Offsets.EM_STATIC_PTR, "PROGRAM.EM");
                Console.WriteLine($"  [+] EM ptr read  : 0x{emTest:X}  {(emTest != 0 ? "OK" : "WARNING: NULL")}");
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"  [!] EM read FAILED: {ex.Message}");
                Console.ResetColor();
            }

            // Quick sanity — camera chain
            try
            {
                long a = mem.Read<long>(mem.BaseAddress + Offsets.CAM_ANCHOR_OFFSET, "PROGRAM.CamAnchor");
                long b = a != 0 ? mem.Read<long>(a, "PROGRAM.CamChain1") : 0;
                long c = b != 0 ? mem.Read<long>(b, "PROGRAM.CamChain2") : 0;
                Console.WriteLine($"  [+] Cam chain    : 0x{a:X} -> 0x{b:X} -> 0x{c:X}  {(c != 0 ? "OK" : "WARNING: NULL")}");
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"  [!] Cam read FAILED: {ex.Message}");
                Console.ResetColor();
            }

            Console.WriteLine();
            Console.WriteLine("  [*] Launching overlay...");
            Console.WriteLine("  [*] INSERT = toggle menu  |  DELETE = exit");
            Console.WriteLine();

            try
            {
                var overlay = new HackOverlay(mem);
                Application.Run(overlay);
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\n[OVERLAY CRASH] {ex}");
                Console.ResetColor();
            }

            Console.WriteLine("\n  [*] Exited. Press any key...");
            Console.ReadKey();
        }
    }
}

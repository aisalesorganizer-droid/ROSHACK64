# ROS64Hack codebase audit report

Audit input: `ROS64Hack_STAGE82_Unified_Optimized.zip` (the supplied archive is left unchanged as rollback input). Audit date: 2026-10-12.

## 1. Scope and structure

The original archive contained 99 files: 37 C# source files, one SDK-style project file, and 61 `.txt` files. The original checksum manifest listed 98 files and all 98 checksums verified before changes. The archive had no exact duplicate-file groups. There are no solution, test-project, CI, application-config, or package-manifest files in the supplied tree.

The app is a Windows-only .NET 8 x64 executable. `Program.Main` waits for process `ros64`, attaches with `Mem`, performs initial memory/camera sanity reads, and starts the WinForms overlay. The overlay constructs camera/player/entity services, the runtime skeleton reader, and the Stage 78 recon object. The Stage 78 capture is started only when `ROS64HACK_STAGE78_RECON=1`; the object otherwise remains inactive. The runtime skeleton loop, drawing loop, and entity/camera read loop are separate timer-driven paths.

Core architecture is summarized in `README.md`. The current reader includes the native-bone path (`ModelSkeletal +0x660` to `SkeletalAnim`, bone count `+0x30`, hierarchy records at `+0x32`, matrix pointer `+0xCE0`, and reciprocal backlink `+0xCF0`) with root-space conversion. The native-bone notes are evidence for a static dump and native disassembly, not proof of successful live animation/rendering.

## 2. History/documentation consolidation

All 61 original `.txt` records were copied in full into named sections of `HISTORY.md`, with original relative paths, byte sizes, and original SHA-256 digests. This includes the original `SHA256SUMS.txt` snapshot and the three archived legacy C# source dumps (`STAGE52_EntityModelCorrelationDiagnostics_LEGACY.cs.txt`, `Stage68TargetRootHierarchyRecon.cs.txt`, and `Stage70ResolverReachabilityRecon.cs.txt`). The scattered `.txt` originals were then removed and a fresh `SHA256SUMS.txt` was generated for the cleaned package.

`README.md` replaces the obsolete build/readme document with current architecture, the native-bone source state, runtime switches, build instructions, and explicit verification limitations. Historical content remains available in `HISTORY.md`; no text record was omitted from consolidation.

## 3. Removed diagnostic modules — evidence inventory

The following 18 classes were each checked by exact symbol search across all other original C# files. Every class had zero incoming references from other C# files; no code path constructs them, calls them, or loads them reflectively. The project is an executable, not a library, and SDK default compile inclusion means these standalone files contributed unused diagnostic implementations to each build. Their notes and reports are retained in `HISTORY.md`, and the untouched input archive remains available for restoring a module if a later investigation explicitly needs it.

| Removed source module | Lines | Incoming references outside its own file | Rationale |
|---|---:|---:|---|
| `Core/Stage53TargetInternalTrace.cs` (`Stage53TargetInternalTrace`) | 901 | 0 | Standalone historical recon implementation; no C# incoming references. SHA-256 `e662b6c8755cea2746c1177835941e189962d7ccf293f2cee421acea01f486b2`. |
| `Core/Stage54BoneHierarchyTrace.cs` (`Stage54BoneHierarchyTrace`) | 950 | 0 | Standalone historical recon implementation; no C# incoming references. SHA-256 `7b653657ad63a66190eac2636830df82b94656f2e68873d4588fd1bec5e9cecc`. |
| `Core/Stage55TargetOwnedSkeletonRecon.cs` (`Stage55TargetOwnedSkeletonRecon`) | 901 | 0 | Standalone historical recon implementation; no C# incoming references. SHA-256 `01288451613b18b693f1b168598f08759c0a32c264cff9a7a9fbfef3a20a7203`. |
| `Core/Stage56TargetClosureSkeletonRecon.cs` (`Stage56TargetClosureSkeletonRecon`) | 1076 | 0 | Standalone historical recon implementation; no C# incoming references. SHA-256 `f98c7f102d51382f5f0925db79a9373ca1af24560fd4138f74034dc7791b321c`. |
| `Core/Stage57RootSpaceNodeCensus.cs` (`Stage57RootSpaceNodeCensus`) | 1127 | 0 | Standalone historical recon implementation; no C# incoming references. SHA-256 `9c992c4ef5f4d28600b8bef826065669c8c7d462217b227ad0849a6d2084df38`. |
| `Core/Stage59ExpandedClosureRawMotionRecon.cs` (`Stage59ExpandedClosureRawMotionRecon`) | 1277 | 0 | Standalone historical recon implementation; no C# incoming references. SHA-256 `ccccd409cb7df2599063c98c398314304df8500b285505e9cdd3dbf004b4b1cd`. |
| `Core/Stage60TargetModelInternalRecon.cs` (`Stage60TargetModelInternalRecon`) | 1216 | 0 | Standalone historical recon implementation; no C# incoming references. SHA-256 `265d5a29fd5987aa547a1573fe90f2813e901ada9b6abf770fea1ead42e8946a`. |
| `Core/Stage61TargetModelAssociationRecon.cs` (`Stage61TargetModelAssociationRecon`) | 929 | 0 | Standalone historical recon implementation; no C# incoming references. SHA-256 `2fb58d8bd6ba31a75a899aee10928c1e646ef24bb70bf67c23135cb7d69538f0`. |
| `Core/Stage62TargetOwnedPointerClosureRecon.cs` (`Stage62TargetOwnedPointerClosureRecon`) | 1087 | 0 | Standalone historical recon implementation; no C# incoming references. SHA-256 `3c95bc4663425de11db4f17c7605b1359ae6d64d8a857872e41b02f21c9a95f0`. |
| `Core/Stage63TargetRootHierarchyRecon.cs` (`Stage63TargetRootHierarchyRecon`) | 1413 | 0 | Standalone historical recon implementation; no C# incoming references. SHA-256 `7e10466753a0942a2ed7e136deb10456a6928341ec1268ad5fb7d5c98c985da9`. |
| `Core/Stage64ExpandedRootFanoutRecon.cs` (`Stage64ExpandedRootFanoutRecon`) | 1490 | 0 | Standalone historical recon implementation; no C# incoming references. SHA-256 `17ade8f27fccd0ee4bd6bf8886c533cd1259f509f179060a80e2a5259ac3e686`. |
| `Core/Stage66BgaPriorityClosureRecon.cs` (`Stage66BgaPriorityClosureRecon`) | 1615 | 0 | Standalone historical recon implementation; no C# incoming references. SHA-256 `d8b4da556d3b2d032e72c665962935b11d5346b7f159e0122dde87ea8f1c737a`. |
| `Core/Stage67VehicleTransitionRecon.cs` (`Stage67VehicleTransitionRecon`) | 1893 | 0 | Standalone historical recon implementation; no C# incoming references. SHA-256 `788532a5cfbdd50da165c4e376c2cbb104e2f2e52e45328355c85bc57872e880`. |
| `Core/Stage71TargetedRouteExtendedRootRecon.cs` (`Stage71TargetedRouteExtendedRootRecon`) | 2400 | 0 | Standalone historical recon implementation; no C# incoming references. SHA-256 `8ad6d01c3743ceb5f6e7a87a26c312a1e273175a17bd4edf8b44373d2b72a18f`. |
| `Core/Stage72ActiveEnemyRouteFieldRecon.cs` (`Stage72ActiveEnemyRouteFieldRecon`) | 458 | 0 | Standalone historical recon implementation; no C# incoming references. SHA-256 `658aa18b92bf8dcdec6785b3c11d6173b971cb3eb8a3a59208a0cf23d66e921c`. |
| `Core/Stage73CandidateModelRootHierarchyRecon.cs` (`Stage73CandidateModelRootHierarchyRecon`) | 412 | 0 | Standalone historical recon implementation; no C# incoming references. SHA-256 `62dd44d6bab5964996303b8d6688932a1bf3aa69f875b84b91777823c9499dcb`. |
| `Core/Stage74ActiveEnemyModelRootHierarchyRecon.cs` (`Stage74ActiveEnemyModelRootHierarchyRecon`) | 458 | 0 | Standalone historical recon implementation; no C# incoming references. SHA-256 `ee94f5f17fd23c92a19d1343e9d2d2b67b1357aea1d56fdaf15b4a426db6a37f`. |
| `Core/Stage76ComprehensiveSkeletonDiscoveryRecon.cs` (`Stage76ComprehensiveSkeletonDiscoveryRecon`) | 1370 | 0 | Standalone historical recon implementation; no C# incoming references. SHA-256 `c05d53e38adce0c48b0f7a66f0fb2e3c7cd81ff4a7d2afd1c810273575398f63`. |


## 4. Removed private dead members and stale switch

| File | Removed item | Concrete evidence | Behavior impact |
|---|---|---|---|
| `Engine/Camera.cs` | `_cameraXFocalBuffer` byte array | Exact field identifier occurred only at the declaration across the original C# source. | Removes an unused 4-byte allocation; no reads/writes/calls existed. |
| `Overlay/HackOverlay.cs` | `EvidenceDiagnosticsEnabled` property | Exact property identifier occurred only at its declaration; no call sites existed. | Removes unused environment-variable accessor. |
| `Program.cs` | Startup display of `ROS64HACK_DIAGNOSTICS` | The environment variable was only printed; the sole corresponding accessor property had no call sites. | Removes misleading no-op diagnostic status output; does not alter attach behavior. |

No other private methods were removed. The static no-use scan found no private methods with a single lexical occurrence. The audit did not attempt aggressive transformations of active runtime methods.

## 5. Verification results

| Check | Result | Notes |
|---|---|---|
| Original SHA256 manifest verification | PASS | 98/98 listed original files verified before modification. |
| Cross-file references for 18 retired stage classes | PASS | 0 incoming references per class in original C# files; active Stage 78 class was retained because it is conditionally wired from `HackOverlay`. |
| Historical text preservation | PASS by construction/static comparison | All 61 original `.txt` files were embedded as full named records in `HISTORY.md`; pre-cleanup checksums are preserved as one record. |
| Source edit scope | PASS | Three narrow edits only: remove one unused Camera buffer, one unused overlay property, and its no-op startup display. |
| Remaining package checksum manifest | PASS | Refreshed after edits to cover every remaining package file except the manifest itself. |
| ZIP CRC integrity | PASS | `unzip -t` reported no errors for the generated archive. The final archive was regenerated and checked again after this report was updated. |
| C# lexical delimiter scan | PASS | A C# lexer-based delimiter scan found no mismatches in the 19 retained source files; this is not compilation. |
| C# compilation | NOT VERIFIED | `dotnet`, `csc`, `mcs`, `mono`, and `msbuild` are unavailable in this environment. Build on Windows with .NET 8 before runtime use. |
| Live ROS Legacy behavior/performance | NOT VERIFIED | No live process is available in this environment. A comparable tracing-disabled capture and controlled runtime test remain necessary. |

## 6. Pre-execution inventory

The following inventory was generated from the original extracted archive before any source or documentation files were modified. It records the full proposed source-deletion list, all consolidated text records, their source hashes, and the member-level evidence.

# Pre-execution deletion and consolidation inventory

Generated before modifications from the original extracted archive. The supplied archive is kept unchanged as rollback input.

## C# diagnostic modules proposed for retirement

Criterion: public diagnostic class has zero exact-name occurrences in every other C# source file; no matching construction/call site is present outside its own file. Project is an executable with implicit SDK compile inclusion and no reflection-based loading pattern for these stage types. Their historical notes will be retained in `HISTORY.md`.

| File | Class | Lines | Bytes | SHA-256 | Incoming C# references |
|---|---|---:|---:|---|---:|
| `Core/Stage53TargetInternalTrace.cs` | `Stage53TargetInternalTrace` | 901 | 37778 | `e662b6c8755cea2746c1177835941e189962d7ccf293f2cee421acea01f486b2` | 0 |
| `Core/Stage54BoneHierarchyTrace.cs` | `Stage54BoneHierarchyTrace` | 950 | 40707 | `7b653657ad63a66190eac2636830df82b94656f2e68873d4588fd1bec5e9cecc` | 0 |
| `Core/Stage55TargetOwnedSkeletonRecon.cs` | `Stage55TargetOwnedSkeletonRecon` | 901 | 40453 | `01288451613b18b693f1b168598f08759c0a32c264cff9a7a9fbfef3a20a7203` | 0 |
| `Core/Stage56TargetClosureSkeletonRecon.cs` | `Stage56TargetClosureSkeletonRecon` | 1076 | 46457 | `f98c7f102d51382f5f0925db79a9373ca1af24560fd4138f74034dc7791b321c` | 0 |
| `Core/Stage57RootSpaceNodeCensus.cs` | `Stage57RootSpaceNodeCensus` | 1127 | 49671 | `9c992c4ef5f4d28600b8bef826065669c8c7d462217b227ad0849a6d2084df38` | 0 |
| `Core/Stage59ExpandedClosureRawMotionRecon.cs` | `Stage59ExpandedClosureRawMotionRecon` | 1277 | 58666 | `ccccd409cb7df2599063c98c398314304df8500b285505e9cdd3dbf004b4b1cd` | 0 |
| `Core/Stage60TargetModelInternalRecon.cs` | `Stage60TargetModelInternalRecon` | 1216 | 53392 | `265d5a29fd5987aa547a1573fe90f2813e901ada9b6abf770fea1ead42e8946a` | 0 |
| `Core/Stage61TargetModelAssociationRecon.cs` | `Stage61TargetModelAssociationRecon` | 929 | 43335 | `2fb58d8bd6ba31a75a899aee10928c1e646ef24bb70bf67c23135cb7d69538f0` | 0 |
| `Core/Stage62TargetOwnedPointerClosureRecon.cs` | `Stage62TargetOwnedPointerClosureRecon` | 1087 | 52867 | `3c95bc4663425de11db4f17c7605b1359ae6d64d8a857872e41b02f21c9a95f0` | 0 |
| `Core/Stage63TargetRootHierarchyRecon.cs` | `Stage63TargetRootHierarchyRecon` | 1413 | 74486 | `7e10466753a0942a2ed7e136deb10456a6928341ec1268ad5fb7d5c98c985da9` | 0 |
| `Core/Stage64ExpandedRootFanoutRecon.cs` | `Stage64ExpandedRootFanoutRecon` | 1490 | 78683 | `17ade8f27fccd0ee4bd6bf8886c533cd1259f509f179060a80e2a5259ac3e686` | 0 |
| `Core/Stage66BgaPriorityClosureRecon.cs` | `Stage66BgaPriorityClosureRecon` | 1615 | 86343 | `d8b4da556d3b2d032e72c665962935b11d5346b7f159e0122dde87ea8f1c737a` | 0 |
| `Core/Stage67VehicleTransitionRecon.cs` | `Stage67VehicleTransitionRecon` | 1893 | 103933 | `788532a5cfbdd50da165c4e376c2cbb104e2f2e52e45328355c85bc57872e880` | 0 |
| `Core/Stage71TargetedRouteExtendedRootRecon.cs` | `Stage71TargetedRouteExtendedRootRecon` | 2400 | 136519 | `8ad6d01c3743ceb5f6e7a87a26c312a1e273175a17bd4edf8b44373d2b72a18f` | 0 |
| `Core/Stage72ActiveEnemyRouteFieldRecon.cs` | `Stage72ActiveEnemyRouteFieldRecon` | 458 | 25288 | `658aa18b92bf8dcdec6785b3c11d6173b971cb3eb8a3a59208a0cf23d66e921c` | 0 |
| `Core/Stage73CandidateModelRootHierarchyRecon.cs` | `Stage73CandidateModelRootHierarchyRecon` | 412 | 26142 | `62dd44d6bab5964996303b8d6688932a1bf3aa69f875b84b91777823c9499dcb` | 0 |
| `Core/Stage74ActiveEnemyModelRootHierarchyRecon.cs` | `Stage74ActiveEnemyModelRootHierarchyRecon` | 458 | 29969 | `ee94f5f17fd23c92a19d1343e9d2d2b67b1357aea1d56fdaf15b4a426db6a37f` | 0 |
| `Core/Stage76ComprehensiveSkeletonDiscoveryRecon.cs` | `Stage76ComprehensiveSkeletonDiscoveryRecon` | 1370 | 91856 | `c05d53e38adce0c48b0f7a66f0fb2e3c7cd81ff4a7d2afd1c810273575398f63` | 0 |

## Text records proposed for consolidation

Every `.txt` record below will be copied in full into a named section of `HISTORY.md`. The incoming `SHA256SUMS.txt` is captured there as a historical manifest, then a fresh manifest is generated for the cleaned package. No text-record content will be discarded.

| Original file | Bytes | SHA-256 |
|---|---:|---|
| `NATIVE_BONE_CANDIDATE_NOTES.txt` | 2158 | `792d3b0b691c1746ddce8199cd06773a81134e0e8aa6878841030b7cad51a025` |
| `NATIVE_BONE_LAYOUT_AUDIT.txt` | 4785 | `d56cf844873bcc282340c4bb27a315e54c6a73056619a467d45e443cf9d0e358` |
| `README_BUILD.txt` | 2685 | `f285c663accb511a351588002dcf5b5121690ef637a63159b746d99b38fd3e8e` |
| `RECON_HISTORY/STAGE47_RUNTIME_CORRUPTION_REVIEW.txt` | 2798 | `486f26a1ff9a07b9f1e995627835c0eb8c59a5896b5937719babdf9226a2219f` |
| `RECON_HISTORY/STAGE49_RUNTIME_RECONCILIATION_NOTES.txt` | 1985 | `d8986874490dc12c4bd87af2ac795e0763b0676ef5c3e5a1719ba99cadaff11b` |
| `RECON_HISTORY/STAGE52_EntityModelCorrelationDiagnostics_LEGACY.cs.txt` | 74349 | `3e43ee25e9b2334cc26aeccb795ff532ba5cc2399dbd4c6d0ac4be58ad8a44b7` |
| `RECON_HISTORY/STAGE67_VALIDATION_REPORT.txt` | 2025 | `47d712a5aabae7b4a14777769e8e1097604f5084db4aaa589d34754b0769d51a` |
| `RECON_HISTORY/STAGE68_VALIDATION_REPORT.txt` | 1582 | `3d1e45ef477fdb7cb4a59b4a4d9d1ac29d73ed5d4e7a70fa2ff1869660ba7bd3` |
| `RECON_HISTORY/Stage68TargetRootHierarchyRecon.cs.txt` | 104487 | `f5fd19ed524a49a050c8159a343c5afffa2714832208eef10ff34c11ca76cdc7` |
| `RECON_HISTORY/Stage70ResolverReachabilityRecon.cs.txt` | 132065 | `3330a729da9fc724cf930705a30f5a60bffba16ab7a38fff4c1090e07dbc0f08` |
| `SHA256SUMS.txt` | 10028 | `1c6ea3883892d79c203059b6f38f27867ade8bd36a7aaa7c6a71f71ffb3061bf` |
| `STAGE52_CLEANUP_AUDIT.txt` | 2393 | `e1d63c72cd72b4d7dcbc4afefd63eca30e9ab88fd770dff1fd0f20d5ae3d98fb` |
| `STAGE52_CLEANUP_NOTES.txt` | 1764 | `ba879f0e7b881e779c79ee182c22fa8ce7952579b2cb4e7ff61b71757d455ac8` |
| `STAGE52_LOW_IMPACT_DIAGNOSTIC_NOTES.txt` | 2396 | `9c7d3a3668a1b5f8a8b99d5f91e01a6a53e473f46e1e640dcf6ac445a460807d` |
| `STAGE53_TARGET_INTERNAL_TRACE_NOTES.txt` | 1981 | `441aeebd1e058b0475a2eb25ff67b75710ef505587c8ba99dd5e4c55a8f5c6b4` |
| `STAGE54_BONE_HIERARCHY_RECON_NOTES.txt` | 2293 | `90f07e5b482da776a48fa3462671fa6816c8693e2f0937f77b9bf93357fff55c` |
| `STAGE55_TARGET_OWNED_SKELETON_RECON_NOTES.txt` | 1394 | `0d58c72112e40349eaa4e7d9d65cc1e2a5a0916f96d1174eea061b12310455f6` |
| `STAGE56_TARGET_CLOSURE_RECON_NOTES.txt` | 1880 | `b3fcd29e15589e058dacb8326d2c47553806d0bf4455d0837ec798cc7fdc1145` |
| `STAGE57_ROOT_SPACENODE_CENSUS_NOTES.txt` | 1829 | `95e8e8df980a7017ef9777079833f3db9ce234b6cc79032b2c35efcead717bb4` |
| `STAGE59_EXPANDED_CLOSURE_RAW_MOTION_RECON_NOTES.txt` | 3766 | `8196e816c774a3a9d554d4c1f1345435d15f3855e898993caa7e87f871d28209` |
| `STAGE60_TARGET_MODEL_INTERNAL_RECON_NOTES.txt` | 3799 | `24870c34718bb3d8afc75a3227b62a8973809f74539179a76a4a17f62b162d70` |
| `STAGE61_TARGET_MODEL_ASSOCIATION_RECON_NOTES.txt` | 4907 | `904e8eee34171d298f24ca45d5e2389b1a47b377b84dc5d82033c81467b9bded` |
| `STAGE61_VALIDATION_REPORT.txt` | 2295 | `8fc7d5b3b779dd90a3818f5763177af54aba5d8e6fc3eaf5f73038c3286cf10c` |
| `STAGE62_TARGET_OWNED_POINTER_CLOSURE_RECON_NOTES.txt` | 3618 | `1f51e22787804aa51740a2393a8f510cb5bcbef21427d184cf6cac444d928a5b` |
| `STAGE62_VALIDATION_REPORT.txt` | 2737 | `3e0761fa8849fd9e540bf9b4928ec952b83a86f9ceed5db034ef54ebdcd0e888` |
| `STAGE63_TARGET_ROOT_HIERARCHY_RECON_NOTES.txt` | 4161 | `e8e800f7153cf6f18e91d551f64e8212db71b9229e720af222c9083fd378c1dc` |
| `STAGE63_VALIDATION_REPORT.txt` | 1312 | `92db38bdb0746d0c0490e3856fa89ae22a82ca2324dae2706635653651a15f94` |
| `STAGE64_EXPANDED_ROOT_FANOUT_RECON_NOTES.txt` | 2945 | `c9ef4803612fd3cbafebe6831ef70b57968357c35476d04680afe0664bf0d3c2` |
| `STAGE64_VALIDATION_REPORT.txt` | 1681 | `80129776b5ebe88a36f7edca6f76e1ae69d9edc2b52d2b6c9bbdf19ccfe819f3` |
| `STAGE65_ACTIVE_TARGET_ROOT_RECON_NOTES.txt` | 2857 | `d5129d44aff233e4299ceccb5e0d4eb281db5619255e44d2d072824c68fd5962` |
| `STAGE65_VALIDATION_REPORT.txt` | 766 | `4984dd2d9deffb2e65a7ef09b220e4c6a367e901f0838842d50e0e2ccbf0b833` |
| `STAGE66_BGA_PRIORITY_CLOSURE_RECON_NOTES.txt` | 2619 | `f521bd8cc50f1be10dbd7f4db86be213c5b5e4a523d34a03110f97d9f67a3aac` |
| `STAGE66_VALIDATION_REPORT.txt` | 966 | `233b4a41fe579f5a776b3e968909328bb22dada159ffcd626190a5e5e71a6542` |
| `STAGE67_VEHICLE_TRANSITION_RECON_NOTES.txt` | 2443 | `37dbdb1a463e871f878e1ba2f8cecb000f313f5e825ea335b6999b2bb7f68efd` |
| `STAGE68_TARGET_ROOT_HIERARCHY_RECON_NOTES.txt` | 2361 | `c60b6554b2b934224e2275445d2a38ba83213a807316d625b6f1e34dea64b79f` |
| `STAGE69_VALIDATION_REPORT.txt` | 2157 | `2e0be9accb81643c325f5419f79f3048f7eeacd5be5ea74a3d4c5d9b0756fa47` |
| `STAGE70_RESOLVER_REACHABILITY_RECON_NOTES.txt` | 2667 | `ee42767b674a7b4ef34db3a784f3654e18304899b20dc7c7c63a7d26ab8da3ba` |
| `STAGE70_VALIDATION_REPORT.txt` | 2222 | `c424730149ccc6bd1bc1452241d55b99561e9c47d55672f016be4a703ec5ed77` |
| `STAGE71_TARGETED_ROUTE_EXTENDED_ROOT_RECON_NOTES.txt` | 2821 | `cb9aa780713c1befc4dcac41f034d9427ccaeda1c398cacfe27f841d11ae7259` |
| `STAGE71_VALIDATION_REPORT.txt` | 1923 | `c546195a53ea976e183774e6bb9c0231c1ae5b1b97501af85e441d0fa3004f85` |
| `STAGE72_ACTIVE_ENEMY_ROUTE_FIELD_RECON_NOTES.txt` | 2308 | `5a6a642cfca80729ebd114e8c81fdcd8fdf9006534ff17d745947d0094efaf5f` |
| `STAGE72_VALIDATION_REPORT.txt` | 1845 | `78466a2a4b010565a260346b501af6549cf46192ba75e3918ab39235c39b2c9e` |
| `STAGE73_CANDIDATE_MODEL_ROOT_HIERARCHY_RECON_NOTES.txt` | 2731 | `63b114cd3abe597e500a9aec03ca6a17f5c42947f5a1c15f02e0688503e8c657` |
| `STAGE73_VALIDATION_REPORT.txt` | 2203 | `b06cfa076f841571243c78b4b88851de0501f1f4b21cc1fdf861a903714f7e1a` |
| `STAGE74_ACTIVE_ENEMY_MODEL_ROOT_HIERARCHY_RECON_NOTES.txt` | 2460 | `93e2d28c6cfe2e0a80364773680f2e24b1d2b7ad5138005aa40ae9b1c92d21f7` |
| `STAGE74_VALIDATION_REPORT.txt` | 1604 | `43f84c3891e0596e54dac618c5a3228fdd15e1e1ca949e85d6ca1a4bb1d574e9` |
| `STAGE75_ACTIVE_ENEMY_MODEL_ROOT_NEIGHBORHOOD_RECON_NOTES.txt` | 6750 | `e4c9636e837af7b01519fcf6f8af1c01f219cc5dedf6ee2fd84e176f60680d30` |
| `STAGE75_VALIDATION_REPORT.txt` | 3865 | `3293f5552761fbe820ec3e1388904271faf7052205824ff237ee5a2704b4f0ca` |
| `STAGE76_VALIDATION_REPORT.txt` | 2265 | `2ee55e0136dbae2198d3334f9dfdea3ad609c10824d0a6d3fecafc07d8f715e7` |
| `STAGE77_CANDIDATE_MOTION_TRACKING_NOTES.txt` | 1559 | `39f16351f2c7f3be23e4b46804309aca3072e478ae2d5249cf4649dc24e2fe23` |
| `STAGE77_VALIDATION_REPORT.txt` | 2761 | `5522f9e6398201833ed55893b6439a7cf01eb6c3dc5738f7c7b341f358837df2` |
| `STAGE78_VALIDATION_NOTES.txt` | 2529 | `b5c6bb9ea949d3bcd6447200ecc9d12237999dcaad03d4725fb05a3fddc5bd4a` |
| `STAGE80_SKELETON_COVERAGE_NOTES.txt` | 6552 | `a1f16a28bbb334cae86685ecf598552a508e5018e0466bac5fe26a5921ef6f37` |
| `STAGE81_FAILED_RESOLVER_TRACE_NOTES.txt` | 5280 | `69b4abbfecd91283c6df2e92eb6d992ad56458375375733287df687e2588bb7c` |
| `STAGE81_VALIDATION_REPORT.txt` | 1016 | `8905ed4241d5e8f345e969fd48f76640e8991f67fc89084688eaf197729a9166` |
| `STAGE82_BOX_ALIGNMENT_CHANGELOG.txt` | 1507 | `18ec265a659be2b04d250c2e4d6a171ef42c5be293d1a25b2c04bf6f6a135b2c` |
| `STAGE82_DIAGNOSTICS_CHANGELOG.txt` | 1685 | `2645e92fd36a356bd1638e8265ba831f338c23bcf6cdcd991bcd94d2947b8738` |
| `STAGE82_GRAPH_POINTER_FILTER_NOTES.txt` | 3626 | `bd1f01e9b9608e08d3d131ae4b58f12acfbf5e4ba133e3e2075470ab00ca4998` |
| `STAGE82_RUNTIME_DIAGNOSTIC_REPORT.txt` | 8142 | `6df8fec849440419c28360968dfd416eead49ba9ae95baa90da24476ac8aa48a` |
| `STAGE82_UNIFIED_CHANGELOG.txt` | 2615 | `995b38067f25c4133522b73e536650b26a7cf0c96e2fd31fde2c1b5ffff92bfd` |
| `STAGE82_VALIDATION_REPORT.txt` | 1248 | `229b67047882b1037af9d65ba0d03446ee76fbcff5e2e0a40a6c1eca1cd2f493` |

## Confirmed member-level dead code proposed for removal

| File/line | Symbol | Evidence |
|---|---|---|
| `Engine/Camera.cs:71` | `_cameraXFocalBuffer` | Exact identifier occurs only at the field declaration in all C# source. |
| `Overlay/HackOverlay.cs:108` | `EvidenceDiagnosticsEnabled` | Exact identifier occurs only at the private property declaration; no call sites. |
| `Program.cs:68` | `ROS64HACK_DIAGNOSTICS` display expression | It only logs an environment variable that no active code consumes; the property that formerly appeared intended to read it has no callers. |

## Execution safeguards

- The original ZIP is unchanged and remains available as rollback source.
- Active files `Core/DynamicSkeletonReader.cs`, `Core/Mem.cs`, `Core/Offsets.cs`, `Core/RuntimeDiagnostics.cs`, `Core/SkeletonCoverageTrace.cs`, `Core/Stage78BoundedNodeHierarchyRecon.cs`, and all Engine/Features/Overlay/Program files are not candidates for deletion.
- No other private method or private member will be removed unless exact no-use evidence is found; static lexical analysis does not substitute for a C# compiler.
- The `.NET` build toolchain is absent in this environment; compilation will be marked unverified.


## 7. Stage 83 skeleton investigation — opt-in bone-index instrumentation

The latest visual report targets a skeleton containing many intersecting green lines. Source review confirms that `DynamicSkeletonReader.ApplyLatest` iterates each projected node with a valid parent and stores that parent-child line in `EntityData.DynamicSkeletonSegments`. It does not apply an anatomical edge whitelist. The checked-in `NATIVE_BONE_LAYOUT_AUDIT.txt` establishes the native record layout for one static capture, but it does not identify a verified head/neck index or a human-body-only edge set. The Stage 82 runtime review explicitly marks both mappings as unresolved.

To avoid inventing bone IDs, this package adds `ROS64HACK_SKELETON_BONE_INDEX_DIAGNOSTICS=1`. The original native `CachedNode.BoneIndex` is carried through the published pose and attached to each projected segment, and `ESP.DrawDynamicSkeleton` draws cyan joint-index labels only when that environment switch is set. With the switch unset, line selection, projection, and normal drawing are unchanged. The purpose is to capture a labeled standing/crouching target so the actual body edges can be mapped before the next surgical renderer change.

Changed files for this stage:
- `Core/DynamicSkeletonReader.cs`: carries native bone-table IDs to projected segments for diagnostics.
- `Features/ESP.cs`: adds opt-in cyan joint-index labels.
- `README.md`: documents the new switch.
- `SKELETON_BONE_INDEX_DIAGNOSTICS.md`: gives build/run/capture instructions and boundaries.
- `SHA256SUMS.txt`: regenerated for this package.

Status: source-level data-flow assertions, delimiter checks, checksum validation, and ZIP integrity checks were run. No .NET SDK/compiler or live game process is available here, so this build has not been compiled or executed in-game. The anatomical line whitelist remains intentionally unimplemented pending the labeled runtime evidence. This diagnostic stage is not reported as a visual fix.


## 8. Stage 84 — snapshot cadence and camera recovery correction

Source changes:
- `Overlay/HackOverlay.cs`: entity/camera read timer and draw invalidation timer now request an 8 ms cadence; skeleton memory sampling remains 33 ms. Added a runtime cadence marker to identify the source build.
- `Engine/Camera.cs`: after persistent invalid reads, retain the last coherent `CameraData` and camera pointer as continuity evidence, immediately retry selection using the cached candidate pool, and retry failed pool selection after 50 ms rather than 500 ms.

Evidence/rationale:
- The supplied runtime log repeatedly shows camera `ACTIVE-INVALID-PERSISTENT` followed by reselection; the previous branch explicitly cleared the continuity pointer/data and delayed another selection attempt by 500 ms.
- The old read and draw periods were both 16 ms (60 Hz target cadence). An 8 ms request can reduce poll staleness on high-refresh systems; actual WinForms/DWM presentation cadence is not guaranteed.
- This patch does not invent anatomical bone IDs. The clean skeleton requires a labeled runtime image from `ROS64HACK_SKELETON_BONE_INDEX_DIAGNOSTICS=1`.

Verification boundary:
- Source assertions, delimiter checks, SHA256 manifest, and ZIP integrity can be verified locally. The archive cannot be claimed compiled or live-tested without the .NET 8 toolchain and a running game process.


## Stage 87 — exclusion-only renderer correction

The active skeleton path restores the baseline validated parent-child traversal. It excludes the
entity-root connector and short terminal-only side branches at mid-body height; no joint-pair
bridging or replacement edge is generated. The separate top-centre tracer path in `ESP.Draw`
was confirmed as the source of the long screen-top green rays (`PenLine`, `Settings.EspLines`),
and that option is now off by default. The menu toggle remains available. Stage 87 has not been
compiled or visually tested in the live game in this environment.

## Stage 97 — focused in-viewport diagnostic target

The earlier Stage 83 description documents the original global opt-in bone labels. Current behavior is narrower: `DynamicSkeletonReader.TrySelectBoneDiagnosticTarget` accepts one `(Ptr, EntityId)` only when at least two-thirds of surviving segments (minimum six) have both endpoints in the client viewport and their vertical extent is at least 12 pixels. `ESP.DrawDynamicSkeleton` labels only that actor. The one-shot Stage 97 edge map includes the number and screen-space bounds of fully in-viewport segments. Native transforms, matrix stride, hierarchy traversal, and pruning rules are unchanged. This fixes the trace-selection failure observed in Stage 96, not the unresolved anatomical topology.


## Stage 98 — native root association gate

The Stage 97 trace captured 39/39 surviving segments inside the 1280x705 viewport, yet the traced pose did not produce head geometry. The native resolver still used a 64-unit root-to-entity gate in `TryAcceptRoot`, native hierarchy construction, cached-native validation, and native pose sampling. Stage 98 separates the native gate (8 units) from the legacy node-reader gate (64 units). The same tighter gate applies to the native hierarchy root bone position. Native transform/matrix offsets, `0x40` matrix stride, 4-byte hierarchy records, parent-child traversal, and exclusion logic are unchanged. Live rejection counts and the resulting same-frame box/skeleton alignment require Windows verification.

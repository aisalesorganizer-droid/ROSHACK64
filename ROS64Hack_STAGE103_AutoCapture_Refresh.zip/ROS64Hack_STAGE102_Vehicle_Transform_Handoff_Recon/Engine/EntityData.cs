using System;
using System.Drawing;
using ROS64Hack.Core;

namespace ROS64Hack.Engine
{
    /// <summary>
    /// One coherent entity snapshot produced by the read thread.
    /// Projection and skeleton data are stored in the same snapshot so paint/aim
    /// never need to touch game memory or recompute the same W2S values.
    /// </summary>
    public sealed class EntityData
    {
        public const int MaxDynamicSkeletonSegments = 96;

        public long Ptr;
        public ulong ObType;

        public bool IsLocalPlayer;
        public bool IsEnemy;

        public uint EntityId;
        public float X, Y, Z;
        public float Distance;

        public float FootSX, FootSY;
        public float HeadSX, HeadSY;
        public float NeckSX, NeckSY;
        public float ChestSX, ChestSY;

        // Box projection shares the same entity/camera snapshot as the other overlays.
        public float BoxFootSX, BoxFootSY;
        public float BoxHeadSX, BoxHeadSY;
        public bool BoxProjected;

        public bool FootProjected;
        public bool HeadProjected;
        public bool NeckProjected;
        public bool ChestProjected;
        public bool OnScreen;

        public readonly SkeletonSegment[] DynamicSkeletonSegments =
            new SkeletonSegment[MaxDynamicSkeletonSegments];
        public int DynamicSkeletonSegmentCount;
        public bool DynamicSkeletonValid;
        // Only one fully in-viewport actor receives cyan native bone-index labels.
        // This flag is presentation metadata; it does not affect skeleton validity.
        public bool DynamicBoneDiagnosticTarget;

        // Screen-space head geometry derived from the current sampled native pose.
        // The native bone matrices/transforms are never modified. The incoming neck edge
        // is rendered only up to the head circle boundary; edges inside the head cluster
        // are replaced by this outline.
        public bool DynamicHeadGeometryValid;
        public PointF DynamicHeadCenter;
        public float DynamicHeadRadius;
        public bool DynamicNeckSegmentValid;
        public PointF DynamicNeckStart;
        public PointF DynamicNeckEnd;
        // Exact world-space position of the validated native neck-base joint.
        public bool DynamicNeckWorldValid;
        public float DynamicNeckWorldX, DynamicNeckWorldY, DynamicNeckWorldZ;
        public int DynamicHeadTipBoneIndex = -1;
        public int DynamicHeadEntryBoneIndex = -1;
        public int DynamicNeckBaseBoneIndex = -1;

        public float Health = -1f;
        public float MaxHealth = 100f;
        public string Name = "Player";

        public float BoxWidth => MathF.Abs(FootSX - HeadSX) * 0.5f + 15f;
        public float BoxHeight => MathF.Abs(FootSY - HeadSY);
        public float BoxLeft => FootSX - BoxWidth;
        public float BoxTop => HeadSY;
    }
}

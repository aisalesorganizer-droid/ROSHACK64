using System;
using ROS64Hack.Core;

namespace ROS64Hack.Engine
{
    /// <summary>
    /// Resolves the local PlayerBattleGroundAvatar from EntityManager.controlledEntities.
    ///
    /// Proven RE layout:
    ///   EM + 0x10F8 -> controlledEntities container
    ///   container + 0x08 -> root node
    ///   root + 0x20 -> PlayerBattleGroundAvatar Python object
    ///
    /// IMPORTANT: container + 0x19 is NOT an empty-tree discriminator. The RE snapshot
    /// had a one-entry container whose +0x18 qword was 0x101, so the previous +0x19 test
    /// incorrectly rejected a valid player.
    /// </summary>
    public class PlayerReader
    {
        private const string PBGA_TYPE_NAME = "PlayerBattleGroundAvatar";
        private readonly Mem _mem;
        private long _cachedPlayerPtr;
        private long _nextPlayerResolveMs;
        private bool _localIdentityLogged;
        private readonly byte[] _playerCoreScratch = new byte[0x28];

        public PlayerReader(Mem mem) { _mem = mem; }

        public long GetPlayerPtr(long emPtr)
        {
            if (emPtr == 0) return 0;

            long container = _mem.ReadLong(emPtr + Offsets.EM_CONTROLLED_ENT);
            if (!IsPlausiblePtr(container)) return 0;

            long root = _mem.ReadLong(container + Offsets.NODE_PARENT);
            if (!IsPlausiblePtr(root) || root == container)
            {
                return 0;
            }

            // The controlledEntities node stores the Python PBGA at +0x20.
            long playerPtr = _mem.ReadLong(root + Offsets.CONTROLLED_NODE_VALUE);
            if (!IsPlausiblePtr(playerPtr)) return 0;

            ulong obType = (ulong)_mem.ReadLong(playerPtr + Offsets.ENT_OB_TYPE);
            if (!IsPlausiblePtr(unchecked((long)obType))) return 0;

            long typeNamePtr = _mem.ReadLong(unchecked((long)obType) + Offsets.PY_TYPE_NAME);
            if (!IsPlausiblePtr(typeNamePtr)) return 0;

            string typeName = _mem.ReadString(typeNamePtr, 96);
            if (!string.Equals(typeName, PBGA_TYPE_NAME, StringComparison.Ordinal))
                return 0;

            return playerPtr;
        }

        public EntityData ReadPlayer(long emPtr)
        {
            long nowMs = Environment.TickCount64;
            long ptr = _cachedPlayerPtr;

            if (!IsPlausiblePtr(ptr) || nowMs >= _nextPlayerResolveMs)
            {
                ptr = GetPlayerPtr(emPtr);
                if (!IsPlausiblePtr(ptr))
                {
                    _cachedPlayerPtr = 0;
                    _nextPlayerResolveMs = nowMs + 250;
                    return null;
                }

                _cachedPlayerPtr = ptr;
                _nextPlayerResolveMs = nowMs + 500;
            }

            // ob_type + entity id + XYZ are captured from the same snapshot block.
            if (!_mem.ReadBytes(ptr + Offsets.ENT_OB_TYPE, _playerCoreScratch, 0, _playerCoreScratch.Length))
            {
                _cachedPlayerPtr = 0;
                _nextPlayerResolveMs = 0;
                return null;
            }

            ulong obType = unchecked((ulong)BitConverter.ToInt64(_playerCoreScratch, 0));
            uint entityId = BitConverter.ToUInt32(
                _playerCoreScratch,
                (int)(Offsets.ENT_ENTITY_ID - Offsets.ENT_OB_TYPE));
            float x = BitConverter.ToSingle(_playerCoreScratch, (int)Offsets.ENT_X - (int)Offsets.ENT_OB_TYPE);
            float y = BitConverter.ToSingle(_playerCoreScratch, (int)Offsets.ENT_Y - (int)Offsets.ENT_OB_TYPE);
            float z = BitConverter.ToSingle(_playerCoreScratch, (int)Offsets.ENT_Z - (int)Offsets.ENT_OB_TYPE);

            if (!IsValidCoord(x) || !IsValidCoord(y) || !IsValidCoord(z))
                return null;

            var local = new EntityData
            {
                Ptr = ptr,
                ObType = obType,
                EntityId = entityId,
                IsLocalPlayer = true,
                IsEnemy = false,
                X = x,
                Y = y,
                Z = z,
                Name = "Local",
            };

            if (!_localIdentityLogged)
            {
                Console.WriteLine(
                    $"  [ENT][LOCAL-PBGA] ptr=0x{ptr:X} id=0x{entityId:X8} " +
                    $"xyz=({x:F3},{y:F3},{z:F3})");
                _localIdentityLogged = true;
            }

            return local;
        }

        private static bool IsPlausiblePtr(long ptr) =>
            ptr >= 0x10000 && ptr < 0x0000800000000000;

        private static bool IsValidCoord(float v) =>
            !float.IsNaN(v) && !float.IsInfinity(v) && v > -50000f && v < 50000f;
    }
}

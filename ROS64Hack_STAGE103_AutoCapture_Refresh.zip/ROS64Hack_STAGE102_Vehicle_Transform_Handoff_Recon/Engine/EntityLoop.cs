using System;
using System.Collections.Generic;
using ROS64Hack.Core;

namespace ROS64Hack.Engine
{
    /// <summary>
    /// Enumerates live enemy BattleGroundAvatar objects through the RE-proven path:
    ///
    ///   controlledEntities -> PlayerBattleGroundAvatar -> instance dict (+0x1B0)
    ///   -> "avatarInAoI" -> AOI dictionary -> BattleGroundAvatar values.
    ///
    /// The hot path is intentionally bounded and allocation-light:
    ///   - dictionary tables are read into one reusable scratch buffer;
    ///   - AOI values are deduplicated by object pointer and nonzero entity ID;
    ///   - each BGA core block is read in one RPM instead of five scalar RPMs;
    ///   - an already-resolved player pointer can be supplied by the overlay so the
    ///     controlledEntities traversal is not repeated in the same read cycle.
    /// </summary>
    public sealed class EntityLoop
    {
        private const string BGA_TYPE_NAME = "BattleGroundAvatar";
        private const string AOI_KEY_NAME = "avatarInAoI";

        private const int MAX_DICT_SLOTS = 0x10000;
        private const int MAX_KEY_STRING = 96;
        private const int VERIFIED_AOI_SLOT = 770;

        // ob_type + id/xyz are all inside this block: entity +0x08 .. +0x2F.
        private const int BGA_CORE_BLOCK_SIZE = 0x28;

        private readonly Mem _mem;
        private readonly PlayerReader _player;

        private readonly byte[] _dictScratch =
            new byte[MAX_DICT_SLOTS * (int)Offsets.PY_DICT_ENTRY_STRIDE];
        private readonly byte[] _bgaCoreScratch = new byte[BGA_CORE_BLOCK_SIZE];
        private readonly HashSet<long> _seenAoi = new HashSet<long>(128);
        private readonly Dictionary<uint, EntityData> _seenEntityIds = new Dictionary<uint, EntityData>(128);

        private long _lastPlayerPtr;
        private long _lastPlayerDictPtr;
        private long _lastPlayerDictTable;
        private int _lastPlayerDictMask = -1;
        private long _aoiDictPtr;

        private int _avatarKeySlot = -1;
        private long _avatarKeyObj;
        private long _nextAvatarScanMs;
        private long _nextAoiValidationMs;
        private int _calibrationLogCount;
        private int _dictReadFailureLogCount;
        private int _localAliasSkipLogs;
        private int _duplicateEntityIdLogCount;

        public ulong TypePbga { get; private set; }
        public ulong TypeBga { get; private set; }

        public EntityLoop(Mem mem, PlayerReader player)
        {
            _mem = mem ?? throw new ArgumentNullException(nameof(mem));
            _player = player ?? throw new ArgumentNullException(nameof(player));
            Console.WriteLine("  [ENT] Enumerating enemies from PBGA.avatarInAoI (verified live path)");
        }

        private static bool IsPlausiblePtr(long ptr) =>
            ptr >= 0x10000 && ptr < 0x0000800000000000L;

        private static bool IsValidCoord(float v) =>
            float.IsFinite(v) && v > -50000f && v < 50000f;

        private bool TryReadPlayerDict(long playerPtr, out long dictPtr)
        {
            dictPtr = 0;
            if (!IsPlausiblePtr(playerPtr)) return false;
            dictPtr = _mem.ReadLong(playerPtr + Offsets.PY_INSTANCE_DICT, "ENT.player_dict");
            return IsPlausiblePtr(dictPtr);
        }

        private bool TryReadDictHeader(long dictPtr, out int used, out int mask, out long table)
        {
            used = 0;
            mask = 0;
            table = 0;

            if (!IsPlausiblePtr(dictPtr)) return false;

            long usedRaw = _mem.ReadLong(dictPtr + Offsets.PY_DICT_USED, "ENT.dict_used");
            long maskRaw = _mem.ReadLong(dictPtr + Offsets.PY_DICT_MASK, "ENT.dict_mask");
            table = _mem.ReadLong(dictPtr + Offsets.PY_DICT_TABLE, "ENT.dict_table");

            if (usedRaw < 0 || usedRaw > MAX_DICT_SLOTS) return false;
            if (maskRaw < 0 || maskRaw > MAX_DICT_SLOTS - 1) return false;
            if (!IsPlausiblePtr(table)) return false;

            used = (int)usedRaw;
            mask = (int)maskRaw;
            int slots = mask + 1;
            return slots > 0 && slots <= MAX_DICT_SLOTS && used <= slots;
        }

        private static long ReadQword(byte[] buffer, int offset) =>
            BitConverter.ToInt64(buffer, offset);

        private bool TryReadDictTable(long table, int mask, out int bytesUsed)
        {
            bytesUsed = 0;
            int slots = mask + 1;
            long totalLong = (long)slots * Offsets.PY_DICT_ENTRY_STRIDE;
            if (totalLong <= 0 || totalLong > _dictScratch.Length)
                return false;

            int total = (int)totalLong;

            // Fast path: the Python dict table is a contiguous allocation. Prefer one
            // RPM; the page-split path remains only as a recovery fallback.
            if (_mem.ReadBytes(table, _dictScratch, 0, total))
            {
                bytesUsed = total;
                return true;
            }

            Array.Clear(_dictScratch, 0, total);
            bool anyChunkRead = false;
            int failedChunks = 0;
            int cursor = 0;

            while (cursor < total)
            {
                long address = table + cursor;
                int pageOffset = (int)(address & 0xFFF);
                int chunk = Math.Min(0x1000 - pageOffset, total - cursor);

                if (_mem.ReadBytes(address, _dictScratch, cursor, chunk))
                    anyChunkRead = true;
                else
                    failedChunks++;

                cursor += chunk;
            }

            if (!anyChunkRead)
                return false;

            if (failedChunks > 0 && _dictReadFailureLogCount < 8)
            {
                _dictReadFailureLogCount++;
                Console.WriteLine(
                    $"  [ENT][DICT-READ] partial table read: failedChunks={failedChunks} total=0x{total:X}");
            }

            bytesUsed = total;
            return true;
        }

        private string ReadPythonString(long keyObj)
        {
            if (!IsPlausiblePtr(keyObj)) return string.Empty;
            long chars = _mem.ReadLong(keyObj + Offsets.PY_STRING_VALUE, "ENT.key_chars");
            if (!IsPlausiblePtr(chars)) return string.Empty;
            return (_mem.ReadString(chars, MAX_KEY_STRING) ?? string.Empty).TrimEnd('\0');
        }

        private bool TryResolveAvatarKey(long playerPtr, long playerDictPtr)
        {
            bool sameDict = _lastPlayerPtr == playerPtr && _lastPlayerDictPtr == playerDictPtr;
            if (sameDict && _avatarKeySlot >= 0 && _aoiDictPtr != 0)
                return true;

            long nowMs = Environment.TickCount64;
            if (sameDict && nowMs < _nextAvatarScanMs)
                return false;

            if (!sameDict)
            {
                _avatarKeySlot = -1;
                _avatarKeyObj = 0;
                _aoiDictPtr = 0;
                _lastPlayerPtr = playerPtr;
                _lastPlayerDictPtr = playerDictPtr;
                _lastPlayerDictTable = 0;
                _lastPlayerDictMask = -1;
            }

            if (!TryReadDictHeader(playerDictPtr, out int used, out int mask, out long table))
            {
                _nextAvatarScanMs = nowMs + 500;
                return false;
            }

            if (_calibrationLogCount < 6)
            {
                Console.WriteLine(
                    $"  [ENT][DICT] player=0x{playerPtr:X} dict=0x{playerDictPtr:X} " +
                    $"used={used} mask=0x{mask:X} table=0x{table:X}");
            }

            _lastPlayerDictTable = table;
            _lastPlayerDictMask = mask;

            if (mask == 0x7FF)
            {
                long entry = table + (long)VERIFIED_AOI_SLOT * Offsets.PY_DICT_ENTRY_STRIDE;
                long rawHash = _mem.ReadLong(entry, "ENT.avatar_slot770_hash");
                long keyObj = _mem.ReadLong(entry + Offsets.PY_DICT_ENTRY_KEY, "ENT.avatar_slot770_key");
                long value = _mem.ReadLong(entry + Offsets.PY_DICT_ENTRY_VALUE, "ENT.avatar_slot770_value");

                if (_calibrationLogCount < 6)
                {
                    Console.WriteLine(
                        $"  [ENT][SLOT770] entry=0x{entry:X} hash=0x{rawHash:X} " +
                        $"key=0x{keyObj:X} value=0x{value:X}");
                }

                if (IsPlausiblePtr(value) &&
                    TryReadDictHeader(value, out int aoiUsed, out int aoiMask, out long aoiTable) &&
                    aoiMask == 0x7F)
                {
                    _avatarKeySlot = VERIFIED_AOI_SLOT;
                    _avatarKeyObj = keyObj;
                    _aoiDictPtr = value;
                    _nextAoiValidationMs = nowMs + 500;
                    Console.WriteLine(
                        $"  [ENT][AOI] avatarInAoI resolved by verified slot 770: " +
                        $"player=0x{playerPtr:X} playerDict=0x{playerDictPtr:X} " +
                        $"aoiDict=0x{value:X} aoiUsed={aoiUsed} aoiMask=0x{aoiMask:X} " +
                        $"aoiTable=0x{aoiTable:X}");
                    return true;
                }
            }

            if (!TryReadDictTable(table, mask, out int bytesUsed))
            {
                _nextAvatarScanMs = nowMs + 500;
                return false;
            }

            int slots = mask + 1;
            for (int slot = 0; slot < slots; slot++)
            {
                int off = checked((int)((long)slot * Offsets.PY_DICT_ENTRY_STRIDE));
                if (off + Offsets.PY_DICT_ENTRY_VALUE + 8 > bytesUsed) break;

                long keyObj = ReadQword(_dictScratch, off + (int)Offsets.PY_DICT_ENTRY_KEY);
                long value = ReadQword(_dictScratch, off + (int)Offsets.PY_DICT_ENTRY_VALUE);
                if (!IsPlausiblePtr(value)) continue;

                string key = ReadPythonString(keyObj);
                if (!string.Equals(key, AOI_KEY_NAME, StringComparison.Ordinal)) continue;

                _avatarKeySlot = slot;
                _avatarKeyObj = keyObj;
                _aoiDictPtr = value;
                _nextAoiValidationMs = nowMs + 500;
                Console.WriteLine(
                    $"  [ENT][AOI] avatarInAoI resolved by key scan: player=0x{playerPtr:X} " +
                    $"playerDict=0x{playerDictPtr:X} slot={slot} aoiDict=0x{value:X} used={used}");
                return true;
            }

            _nextAvatarScanMs = nowMs + 500;
            return false;
        }

        private bool TryRefreshAoiDict(long playerDictPtr)
        {
            if (_aoiDictPtr == 0 || _lastPlayerDictPtr != playerDictPtr || _avatarKeySlot < 0)
                return false;

            long nowMs = Environment.TickCount64;
            if (nowMs < _nextAoiValidationMs)
                return true;

            if (!TryReadDictHeader(playerDictPtr, out _, out int mask, out long table))
                return false;

            if (mask != _lastPlayerDictMask || table != _lastPlayerDictTable)
            {
                _avatarKeySlot = -1;
                _aoiDictPtr = 0;
                _nextAoiValidationMs = 0;
                return false;
            }

            long entry = table + (long)_avatarKeySlot * Offsets.PY_DICT_ENTRY_STRIDE;
            long value = _mem.ReadLong(entry + Offsets.PY_DICT_ENTRY_VALUE, "ENT.avatar_value_fast");

            if (IsPlausiblePtr(value))
            {
                _aoiDictPtr = value;
                _nextAoiValidationMs = nowMs + 500;
                return true;
            }

            _avatarKeySlot = -1;
            _aoiDictPtr = 0;
            _nextAoiValidationMs = 0;
            return false;
        }

        private bool TryReadBgaTypeFromCore(long rawType, out ulong typePtr)
        {
            typePtr = 0;
            if (!IsPlausiblePtr(rawType)) return false;

            typePtr = unchecked((ulong)rawType);
            if (TypeBga == typePtr) return true;

            long typeNamePtr = _mem.ReadLong(rawType + Offsets.PY_TYPE_NAME, "ENT.bga_type_name");
            if (!IsPlausiblePtr(typeNamePtr)) return false;

            string typeName = (_mem.ReadString(typeNamePtr, 96) ?? string.Empty).TrimEnd('\0');
            if (!string.Equals(typeName, BGA_TYPE_NAME, StringComparison.Ordinal)) return false;

            TypeBga = typePtr;
            return true;
        }

        private bool TryReadBga(
            long obj,
            long localPlayerPtr,
            uint localPlayerEntityId,
            out EntityData entity)
        {
            entity = null;
            if (!IsPlausiblePtr(obj) || obj == localPlayerPtr)
                return false;

            if (!_mem.ReadBytes(obj + Offsets.ENT_OB_TYPE, _bgaCoreScratch, 0, _bgaCoreScratch.Length))
                return false;

            ulong type = unchecked((ulong)ReadQword(_bgaCoreScratch, 0));
            if (!IsPlausiblePtr(unchecked((long)type)))
                return false;

            if (TypeBga == 0)
            {
                if (!TryReadBgaTypeFromCore(unchecked((long)type), out type))
                    return false;
            }
            else if (type != TypeBga)
            {
                if (!TryReadBgaTypeFromCore(unchecked((long)type), out ulong liveType) || liveType != type)
                    return false;
            }

            uint id = BitConverter.ToUInt32(_bgaCoreScratch, (int)Offsets.ENT_ENTITY_ID - (int)Offsets.ENT_OB_TYPE);
            if (localPlayerEntityId != 0 && id == localPlayerEntityId)
            {
                if (_localAliasSkipLogs < 8)
                {
                    _localAliasSkipLogs++;
                    Console.WriteLine(
                        $"  [ENT][LOCAL-ALIAS-SKIP] bga=0x{obj:X} id=0x{id:X8} " +
                        $"pbga=0x{localPlayerPtr:X} reason=ENTITY_ID_MATCH");
                }
                return false;
            }

            float x = BitConverter.ToSingle(_bgaCoreScratch, (int)Offsets.ENT_X - (int)Offsets.ENT_OB_TYPE);
            float y = BitConverter.ToSingle(_bgaCoreScratch, (int)Offsets.ENT_Y - (int)Offsets.ENT_OB_TYPE);
            float z = BitConverter.ToSingle(_bgaCoreScratch, (int)Offsets.ENT_Z - (int)Offsets.ENT_OB_TYPE);

            if (!IsValidCoord(x) || !IsValidCoord(y) || !IsValidCoord(z))
                return false;

            entity = new EntityData
            {
                Ptr = obj,
                ObType = type,
                IsLocalPlayer = false,
                IsEnemy = true,
                EntityId = id,
                X = x,
                Y = y,
                Z = z,
                Name = "Enemy",
            };
            return true;
        }

        private int EnumerateAoi(
            long aoiDictPtr,
            long localPlayerPtr,
            uint localPlayerEntityId,
            List<EntityData> output)
        {
            if (!TryReadDictHeader(aoiDictPtr, out _, out int mask, out long table))
                return 0;

            if (!TryReadDictTable(table, mask, out int bytesUsed))
                return 0;

            int slots = mask + 1;
            int count = 0;
            _seenAoi.Clear();
            _seenEntityIds.Clear();

            for (int slot = 0; slot < slots; slot++)
            {
                int off = checked((int)((long)slot * Offsets.PY_DICT_ENTRY_STRIDE));
                if (off + Offsets.PY_DICT_ENTRY_VALUE + 8 > bytesUsed) break;

                long valueObj = ReadQword(_dictScratch, off + (int)Offsets.PY_DICT_ENTRY_VALUE);
                if (!IsPlausiblePtr(valueObj) || !_seenAoi.Add(valueObj))
                    continue;

                if (!TryReadBga(valueObj, localPlayerPtr, localPlayerEntityId, out EntityData entity))
                    continue;

                // A Python dict may contain different object pointers that report the same
                // game EntityId. Only the first nonzero ID is retained in this snapshot, so
                // every downstream consumer (boxes, labels and skeleton sampling) sees one
                // actor entry. Log both handles and coordinates to expose which alias won.
                if (entity.EntityId != 0)
                {
                    if (_seenEntityIds.TryGetValue(entity.EntityId, out EntityData first))
                    {
                        if (_duplicateEntityIdLogCount < 32)
                        {
                            _duplicateEntityIdLogCount++;
                            Console.WriteLine(
                                $"  [ENT][DUPLICATE-ID-SKIP] id=0x{entity.EntityId:X8} " +
                                $"kept=0x{first.Ptr:X} keptXYZ=({first.X:F2},{first.Y:F2},{first.Z:F2}) " +
                                $"skipped=0x{entity.Ptr:X} skippedXYZ=({entity.X:F2},{entity.Y:F2},{entity.Z:F2}) " +
                                "reason=REPEATED_NONZERO_ENTITY_ID_IN_AOI_SNAPSHOT");
                        }
                        continue;
                    }

                    _seenEntityIds.Add(entity.EntityId, entity);
                }

                output.Add(entity);
                count++;
                RuntimeDiagnostics.EntityNode(
                    table + off,
                    entity.Ptr,
                    entity.ObType,
                    entity.X,
                    entity.Y,
                    entity.Z);
                RuntimeDiagnostics.EntityAccepted();
            }

            return count;
        }

        public bool Calibrate()
        {
            var snapshot = Enumerate();
            if (snapshot.Count > 0)
            {
                Console.WriteLine(
                    $"  [ENT][CAL] avatarInAoI active; BGA type=0x{TypeBga:X} enemies={snapshot.Count}");
                return true;
            }

            if (_calibrationLogCount++ < 3)
            {
                Console.WriteLine(_aoiDictPtr != 0
                    ? "  [ENT][CAL] AOI dictionary present, but no accepted live BGA values are currently present"
                    : "  [ENT][CAL] avatarInAoI has not yet been resolved");
            }
            return TypeBga != 0;
        }

        /// <summary>
        /// Enumerate using the already captured EM/player snapshot whenever available.
        /// Passing the local entity ID excludes its AOI BGA mirror even though that BGA
        /// and the controlled PBGA are different Python object pointers.
        /// </summary>
        public List<EntityData> Enumerate(
            long emPtr = 0,
            long knownPlayerPtr = 0,
            uint knownPlayerEntityId = 0)
        {
            var result = new List<EntityData>(64);

            if (!IsPlausiblePtr(emPtr))
            {
                emPtr = _mem.ReadLong(_mem.BaseAddress + Offsets.EM_STATIC_PTR, "ENT.EM");
            }
            if (!IsPlausiblePtr(emPtr)) return result;

            long playerPtr = IsPlausiblePtr(knownPlayerPtr)
                ? knownPlayerPtr
                : _player.GetPlayerPtr(emPtr);
            if (!IsPlausiblePtr(playerPtr)) return result;

            if (!TryReadPlayerDict(playerPtr, out long playerDictPtr))
                return result;

            if (!TryRefreshAoiDict(playerDictPtr) &&
                !TryResolveAvatarKey(playerPtr, playerDictPtr))
            {
                return result;
            }

            int enemies = EnumerateAoi(_aoiDictPtr, playerPtr, knownPlayerEntityId, result);

            if (enemies == 0 && _aoiDictPtr != 0)
                _nextAoiValidationMs = 0;

            if (_calibrationLogCount < 3 || (enemies > 0 && _calibrationLogCount == 3))
            {
                Console.WriteLine(
                    $"  [ENT][AOI] aoiDict=0x{_aoiDictPtr:X} enemies={enemies} bgaType=" +
                    (TypeBga == 0 ? "?" : $"0x{TypeBga:X}"));
                _calibrationLogCount++;
            }

            return result;
        }

        public void Invalidate()
        {
            _lastPlayerPtr = 0;
            _lastPlayerDictPtr = 0;
            _lastPlayerDictTable = 0;
            _lastPlayerDictMask = -1;
            _aoiDictPtr = 0;
            _avatarKeySlot = -1;
            _nextAvatarScanMs = 0;
            _nextAoiValidationMs = 0;
            _avatarKeyObj = 0;
            TypePbga = 0;
            TypeBga = 0;
            _calibrationLogCount = 0;
            _seenAoi.Clear();
            _seenEntityIds.Clear();
        }
    }
}

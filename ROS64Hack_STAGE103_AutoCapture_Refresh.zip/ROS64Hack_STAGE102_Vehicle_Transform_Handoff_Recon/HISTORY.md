# ROS64Hack development history and archived records

This file consolidates every text record shipped in the input archive, including the earlier checksum manifest and three historical diagnostic source snapshots. Each original record is included in full in a named section. The source code currently retained in the build is kept separately under `Core/`, `Engine/`, `Features/`, and `Overlay/`.

## Development arc (index)

| Stage / record group | Documented focus | Current significance |
|---|---|---|
| 87 | Parent-child edge exclusions and tracer separation | Current implementation uses existing hierarchy edges only; build/live test pending. |
| 47–49 | Runtime corruption review and reconciliation | Historical runtime observations and state reconciliation. |
| 52 | Cleanup audit, baseline diagnostics, and legacy entity/model correlation code | Documents earlier cleanup decisions and the initial focused diagnostic baseline. |
| 53–57 | Target-internal inspection, bone hierarchy, target-owned skeleton, closure traversal, and root/SpaceNode census | Earlier discovery experiments; their standalone diagnostic classes are no longer compiled into this package, but all supplied notes/reports and archived source snapshots are retained below. |
| 59–64 | Expanded closure/raw-motion analysis, target model internals/association, target-owned pointer closure, root hierarchy, and expanded fanout | Historical read-only discovery methods, including their recorded limits and findings. |
| 65–70 | Active-target root capture, BGA-prioritized closure, vehicle transition, target-root hierarchy, and resolver reachability | Captures limitations and failed assumptions; prior Stage 68 and Stage 70 source snapshots are archived below. |
| 71–74 | Targeted route/extended root, active-enemy route fields, candidate model/root hierarchy, and active-enemy root hierarchy | Intermediate diagnostic iterations; findings remain available without adding old scanners to the executable. |
| 75–78 | Root neighborhood, comprehensive discovery, candidate motion tracking, and bounded node hierarchy | Establishes the 0x620-byte SpaceNode boundary and treats broad graph evidence as exploratory rather than anatomical proof. Stage 78 remains as an opt-in diagnostic module. |
| 80–81 | Skeleton coverage and failed-resolver tracing | Documents opt-in visibility into missing-pose/rejection paths and the limits of runtime evidence. |
| 82 | Graph-pointer filtering, box alignment, unified low-overhead diagnostics, and runtime-log review | Current source retains the Stage 82 graph filter/box behavior and opt-in detailed tracing. Build/live performance verification is still required. |
| Native-bone audit | Static disassembly/minidump evidence for SkeletalAnim hierarchy and matrix layout | The current `DynamicSkeletonReader.cs` contains the native-bone path described by these records. The notes explicitly limit the evidence to the captured executable/static dump; they do not establish live rendering on another build. |

## Current-state cautions

- The current source reads the native `SkeletalAnim` hierarchy and 64-byte bone matrices. Some archived notes predate that source state, including the Stage 76 build note that describes the older graph-based discovery implementation. Those notes are preserved as historical evidence, not current build instructions.
- The legacy attach banner in `Program.cs` still contains a Stage 78 marker, while `HackOverlay` emits the Stage 82 overlay marker. Use the overlay marker to identify the active runtime source state.
- The former `ROS64HACK_DIAGNOSTICS` property had no call sites and no effect on runtime behavior; it was removed during this audit. The functional controls retained in source are `ROS64HACK_SKELETON_COVERAGE=1`, `ROS64HACK_SKELETON_DISCOVERY_TRACE=1`, and `ROS64HACK_STAGE78_RECON=1`.
- The supplied archive's original `SHA256SUMS.txt` is archived below as a historical record. The package root's refreshed `SHA256SUMS.txt` is the integrity manifest for this cleaned package.

## Complete original text records

The following sections preserve all original `.txt` file contents from the input archive. Original paths, byte sizes, and SHA-256 digests are recorded for traceability. Historical source dumps are fenced as C# text so they are not mistaken for active build files.


---

## Record 01 — `NATIVE_BONE_CANDIDATE_NOTES.txt`

<sub>Original size: 2158 bytes · Original SHA-256: `792d3b0b691c1746ddce8199cd06773a81134e0e8aa6878841030b7cad51a025`</sub>

ROS64Hack native-bone skeleton candidate — audited layout

Scope
- Source-only candidate; original source directory remains unchanged.
- Runtime path: ModelSkeletal +0x660 -> SkeletalAnim.
- Validates exact SkeletalAnim vtable (image RVA 0x1C1AC30) and reciprocal ModelSkeletal
  backlink at +0xCF0.
- Native disassembly confirms SkeletalAnim +0xCE0 is a pointer to a 64-byte matrix table:
  getter at VA 0x1403DF430 returns the field; VA 0x1403DF111 indexes it by index * 0x40.
- Native accessors at VAs 0x1403DFC70, 0x1403DFD20, and 0x1403DF850 read +0x33 next-sibling,
  +0x32 parent, and +0x34 first-child from 4-byte hierarchy records.
- Reads the 16-bit bone count at +0x30 and the inline hierarchy at +0x32.
- Uses root SpaceNode +0x148 world matrix to convert model-space bone-matrix translations to
  world coordinates. Does not use SpaceNode +0x318/+0x618 as bone links.
- Expands render segment capacity to 96 so the 68-bone target's possible 67 links are not
  truncated by the prior 32-segment capacity.
- Fixes the graph resolver's expansion-cap frontier check for direct exact ModelSkeletal
  pointers that appear later in an in-bounds qword scan.

Verification summary
- Target BGA 0x5561FC18 -> ModelSkeletal 0x35D87E18 -> root 0x16F57750.
- SkeletalAnim 0x59419A50; count 68; table 0x373AA1B0; hierarchy root index 62.
- 68/68 bones reached; one root; zero hierarchy-link errors.
- Captured world-space extent: approximately 7.47 x 21.09 x 7.73 units.
- Pool-wide: 69 reciprocal model/anim/root structures; 33 of 34 entries with count 6..96 pass
  the candidate's static structural/affine/plausibility checks; one non-affine matrix table is
  rejected. This is not proof that every accepted model is a player body in all states.
- See NATIVE_BONE_LAYOUT_AUDIT.txt for machine-code evidence and exact test scope.

Limitations
- NOT compiled: this environment has no .NET SDK/C# compiler/MSBuild.
- NOT live-tested: the input is one static minidump, which cannot demonstrate live animation,
  frame timing, or rendered output. Build using .NET 8 on Windows and verify in a controlled
  session before replacing any existing runtime binary.


---

## Record 02 — `NATIVE_BONE_LAYOUT_AUDIT.txt`

<sub>Original size: 4785 bytes · Original SHA-256: `d56cf844873bcc282340c4bb27a315e54c6a73056619a467d45e443cf9d0e358`</sub>

ROS64HACK NATIVE BONE LAYOUT AUDIT
================================
Audit date: 2026-10-11
Scope: static analysis of the supplied ros64.exe minidump and source candidate.

RESULT
------
The outstanding +0xCE0 field uncertainty is resolved for the captured executable:
SkeletalAnim +0xCE0 is a pointer to 64-byte matrix entries. This is supported by native
machine-code access patterns, not only by plausible values found in memory. The dump also
supports the native 4-byte bone hierarchy record at +0x32 with fields parent (+0), next
sibling (+1), first child (+2), reserved (+3). The candidate reads translations from each
matrix's row 3 and applies the owning root SpaceNode world matrix to convert model-space
points to world space.

NATIVE EXECUTABLE EVIDENCE
--------------------------
1. VA 0x1403DF430:
   mov rax, [rcx+0x660]
   mov rax, [rax+0xCE0]
   ret
   This getter follows ModelSkeletal +0x660 to SkeletalAnim and returns the +0xCE0 field.

2. VA 0x1403DF111:
   mov rax, [rdi+0xCE0]
   mov rcx, rsi
   shl rcx, 6
   loads four 16-byte chunks from [rax+rcx] through [rax+rcx+0x30].
   The stride is 0x40 bytes (64 bytes) for a 4x4 matrix.

3. Native accessors at VA 0x1403DFC70, 0x1403DFD20, and 0x1403DF850 read bytes
   at SkeletalAnim +0x33, +0x32, and +0x34 respectively, indexing records with index*4.
   These correspond to next-sibling, parent, and first-child fields. The record pitch is 4.

DUMP-BACKED TARGET
------------------
Target BGA:                  0x5561FC18
BGA graph bridge (+0xB8):    0x599341E0
ModelSkeletal:               0x35D87E18
Model root (+0x38):          0x16F57750
SkeletalAnim (+0x660):        0x59419A50
Matrix table (+0xCE0):       0x373AA1B0
Reciprocal model backlink:   SkeletalAnim +0xCF0 -> 0x35D87E18
Bone count (+0x30):          68
Hierarchy root bone index:  62

The hierarchy traversal reaches 68/68 bones with one root and no parent mismatch,
invalid child/sibling link, or cycle. The root bone's matrix translation is (0,0,0).
The root SpaceNode matrix translation equals the captured BGA/entity position:
(11739.7744, -987.1624, -979.7286). Applying that root matrix to the 68 model-space bone
matrix translations gives an approximate world-space extent of 7.47 x 21.09 x 7.73 units.
All 67 parent-child links in this target have length <= 12.69 units; none is rejected by
the candidate's 160-unit renderer segment limit.

POOL-WIDE STATIC CHECK
----------------------
The captured model pool contains 69 exact ModelSkeletal-vtable objects. All 69 point to
an exact SkeletalAnim-vtable object and have the expected reciprocal model backlink and a
reciprocal root SpaceNode. Bone counts include small non-body/attachment structures; the
candidate therefore requires 6..96 bones and validates the hierarchy/matrix content before
accepting a model. Of the 34 pool entries with bone count 6..96, 33 pass the matrix affine,
hierarchy-connectivity, and root-local plausibility checks; one 13-entry table contains
non-affine values and is rejected. This is static-capture evidence, not a claim that all
accepted models are anatomical player skeletons in every live state.

SOURCE/PATCH AUDIT
------------------
Modified source files:
- Core/DynamicSkeletonReader.cs
  Replaces SpaceNode-qword hierarchy discovery with the native SkeletalAnim bone table;
  validates exact ModelSkeletal/SkeletalAnim/root ownership; converts model-space matrix
  translations through the root world matrix; adds a native-bone sampling path; and fixes
  the resolver's object-cap frontier scan so a direct exact-type candidate beyond the
  expansion budget is not silently skipped.
- Engine/EntityData.cs
  Raises DynamicSkeletonSegments capacity from 32 to 96. The target has 68 bones and up to
  67 parent-child segments, so a 32-segment array would truncate the output.

Static checks run:
- Dump reconstruction/integrity had previously been verified; the exact dump-backed values
  above were re-read during this audit.
- Native-bone candidate validation script: PASS.
- C# delimiter/lexical checks: PASS.
- Unified patch apply-check against the unmodified source: PASS.
- Package archive integrity and SHA256SUMS manifest: checked during packaging.

LIMITATIONS / NOT CLAIMED
-------------------------
- No .NET SDK, C# compiler, or MSBuild is installed in this environment. The package has NOT
  been compiled here.
- No live ROS64 process was available for runtime rendering/animation verification.
- The dump is one static capture. It verifies captured structure and pose geometry, not that
  the same addresses/layouts remain identical in another game build or live session.
- The candidate must be built on Windows with .NET 8 before runtime use. Compare the build
  output and live diagnostic logs before treating rendering as confirmed.


---

## Record 03 — `README_BUILD.txt`

<sub>Original size: 2685 bytes · Original SHA-256: `f285c663accb511a351588002dcf5b5121690ef637a63159b746d99b38fd3e8e`</sub>

ROS64HACK — STAGE 76 COMPREHENSIVE SKELETON DISCOVERY
====================================================

Purpose
-------
This diagnostic revisits the earlier model/root/node evidence without making a runtime skeleton-renderer change. It compares direct model, model array, bounded BGA+0x0B8 graph, graph bridge fields +0x830..+0x870, historical BGA+0x048/+0x128/+0x130 routes, and bounded pointer closures from current live enemy BGA objects in one capture.

It retains every exact ModelSkeletal-vtable candidate from every route even when the reciprocal root is far from the entity object that exposed it. The live resolver radius is 128 world units; wider-distance exact model/root candidates are still logged and inspected where ownership permits. Reciprocal model/root ownership is still required before crawling a model's root. Each valid root is mapped to the nearest current enemy snapshot. The node census examines every qword-aligned field from +0x000 through +0xFF8 in each discovered exact-type node and records owner, coordinates, graph edge and root-relative movement; owner and distance do not suppress edge discovery.

Build and run
-------------
On Windows with the .NET 8 SDK:
  dotnet build -c Release

Run while ROS Legacy is active. The diagnostic starts with the overlay, as in the previous package. It writes:
  STAGE76_COMPREHENSIVE_SKELETON_DISCOVERY.txt
  STAGE76_ATTACH_DIAGNOSTIC.txt

The capture uses up to 64 current overlay enemy snapshots for 24 rounds, approximately 18 seconds of planned sampling plus initial delay. Keep the same target visible if possible and vary its movement naturally (standing, running, jumping, crouching). The capture is read-only: no process-wide scan, process memory writes, renderer change, or DynamicSkeletonReader change.

Interpretation
--------------
Exact vtables and reciprocal model/root ownership identify real structures, not necessarily anatomical joints. A connected node graph and root-relative movement are candidate evidence; they do not by themselves prove that the graph is a human bone hierarchy. Use the final source/model/node-motion records to decide which candidate is strong enough for integration.

Build status
------------
This environment does not have the .NET SDK available, so compilation has not been verified here. Build on Windows before running capture. The runtime DynamicSkeletonReader is intended to remain byte-identical to the Stage 75 runtime-equivalent baseline.


Stage 78: bounded node hierarchy reconciliation. Diagnostic reads are capped at the established 0x620-byte SpaceNode extent; runtime skeleton reader and renderer remain unchanged. See STAGE78_VALIDATION_NOTES.txt.


---

## Record 04 — `RECON_HISTORY/STAGE47_RUNTIME_CORRUPTION_REVIEW.txt`

<sub>Original size: 2798 bytes · Original SHA-256: `486f26a1ff9a07b9f1e995627835c0eb8c59a5896b5937719babdf9226a2219f`</sub>

STAGE 47 RUNTIME CORRUPTION REVIEW
=================================

Evidence observed in the supplied screenshot/log
------------------------------------------------
1. The visible thin green line is the existing ESP tracer in Features/ESP.cs; its
   draw origin is (screen center X, Y=0). It is not a skeleton bone.
2. The camera selected in this run reports YFocal=9.98595, XFocal=0, rounded
   position (0,-1,0), and player/camera distance about 1117 metres. The camera
   diagnostic itself reports scanYFocalOK=0. This is not sufficient evidence to
   use the pointer for a cold-start projection.
3. The resolver's one-time global scan covered about 2.05 GB and took 6.76 s.
   avgSkelSampleMs=7052.00 was measured from before TryResolve, so it included
   discovery/scan latency rather than measuring only the pose sample.
4. The hierarchy trace accepted only two same-vtable target-local nodes. It also
   followed +0x618/+0x318 fields that yielded implausible values, including a
   pointer into the process image. No articulated skeleton was verified.
5. The local controlled object is a PlayerBattleGroundAvatar (PBGA) while AOI
   enumeration returns BattleGroundAvatar (BGA) values. The previous code excluded
   the local object only by pointer equality, then marked every remaining AOI BGA
   as an enemy. The updated code reads the local entity ID and excludes an AOI BGA
   with the same ID, with explicit log output when the alias is found.

Targeted changes in this package
--------------------------------
- Prevent a cold-start camera candidate outside the observed [1.8,6.0] focal range
  from being selected. Known-good active camera pointers remain eligible to change
  focal value during ADS/zoom, preserving the existing continuity design.
- If no cold-start candidate passes the gate, withhold projection rather than draw
  incorrect ESP lines with an unconfirmed camera. This may leave ESP blank if the
  scanner is not finding the true render camera; the log states that explicitly.
- Capture the local PBGA entity ID and suppress its BGA alias from the AOI enemy list.
- Restrict hierarchy expansion to the observed +0x18 child link on recognized
  SpaceNode-vtable objects. +0x318/+0x618 remain logged as evidence, not followed.
- Measure avgSkelSampleMs around SamplePose only; the outer skeleton-loop metric
  continues to include model discovery/global scan latency.
- Preserve the six-node articulation threshold. No bones are claimed as verified.

Validation limitations
----------------------
A Windows .NET 8 build and live game run could not be executed in this environment
because the dotnet SDK is not installed. Static structure checks and ZIP integrity
checks are included in the delivery process, but they do not substitute for the
Windows runtime test.


---

## Record 05 — `RECON_HISTORY/STAGE49_RUNTIME_RECONCILIATION_NOTES.txt`

<sub>Original size: 1985 bytes · Original SHA-256: `d8986874490dc12c4bd87af2ac795e0763b0676ef5c3e5a1719ba99cadaff11b`</sub>

STAGE 49 — Stage 48 runtime reconciliation

Confirmed Stage 48 findings:
- The runtime accepted only 1 hierarchy node for each of the 3 focused entities.
- Each root's +0x18 field pointed to 0x68FE9FB0, whose vtable was 0x141C409E0 rather than the required SpaceNode vtable.
- One traced root's +0x318 field held 0x1594CA50. Stage 48 did not probe that candidate's vtable because +0x318 had been disabled.
- Camera discovery admitted four image-backed candidates at 0x141C0580, 0x141C1270, 0x141C23B0, and 0x141C34F0. It also reselected among several pointer candidates after camera-invalid events.
- At a failed-resolution retry interval of 500 ms, per-entity candidate checks produced repeated MODEL_INVALID / HIERARCHY_TOO_SMALL rejects and RPM failure rates near 126/s.

Changes:
1. Camera scanning now limits candidates to committed writable MEM_PRIVATE regions. The +0x320 aspect value is treated as a prefilter, not proof of camera identity.
2. A single invalid active-camera read no longer immediately discards the previous coherent camera snapshot. Three transient invalid reads are tolerated before reselection is permitted.
3. Hierarchy traversal probes all historically observed node fields (+0x18, +0x318, +0x618), but enqueues a child only after a readable object shows an exact matching vtable and a target-local transform. Arbitrary wrapper pointers are not recursively followed.
4. Failed entity/model/root resolution is retried every 5 seconds rather than every 500 ms, including invalid root/BGA pointers.
5. The six-node articulated skeleton threshold and repeated relative-motion verification are unchanged.
6. Added Stage 49 build marker to distinguish this source version from the Stage 47 executable.

Validation notes:
- This package contains the full source project and no launcher.
- Static source, XML, ZIP, and SHA-256 checks are expected to be run after packaging.
- A Windows .NET build and in-game runtime test were not performed in this environment.


---

## Record 06 — `RECON_HISTORY/STAGE52_EntityModelCorrelationDiagnostics_LEGACY.cs.txt`

<sub>Original size: 74349 bytes · Original SHA-256: `3e43ee25e9b2334cc26aeccb795ff532ba5cc2399dbd4c6d0ac4be58ad8a44b7`</sub>

```csharp
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using ROS64Hack.Engine;

namespace ROS64Hack.Core
{
    /// <summary>
    /// Focused one-run skeleton hierarchy evidence capture.
    ///
    /// The diagnostic locks one live enemy BGA and captures, in a single window:
    ///   BGA raw state + Python instance-dict keys
    ///   BGA +0xB8 -> native owner graph
    ///   bounded readable-private pointer graph from the target-owned root
    ///   exact ModelSkeletal <-> SpaceNode RTTI/vtable validation
    ///   SpaceNode local transform (+0x48) and world matrix (+0x148)
    ///   target BGA semantic fields (ID/XYZ/model span)
    ///   per-sample motion/change data for recovered strict SpaceNodes
    ///   one focused MODEL+0x3E8 hierarchy branch with a hard object budget
    ///
    /// No ESP/W2S/aim path is used. No process writes are performed.
    /// </summary>
    public sealed class EntityModelCorrelationDiagnostics : IDisposable
    {
        // Proven image-relative vtables.
        private const long MODEL_SKELETAL_VTABLE_RVA = 0x001C1ACE0;
        private const long SPACE_NODE_VTABLE_RVA     = 0x001C137C8;
        private const long MODEL_VTABLE_RVA          = 0x001C173E0;

        // Proven BGA/native Entity fields.
        private const int ENTITY_ID             = 0x18;
        private const int ENTITY_X              = 0x1C;
        private const int ENTITY_Y              = 0x20;
        private const int ENTITY_Z              = 0x24;
        private const int ENTITY_SPACE_ID       = 0x54;
        private const int ENTITY_VEHICLE_RAW    = 0x58;
        private const int ENTITY_SELF_CONTROL   = 0x5E;
        private const int ENTITY_MODEL          = 0xD8;
        private const int ENTITY_MODELS_BEGIN   = 0xE0;
        private const int ENTITY_MODELS_END     = 0xE8;
        private const int BGA_NATIVE_GRAPH      = 0xB8;

        // Proven ModelSkeletal / SpaceNode relation.
        private const int MODEL_SPACE_NODE      = 0x38;
        private const int SPACE_MODEL           = 0x40;
        private const int SPACE_TRANSFORM       = 0x48;
        private const int SPACE_WORLD_MATRIX    = 0x148;
        private const int MATRIX_BYTES          = 0x40;

        // Python 2.7 fields already established in the codebase.
        private const int PY_DICT               = 0x1B0;
        private const int PY_DICT_USED          = 0x18;
        private const int PY_DICT_MASK          = 0x20;
        private const int PY_DICT_TABLE         = 0x28;
        private const int PY_DICT_KEY           = 0x08;
        private const int PY_DICT_VALUE         = 0x10;
        private const int PY_DICT_STRIDE        = 0x18;
        private const int PY_TYPE               = 0x08;
        private const int PY_TYPE_NAME          = 0x18;
        private const int PY_STRING_VALUE       = 0x20;

        // Capture window: one Stage 52 run, long enough to include the controlled motion sequence.
        private const int CAPTURE_SAMPLES       = 120;
        private const int CAPTURE_INTERVAL_MS   = 500;
        private const int INITIAL_DELAY_MS       = 1500;

        // Per-object forensic dump range. 0x800 captures more than prior branch stages.
        private const int OBJECT_DUMP_BYTES     = 0x1000;
        private const int BGA_DUMP_BYTES        = 0x1000;
        private const int OWNER_DUMP_BYTES      = 0x1000;

        // Pointer graph depth guard only; no object/node count cap.
        private const int MAX_GRAPH_DEPTH       = 8;
        private const int READ_CHUNK_BYTES      = 0x1000;
        private const float MAX_WORLD_COORD     = 50000f;
        // Focused hierarchy edges proven in earlier captures from the target-local root.
        // These are probe edges, not bone-name assumptions.
        // Stage 52 focused path: the only model-side branch under test is MODEL+0x3E8.
        // Child exploration follows the three previously observed edge slots, with +0x618
        // examined first.
        private static readonly int[] FOCUSED_NODE_EDGES = { 0x618, 0x318, 0x018 };
        private static readonly int[] FOCUSED_MODEL_REF_OFFSETS = { 0x3E8 };
        private static readonly int[] FOCUSED_MATRIX_CANDIDATE_OFFSETS =
        {
            0x048, 0x060, 0x0E0, 0x120, 0x130, 0x13C, 0x148,
            0x154, 0x360, 0x3E0, 0x420, 0x43C, 0x660, 0x6E0,
            0x720, 0x72C, 0x730, 0x738, 0x73C, 0x740, 0x74C, 0x754
        };
        private const int FOCUSED_MAX_ROOT_MODELS = 1;
        private const int FOCUSED_MAX_NODE_DEPTH = 6;
        private const int FOCUSED_MAX_OBJECTS = 16;
        private const int FOCUSED_MAX_NODE_TRACKS = 15;
        private const int TARGET_GRAPH_MAX_OBJECTS = 4096;
        private const int TARGET_GRAPH_MAX_DEPTH = 6;
        private const int TARGET_GRAPH_OBJECT_BYTES = 0x800;
        private const int TARGET_GRAPH_MAX_PER_DEPTH = 1024;
        private static readonly int[] EVIDENCE_OWNER_BRANCH_OFFSETS =
        { 0x020, 0x0D0, 0x120, 0x128, 0x1F0, 0x288, 0x4E0, 0x500, 0x600, 0x608 };


        private readonly Mem _mem;
        private readonly object _sync = new();
        private System.Threading.Timer _timer;
        private int _started;
        private int _disposed;
        private int _sampleIndex;
        private bool _captureComplete;
        // System.Threading.Timer may invoke callbacks concurrently when a previous
        // capture pass takes longer than the timer period. The original Stage 27
        // capture proved this happened: the same target was locked three times
        // while _sampleIndex was still zero. Serialize the entire diagnostic tick
        // so only one initial scan/graph walk can execute at a time.
        private int _timerBusy;

        private readonly Dictionary<uint, EntityData> _latestBgaById = new();

        private long _lockedBgaPtr;
        private uint _lockedBgaId;
        private float _lastTargetX;
        private float _lastTargetY;
        private float _lastTargetZ;
        private bool _haveTargetMotion;
        private float _targetTotalStep;

        private long _lockedB8;
        private long _lockedOwner;
        private long _firstB8;
        private long _firstOwner;
        private int _b8Changes;
        private int _ownerChanges;
        private int _targetLostSamples;

        private readonly HashSet<long> _visitedObjects = new();
        private readonly Dictionary<long, GraphObjectRecord> _graphObjects = new();
        private readonly Dictionary<long, ModelRecord> _models = new();
        private readonly Dictionary<long, SpaceNodeRecord> _spaceNodes = new();
        private List<MemoryRegion> _readablePrivateRegions = new();
        private bool _initialGraphBuilt;

        private string _captureFile;
        private StreamWriter _fileWriter;
        private readonly object _fileSync = new();

        private readonly List<long> _focusedRootModels = new();
        private readonly Dictionary<long, FocusedNodeTrack> _focusedNodeTracks = new();
        private readonly Dictionary<string, MatrixCandidateTrack> _focusedMatrixCandidates = new(StringComparer.Ordinal);
        private readonly HashSet<long> _focusedProbedObjects = new();


        [StructLayout(LayoutKind.Sequential)]
        private struct MEMORY_BASIC_INFORMATION64
        {
            public IntPtr BaseAddress;
            public IntPtr AllocationBase;
            public uint AllocationProtect;
            public uint __alignment1;
            public UIntPtr RegionSize;
            public uint State;
            public uint Protect;
            public uint Type;
            public uint __alignment2;
        }

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern UIntPtr VirtualQueryEx(
            IntPtr hProcess,
            IntPtr lpAddress,
            out MEMORY_BASIC_INFORMATION64 lpBuffer,
            UIntPtr dwLength);

        private struct MemoryRegion
        {
            public long Base;
            public long Size;
        }

        private sealed class GraphObjectRecord
        {
            public long Ptr;
            public int Depth;
            public string Path;
            public long Vtable;
            public byte[] LastBytes;
            public int DiscoverySample;
        }

        private sealed class ModelRecord
        {
            public long Ptr;
            public long Vtable;
            public long SpaceNode;
            public long SpaceVtable;
            public bool Reciprocal;
            public int FirstSample;
            public string FirstPath;
            public int SeenSamples;
            public byte[] LastDump;
        }

        private sealed class SpaceNodeRecord
        {
            public long Ptr;
            public long Vtable;
            public long Model;
            public bool Reciprocal;
            public int FirstSample;
            public string FirstPath;
            public int SeenSamples;
            public int ValidTransformSamples;
            public int ValidWorldMatrixSamples;
            public float MinTargetDist = float.MaxValue;
            public float FirstTargetDist = float.NaN;
            public float LastNodeStep;
            public float TotalNodeStep;
            public float TotalRelativeStep;
            public float MaxNodeStep;
            public float MaxRelativeStep;
            public float LastX;
            public float LastY;
            public float LastZ;
            public bool HasLast;
            public byte[] LastTransform;
            public byte[] LastWorldMatrix;
            public float ClosestX;
            public float ClosestY;
            public float ClosestZ;
            public int ClosestSample;
            public float MinWorldM3Dist = float.MaxValue;
            public float TotalWorldM3Step;
            public float TotalWorldM3RelativeStep;
            public float MaxWorldM3Step;
            public float MaxWorldM3RelativeStep;
            public float LastWorldM3X;
            public float LastWorldM3Y;
            public float LastWorldM3Z;
            public float ClosestWorldM3X;
            public float ClosestWorldM3Y;
            public float ClosestWorldM3Z;
            public int ClosestWorldM3Sample;
            public bool HasLastWorldM3;
        }

        private sealed class FocusedNodeTrack
        {
            public long Ptr;
            public long Vtable;
            public long OwnerModel;
            public int FirstSample;
            public string FirstPath;
            public int SeenSamples;
            public float MinTargetDist = float.MaxValue;
            public float FirstTargetDist = float.NaN;
            public float LastX;
            public float LastY;
            public float LastZ;
            public bool HasLast;
            public float TotalStep;
            public float TotalRelativeStep;
            public float MaxStep;
            public float MaxRelativeStep;
        }

        private sealed class MatrixCandidateTrack
        {
            public long Ptr;
            public int Offset;
            public int FirstSample;
            public string FirstPath;
            public int ValidSamples;
            public float MinTargetDist = float.MaxValue;
            public float FirstTargetDist = float.NaN;
            public float LastX;
            public float LastY;
            public float LastZ;
            public bool HasLast;
            public float TotalStep;
            public float TotalRelativeStep;
            public float MaxStep;
            public float MaxRelativeStep;
            public float ClosestX;
            public float ClosestY;
            public float ClosestZ;
            public int ClosestSample;
            public byte[] LastBytes;
        }



        public EntityModelCorrelationDiagnostics(Mem mem)
        {
            _mem = mem ?? throw new ArgumentNullException(nameof(mem));
        }

        public void Start()
        {
            if (Interlocked.Exchange(ref _started, 1) != 0)
                return;

            try
            {
                _captureFile = Path.Combine(Environment.CurrentDirectory, "STAGE52_MODEL_GRAPH_CAPTURE.txt");
                _fileWriter = new StreamWriter(_captureFile, false, new UTF8Encoding(false))
                {
                    AutoFlush = true,
                    NewLine = Environment.NewLine,
                };
            }
            catch (Exception ex)
            {
                _captureFile = null;
                _fileWriter = null;
                Console.WriteLine($"[BONE-DIAG][STAGE 52][FILE-OPEN-FAILED] {ex.GetType().Name}: {ex.Message}");
            }

            if (_fileWriter != null)
                RuntimeDiagnostics.SetSkeletonEvidenceSink(WriteResolverEvidence);

            WriteLine("");
            WriteLine("============================================================");
            WriteLine("[BONE-DIAG][STAGE 52] TARGET-OWNED SKELETON + RESOLVER CANDIDATE CAPTURE");
            WriteLine("============================================================");
            WriteLine($"  samples={CAPTURE_SAMPLES} intervalMs={CAPTURE_INTERVAL_MS} totalSeconds={CAPTURE_SAMPLES * CAPTURE_INTERVAL_MS / 1000.0:F1}");
            WriteLine($"  ModelSkeletal vtable RVA = 0x{MODEL_SKELETAL_VTABLE_RVA:X}");
            WriteLine($"  SpaceNode vtable RVA     = 0x{SPACE_NODE_VTABLE_RVA:X}");
            WriteLine($"  Model vtable RVA         = 0x{MODEL_VTABLE_RVA:X}");
            WriteLine("  graph = BGA+0xB8 -> bounded target-owned readable-private graph");
            WriteLine("  graph policy = target-owned BFS depth<=6; no global private-memory class scan");
            WriteLine("  focused policy = one strict root model, MODEL+0x3E8, three node edges, max 16 focused objects (15 node tracks plus the model)");
            WriteLine("  strict node data = +0x48 transform +0x148 world matrix; focused matrix candidates are evidence only");
            WriteLine("  Diagnostic capture performs remote-memory reads only; it does not write to the game process.");
            WriteLine("  The regular overlay still runs during capture; keep Aimbot inactive while collecting evidence.");
            WriteLine("  Resolver tracing: first two distinct eligible enemy entities, first discovery attempt only.");
            WriteLine("  Each traced B8 walk records object pointer/depth/parent/slot/vtable; direct and array candidates include rejection reasons.");
            WriteLine($"  captureFile = {_captureFile ?? "console-only; no graph file could be opened"}");
            WriteLine("------------------------------------------------------------");
            WriteLine("  CONTROLLED MOTION SEQUENCE (same enemy for all 120 samples / 60 seconds)");
            WriteLine("  Keep the same enemy visible and do not switch targets during capture.");
            WriteLine("  If available, observe standing, crouching, prone/lying, jumping, and turning/leaning.");
            WriteLine("  Include a short stationary period, then movement, then another stationary period.");
            WriteLine("  Vehicle enter/drive/exit is optional; do it only if it can be completed without losing the target.");
            WriteLine("============================================================");

            WriteLine("[BONE-DIAG][STAGE 52][CAPTURE-STARTED] graph timer armed; waiting for first eligible enemy snapshot.");
            _timer = new System.Threading.Timer(TimerTick, null, INITIAL_DELAY_MS, CAPTURE_INTERVAL_MS);
        }

        public void ObserveSnapshot(EntityData local, List<EntityData> enemies, long emPtr)
        {
            if (Volatile.Read(ref _disposed) != 0 || Volatile.Read(ref _started) == 0)
                return;

            lock (_sync)
            {
                _latestBgaById.Clear();
                if (enemies != null)
                {
                    foreach (EntityData e in enemies)
                    {
                        if (e == null || e.Ptr == 0) continue;
                        uint observedId = ReadSnapshotEntityId(e);
                        if (observedId != 0 && !_latestBgaById.ContainsKey(observedId))
                            _latestBgaById[observedId] = CloneEntity(e);
                    }
                }
            }
        }

        private static uint ReadSnapshotEntityId(EntityData e)
        {
            return e?.EntityId ?? 0u;
        }

        private static EntityData CloneEntity(EntityData e)
        {
            return new EntityData
            {
                Ptr = e.Ptr,
                ObType = e.ObType,
                IsLocalPlayer = e.IsLocalPlayer,
                IsEnemy = e.IsEnemy,
                EntityId = e.EntityId,
                X = e.X,
                Y = e.Y,
                Z = e.Z,
                Distance = e.Distance,
                Name = e.Name,
                Health = e.Health,
                MaxHealth = e.MaxHealth,
            };
        }

        private void TimerTick(object state)
        {
            if (Volatile.Read(ref _disposed) != 0 || _captureComplete)
                return;

            // Prevent System.Threading.Timer re-entry. A complete graph/global
            // scan is intentionally expensive and can exceed the 500 ms period.
            // Without this guard, multiple callbacks start from the same
            // _sampleIndex==0 state and duplicate the entire capture concurrently.
            if (Interlocked.Exchange(ref _timerBusy, 1) != 0)
                return;

            try
            {
                if (_sampleIndex == 0)
                {
                    if (!LockTarget())
                    {
                        WriteLine("[FINAL][WAIT] No enemy BGA available yet; target lock will retry.");
                        FlushFile();
                        return;
                    }

                    RefreshReadableRegions();
                    DumpInitialTargetState();
                    BuildTargetOwnedGraph();
                    InitializeFocusedHierarchyProbe();
                    _initialGraphBuilt = true;
                }
                else if (_lockedBgaPtr == 0 || !IsPlausiblePtr(_lockedBgaPtr))
                {
                    WriteLine("[FINAL][TARGET] locked pointer invalidated.");
                }

                CaptureSample();
                FlushFile();

                _sampleIndex++;
                if (_sampleIndex >= CAPTURE_SAMPLES)
                {
                    EmitFinalSummary();
                    _captureComplete = true;
                    RuntimeDiagnostics.SetSkeletonEvidenceSink(null);
                    FlushFile();
                    _fileWriter?.Dispose();
                    _fileWriter = null;
                    _timer?.Change(Timeout.Infinite, Timeout.Infinite);
                }
            }
            catch (Exception ex)
            {
                WriteLine($"[FINAL][EXCEPTION] {ex.GetType().Name}: {ex.Message}");
                FlushFile();
            }
            finally
            {
                Volatile.Write(ref _timerBusy, 0);
            }
        }

        private bool LockTarget()
        {
            lock (_sync)
            {
                EntityData target = _latestBgaById.Values.FirstOrDefault(e => e != null && e.IsEnemy && e.Ptr != 0);
                if (target == null)
                    return false;

                _lockedBgaPtr = target.Ptr;
                _lockedBgaId = ReadSnapshotEntityId(target);
                _lastTargetX = target.X;
                _lastTargetY = target.Y;
                _lastTargetZ = target.Z;
                _haveTargetMotion = false;
                _firstB8 = 0;
                _firstOwner = 0;
                _lockedB8 = 0;
                _lockedOwner = 0;
                _b8Changes = 0;
                _ownerChanges = 0;

                WriteLine($"[FINAL][TARGET-LOCK] bga=0x{_lockedBgaPtr:X} id=0x{_lockedBgaId:X8} xyz=({_lastTargetX:F3},{_lastTargetY:F3},{_lastTargetZ:F3})");
                return true;
            }
        }

        private void RefreshReadableRegions()
        {
            _readablePrivateRegions = EnumerateReadablePrivateRegions().ToList();
            WriteLine($"[FINAL][MEMORY] readablePrivateRegions={_readablePrivateRegions.Count}");
        }

        private void DumpInitialTargetState()
        {
            WriteLine("");
            WriteLine("[FINAL][BGA-RAW] target +0x000..+0x7FF qwords -> full dump is written to capture file");
            DumpObjectToFile(_lockedBgaPtr, BGA_DUMP_BYTES, "BGA");

            long b8 = ReadQuiet(_lockedBgaPtr + BGA_NATIVE_GRAPH);
            WriteLine($"[FINAL][BGA+0xB8] value=0x{b8:X}");

            if (IsPlausiblePtr(b8))
            {
                WriteLine("[FINAL][B8-RAW] +0x000..+0x7FF qwords -> full dump is written to capture file");
                DumpObjectToFile(b8, OWNER_DUMP_BYTES, "B8");
                if (!_graphObjects.ContainsKey(b8))
                {
                    _graphObjects[b8] = new GraphObjectRecord
                    {
                        Ptr = b8, Depth = -1, Path = "target+0x0B8", Vtable = ReadQuiet(b8),
                        LastBytes = ReadObjectBytes(b8, OWNER_DUMP_BYTES), DiscoverySample = _sampleIndex
                    };
                }
                byte[] b8Raw = ReadObjectBytes(b8, OWNER_DUMP_BYTES);
                if (b8Raw != null)
                {
                    for (int q = 0; q < b8Raw.Length / 8; q++)
                    {
                        long value = BitConverter.ToInt64(b8Raw, q * 8);
                        if (value == _lockedBgaPtr || value == _lockedBgaId)
                            WriteLine($"[FINAL][B8-BACKREF] b8=0x{b8:X} +0x{q * 8:X3} -> 0x{value:X}");
                    }
                }
            }

            DumpPythonDict(_lockedBgaPtr, "TARGET-BGA");
            DumpRawSemanticFields(_lockedBgaPtr, "TARGET-BGA");
        }

        private void DumpRawSemanticFields(long obj, string label)
        {
            if (!IsPlausiblePtr(obj)) return;
            long spaceId = ReadQuiet(obj + ENTITY_SPACE_ID);
            long vehicleRaw = ReadQuiet(obj + ENTITY_VEHICLE_RAW);
            byte self = ReadByteQuiet(obj + ENTITY_SELF_CONTROL);
            long model = ReadQuiet(obj + ENTITY_MODEL);
            long begin = ReadQuiet(obj + ENTITY_MODELS_BEGIN);
            long end = ReadQuiet(obj + ENTITY_MODELS_END);
            WriteLine($"[FINAL][RAW-FIELDS] {label} +0x54(spaceId)=0x{spaceId:X} +0x58(raw)=0x{vehicleRaw:X} +0x5E(selfByte)=0x{self:X2} +0xD8(model)=0x{model:X} +0xE0(begin)=0x{begin:X} +0xE8(end)=0x{end:X}");
        }

        private void DumpPythonDict(long obj, string label)
        {
            if (!IsPlausiblePtr(obj)) return;

            long dict = ReadQuiet(obj + PY_DICT);
            if (!IsPlausiblePtr(dict))
            {
                WriteLine($"[FINAL][PY-DICT] {label} unavailable dict=0x{dict:X}");
                return;
            }

            long usedRaw = ReadQuiet(dict + PY_DICT_USED);
            long maskRaw = ReadQuiet(dict + PY_DICT_MASK);
            long table = ReadQuiet(dict + PY_DICT_TABLE);
            if (usedRaw < 0 || usedRaw > 0x20000 || maskRaw < 0 || maskRaw > 0x1FFFF || !IsPlausiblePtr(table))
            {
                WriteLine($"[FINAL][PY-DICT] {label} invalid header dict=0x{dict:X} used={usedRaw} mask=0x{maskRaw:X} table=0x{table:X}");
                return;
            }

            int slots = (int)maskRaw + 1;
            WriteFileLine($"[FINAL][PY-DICT] {label} dict=0x{dict:X} used={usedRaw} mask=0x{maskRaw:X} slots={slots} table=0x{table:X}");
            for (int i = 0; i < slots; i++)
            {
                long entry = table + (long)i * PY_DICT_STRIDE;
                long key = ReadQuiet(entry + PY_DICT_KEY);
                long value = ReadQuiet(entry + PY_DICT_VALUE);
                if (!IsPlausiblePtr(key) && !IsPlausiblePtr(value)) continue;

                string keyText = ReadPythonStringQuiet(key);
                string typeName = ReadPythonTypeName(value);
                if (string.IsNullOrEmpty(keyText) && !IsPlausiblePtr(value)) continue;

                WriteFileLine($"  [PY-KV] slot={i} key='{keyText}' keyObj=0x{key:X} value=0x{value:X} valueType={typeName}");
            }
        }

        private void InitializeFocusedHierarchyProbe()
        {
            _focusedRootModels.Clear();
            _focusedNodeTracks.Clear();
            _focusedMatrixCandidates.Clear();
            _focusedProbedObjects.Clear();

            if (_models.Count == 0)
            {
                WriteLine("[FINAL][FOCUSED] no strict ModelSkeletal objects discovered in target-owned graph");
                return;
            }

            var ranked = _models.Values
                .Where(m => m.Reciprocal && IsPlausiblePtr(m.SpaceNode))
                .Select(m =>
                {
                    float transformDist = ReadTranslationDistance(m.SpaceNode + SPACE_TRANSFORM, _lastTargetX, _lastTargetY, _lastTargetZ);
                    float worldDist = ReadMatrixTranslationDistance(m.SpaceNode + SPACE_WORLD_MATRIX, _lastTargetX, _lastTargetY, _lastTargetZ);
                    float rank = MathF.Min(transformDist, worldDist);
                    return new { Model = m, Rank = rank, TransformDist = transformDist, WorldDist = worldDist };
                })
                .OrderBy(x => x.Rank)
                .ThenBy(x => x.Model.FirstSample)
                .Take(FOCUSED_MAX_ROOT_MODELS)
                .ToList();

            foreach (var item in ranked)
            {
                _focusedRootModels.Add(item.Model.Ptr);
                WriteLine($"[FINAL][FOCUSED-ROOT] rank={_focusedRootModels.Count - 1} model=0x{item.Model.Ptr:X} node=0x{item.Model.SpaceNode:X} transformDist={item.TransformDist:F3} worldDist={item.WorldDist:F3} path={item.Model.FirstPath}");
                ProbeFocusedModel(item.Model.Ptr, item.Model.FirstPath);
                if (IsPlausiblePtr(item.Model.SpaceNode))
                    ProbeFocusedNode(item.Model.SpaceNode, "ROOT-NODE", 0, new HashSet<long>());
            }

            WriteLine($"[FINAL][FOCUSED-INIT] roots={_focusedRootModels.Count} nodes={_focusedNodeTracks.Count} matrixCandidates={_focusedMatrixCandidates.Count}");
        }

        private void ProbeFocusedModel(long modelPtr, string rootPath)
        {
            if (!IsPlausiblePtr(modelPtr) ||
                (_focusedProbedObjects.Count >= FOCUSED_MAX_OBJECTS && !_focusedProbedObjects.Contains(modelPtr)) ||
                !_focusedProbedObjects.Add(modelPtr))
                return;

            WriteLine($"[FINAL][FOCUSED-MODEL] ptr=0x{modelPtr:X} vtable=0x{ReadQuiet(modelPtr):X} path={rootPath}");
            DumpObjectToFile(modelPtr, OBJECT_DUMP_BYTES, "FOCUSED-MODEL");

            foreach (int offset in FOCUSED_MODEL_REF_OFFSETS)
            {
                long ptr = ReadQuiet(modelPtr + offset);
                if (!IsFollowableGraphPointer(ptr))
                    continue;

                string cls = ClassifyVtable(ptr);
                WriteFileLine($"[FINAL][FOCUSED-MODEL-REF] model=0x{modelPtr:X} +0x{offset:X3} -> 0x{ptr:X} class={cls}");

                if (offset == 0x3E8)
                    ProbeFocusedNode(ptr, $"MODEL=0x{modelPtr:X} +0x3E8", 1, new HashSet<long>());
                else if (ClassifyVtable(ptr) == "ModelSkeletal")
                    ProbeFocusedModel(ptr, $"MODEL=0x{modelPtr:X} +0x{offset:X3}");
            }
        }

        private void ProbeFocusedNode(long ptr, string path, int depth, HashSet<long> branchVisited)
        {
            if (!IsFollowableGraphPointer(ptr) || depth > FOCUSED_MAX_NODE_DEPTH)
                return;
            if (!branchVisited.Add(ptr))
                return;

            bool firstProbe = _focusedProbedObjects.Add(ptr);
            if (!firstProbe && !_focusedNodeTracks.ContainsKey(ptr))
                return;
            if (firstProbe && !_focusedNodeTracks.ContainsKey(ptr) &&
                _focusedNodeTracks.Count >= FOCUSED_MAX_NODE_TRACKS)
            {
                _focusedProbedObjects.Remove(ptr);
                return;
            }
            if (_focusedProbedObjects.Count > FOCUSED_MAX_OBJECTS)
            {
                _focusedProbedObjects.Remove(ptr);
                if (!firstProbe) _focusedProbedObjects.Add(ptr);
                return;
            }

            long vtable = ReadQuiet(ptr);
            long owner = ReadQuiet(ptr + SPACE_MODEL);
            bool exactSpace = vtable == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA;
            long ownerVtable = ReadQuiet(owner);
            string cls = ClassifyVtable(ptr);

            if (!_focusedNodeTracks.TryGetValue(ptr, out FocusedNodeTrack track))
            {
                track = new FocusedNodeTrack
                {
                    Ptr = ptr,
                    Vtable = vtable,
                    OwnerModel = owner,
                    FirstSample = _sampleIndex,
                    FirstPath = path,
                };
                _focusedNodeTracks[ptr] = track;

                WriteLine($"[FINAL][FOCUSED-NODE] depth={depth} ptr=0x{ptr:X} class={cls} owner=0x{owner:X} ownerVtable=0x{ownerVtable:X} exactSpace={(exactSpace ? 1 : 0)} path={path}");
                DumpObjectToFile(ptr, OBJECT_DUMP_BYTES, "FOCUSED-NODE");
            }
            else
            {
                track.OwnerModel = owner;
                track.Vtable = vtable;
            }

            foreach (int offset in FOCUSED_MATRIX_CANDIDATE_OFFSETS)
                RegisterFocusedMatrixCandidate(ptr, offset, path, _sampleIndex, _lastTargetX, _lastTargetY, _lastTargetZ);

            foreach (int offset in FOCUSED_NODE_EDGES)
            {
                long child = ReadQuiet(ptr + offset);
                if (!IsFollowableGraphPointer(child))
                    continue;

                WriteFileLine($"[FINAL][FOCUSED-EDGE] from=0x{ptr:X} +0x{offset:X3} -> 0x{child:X} class={ClassifyVtable(child)}");
                ProbeFocusedNode(child, $"{path} -> +0x{offset:X3}=0x{child:X}", depth + 1, branchVisited);
            }
        }

        private void UpdateFocusedHierarchyProbe(
            float tx, float ty, float tz,
            float previousTx, float previousTy, float previousTz,
            bool hadPreviousTarget)
        {
            if (_focusedRootModels.Count == 0)
                return;

            foreach (long modelPtr in _focusedRootModels)
            {
                long rootNode = ReadQuiet(modelPtr + MODEL_SPACE_NODE);
                if (IsFollowableGraphPointer(rootNode))
                    ProbeFocusedNode(rootNode, $"TRACK-ROOT-MODEL=0x{modelPtr:X} +0x038", 0, new HashSet<long>());
            }

            foreach (FocusedNodeTrack node in _focusedNodeTracks.Values)
            {
                float nx = ReadFloatQuiet(node.Ptr + SPACE_TRANSFORM + 0x00);
                float ny = ReadFloatQuiet(node.Ptr + SPACE_TRANSFORM + 0x04);
                float nz = ReadFloatQuiet(node.Ptr + SPACE_TRANSFORM + 0x08);
                if (!IsValidCoordinate(nx) || !IsValidCoordinate(ny) || !IsValidCoordinate(nz))
                    continue;

                node.SeenSamples++;
                float d = Distance(tx, ty, tz, nx, ny, nz);
                if (float.IsNaN(node.FirstTargetDist))
                    node.FirstTargetDist = d;
                if (d < node.MinTargetDist)
                    node.MinTargetDist = d;

                if (node.HasLast && hadPreviousTarget)
                {
                    float step = Distance(0, 0, 0, nx - node.LastX, ny - node.LastY, nz - node.LastZ);
                    float rel = Distance(0, 0, 0,
                        (nx - node.LastX) - (tx - previousTx),
                        (ny - node.LastY) - (ty - previousTy),
                        (nz - node.LastZ) - (tz - previousTz));
                    node.TotalStep += step;
                    node.TotalRelativeStep += rel;
                    node.MaxStep = Math.Max(node.MaxStep, step);
                    node.MaxRelativeStep = Math.Max(node.MaxRelativeStep, rel);
                    if (step > 0.01f || rel > 0.01f)
                        WriteLine($"  [FOCUSED-NODE-MOVE] node=0x{node.Ptr:X} sample={_sampleIndex + 1} step={step:F4} relativeStep={rel:F4} dist={d:F3} xyz=({nx:F3},{ny:F3},{nz:F3})");
                }

                node.LastX = nx;
                node.LastY = ny;
                node.LastZ = nz;
                node.HasLast = true;
            }

            foreach (MatrixCandidateTrack candidate in _focusedMatrixCandidates.Values)
            {
                if (candidate.FirstSample == _sampleIndex)
                    continue;
                UpdateFocusedMatrixCandidate(candidate, tx, ty, tz, previousTx, previousTy, previousTz, hadPreviousTarget);
            }
        }

        private void RegisterFocusedMatrixCandidate(
            long ptr, int offset, string path, int sample,
            float tx, float ty, float tz)
        {
            byte[] bytes = ReadExactBytes(ptr + offset, MATRIX_BYTES);
            if (!IsValidMatrixCandidate(bytes))
                return;

            string key = $"{ptr:X}:{offset:X}";
            if (_focusedMatrixCandidates.ContainsKey(key))
                return;

            float[] f = MatrixFloats(bytes);
            float x = f[12], y = f[13], z = f[14];
            var track = new MatrixCandidateTrack
            {
                Ptr = ptr,
                Offset = offset,
                FirstSample = sample,
                FirstPath = path,
                ValidSamples = 1,
                FirstTargetDist = Distance(tx, ty, tz, x, y, z),
                MinTargetDist = Distance(tx, ty, tz, x, y, z),
                LastX = x,
                LastY = y,
                LastZ = z,
                HasLast = true,
                ClosestX = x,
                ClosestY = y,
                ClosestZ = z,
                ClosestSample = sample + 1,
                LastBytes = (byte[])bytes.Clone(),
            };
            _focusedMatrixCandidates[key] = track;

            WriteFileLine($"[FINAL][FOCUSED-MATRIX-CANDIDATE] ptr=0x{ptr:X} +0x{offset:X3} firstTargetDist={track.FirstTargetDist:F3} translation=({x:F3},{y:F3},{z:F3}) path={path}");
            DumpBytesToFile(bytes, $"[RAW][FOCUSED-MATRIX-CANDIDATE] ptr=0x{ptr:X} +0x{offset:X3}");
        }

        private void UpdateFocusedMatrixCandidate(
            MatrixCandidateTrack candidate,
            float tx, float ty, float tz,
            float previousTx, float previousTy, float previousTz,
            bool hadPreviousTarget)
        {
            byte[] bytes = ReadExactBytes(candidate.Ptr + candidate.Offset, MATRIX_BYTES);
            if (!IsValidMatrixCandidate(bytes))
                return;

            float[] f = MatrixFloats(bytes);
            float x = f[12], y = f[13], z = f[14];
            candidate.ValidSamples++;
            float d = Distance(tx, ty, tz, x, y, z);
            if (d < candidate.MinTargetDist)
            {
                candidate.MinTargetDist = d;
                candidate.ClosestX = x;
                candidate.ClosestY = y;
                candidate.ClosestZ = z;
                candidate.ClosestSample = _sampleIndex + 1;
            }

            if (candidate.LastBytes != null && !ByteArraysEqual(candidate.LastBytes, bytes))
                DumpBytesToFile(bytes, $"[RAW][FOCUSED-MATRIX-CHANGE] ptr=0x{candidate.Ptr:X} +0x{candidate.Offset:X3} sample={_sampleIndex + 1}");
            candidate.LastBytes = (byte[])bytes.Clone();

            if (candidate.HasLast && hadPreviousTarget)
            {
                float dx = x - candidate.LastX;
                float dy = y - candidate.LastY;
                float dz = z - candidate.LastZ;
                float step = Distance(0, 0, 0, dx, dy, dz);
                float rel = Distance(0, 0, 0,
                    dx - (tx - previousTx),
                    dy - (ty - previousTy),
                    dz - (tz - previousTz));
                candidate.TotalStep += step;
                candidate.TotalRelativeStep += rel;
                candidate.MaxStep = Math.Max(candidate.MaxStep, step);
                candidate.MaxRelativeStep = Math.Max(candidate.MaxRelativeStep, rel);
                if (step > 0.01f || rel > 0.01f)
                    WriteLine($"  [FOCUSED-MATRIX-MOVE] ptr=0x{candidate.Ptr:X} +0x{candidate.Offset:X3} sample={_sampleIndex + 1} step={step:F4} relativeStep={rel:F4} dist={d:F3} translation=({x:F3},{y:F3},{z:F3})");
            }

            candidate.LastX = x;
            candidate.LastY = y;
            candidate.LastZ = z;
            candidate.HasLast = true;
        }

        private void EmitFocusedHierarchySummary()
        {
            WriteLine("");
            WriteLine("[FINAL][FOCUSED-HIERARCHY-TRACKS]");
            foreach (FocusedNodeTrack n in _focusedNodeTracks.Values.OrderBy(x => x.MinTargetDist).ThenBy(x => x.FirstSample))
            {
                string verdict = n.MinTargetDist <= 64f && (n.TotalStep > 0.01f || n.TotalRelativeStep > 0.01f)
                    ? "TARGET-LOCAL-MOVING-CANDIDATE"
                    : (n.TotalStep > 0.01f || n.TotalRelativeStep > 0.01f)
                        ? "MOVING-DISTANT-OR-UNMAPPED"
                        : "STATIONARY-OR-INVALID";
                WriteLine($"  node=0x{n.Ptr:X} owner=0x{n.OwnerModel:X} samples={n.SeenSamples} minTargetDist={n.MinTargetDist:F4} firstDist={n.FirstTargetDist:F4} totalStep={n.TotalStep:F4} totalRelativeStep={n.TotalRelativeStep:F4} maxStep={n.MaxStep:F4} maxRelativeStep={n.MaxRelativeStep:F4} verdict={verdict} path={n.FirstPath}");
            }

            WriteLine("");
            WriteLine("[FINAL][FOCUSED-MATRIX-TRACKS]");
            foreach (MatrixCandidateTrack c in _focusedMatrixCandidates.Values.OrderBy(x => x.MinTargetDist).ThenBy(x => x.Offset))
            {
                string verdict = c.MinTargetDist <= 64f && (c.TotalStep > 0.01f || c.TotalRelativeStep > 0.01f)
                    ? "TARGET-LOCAL-MOVING-MATRIX-CANDIDATE"
                    : (c.TotalStep > 0.01f || c.TotalRelativeStep > 0.01f)
                        ? "MOVING-DISTANT-OR-UNMAPPED"
                        : "STATIONARY-OR-INVALID";
                WriteLine($"  ptr=0x{c.Ptr:X} +0x{c.Offset:X3} valid={c.ValidSamples} minTargetDist={c.MinTargetDist:F4} firstDist={c.FirstTargetDist:F4} totalStep={c.TotalStep:F4} totalRelativeStep={c.TotalRelativeStep:F4} maxStep={c.MaxStep:F4} maxRelativeStep={c.MaxRelativeStep:F4} closestSample={c.ClosestSample} closestTranslation=({c.ClosestX:F3},{c.ClosestY:F3},{c.ClosestZ:F3}) verdict={verdict} path={c.FirstPath}");
            }

            bool movingNode = _focusedNodeTracks.Values.Any(n => n.MinTargetDist <= 64f && n.TotalStep > 0.01f);
            bool movingMatrix = _focusedMatrixCandidates.Values.Any(c => c.MinTargetDist <= 64f && c.TotalStep > 0.01f);
            bool relativeMatrix = _focusedMatrixCandidates.Values.Any(c => c.MinTargetDist <= 128f && c.TotalRelativeStep > 0.01f);
            WriteLine($"[FINAL][FOCUSED-PROOF] targetLocalMovingNode={(movingNode ? 1 : 0)} targetLocalMovingMatrix={(movingMatrix ? 1 : 0)} targetLocalRelativeMatrix={(relativeMatrix ? 1 : 0)} roots={_focusedRootModels.Count} nodes={_focusedNodeTracks.Count} matrixCandidates={_focusedMatrixCandidates.Count}");
        }

        private float ReadTranslationDistance(long address, float tx, float ty, float tz)
        {
            float x = ReadFloatQuiet(address + 0x00);
            float y = ReadFloatQuiet(address + 0x04);
            float z = ReadFloatQuiet(address + 0x08);
            return IsValidCoordinate(x) && IsValidCoordinate(y) && IsValidCoordinate(z)
                ? Distance(tx, ty, tz, x, y, z)
                : float.MaxValue;
        }

        private float ReadMatrixTranslationDistance(long address, float tx, float ty, float tz)
        {
            byte[] bytes = ReadExactBytes(address, MATRIX_BYTES);
            if (!IsValidMatrixCandidate(bytes))
                return float.MaxValue;
            float[] f = MatrixFloats(bytes);
            return Distance(tx, ty, tz, f[12], f[13], f[14]);
        }

        private bool IsValidMatrixCandidate(byte[] bytes)
        {
            if (bytes == null || bytes.Length < MATRIX_BYTES)
                return false;
            for (int i = 0; i < 16; i++)
                if (!float.IsFinite(BitConverter.ToSingle(bytes, i * 4)))
                    return false;
            float[] f = MatrixFloats(bytes);
            return IsValidCoordinate(f[12]) && IsValidCoordinate(f[13]) && IsValidCoordinate(f[14]);
        }









        private void BuildTargetOwnedGraph()
        {
            long b8 = ReadQuiet(_lockedBgaPtr + BGA_NATIVE_GRAPH);
            if (!IsPlausiblePtr(b8))
            {
                WriteLine("[FINAL][GRAPH] BGA+0xB8 unavailable; no target-owned graph could be built.");
                return;
            }

            long owner = ReadQuiet(b8 + 0x038);
            bool ownerValid = IsPlausiblePtr(owner);
            if (!ownerValid)
                WriteLine($"[FINAL][GRAPH] BGA+0xB8=0x{b8:X} owner unavailable; traversing B8 branch anyway");

            if (_firstB8 == 0) _firstB8 = b8;
            if (_firstOwner == 0) _firstOwner = owner;
            _lockedB8 = b8;
            _lockedOwner = owner;

            string ownerVtable = ownerValid ? $"0x{ReadQuiet(owner):X}" : "INVALID";
            WriteLine($"[FINAL][GRAPH-ROOT] bga+0xB8=0x{b8:X} owner=0x{owner:X} ownerVtable={ownerVtable}");
            WriteLine("[FINAL][GRAPH-POLICY] bounded recursive graph from B8 itself plus B8+0x038 owner; exact ModelSkeletal/SpaceNode only for proof");
            WriteLine("[FINAL][GRAPH-POLICY] stale owner+0x288/+0x500 path is recorded for comparison, not trusted");

            ProbeStrictObject(b8, -1, "target+0x0B8");
            if (ownerValid)
                ProbeStrictObject(owner, 0, "target+0x0B8 -> +0x038 owner");

            if (ownerValid)
            {
                long staleIntermediate = ReadQuiet(owner + 0x288);
                WriteLine($"[FINAL][OLD-PATH-CHECK] owner+0x288 -> 0x{staleIntermediate:X} class={ClassifyVtable(staleIntermediate)}");
                if (IsFollowableGraphPointer(staleIntermediate))
                {
                    long staleModel = ReadQuiet(staleIntermediate + 0x500);
                    WriteLine($"[FINAL][OLD-PATH-CHECK] intermediate+0x500 -> 0x{staleModel:X} class={ClassifyVtable(staleModel)}");
                }

                foreach (int offset in EVIDENCE_OWNER_BRANCH_OFFSETS)
                {
                    long branch = ReadQuiet(owner + offset);
                    if (!IsFollowableGraphPointer(branch)) continue;
                    WriteLine($"[FINAL][OWNER-BRANCH] +0x{offset:X3} -> 0x{branch:X} class={ClassifyVtable(branch)}");
                }
            }

            var queue = new Queue<(long Ptr, int Depth, string Path)>();
            var visited = new HashSet<long>();
            var perDepth = new int[TARGET_GRAPH_MAX_DEPTH + 1];

            // Critical correction: B8 itself is a traversal root. Earlier evidence
            // showed relevant target-owned chains descending directly from this node
            // (for example +0x318 -> +0x4E8 -> +0x7B0 -> ModelSkeletal).
            EnqueueTargetGraph(b8, 0, "B8", queue, visited, perDepth);
            if (ownerValid && owner != b8)
                EnqueueTargetGraph(owner, 0, "B8 -> +0x038 owner", queue, visited, perDepth);

            int expanded = 0;
            while (queue.Count > 0 && expanded < TARGET_GRAPH_MAX_OBJECTS)
            {
                var item = queue.Dequeue();
                if (item.Depth > TARGET_GRAPH_MAX_DEPTH) continue;
                if (!IsFollowableGraphPointer(item.Ptr)) continue;

                byte[] bytes = ReadObjectBytes(item.Ptr, TARGET_GRAPH_OBJECT_BYTES);
                if (bytes == null) continue;
                expanded++;

                long vt = ReadQuiet(item.Ptr);
                if (vt == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA ||
                    vt == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA)
                {
                    WriteLine($"[FINAL][TARGET-GRAPH-STRICT-HIT] depth={item.Depth} ptr=0x{item.Ptr:X} class={ClassifyVtable(item.Ptr)} path={item.Path}");
                    ProbeStrictObject(item.Ptr, item.Depth, item.Path);
                }

                if (item.Depth >= TARGET_GRAPH_MAX_DEPTH) continue;
                int nextDepth = item.Depth + 1;
                for (int q = 0; q < bytes.Length / 8; q++)
                {
                    long child = BitConverter.ToInt64(bytes, q * 8);
                    if (!IsFollowableGraphPointer(child)) continue;
                    if (visited.Contains(child)) continue;
                    if (visited.Count >= TARGET_GRAPH_MAX_OBJECTS) break;
                    if (perDepth[nextDepth] >= TARGET_GRAPH_MAX_PER_DEPTH) break;

                    string childPath = $"{item.Path} -> +0x{q * 8:X3}=0x{child:X}";
                    EnqueueTargetGraph(child, nextDepth, childPath, queue, visited, perDepth);
                }
            }

            WriteLine($"[FINAL][TARGET-GRAPH-SUMMARY] visited={visited.Count} expanded={expanded} queued={queue.Count} " +
                      $"strictModels={_models.Count} strictSpaceNodes={_spaceNodes.Count}");
            if (_models.Count == 0)
                WriteLine("[FINAL][FOCUSED] no exact ModelSkeletal discovered in the current B8/owner graph");
        }

        private void EnqueueTargetGraph(
            long ptr,
            int depth,
            string path,
            Queue<(long Ptr, int Depth, string Path)> queue,
            HashSet<long> visited,
            int[] perDepth)
        {
            if (depth < 0 || depth > TARGET_GRAPH_MAX_DEPTH) return;
            if (!IsFollowableGraphPointer(ptr)) return;
            if (!visited.Add(ptr)) return;
            perDepth[depth]++;
            queue.Enqueue((ptr, depth, path));
        }

        private void ProbeStrictObject(long ptr, int depth, string path)
        {
            if (!IsFollowableGraphPointer(ptr))
                return;

            long vtable = ReadQuiet(ptr);
            bool strict = vtable == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA ||
                          vtable == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA;
            if (!strict)
                return;

            if (_graphObjects.ContainsKey(ptr))
                return;

            var record = new GraphObjectRecord
            {
                Ptr = ptr,
                Depth = depth,
                Path = path,
                DiscoverySample = _sampleIndex,
                Vtable = vtable,
                LastBytes = ReadObjectBytes(ptr, OBJECT_DUMP_BYTES),
            };
            _graphObjects[ptr] = record;
            _visitedObjects.Add(ptr);
            WriteLine($"[FINAL][STRICT-OBJECT] ptr=0x{ptr:X} depth={depth} class={ClassifyVtable(ptr)} path={path}");
            TestExactModel(record);
            TestExactSpaceNode(record);

            // Keep only the strict object itself in the graph record. The full raw
            // object dump is already emitted for the strict candidate by the
            // existing exact-object handlers.
        }







        private void TestExactModel(GraphObjectRecord record)
        {
            long expected = _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;
            if (record.Vtable != expected)
                return;

            long node = ReadQuiet(record.Ptr + MODEL_SPACE_NODE);
            long nodeVtable = ReadQuiet(node);
            bool reciprocal = IsPlausiblePtr(node) && nodeVtable == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA && ReadQuiet(node + SPACE_MODEL) == record.Ptr;

            if (!_models.TryGetValue(record.Ptr, out ModelRecord model))
            {
                model = new ModelRecord
                {
                    Ptr = record.Ptr,
                    Vtable = record.Vtable,
                    SpaceNode = node,
                    SpaceVtable = nodeVtable,
                    Reciprocal = reciprocal,
                    FirstSample = _sampleIndex,
                    FirstPath = record.Path,
                    LastDump = record.LastBytes,
                };
                _models[record.Ptr] = model;
                WriteFileLine($"[FINAL][MODEL] ptr=0x{record.Ptr:X} node=0x{node:X} nodeVtable=0x{nodeVtable:X} reciprocal={(reciprocal ? 1 : 0)}");
                DumpKnownVtableMethods(record.Vtable, "MODEL");
            }

            model.SpaceNode = node;
            model.SpaceVtable = nodeVtable;
            model.Reciprocal = reciprocal;
        }

        private void TestExactSpaceNode(GraphObjectRecord record)
        {
            long expected = _mem.BaseAddress + SPACE_NODE_VTABLE_RVA;
            if (record.Vtable != expected)
                return;

            long model = ReadQuiet(record.Ptr + SPACE_MODEL);
            long modelVtable = ReadQuiet(model);
            bool reciprocal = IsPlausiblePtr(model) && modelVtable == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA && ReadQuiet(model + MODEL_SPACE_NODE) == record.Ptr;

            if (!_spaceNodes.TryGetValue(record.Ptr, out SpaceNodeRecord node))
            {
                node = new SpaceNodeRecord
                {
                    Ptr = record.Ptr,
                    Vtable = record.Vtable,
                    Model = model,
                    Reciprocal = reciprocal,
                    FirstSample = _sampleIndex,
                    FirstPath = record.Path,
                };
                _spaceNodes[record.Ptr] = node;
                WriteFileLine($"[FINAL][SPACE-NODE] ptr=0x{record.Ptr:X} model=0x{model:X} modelVtable=0x{modelVtable:X} reciprocal={(reciprocal ? 1 : 0)}");
                DumpKnownVtableMethods(record.Vtable, "SPACE");
            }

            node.Model = model;
            node.Reciprocal = reciprocal;

            // Exact SpaceNode identity is sufficient to keep and sample the node.
            // Reciprocal ModelSkeletal linkage is a stronger classification, not a
            // prerequisite for collecting the node transform/matrix evidence.
            CaptureSpaceNodeImmediate(node);

            // Probe the previously evidence-backed SpaceNode child edges even when
            // the +0x40 reciprocal ModelSkeletal link is absent. This is required
            // to distinguish a standalone target-local node from a model-linked root.
            ProbeFocusedNode(
                node.Ptr,
                $"STRICT-SPACENODE=0x{node.Ptr:X}",
                0,
                new HashSet<long>());
        }

        private void CaptureSpaceNodeImmediate(SpaceNodeRecord node)
        {
            byte[] transform = ReadExactBytes(node.Ptr + SPACE_TRANSFORM, MATRIX_BYTES);
            byte[] world = ReadExactBytes(node.Ptr + SPACE_WORLD_MATRIX, MATRIX_BYTES);

            if (transform != null)
            {
                if (node.LastTransform == null)
                {
                    node.LastTransform = (byte[])transform.Clone();
                    WriteLine($"  [SPACE-TRANSFORM-FIRST] node=0x{node.Ptr:X}");
                    DumpFloatMatrix(transform, "    transform");
                }
                else if (!ByteArraysEqual(node.LastTransform, transform))
                {
                    WriteLine($"  [SPACE-TRANSFORM-CHANGE] node=0x{node.Ptr:X}");
                    DumpBytesCompact(transform, 0, transform.Length, "    now");
                    node.LastTransform = (byte[])transform.Clone();
                }
            }

            if (world != null)
            {
                if (node.LastWorldMatrix == null)
                {
                    node.LastWorldMatrix = (byte[])world.Clone();
                    WriteLine($"  [SPACE-WORLD-MATRIX-FIRST] node=0x{node.Ptr:X}");
                    DumpFloatMatrix(world, "    worldMatrix");
                }
                else if (!ByteArraysEqual(node.LastWorldMatrix, world))
                {
                    WriteLine($"  [SPACE-WORLD-MATRIX-CHANGE] node=0x{node.Ptr:X}");
                    DumpBytesCompact(world, 0, world.Length, "    now");
                    node.LastWorldMatrix = (byte[])world.Clone();
                }
            }
        }

        private void CaptureSample()
        {
            EntityData target = GetLockedTargetSnapshot();
            float tx, ty, tz;
            uint currentId;
            bool hadPreviousTarget = _haveTargetMotion;
            float previousTx = _lastTargetX;
            float previousTy = _lastTargetY;
            float previousTz = _lastTargetZ;

            if (target != null)
            {
                tx = target.X;
                ty = target.Y;
                tz = target.Z;
                currentId = ReadSnapshotEntityId(target);
            }
            else
            {
                tx = ReadFloatQuiet(_lockedBgaPtr + ENTITY_X);
                ty = ReadFloatQuiet(_lockedBgaPtr + ENTITY_Y);
                tz = ReadFloatQuiet(_lockedBgaPtr + ENTITY_Z);
                currentId = unchecked((uint)ReadQuiet(_lockedBgaPtr + ENTITY_ID));
            }

            if (currentId != _lockedBgaId || !IsValidCoordinate(tx) || !IsValidCoordinate(ty) || !IsValidCoordinate(tz))
            {
                _targetLostSamples++;
                WriteLine($"[FINAL][SAMPLE {_sampleIndex + 1:D3}] TARGET-LOST/INVALID id=0x{currentId:X8} xyz=({tx:F3},{ty:F3},{tz:F3})");
                return;
            }

            if (hadPreviousTarget)
            {
                float dx = tx - previousTx;
                float dy = ty - previousTy;
                float dz = tz - previousTz;
                _targetTotalStep += MathF.Sqrt(dx * dx + dy * dy + dz * dz);
            }
            _lastTargetX = tx;
            _lastTargetY = ty;
            _lastTargetZ = tz;
            _haveTargetMotion = true;

            long previousB8 = _lockedB8;
            long previousOwner = _lockedOwner;
            long b8 = ReadQuiet(_lockedBgaPtr + BGA_NATIVE_GRAPH);
            long owner = IsPlausiblePtr(b8) ? ReadQuiet(b8 + 0x038) : 0;

            if (previousB8 != 0 && b8 != previousB8)
                _b8Changes++;
            if (previousOwner != 0 && owner != previousOwner)
                _ownerChanges++;
            if (_firstB8 == 0) _firstB8 = b8;
            if (_firstOwner == 0) _firstOwner = owner;
            _lockedB8 = b8;
            _lockedOwner = owner;

            WriteLine($"[FINAL][SAMPLE {_sampleIndex + 1:D3}/{CAPTURE_SAMPLES}] target=0x{_lockedBgaPtr:X} id=0x{_lockedBgaId:X8} xyz=({tx:F3},{ty:F3},{tz:F3}) b8=0x{b8:X} owner=0x{owner:X}");
            DumpChangedBgaQwords(_lockedBgaPtr);
            DumpChangedGraphQwords(_lockedB8, "B8");
            DumpChangedGraphQwords(_lockedOwner, "OWNER");

            if (!_initialGraphBuilt || (b8 != previousB8) || (owner != previousOwner))
            {
                _initialGraphBuilt = true;
                RefreshReadableRegions();
                BuildTargetOwnedGraph();
                InitializeFocusedHierarchyProbe();
            }

            UpdateFocusedHierarchyProbe(tx, ty, tz, previousTx, previousTy, previousTz, hadPreviousTarget);
        }

        private EntityData GetLockedTargetSnapshot()
        {
            lock (_sync)
            {
                if (_latestBgaById.TryGetValue(_lockedBgaId, out EntityData e) && e != null && e.Ptr == _lockedBgaPtr)
                    return CloneEntity(e);
            }
            return null;
        }

        private void DumpChangedBgaQwords(long bga)
        {
            GraphObjectRecord existing;
            if (!_graphObjects.TryGetValue(bga, out existing) || existing.LastBytes == null)
            {
                byte[] now = ReadObjectBytes(bga, BGA_DUMP_BYTES);
                if (now != null)
                {
                    _graphObjects[bga] = new GraphObjectRecord { Ptr = bga, Depth = -1, Path = "TARGET-BGA", Vtable = ReadQuiet(bga), LastBytes = now, DiscoverySample = _sampleIndex };
                }
                return;
            }

            byte[] current = ReadObjectBytes(bga, BGA_DUMP_BYTES);
            if (current == null) return;
            int qwords = Math.Min(existing.LastBytes.Length, current.Length) / 8;
            for (int q = 0; q < qwords; q++)
            {
                long oldVal = BitConverter.ToInt64(existing.LastBytes, q * 8);
                long newVal = BitConverter.ToInt64(current, q * 8);
                if (oldVal == newVal) continue;

                int off = q * 8;
                float oldLo = BitConverter.ToSingle(existing.LastBytes, off);
                float newLo = BitConverter.ToSingle(current, off);
                float oldHi = BitConverter.ToSingle(existing.LastBytes, off + 4);
                float newHi = BitConverter.ToSingle(current, off + 4);
                WriteLine($"  [BGA-CHANGED] +0x{off:X3} old=0x{oldVal:X16} new=0x{newVal:X16} f32=({oldLo:G9}->{newLo:G9},{oldHi:G9}->{newHi:G9})");
            }
            existing.LastBytes = current;
        }

        private void DumpChangedGraphQwords(long ptr, string label)
        {
            if (!IsPlausiblePtr(ptr) || !_graphObjects.TryGetValue(ptr, out GraphObjectRecord record) || record.LastBytes == null)
                return;

            byte[] current = ReadObjectBytes(ptr, record.LastBytes.Length);
            if (current == null) return;
            int qwords = Math.Min(record.LastBytes.Length, current.Length) / 8;
            for (int q = 0; q < qwords; q++)
            {
                long oldVal = BitConverter.ToInt64(record.LastBytes, q * 8);
                long newVal = BitConverter.ToInt64(current, q * 8);
                if (oldVal == newVal) continue;
                WriteLine($"  [{label}-CHANGED] +0x{q * 8:X3} old=0x{oldVal:X16} new=0x{newVal:X16}");
            }
            record.LastBytes = current;
        }

















        private void EmitFinalSummary()
        {
            WriteLine("");
            WriteLine("============================================================");
            WriteLine("[BONE-DIAG][FINAL][RESULT]");
            WriteLine("============================================================");
            WriteLine($"[FINAL][TARGET] bga=0x{_lockedBgaPtr:X} id=0x{_lockedBgaId:X8} firstB8=0x{_firstB8:X} lastB8=0x{_lockedB8:X} firstOwner=0x{_firstOwner:X} lastOwner=0x{_lockedOwner:X}");
            WriteLine($"[FINAL][STABILITY] b8Changes={_b8Changes} ownerChanges={_ownerChanges} targetLostSamples={_targetLostSamples} targetTotalStep={_targetTotalStep:F4}");
            WriteLine($"[FINAL][GRAPH] objects={_graphObjects.Count} models={_models.Count} spaceNodes={_spaceNodes.Count}");

            int reciprocalModels = _models.Values.Count(m => m.Reciprocal);
            int reciprocalNodes = _spaceNodes.Values.Count(n => n.Reciprocal);
            WriteLine($"[FINAL][STRICT] reciprocalModelSpaceNodePairs={reciprocalModels} reciprocalSpaceModelPairs={reciprocalNodes}");

            WriteLine("");
            WriteLine("[FINAL][SPACE-NODE-TRACKS]");
            foreach (SpaceNodeRecord n in _spaceNodes.Values.OrderBy(x => x.MinTargetDist))
            {
                string verdict = n.Reciprocal && !float.IsPositiveInfinity(n.MinTargetDist) && n.MinTargetDist <= 64f
                    ? "TARGET-LOCAL-CANDIDATE"
                    : (n.TotalNodeStep > 0.01f || n.TotalWorldM3Step > 0.01f)
                        ? "MOVING-DISTANT-OR-UNMAPPED"
                        : "STATIONARY-DISTANT-OR-DECOY";

                WriteLine($"  node=0x{n.Ptr:X} model=0x{n.Model:X} seen={n.SeenSamples} validTransform={n.ValidTransformSamples} validWorld={n.ValidWorldMatrixSamples} minTargetDist={n.MinTargetDist:F4} firstDist={n.FirstTargetDist:F4} totalNodeStep={n.TotalNodeStep:F4} totalRelativeStep={n.TotalRelativeStep:F4} maxNodeStep={n.MaxNodeStep:F4} maxRelativeStep={n.MaxRelativeStep:F4} closestSample={n.ClosestSample} closestXYZ=({n.ClosestX:F3},{n.ClosestY:F3},{n.ClosestZ:F3}) minWorldM3Dist={n.MinWorldM3Dist:F4} totalWorldM3Step={n.TotalWorldM3Step:F4} totalWorldM3RelativeStep={n.TotalWorldM3RelativeStep:F4} maxWorldM3Step={n.MaxWorldM3Step:F4} maxWorldM3RelativeStep={n.MaxWorldM3RelativeStep:F4} closestWorldM3Sample={n.ClosestWorldM3Sample} closestWorldM3=({n.ClosestWorldM3X:F3},{n.ClosestWorldM3Y:F3},{n.ClosestWorldM3Z:F3}) verdict={verdict}");
                WriteLine($"    path={n.FirstPath}");
            }

            EmitFocusedHierarchySummary();

            bool targetLocal = _spaceNodes.Values.Any(n => n.Reciprocal && n.MinTargetDist <= 64f && n.TotalNodeStep > 0.01f);
            bool targetLocalWorldM3 = _spaceNodes.Values.Any(n => n.Reciprocal && n.MinWorldM3Dist <= 64f && n.TotalWorldM3Step > 0.01f);
            bool anyMovingNode = _spaceNodes.Values.Any(n => n.TotalNodeStep > 0.01f || n.TotalWorldM3Step > 0.01f);

            WriteLine("");
            WriteLine($"[FINAL][PROOF] targetLocalMovingSpaceNode={(targetLocal ? 1 : 0)} worldMatrixM3TargetLocalMovingCandidate={(targetLocalWorldM3 ? 1 : 0)} anyMovingSpaceNode={(anyMovingNode ? 1 : 0)}");
            if (targetLocal)
            {
                WriteLine("[FINAL][PROOF-RESULT] TARGET-LOCAL MOVING STRICT SPACENODE FOUND");
                WriteLine("[FINAL][PROOF-RESULT] ModelSkeletal <-> SpaceNode chain is ready for bone mapping analysis from the captured raw graph.");
            }
            else
            {
                WriteLine("[FINAL][PROOF-RESULT] No target-local moving strict SpaceNode was proven in the captured target-owned graph.");
                WriteLine("[FINAL][PROOF-LIMITATION] The capture still contains first-discovery raw objects and all observed changes for offline reconciliation.");
            }
            WriteLine($"[FINAL][FILE] {(_captureFile ?? "console-only")}");
            WriteLine("============================================================");
        }

        private string ClassifyVtable(long ptr)
        {
            if (!IsPlausiblePtr(ptr)) return "invalid";
            long vt = ReadQuiet(ptr);
            if (vt == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA) return "ModelSkeletal";
            if (vt == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA) return "SpaceNode";
            if (vt == _mem.BaseAddress + MODEL_VTABLE_RVA) return "WorldModel";
            return $"vt=0x{vt:X}";
        }

        private byte[] ReadObjectBytes(long address, int size)
        {
            if (!IsPlausiblePtr(address) || size <= 0)
                return null;

            var result = new byte[size];
            bool any = false;
            int cursor = 0;
            while (cursor < size)
            {
                long at = address + cursor;
                int pageOffset = (int)(at & 0xFFF);
                int chunk = Math.Min(0x1000 - pageOffset, size - cursor);
                if (_mem.ReadBytesQuiet(at, result, cursor, chunk))
                    any = true;
                else
                    Array.Clear(result, cursor, chunk);
                cursor += chunk;
            }
            return any ? result : null;
        }

        private byte[] ReadExactBytes(long address, int size)
        {
            if (!IsPlausiblePtr(address) || size <= 0 || size > 0x10000)
                return null;
            var result = new byte[size];
            return _mem.ReadBytesQuiet(address, result, 0, size) ? result : null;
        }

        private void DumpKnownVtableMethods(long vtable, string label)
        {
            if (!IsPlausiblePtr(vtable)) return;
            WriteLine($"  [{label}-VTABLE] ptr=0x{vtable:X} +0x230=0x{ReadQuiet(vtable + 0x230):X} +0x240=0x{ReadQuiet(vtable + 0x240):X}");
            if (vtable == _mem.BaseAddress + MODEL_VTABLE_RVA)
            {
                WriteLine($"  [WORLD-MODEL-METHODS] +0x008=0x{ReadQuiet(vtable + 0x008):X} +0x010=0x{ReadQuiet(vtable + 0x010):X} +0x2B8=0x{ReadQuiet(vtable + 0x2B8):X} +0x2C0=0x{ReadQuiet(vtable + 0x2C0):X} +0x2C8=0x{ReadQuiet(vtable + 0x2C8):X} +0x2E0=0x{ReadQuiet(vtable + 0x2E0):X} +0x2E8=0x{ReadQuiet(vtable + 0x2E8):X}");
            }
        }

        private static float[] MatrixFloats(byte[] bytes)
        {
            var f = new float[16];
            if (bytes == null || bytes.Length < 64) return f;
            for (int i = 0; i < 16; i++)
                f[i] = BitConverter.ToSingle(bytes, i * 4);
            return f;
        }

        private void DumpFloatMatrix(byte[] bytes, string label)
        {
            if (bytes == null || bytes.Length < 64) return;
            float[] f = new float[16];
            for (int i = 0; i < 16; i++)
                f[i] = BitConverter.ToSingle(bytes, i * 4);
            WriteLine($"{label} M0=({f[0]:G9},{f[1]:G9},{f[2]:G9},{f[3]:G9})");
            WriteLine($"{label} M1=({f[4]:G9},{f[5]:G9},{f[6]:G9},{f[7]:G9})");
            WriteLine($"{label} M2=({f[8]:G9},{f[9]:G9},{f[10]:G9},{f[11]:G9})");
            WriteLine($"{label} M3=({f[12]:G9},{f[13]:G9},{f[14]:G9},{f[15]:G9})");
        }

        private void DumpObjectToFile(long ptr, int bytes, string label)
        {
            byte[] data = ReadObjectBytes(ptr, bytes);
            if (data == null)
            {
                WriteLine($"[RAW][{label}] unreadable ptr=0x{ptr:X}");
                return;
            }
            DumpBytesToFile(data, $"[RAW][{label}] ptr=0x{ptr:X} bytes=0x{bytes:X}");
        }

        private void DumpBytesToFile(byte[] data, string header)
        {
            lock (_fileSync)
            {
                try
                {
                    if (_fileWriter == null) return;
                    _fileWriter.WriteLine(header);
                    const int qwordsPerLine = 8;
                    for (int offset = 0; offset + 8 <= data.Length; offset += qwordsPerLine * 8)
                    {
                        int end = Math.Min(data.Length, offset + qwordsPerLine * 8);
                        var sb = new StringBuilder();
                        sb.Append("  +0x").Append(offset.ToString("X3")).Append(":");
                        for (int p = offset; p + 8 <= end; p += 8)
                            sb.Append(' ').Append(BitConverter.ToInt64(data, p).ToString("X16"));
                        _fileWriter.WriteLine(sb.ToString());
                    }
                }
                catch { }
            }
        }



        private void DumpBytesCompact(byte[] data, int start, int length, string prefix)
        {
            if (data == null || length <= 0 || start < 0 || start + length > data.Length)
                return;

            const int qwordsPerLine = 8;
            for (int offset = start; offset < start + length; offset += qwordsPerLine * 8)
            {
                int end = Math.Min(start + length, offset + qwordsPerLine * 8);
                var sb = new StringBuilder();
                sb.Append(prefix).Append(" +0x").Append((offset - start).ToString("X3")).Append(":");
                for (int p = offset; p < end; p += 8)
                {
                    if (p + 8 <= data.Length)
                    {
                        long q = BitConverter.ToInt64(data, p);
                        sb.Append(' ').Append(q.ToString("X16"));
                    }
                }
                WriteLine(sb.ToString());
            }
        }

        private static bool ByteArraysEqual(byte[] a, byte[] b)
        {
            if (ReferenceEquals(a, b)) return true;
            if (a == null || b == null || a.Length != b.Length) return false;
            for (int i = 0; i < a.Length; i++)
                if (a[i] != b[i]) return false;
            return true;
        }

        private bool IsFollowableGraphPointer(long ptr)
        {
            if (!IsPlausiblePtr(ptr)) return false;
            if (ptr >= _mem.BaseAddress && ptr < _mem.BaseAddress + 0x10000000L)
                return false; // image/module pointers are code/static data, not target-owned heap objects
            return IsReadablePrivatePointer(ptr);
        }

        private bool IsReadablePrivatePointer(long ptr)
        {
            foreach (MemoryRegion region in _readablePrivateRegions)
            {
                if (ptr >= region.Base && ptr < region.Base + region.Size)
                    return true;
            }
            return false;
        }

        private IEnumerable<MemoryRegion> EnumerateReadablePrivateRegions()
        {
            if (_mem.Handle == IntPtr.Zero)
                yield break;

            IntPtr cursor = IntPtr.Zero;
            int mbiSize = Marshal.SizeOf<MEMORY_BASIC_INFORMATION64>();
            while (true)
            {
                UIntPtr result = VirtualQueryEx(_mem.Handle, cursor, out MEMORY_BASIC_INFORMATION64 mbi, (UIntPtr)mbiSize);
                if (result == UIntPtr.Zero)
                    yield break;

                long baseAddress = mbi.BaseAddress.ToInt64();
                long size = unchecked((long)mbi.RegionSize.ToUInt64());
                if (size <= 0)
                    yield break;

                if (mbi.State == 0x1000 && mbi.Type == 0x20000 && IsReadableProtection(mbi.Protect))
                {
                    yield return new MemoryRegion { Base = baseAddress, Size = size };
                }

                long next = baseAddress + size;
                if (next <= baseAddress)
                    yield break;
                cursor = new IntPtr(next);
            }
        }

        private static bool IsReadableProtection(uint protect)
        {
            const uint PAGE_NOACCESS = 0x01;
            const uint PAGE_GUARD = 0x100;
            uint basic = protect & 0xFF;
            if (basic == PAGE_NOACCESS || (protect & PAGE_GUARD) != 0)
                return false;
            return basic == 0x02 || basic == 0x04 || basic == 0x08 || basic == 0x20 || basic == 0x40 || basic == 0x80;
        }

        private static bool IsPlausiblePtr(long ptr) => ptr >= 0x10000 && ptr < 0x0000800000000000L;
        private static bool IsValidCoordinate(float value) => float.IsFinite(value) && value > -MAX_WORLD_COORD && value < MAX_WORLD_COORD;

        private static float Distance(float ax, float ay, float az, float bx, float by, float bz)
        {
            float dx = ax - bx;
            float dy = ay - by;
            float dz = az - bz;
            return MathF.Sqrt(dx * dx + dy * dy + dz * dz);
        }

        private long ReadQuiet(long address)
        {
            byte[] bytes = new byte[8];
            return _mem.ReadBytesQuiet(address, bytes, 0, 8) ? BitConverter.ToInt64(bytes, 0) : 0;
        }

        private float ReadFloatQuiet(long address)
        {
            byte[] bytes = new byte[4];
            return _mem.ReadBytesQuiet(address, bytes, 0, 4) ? BitConverter.ToSingle(bytes, 0) : float.NaN;
        }

        private byte ReadByteQuiet(long address)
        {
            byte[] bytes = new byte[1];
            return _mem.ReadBytesQuiet(address, bytes, 0, 1) ? bytes[0] : (byte)0;
        }

        private string ReadPythonStringQuiet(long keyObj)
        {
            if (!IsPlausiblePtr(keyObj)) return string.Empty;
            long chars = ReadQuiet(keyObj + PY_STRING_VALUE);
            if (!IsPlausiblePtr(chars)) return string.Empty;
            byte[] bytes = ReadObjectBytes(chars, 96);
            if (bytes == null) return string.Empty;
            int end = Array.IndexOf(bytes, (byte)0);
            if (end < 0) end = bytes.Length;
            try { return Encoding.ASCII.GetString(bytes, 0, end); } catch { return string.Empty; }
        }

        private string ReadPythonTypeName(long obj)
        {
            if (!IsPlausiblePtr(obj)) return "<invalid>";
            long type = ReadQuiet(obj + PY_TYPE);
            if (!IsPlausiblePtr(type)) return "<no-type>";
            long name = ReadQuiet(type + PY_TYPE_NAME);
            if (!IsPlausiblePtr(name)) return $"<type=0x{type:X}>";
            byte[] bytes = ReadObjectBytes(name, 96);
            if (bytes == null) return $"<type=0x{type:X}>";
            int end = Array.IndexOf(bytes, (byte)0);
            if (end < 0) end = bytes.Length;
            try { return Encoding.ASCII.GetString(bytes, 0, end); } catch { return $"<type=0x{type:X}>"; }
        }

        private void WriteFileLine(string line)
        {
            lock (_fileSync)
            {
                try { _fileWriter?.WriteLine(line); } catch { }
            }
        }

        private void WriteResolverEvidence(string line)
        {
            WriteFileLine("[DYN-SKEL][CANDIDATE-EVIDENCE] " + line);
        }

        private void WriteLine(string line)
        {
            Console.WriteLine(line);
            lock (_fileSync)
            {
                try { _fileWriter?.WriteLine(line); } catch { }
            }
        }

        private void FlushFile()
        {
            lock (_fileSync)
            {
                try { _fileWriter?.Flush(); } catch { }
            }
        }

        public void Dispose()
        {
            if (Interlocked.Exchange(ref _disposed, 1) != 0)
                return;

            try { _timer?.Dispose(); } catch { }
            _timer = null;
            RuntimeDiagnostics.SetSkeletonEvidenceSink(null);
            lock (_fileSync)
            {
                try { _fileWriter?.Flush(); } catch { }
                try { _fileWriter?.Dispose(); } catch { }
                _fileWriter = null;
            }
        }
    }
}
```


---

## Record 07 — `RECON_HISTORY/STAGE67_VALIDATION_REPORT.txt`

<sub>Original size: 2025 bytes · Original SHA-256: `47d712a5aabae7b4a14777769e8e1097604f5084db4aaa589d34754b0769d51a`</sub>

STAGE 67 PACKAGE VALIDATION REPORT

Base package: ROS64Hack_STAGE66_BgaPriorityClosureRecon.zip
New active diagnostic: Core/Stage67VehicleTransitionRecon.cs
Active wiring: Overlay/HackOverlay.cs and Program.cs

Checks performed in this environment
1. The Stage 67 diagnostic source file exists and the active overlay constructs, starts,
   observes snapshots through, and disposes Stage67VehicleTransitionRecon.
2. Program.cs creates STAGE67_ATTACH_DIAGNOSTIC.txt and writes a Stage 67 build marker.
3. A C# lexical/delimiter scan was run across all C# files in the package. No unterminated
   string/comment or unmatched delimiter was detected.
4. Thirteen protected runtime files were byte-compared against the Stage 66 source package;
   all were identical:
     Core/DynamicSkeletonReader.cs
     Core/Mem.cs
     Core/Offsets.cs
     Core/WorldToScreen.cs
     Engine/Camera.cs
     Engine/EntityLoop.cs
     Engine/EntityData.cs
     Engine/PlayerReader.cs
     Features/Aimbot.cs
     Features/ESP.cs
     Features/NoClip.cs
     Features/EntityClassifier.cs
     Features/Settings.cs
5. The Stage 67 logic retains bounded target-reachable discovery, adds no process-wide scan,
   performs no process memory writes, and does not select a vehicle/bone winner automatically.

Not verified here
- A .NET build was NOT run because dotnet/csc/msbuild are unavailable in this environment.
- No live-game runtime test was performed. Build and attach must be validated on the user's
  Windows machine before interpreting the capture.

Key new evidence
- Per-sample raw BGA coordinates and step class, including large jumps in the trace.
- BGA-stationary interval detection.
- Raw BGA vs overlay EntityData snapshot comparison (the overlay snapshot is not an independent
  game-transform source).
- Candidate model/root transforms plus capped discovered-object transform probes.
- Final probe summaries separating candidate model-root movement from generic-object or other
  SpaceNode movement during BGA-stationary intervals.


---

## Record 08 — `RECON_HISTORY/STAGE68_VALIDATION_REPORT.txt`

<sub>Original size: 1582 bytes · Original SHA-256: `3d1e45ef477fdb7cb4a59b4a4d9d1ac29d73ed5d4e7a70fa2ff1869660ba7bd3`</sub>

STAGE 68 PACKAGE VALIDATION REPORT

Base package: ROS64Hack_STAGE67_VehicleTransitionRecon.zip
Active diagnostic: Core/Stage68TargetRootHierarchyRecon.cs
Active wiring: Overlay/HackOverlay.cs and Program.cs

Changes
1. Cloned Stage 67 into a separately named Stage 68 diagnostic; Stage 67 source retained as history.
2. Reordered only the focused-root fallback ranking: closest structurally valid candidate by discovery distance now precedes provenance tie-breakers.
3. Kept the Stage 67 raw BGA, root association, entity-snapshot and vehicle-handoff trace.
4. Changed active overlay wiring and attach/log file markers to Stage 68.
5. Added Stage 68 build/test notes and checksum manifest.

Static checks performed in this environment
- ZIP archive integrity tested.
- SHA256SUMS.txt regenerated and every listed hash verified.
- C# lexical/string/comment/delimiter scan passed across all C# files.
- Protected runtime components were byte-compared against the Stage 67 package and are unchanged:
  Core/DynamicSkeletonReader.cs, Core/Mem.cs, Core/Offsets.cs, Core/WorldToScreen.cs,
  Engine/Camera.cs, Engine/EntityLoop.cs, Engine/EntityData.cs, Engine/PlayerReader.cs,
  Features/Aimbot.cs, Features/ESP.cs, Features/NoClip.cs, Features/EntityClassifier.cs,
  Features/Settings.cs.
- The focused-root ordering change was found in Stage 68 and is absent from Stage 67's archived source.

Not verified
- A .NET build was not run because dotnet/csc/msbuild are unavailable in this environment.
- No live-game runtime test was performed. Build and attach must be verified on Windows.


---

## Record 09 — `RECON_HISTORY/Stage68TargetRootHierarchyRecon.cs.txt`

<sub>Original size: 104487 bytes · Original SHA-256: `f5fd19ed524a49a050c8159a343c5afffa2714832208eef10ff34c11ca76cdc7`</sub>

```csharp
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using ROS64Hack.Engine;

namespace ROS64Hack.Core
{
    /// <summary>
    /// Stage 68 preserves bounded target/root recon while adding a read-only time series
    /// for possible stale-position and transform-handoff behavior. It also prioritizes the nearest structurally-valid candidate for focused descendant sampling. Raw large BGA jumps
    /// remain visible even when excluded from the plausible-motion association heuristic.
    /// Transform probes are measurements only; no probe is assumed to be a vehicle or bone.
    ///
    /// No process-wide scan, memory writes, renderer changes, or DynamicSkeletonReader
    /// changes are performed.
    /// </summary>
    public sealed class Stage68TargetRootHierarchyRecon : IDisposable
    {
        private const int BGA_ID = 0x018;
        private const long MODEL_SKELETAL_VTABLE_RVA = 0x001C1ACE0;
        private const long SPACE_NODE_VTABLE_RVA = 0x001C137C8;
        private const int MODEL_SPACE_NODE = 0x038;
        private const int SPACE_MODEL = 0x040;
        private const int SPACE_WORLD_MATRIX = 0x148;
        private const int SPACE_WORLD_TRANSLATION = 0x178;
        private const int MATRIX_BYTES = 0x40;

        private const int SAMPLE_COUNT = 240;
        private const int SAMPLE_INTERVAL_MS = 250;
        private const int INITIAL_DELAY_MS = 500;
        private const int PRE_SAMPLE_DELAY_MS = 1000;
        private const int TARGET_SELECTION_SAMPLE_INTERVAL_MS = 250;
        private const int TARGET_SELECTION_WINDOW_MS = 4000;
        private const int TARGET_SELECTION_TIMEOUT_MS = 15000;
        private const int TARGET_SELECTION_STALE_MS = 1000;
        private const int MIN_TARGET_SELECTION_SAMPLES = 8;
        private const int MIN_TARGET_SELECTION_MOVING_TRANSITIONS = 3;
        private const float MAX_TARGET_SELECTION_STEP = 256f;
        private const float MAX_ASSOCIATION_TARGET_STEP = 256f;
        private const int BGA_READ_BYTES = 0x1000;
        private const int OBJECT_READ_BYTES = 0x1000;
        private const int ROOT_CENSUS_BYTES = 0x2000;
        private const int MAX_FOCUSED_ROOT_CANDIDATES = 4;
        private const int MAX_FOCUSED_NODES_PER_ROOT = 64;
        private const int MAX_FOCUSED_EDGES_PER_ROOT = 256;
        private const int MAX_FOCUSED_DEPTH = 3;
        private const int MAX_DISCOVERY_ATTEMPTS = 8;
        private const int MAX_FIRST_HOP_OBJECTS = 48;
        private const int MAX_NESTED_OBJECTS_PER_ATTEMPT = 192;
        private const int MAX_NESTED_DEPTH = 3;
        private const int MAX_TRANSFORM_PROBES = 192;
        private const int MAX_GENERIC_TRANSFORM_PROBES = 64;
        private const float BGA_STATIONARY_THRESHOLD = 0.10f;
        private const float PROBE_MOVEMENT_THRESHOLD = 0.50f;
        private const int MIN_STATIONARY_SAMPLES_FOR_HANDOFF = 4;
        private const long SNAPSHOT_STALE_MS = 1000;
        private const float SNAPSHOT_DIVERGENCE_THRESHOLD = 1.0f;
        private const int MAX_QUEUED_POINTERS = 4096;
        private const long IMAGE_SIZE = 0x05AEA000;
        private const int MAX_MODEL_CANDIDATES = 64;
        private const int MAX_SCENE_ANCHORS = 12;
        private const int MAX_SCENE_NODES = 64;
        private const int MAX_SCENE_EDGES = 512;
        private const int MAX_HIERARCHY_DEPTH = 6;
        private const int MAX_CHILD_POINTER_CHECKS = OBJECT_READ_BYTES / 8;
        private const float MAX_WORLD_COORD = 50000f;
        private const float ROOT_STEP_THRESHOLD = 0.05f;
        private const float TARGET_MOVEMENT_THRESHOLD = 0.5f;
        private const float MAX_NEAR_TARGET_DISTANCE = 128f;
        private const float MAX_NEAR_TARGET_DIAGNOSTIC_DISTANCE = 256f;
        private const int MIN_ASSOCIATION_MOVING_OBSERVATIONS = 20;
        private const float MIN_ASSOCIATION_RATIO = 0.80f;
        private const float MAX_ASSOCIATION_MEAN_DISTANCE = 64f;

        private readonly Mem _mem;
        private readonly object _sync = new();
        private readonly byte[] _bgaScratch = new byte[BGA_READ_BYTES];
        private readonly byte[] _objectScratch = new byte[OBJECT_READ_BYTES];
        private readonly byte[] _rootCensusScratch = new byte[ROOT_CENSUS_BYTES];
        private readonly byte[] _ptrScratch = new byte[8];
        private readonly byte[] _transformScratch = new byte[MATRIX_BYTES];
        private readonly byte[] _translationScratch = new byte[12];
        private readonly Dictionary<long, CandidateRecord> _candidates = new();
        private readonly Dictionary<(long Ptr, uint EntityId), TargetMotionRecord> _targetMotionRecords = new();
        private readonly Dictionary<long, SceneNodeRecord> _sceneNodes = new();
        private readonly Dictionary<long, TransformProbeRecord> _transformProbes = new();
        private readonly List<CandidateRecord> _focusedRootCandidates = new();
        private readonly HashSet<long> _sceneScanned = new();
        private readonly HashSet<(long Parent, long Child, int Offset)> _sceneEdgeKeys = new();
        private readonly Queue<PointerWorkItem> _nestedQueue = new();
        private readonly HashSet<long> _nestedQueued = new();
        private readonly HashSet<long> _nestedScanned = new();

        private StreamWriter _writer;
        private System.Threading.Timer _timer;
        private int _started;
        private int _disposed;
        private int _timerBusy;
        private int _sample;
        private bool _targetLocked;
        private bool _discoveryComplete;
        private bool _captureComplete;
        private bool _samplingDelayScheduled;
        private bool _waitForTargetLogged;
        private long _targetSelectionStartedMs;
        private long _lastTargetSelectionSampleMs;
        private long _lastTargetSelectionWaitLogMs;
        private string _targetSelectionMethod = "NOT_SELECTED";
        private int _targetSelectionSamples;
        private int _targetSelectionTransitions;
        private int _targetSelectionOutliers;
        private double _targetSelectionPlausibleStep;
        private int _targetOutlierTransitions;

        // Latest independently published entity snapshot for the locked BGA. This is
        // compared with the raw BGA fields at every timed diagnostic sample.
        private bool _latestSnapshotPresent;
        private long _latestSnapshotPtr;
        private uint _latestSnapshotId;
        private float _latestSnapshotX, _latestSnapshotY, _latestSnapshotZ;
        private long _latestSnapshotTicks;
        private int _snapshotSeenSamples;
        private int _snapshotMissingSamples;
        private int _snapshotDivergenceSamples;
        private long _associationStartMs;
        private int _targetStationaryRun;
        private int _targetStationarySamples;
        private int _targetStationaryEpisodes;
        private int _largeRawJumpTransitions;
        private float _largestRawJump;
        private int _genericTransformProbeCount;

        private long _targetPtr;
        private uint _targetId;
        private int _discoveryAttempts;
        private int _discoveryObjectsInspected;
        private int _firstHopObjectsOnLastAttempt;
        private int _nextPointerSweepOffset;
        private int _directModelCandidates;
        private int _nestedObjectsOnLastAttempt;
        private int _nestedObjectsTotalRead;
        private int _nestedReadFailures;
        private int _scenePointerReferences;
        private int _sceneAnchorsScanned;
        private int _targetLostSamples;
        private int _targetIdMismatchSamples;
        private int _targetMotionTransitions;
        private float _targetTotalStep;
        private float _previousTargetX;
        private float _previousTargetY;
        private float _previousTargetZ;
        private bool _hasPreviousTarget;

        private sealed class SceneNodeRecord
        {
            public long Ptr;
            public long Owner;
            public int Depth;
            public string FirstPath;
        }

        private sealed class TransformProbeRecord
        {
            public long Ptr;
            public long Vtable;
            public string Path;
            public int Priority;
            public int ValidSamples;
            public int InvalidSamples;
            public int MovingTransitions;
            public int MovesWhileBgaStationary;
            public int SamplesWhileBgaStationary;
            public float TotalStep;
            public float MaxStep;
            public float MinTargetDistance = float.MaxValue;
            public float MaxTargetDistance;
            public double TargetDistanceSum;
            public float LastStep;
            public float LastDistance = float.NaN;
            public string LastSource = "NONE";
            public bool HasPrevious;
            public float PreviousX, PreviousY, PreviousZ;
        }

        private sealed class TargetMotionRecord
        {
            public long Ptr;
            public uint EntityId;
            public int Samples;
            public int MovingTransitions;
            public int OutlierSteps;
            public double PlausibleTotalStep;
            public long LastSeenMs;
            public bool HasPrevious;
            public float PreviousX, PreviousY, PreviousZ;
        }

        private sealed class PointerWorkItem
        {
            public long Ptr;
            public int Depth;
            public string Path;
        }

        private sealed class CandidateRecord
        {
            public long ModelPtr;
            public long RootPtr;
            public string Path;
            public bool FromBgaClosure;
            public long SourceNodePtr;
            public float DiscoveryDistance = float.NaN;

            public int StructurallyValidSamples;
            public int StructurallyInvalidSamples;
            public int ValidTransformSamples;
            public int Near128Samples;
            public int Near256Samples;
            public int TargetMovingObservations;
            public int RelativeStableWhileTargetMoves;
            public int CoMotionSamples;

            public float MinDistance = float.MaxValue;
            public float MaxDistance;
            public double DistanceSum;
            public float TotalRootStep;
            public float TotalRelativeStep;
            public float MaxRelativeStep;
            public float LastDistance = float.NaN;

            public bool HasPrevious;
            public float PreviousX;
            public float PreviousY;
            public float PreviousZ;
            public float PreviousRx;
            public float PreviousRy;
            public float PreviousRz;
            public readonly Dictionary<long, FocusedNodeRecord> FocusedNodes = new();
            public readonly List<FocusedEdgeRecord> FocusedEdges = new();
            public readonly HashSet<(long Source, long Target, int Offset)> FocusedEdgeKeys = new();
        }

        private sealed class FocusedNodeRecord
        {
            public long NodePtr;
            public long OwnerPtr;
            public int Depth;
            public string FirstPath;
            public int StructuralValidSamples;
            public int StructuralInvalidSamples;
            public int OwnerMatchesCandidateSamples;
            public int OwnerIsModelSamples;
            public int ValidTransformSamples;
            public int TargetMovingObservations;
            public int StableRelativeToTargetWhileMoving;
            public int CoMotionSamples;
            public float MinTargetDistance = float.MaxValue;
            public float MaxTargetDistance;
            public double TargetDistanceSum;
            public float TotalNodeStep;
            public float TotalTargetRelativeStep;
            public float TotalRootRelativeStep;
            public float MaxTargetRelativeStep;
            public float MaxRootRelativeStep;
            public bool HasPrevious;
            public float PreviousX, PreviousY, PreviousZ;
            public float PreviousTargetRx, PreviousTargetRy, PreviousTargetRz;
            public float PreviousRootRx, PreviousRootRy, PreviousRootRz;
        }

        private sealed class FocusedEdgeRecord
        {
            public long SourcePtr;
            public long TargetPtr;
            public int Offset;
            public int Depth;
            public string Role;
            public string Path;
        }

        public Stage68TargetRootHierarchyRecon(Mem mem)
        {
            _mem = mem ?? throw new ArgumentNullException(nameof(mem));
        }

        public void Start()
        {
            if (Interlocked.Exchange(ref _started, 1) != 0)
                return;

            try
            {
                string path = Path.Combine(Environment.CurrentDirectory, "STAGE68_TARGET_ROOT_HIERARCHY_RECON.txt");
                _writer = new StreamWriter(
                    new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.ReadWrite))
                {
                    AutoFlush = false,
                };

                Write("============================================================");
                Write("STAGE 67 — TARGET-ROOT HIERARCHY AND TRANSFORM-ARTICULATION RECON");
                Write("============================================================");
                Write($"[STAGE68][CONFIG] samples={SAMPLE_COUNT} intervalMs={SAMPLE_INTERVAL_MS} sampleSeconds={SAMPLE_COUNT * SAMPLE_INTERVAL_MS / 1000.0:F1} preSampleDelayMs={PRE_SAMPLE_DELAY_MS}");
                Write($"[STAGE68][CONFIG] ModelSkeletalVtable=0x{_mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA:X} SpaceNodeVtable=0x{_mem.BaseAddress + SPACE_NODE_VTABLE_RVA:X}");
                Write("[STAGE68][POLICY] processWideScan=0 memoryWrites=0 rendererChanges=0 DynamicSkeletonReaderChanges=0 anatomicalWinner=0");
                Write($"[STAGE68][BUDGET] discoveryAttempts={MAX_DISCOVERY_ATTEMPTS} firstHopObjectsPerAttempt={MAX_FIRST_HOP_OBJECTS} nestedObjectsPerAttempt={MAX_NESTED_OBJECTS_PER_ATTEMPT} nestedDepth={MAX_NESTED_DEPTH} maxQueuedPointers={MAX_QUEUED_POINTERS} modelCandidates={MAX_MODEL_CANDIDATES} sceneAnchors={MAX_SCENE_ANCHORS} sceneNodes={MAX_SCENE_NODES} sceneEdges={MAX_SCENE_EDGES} sceneDepth={MAX_HIERARCHY_DEPTH} focusedRoots={MAX_FOCUSED_ROOT_CANDIDATES} rootCensusBytes=0x{ROOT_CENSUS_BYTES:X} focusedNodesPerRoot={MAX_FOCUSED_NODES_PER_ROOT} focusedEdgesPerRoot={MAX_FOCUSED_EDGES_PER_ROOT} focusedDepth={MAX_FOCUSED_DEPTH}");
                Write("[STAGE68][DISCOVERY-ORDER] priorityBgaOffsets=+0x0A8,+0x0B8,+0x128,+0x130,+0x048,+0x648; useful target routes first, high-fanout +0x648 last; aligned BGA pointer sweep; bounded nested closure; no fixed runtime object addresses");
                Write("[STAGE68][PURPOSE] retain Stage 67 raw BGA / handoff telemetry while ensuring the nearest candidate root receives focused descendant-space-node sampling; compare node motion against both the selected BGA and the candidate root");
                Write($"[STAGE68][HANDOFF-CONFIG] samples={SAMPLE_COUNT} durationSeconds={SAMPLE_COUNT * SAMPLE_INTERVAL_MS / 1000.0:F1} stationaryThreshold={BGA_STATIONARY_THRESHOLD:F2} minimumStationarySamples={MIN_STATIONARY_SAMPLES_FOR_HANDOFF} probeMoveThreshold={PROBE_MOVEMENT_THRESHOLD:F2} snapshotStaleMs={SNAPSHOT_STALE_MS} snapshotDivergenceThreshold={SNAPSHOT_DIVERGENCE_THRESHOLD:F2} maxTransformProbes={MAX_TRANSFORM_PROBES} maxGenericProbes={MAX_GENERIC_TRANSFORM_PROBES}");
                Write($"[STAGE68][FILE] {Path.GetFullPath(path)}");
                Write("[STAGE68][CAPTURE-STARTED] observing valid enemies before locking the most consistently moving target; any large raw BGA jump is logged, not erased from the trace");
                Write("------------------------------------------------------------");

                _timer = new System.Threading.Timer(TimerTick, null, INITIAL_DELAY_MS, SAMPLE_INTERVAL_MS);
            }
            catch (Exception ex)
            {
                SafeConsole($"[STAGE68][START-FAILED] {ex.GetType().Name}: {ex.Message}");
            }
        }

        public void ObserveSnapshot(List<EntityData> enemies)
        {
            if (Volatile.Read(ref _disposed) != 0 ||
                Volatile.Read(ref _started) == 0 ||
                enemies == null)
                return;

            long now = Environment.TickCount64;
            lock (_sync)
            {
                if (_targetLocked)
                {
                    EntityData lockedSnapshot = enemies.FirstOrDefault(e => e != null && e.Ptr == _targetPtr);
                    _latestSnapshotPresent = lockedSnapshot != null;
                    if (lockedSnapshot != null)
                    {
                        _latestSnapshotPtr = lockedSnapshot.Ptr;
                        _latestSnapshotId = lockedSnapshot.EntityId;
                        _latestSnapshotX = lockedSnapshot.X;
                        _latestSnapshotY = lockedSnapshot.Y;
                        _latestSnapshotZ = lockedSnapshot.Z;
                        _latestSnapshotTicks = now;
                    }
                    return;
                }

                if (_targetSelectionStartedMs == 0)
                {
                    _targetSelectionStartedMs = now;
                    _lastTargetSelectionSampleMs = now - TARGET_SELECTION_SAMPLE_INTERVAL_MS;
                    Write("[STAGE68][TARGET-SELECTION-START] sampling all valid enemy snapshots before locking; choose by plausible motion, not list order");
                }

                if (now - _lastTargetSelectionSampleMs < TARGET_SELECTION_SAMPLE_INTERVAL_MS)
                    return;
                _lastTargetSelectionSampleMs = now;

                foreach (EntityData enemy in enemies)
                {
                    if (enemy?.IsEnemy != true ||
                        !IsPtr(enemy.Ptr) || enemy.EntityId == 0 ||
                        !IsValidCoordinate(enemy.X) ||
                        !IsValidCoordinate(enemy.Y) ||
                        !IsValidCoordinate(enemy.Z))
                        continue;

                    var key = (enemy.Ptr, enemy.EntityId);
                    if (!_targetMotionRecords.TryGetValue(key, out TargetMotionRecord record))
                    {
                        record = new TargetMotionRecord { Ptr = enemy.Ptr, EntityId = enemy.EntityId };
                        _targetMotionRecords[key] = record;
                    }

                    record.LastSeenMs = now;
                    record.Samples++;
                    if (record.HasPrevious)
                    {
                        float step = Distance(record.PreviousX, record.PreviousY, record.PreviousZ,
                            enemy.X, enemy.Y, enemy.Z);
                        if (float.IsFinite(step) && step >= TARGET_MOVEMENT_THRESHOLD && step <= MAX_TARGET_SELECTION_STEP)
                        {
                            record.MovingTransitions++;
                            record.PlausibleTotalStep += step;
                        }
                        else if (float.IsFinite(step) && step > MAX_TARGET_SELECTION_STEP)
                        {
                            record.OutlierSteps++;
                        }
                    }

                    record.PreviousX = enemy.X;
                    record.PreviousY = enemy.Y;
                    record.PreviousZ = enemy.Z;
                    record.HasPrevious = true;
                }

                long elapsedMs = now - _targetSelectionStartedMs;
                List<TargetMotionRecord> live = _targetMotionRecords.Values
                    .Where(r => now - r.LastSeenMs <= TARGET_SELECTION_STALE_MS &&
                                r.Samples >= MIN_TARGET_SELECTION_SAMPLES)
                    .ToList();

                bool activeTargetFound = elapsedMs >= TARGET_SELECTION_WINDOW_MS &&
                    live.Any(r => r.MovingTransitions >= MIN_TARGET_SELECTION_MOVING_TRANSITIONS);
                bool selectionTimedOut = elapsedMs >= TARGET_SELECTION_TIMEOUT_MS;
                if (!activeTargetFound && !selectionTimedOut)
                    return;

                TargetMotionRecord selected = live
                    .OrderByDescending(r => r.MovingTransitions)
                    .ThenByDescending(r => r.PlausibleTotalStep)
                    .ThenByDescending(r => r.Samples)
                    .ThenBy(r => r.EntityId)
                    .FirstOrDefault();

                if (selected == null)
                {
                    if (now - _lastTargetSelectionWaitLogMs >= 2000)
                    {
                        _lastTargetSelectionWaitLogMs = now;
                        Write($"[STAGE68][TARGET-SELECTION-WAIT] elapsedMs={elapsedMs} validTrackedTargets={_targetMotionRecords.Count} no currently visible target has {MIN_TARGET_SELECTION_SAMPLES}+ samples");
                    }
                    return;
                }

                _targetPtr = selected.Ptr;
                _targetId = selected.EntityId;
                _targetSelectionMethod = activeTargetFound ? "MOST_MOVED_TARGET" : "BEST_AVAILABLE_TIMEOUT_FALLBACK";
                _targetSelectionSamples = selected.Samples;
                _targetSelectionTransitions = selected.MovingTransitions;
                _targetSelectionOutliers = selected.OutlierSteps;
                _targetSelectionPlausibleStep = selected.PlausibleTotalStep;
                _targetLocked = true;

                Write($"[STAGE68][TARGET-LOCK] bga=0x{_targetPtr:X} id=0x{_targetId:X8} selectionMethod={_targetSelectionMethod} preselectionSamples={_targetSelectionSamples} plausibleMovingTransitions={_targetSelectionTransitions} plausibleTotalStep={_targetSelectionPlausibleStep:F3} outlierSteps={_targetSelectionOutliers} elapsedMs={elapsedMs}");
                int rank = 0;
                foreach (TargetMotionRecord item in _targetMotionRecords.Values
                    .Where(r => now - r.LastSeenMs <= TARGET_SELECTION_STALE_MS)
                    .OrderByDescending(r => r.MovingTransitions)
                    .ThenByDescending(r => r.PlausibleTotalStep)
                    .ThenByDescending(r => r.Samples)
                    .Take(5))
                {
                    rank++;
                    Write($"[STAGE68][TARGET-SELECTION-CANDIDATE] rank={rank} bga=0x{item.Ptr:X} id=0x{item.EntityId:X8} samples={item.Samples} plausibleMovingTransitions={item.MovingTransitions} plausibleTotalStep={item.PlausibleTotalStep:F3} outlierSteps={item.OutlierSteps}");
                }
                Write("[STAGE68][TARGET-SELECTION-VERDICT] the selected enemy had the strongest plausible movement history available; this does not prove any candidate is a skeletal bone hierarchy");
            }
        }

        private void TimerTick(object state)
        {
            if (Volatile.Read(ref _disposed) != 0 || _captureComplete)
                return;
            if (Interlocked.Exchange(ref _timerBusy, 1) != 0)
                return;

            try
            {
                if (!_targetLocked)
                {
                    if (!_waitForTargetLogged)
                    {
                        Write("[STAGE68][WAIT] no live enemy target snapshot yet");
                        _waitForTargetLogged = true;
                    }
                    return;
                }

                if (!_discoveryComplete)
                {
                    _discoveryAttempts++;
                    bool found = RunDiscoveryPass();
                    if (found)
                    {
                        _discoveryComplete = true;
                        _hasPreviousTarget = false;
                        foreach (CandidateRecord c in _candidates.Values)
                            ResetCandidateSampling(c);

                        PrepareFocusedRootCensuses();
                        Write($"[STAGE68][DISCOVERY-COMPLETE] attempts={_discoveryAttempts} candidates={_candidates.Count} sceneNodes={_sceneNodes.Count} pointerReferences={_scenePointerReferences} focusedRoots={_focusedRootCandidates.Count}");
                        Write("[STAGE68][PREPARE] sampling begins in 1 second; the selected target is an enemy entity, not the local player");
                        Write("[STAGE68][MOTION-PROTOCOL] keep the selected enemy visible and moving where possible; movement by the local player does not count as target movement");
                        _samplingDelayScheduled = true;
                        _timer?.Change(PRE_SAMPLE_DELAY_MS, SAMPLE_INTERVAL_MS);
                        return;
                    }

                    if (_discoveryAttempts >= MAX_DISCOVERY_ATTEMPTS)
                    {
                        Write($"[STAGE68][DISCOVERY-EXHAUSTED] attempts={_discoveryAttempts} noCandidatePool=1 objectsInspectedLastAttempt={_firstHopObjectsOnLastAttempt}; stopping instead of repeating an unbounded scan");
                        EmitFinal("NO_CANDIDATE_POOL");
                        CompleteCapture();
                    }
                    return;
                }

                if (_samplingDelayScheduled)
                {
                    _samplingDelayScheduled = false;
                    Write("[STAGE68][ASSOCIATION-SAMPLING-START]");
                }

                if (_sample >= SAMPLE_COUNT)
                {
                    EmitFinal("SAMPLE_WINDOW_COMPLETE");
                    CompleteCapture();
                    return;
                }

                RunAssociationSample();
                _sample++;
                if (_sample >= SAMPLE_COUNT)
                {
                    EmitFinal("SAMPLE_WINDOW_COMPLETE");
                    CompleteCapture();
                }
            }
            catch (Exception ex)
            {
                Write($"[STAGE68][EXCEPTION] sample={_sample} {ex.GetType().Name}: {ex.Message}");
            }
            finally
            {
                Volatile.Write(ref _timerBusy, 0);
            }
        }

        private bool RunDiscoveryPass()
        {
            if (!TryReadTarget(out uint liveId, out float tx, out float ty, out float tz))
            {
                Write($"[STAGE68][DISCOVERY-RETRY] attempt={_discoveryAttempts} reason=lockedBgaUnreadable");
                return false;
            }

            if (liveId != _targetId)
            {
                _targetIdMismatchSamples++;
                Write($"[STAGE68][TARGET-ID-MISMATCH] locked=0x{_targetId:X8} live=0x{liveId:X8} attempt={_discoveryAttempts}");
                return false;
            }

            var directCandidates = new Dictionary<long, CandidateRecord>();
            var scannedFirstHop = new HashSet<long>();
            int firstHopObjects = 0;

            // The earlier captures found useful target-reachable model paths under BGA+0x0A8
            // and BGA+0x0B8. Inspect those roots before the high-fanout BGA+0x648 branch.
            // All pointer values are read at runtime; no process-specific address is embedded.
            int[] priorityOffsets = { 0x0A8, 0x0B8, 0x128, 0x130, 0x048, 0x648 };
            foreach (int offset in priorityOffsets)
            {
                if (firstHopObjects >= MAX_FIRST_HOP_OBJECTS)
                    break;
                long pointer = ReadPtr(_targetPtr + offset);
                Write($"[STAGE68][PRIORITY-SEED] bgaOffset=+0x{offset:X3} ptr=0x{pointer:X}");
                InspectFirstHopObject(pointer, $"BGA+0x{offset:X3}", tx, ty, tz,
                    directCandidates, scannedFirstHop, ref firstHopObjects);
            }

            int sweepStartOffset = _nextPointerSweepOffset;
            if (_mem.ReadBytesQuiet(_targetPtr, _bgaScratch, 0, _bgaScratch.Length))
            {
                var seenBgaPointers = new HashSet<long>();
                int slotCount = _bgaScratch.Length / 8;
                for (int checks = 0; checks < slotCount; checks++)
                {
                    int offset = (sweepStartOffset + checks * 8) % _bgaScratch.Length;
                    if (firstHopObjects >= MAX_FIRST_HOP_OBJECTS)
                    {
                        _nextPointerSweepOffset = offset;
                        break;
                    }

                    long pointer = ReadQword(_bgaScratch, offset);
                    _nextPointerSweepOffset = (offset + 8) % _bgaScratch.Length;
                    if (!IsPtr(pointer) || !seenBgaPointers.Add(pointer) || scannedFirstHop.Contains(pointer))
                        continue;

                    InspectFirstHopObject(pointer, $"BGA+0x{offset:X3}", tx, ty, tz,
                        directCandidates, scannedFirstHop, ref firstHopObjects);
                }
            }

            int nestedThisAttempt = ProcessNestedPointerQueue(tx, ty, tz, directCandidates);
            _nestedObjectsOnLastAttempt = nestedThisAttempt;
            _firstHopObjectsOnLastAttempt = firstHopObjects;
            _discoveryObjectsInspected += firstHopObjects + nestedThisAttempt;
            _directModelCandidates = directCandidates.Count;
            Write($"[STAGE68][DISCOVERY-SCAN] attempt={_discoveryAttempts} sweepStart=+0x{sweepStartOffset:X3} sweepNext=+0x{_nextPointerSweepOffset:X3} bgaSeedObjects={firstHopObjects} nestedObjects={nestedThisAttempt} queuedPending={_nestedQueue.Count} directOrNestedModels={directCandidates.Count} cumulativeObjects={_discoveryObjectsInspected}");

            if (directCandidates.Count == 0)
                return false;

            _candidates.Clear();
            _sceneNodes.Clear();
            _sceneScanned.Clear();
            _sceneEdgeKeys.Clear();
            _scenePointerReferences = 0;

            foreach (CandidateRecord candidate in directCandidates.Values)
                AddCandidate(candidate);

            // Stage 63 scanned only the nearest four direct candidates. That missed
            // useful provenance paths such as the previously productive BGA+0x0B8
            // closure. Stage 68 takes one candidate per known BGA path first, then
            // fills the remaining bounded anchor budget by distance.
            string[] preferredPathTokens =
            {
                "BGA+0x0A8", "BGA+0x0B8", "BGA+0x128", "BGA+0x130",
                "BGA+0x048", "BGA+0x648", "BGA+0x298", "BGA+0x118"
            };
            var anchors = new List<CandidateRecord>();
            var anchorModels = new HashSet<long>();
            foreach (string token in preferredPathTokens)
            {
                CandidateRecord routeCandidate = directCandidates.Values
                    .Where(c => !string.IsNullOrEmpty(c.Path) && c.Path.Contains(token, StringComparison.Ordinal))
                    .OrderBy(c => float.IsFinite(c.DiscoveryDistance) ? c.DiscoveryDistance : float.MaxValue)
                    .ThenBy(c => c.ModelPtr)
                    .FirstOrDefault();
                if (routeCandidate != null && anchorModels.Add(routeCandidate.ModelPtr))
                    anchors.Add(routeCandidate);
                if (anchors.Count >= MAX_SCENE_ANCHORS)
                    break;
            }

            foreach (CandidateRecord candidate in directCandidates.Values
                .OrderBy(c => float.IsFinite(c.DiscoveryDistance) ? c.DiscoveryDistance : float.MaxValue)
                .ThenBy(c => c.ModelPtr))
            {
                if (anchors.Count >= MAX_SCENE_ANCHORS)
                    break;
                if (anchorModels.Add(candidate.ModelPtr))
                    anchors.Add(candidate);
            }
            Write($"[STAGE68][SCENE-ANCHOR-PLAN] directCandidates={directCandidates.Count} selectedAnchors={anchors.Count} cap={MAX_SCENE_ANCHORS} policy=one-per-priority-path-then-nearest; tokens={string.Join(",", preferredPathTokens)}");

            foreach (CandidateRecord anchor in anchors)
            {
                if (_sceneNodes.Count >= MAX_SCENE_NODES)
                    break;
                _sceneAnchorsScanned++;
                Write($"[STAGE68][SCENE-ANCHOR] index={_sceneAnchorsScanned} model=0x{anchor.ModelPtr:X} root=0x{anchor.RootPtr:X} distance={FormatDistance(anchor.DiscoveryDistance)} directPath={anchor.Path}");
                ScanSceneClosure(anchor, tx, ty, tz);
            }

            Write($"[STAGE68][SCENE-SUMMARY] scannedAnchors={Math.Min(_sceneAnchorsScanned, MAX_SCENE_ANCHORS)} exactSpaceNodes={_sceneNodes.Count} pointerReferences={_scenePointerReferences} uniqueModelCandidates={_candidates.Count}");
            foreach (CandidateRecord candidate in _candidates.Values
                .OrderBy(c => float.IsFinite(c.DiscoveryDistance) ? c.DiscoveryDistance : float.MaxValue)
                .ThenBy(c => c.ModelPtr))
            {
                RegisterTransformProbe(candidate.ModelPtr, ReadPtr(candidate.ModelPtr), candidate.Path + "::Model", 3);
                RegisterTransformProbe(candidate.RootPtr, ReadPtr(candidate.RootPtr), candidate.Path + "::RootSpaceNode", 4);
                Write($"[STAGE68][CANDIDATE-BASELINE] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} discoveryDistance={FormatDistance(candidate.DiscoveryDistance)} fromBgaClosure={(candidate.FromBgaClosure ? 1 : 0)} sourceNode=0x{candidate.SourceNodePtr:X} path={candidate.Path}");
            }

            Write("[STAGE68][CANDIDATE-POOL-READY] no candidate was selected; every candidate root enters the same association window");
            return _candidates.Count > 0;
        }

        private void InspectFirstHopObject(
            long firstHopPtr,
            string sourceLabel,
            float tx,
            float ty,
            float tz,
            Dictionary<long, CandidateRecord> directCandidates,
            HashSet<long> scannedFirstHop,
            ref int firstHopObjects)
        {
            if (!IsPtr(firstHopPtr) || !scannedFirstHop.Add(firstHopPtr) ||
                firstHopObjects >= MAX_FIRST_HOP_OBJECTS)
                return;

            firstHopObjects++;
            long firstHopVtable = ReadPtr(firstHopPtr);
            RegisterTransformProbe(firstHopPtr, firstHopVtable, sourceLabel,
                firstHopVtable == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA ? 4 :
                firstHopVtable == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA ? 3 : 1);
            if (firstHopObjects <= 24)
                Write($"[STAGE68][FIRST-HOP] source={sourceLabel} ptr=0x{firstHopPtr:X} vtable=0x{firstHopVtable:X}");

            if (TryValidateModelCandidate(firstHopPtr, sourceLabel, tx, ty, tz, true, 0,
                out CandidateRecord directCandidate))
            {
                AddCandidateToDictionary(directCandidates, directCandidate);
                Write($"[STAGE68][DIRECT-MODEL-HIT] model=0x{directCandidate.ModelPtr:X} root=0x{directCandidate.RootPtr:X} distance={FormatDistance(directCandidate.DiscoveryDistance)} path={sourceLabel}");
                return;
            }

            if (!_mem.ReadBytesQuiet(firstHopPtr, _objectScratch, 0, _objectScratch.Length))
                return;

            // This object's full field block has already been inspected as a BGA seed;
            // do not process it a second time if a nested pointer cycles back to it.
            _nestedScanned.Add(firstHopPtr);

            long modelVtable = _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;
            long spaceNodeVtable = _mem.BaseAddress + SPACE_NODE_VTABLE_RVA;
            var localChildren = new HashSet<long>();
            for (int offset = 0, checks = 0;
                 offset + 8 <= _objectScratch.Length && checks < MAX_CHILD_POINTER_CHECKS;
                 offset += 8, checks++)
            {
                long child = ReadQword(_objectScratch, offset);
                if (!IsPtr(child) || child == firstHopPtr || !localChildren.Add(child))
                    continue;

                long childVtable = ReadPtr(child);
                string childPath = $"{sourceLabel}->0x{firstHopPtr:X}+0x{offset:X3}";
                if (childVtable == modelVtable &&
                    TryValidateModelCandidate(child, childPath, tx, ty, tz, true, 0,
                        out CandidateRecord candidate))
                {
                    AddCandidateToDictionary(directCandidates, candidate);
                    Write($"[STAGE68][MODEL-HIT][BGA-OBJECT] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} distance={FormatDistance(candidate.DiscoveryDistance)} path={candidate.Path}");
                }
                else if (childVtable == spaceNodeVtable)
                {
                    RegisterTransformProbe(child, childVtable, childPath, 4);
                    long owner = ReadPtr(child + SPACE_MODEL);
                    if (TryValidateModelCandidate(owner, $"{childPath}->SpaceNodeOwner", tx, ty, tz,
                        true, child, out CandidateRecord ownerCandidate))
                    {
                        AddCandidateToDictionary(directCandidates, ownerCandidate);
                        Write($"[STAGE68][MODEL-HIT][SPACE-NODE-OWNER] model=0x{ownerCandidate.ModelPtr:X} root=0x{ownerCandidate.RootPtr:X} sourceNode=0x{child:X} distance={FormatDistance(ownerCandidate.DiscoveryDistance)} path={ownerCandidate.Path}");
                    }
                }

                // Exact executable-image vtables are high-priority nested objects. Small
                // sentinel/container records (vtable 1) are also followed, but the global
                // pending/scan budgets prevent a broad or unbounded walk.
                if (ShouldQueueNestedPointer(childVtable) && offset + 8 <= _objectScratch.Length)
                    QueueNestedPointer(child, 1, childPath);
            }
        }

        private int ProcessNestedPointerQueue(
            float tx,
            float ty,
            float tz,
            Dictionary<long, CandidateRecord> directCandidates)
        {
            int processed = 0;
            long modelVtable = _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;
            long spaceNodeVtable = _mem.BaseAddress + SPACE_NODE_VTABLE_RVA;

            while (_nestedQueue.Count > 0 && processed < MAX_NESTED_OBJECTS_PER_ATTEMPT)
            {
                PointerWorkItem item = _nestedQueue.Dequeue();
                if (item == null || item.Depth > MAX_NESTED_DEPTH || !IsPtr(item.Ptr) ||
                    !_nestedScanned.Add(item.Ptr))
                    continue;

                if (!_mem.ReadBytesQuiet(item.Ptr, _objectScratch, 0, _objectScratch.Length))
                {
                    _nestedReadFailures++;
                    if (_nestedReadFailures <= 24)
                        Write($"[STAGE68][NESTED-READ-FAILED] ptr=0x{item.Ptr:X} depth={item.Depth} path={item.Path}");
                    continue;
                }

                processed++;
                long objectVtable = ReadQword(_objectScratch, 0);
                RegisterTransformProbe(item.Ptr, objectVtable, item.Path,
                    objectVtable == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA ? 4 :
                    objectVtable == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA ? 3 : 1);
                if (processed <= 24 || objectVtable == modelVtable || objectVtable == spaceNodeVtable)
                    Write($"[STAGE68][NESTED-OBJECT] ptr=0x{item.Ptr:X} depth={item.Depth} vtable=0x{objectVtable:X} path={item.Path}");

                if (objectVtable == modelVtable &&
                    TryValidateModelCandidate(item.Ptr, item.Path, tx, ty, tz, true, 0,
                        out CandidateRecord selfCandidate))
                {
                    AddCandidateToDictionary(directCandidates, selfCandidate);
                    Write($"[STAGE68][MODEL-HIT][NESTED-OBJECT] model=0x{selfCandidate.ModelPtr:X} root=0x{selfCandidate.RootPtr:X} distance={FormatDistance(selfCandidate.DiscoveryDistance)} path={selfCandidate.Path}");
                }
                else if (objectVtable == spaceNodeVtable)
                {
                    RegisterTransformProbe(item.Ptr, objectVtable, item.Path, 4);
                    long owner = ReadQword(_objectScratch, SPACE_MODEL);
                    if (TryValidateModelCandidate(owner, $"{item.Path}->SpaceNodeOwner", tx, ty, tz,
                        true, item.Ptr, out CandidateRecord ownerCandidate))
                    {
                        AddCandidateToDictionary(directCandidates, ownerCandidate);
                        Write($"[STAGE68][MODEL-HIT][NESTED-SPACE-NODE-OWNER] model=0x{ownerCandidate.ModelPtr:X} root=0x{ownerCandidate.RootPtr:X} sourceNode=0x{item.Ptr:X} distance={FormatDistance(ownerCandidate.DiscoveryDistance)} path={ownerCandidate.Path}");
                    }
                }

                var localChildren = new HashSet<long>();
                for (int offset = 0, checks = 0;
                     offset + 8 <= _objectScratch.Length && checks < MAX_CHILD_POINTER_CHECKS;
                     offset += 8, checks++)
                {
                    long child = ReadQword(_objectScratch, offset);
                    if (!IsPtr(child) || child == item.Ptr || !localChildren.Add(child))
                        continue;

                    long childVtable = ReadPtr(child);
                    string childPath = $"{item.Path}/+0x{offset:X3}";
                    if (childVtable == modelVtable &&
                        TryValidateModelCandidate(child, childPath, tx, ty, tz, true, 0,
                            out CandidateRecord candidate))
                    {
                        AddCandidateToDictionary(directCandidates, candidate);
                        Write($"[STAGE68][MODEL-HIT][NESTED-FIELD] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} distance={FormatDistance(candidate.DiscoveryDistance)} path={candidate.Path}");
                    }
                    else if (childVtable == spaceNodeVtable)
                    {
                        RegisterTransformProbe(child, childVtable, childPath, 4);
                        long owner = ReadPtr(child + SPACE_MODEL);
                        if (TryValidateModelCandidate(owner, $"{childPath}->SpaceNodeOwner", tx, ty, tz,
                            true, child, out CandidateRecord ownerCandidate))
                        {
                            AddCandidateToDictionary(directCandidates, ownerCandidate);
                            Write($"[STAGE68][MODEL-HIT][NESTED-OWNER] model=0x{ownerCandidate.ModelPtr:X} root=0x{ownerCandidate.RootPtr:X} sourceNode=0x{child:X} distance={FormatDistance(ownerCandidate.DiscoveryDistance)} path={ownerCandidate.Path}");
                        }
                    }

                    if (item.Depth < MAX_NESTED_DEPTH && ShouldQueueNestedPointer(childVtable))
                        QueueNestedPointer(child, item.Depth + 1, childPath);
                }
            }

            _nestedObjectsTotalRead += processed;
            Write($"[STAGE68][NESTED-CLOSURE] processedThisAttempt={processed} totalObjectsRead={_nestedObjectsTotalRead} uniquePointersSeen={_nestedScanned.Count} pending={_nestedQueue.Count} queuedCap={MAX_QUEUED_POINTERS} maxDepth={MAX_NESTED_DEPTH} readFailures={_nestedReadFailures} modelCandidates={directCandidates.Count}");
            return processed;
        }

        private bool ShouldQueueNestedPointer(long vtable)
        {
            if (vtable == 1)
                return true;

            long baseAddress = _mem.BaseAddress;
            return vtable >= baseAddress && vtable < baseAddress + IMAGE_SIZE;
        }

        private void QueueNestedPointer(long ptr, int depth, string path)
        {
            if (!IsPtr(ptr) || depth > MAX_NESTED_DEPTH || _nestedQueued.Contains(ptr) ||
                _nestedScanned.Contains(ptr) || _nestedQueued.Count >= MAX_QUEUED_POINTERS)
                return;

            _nestedQueued.Add(ptr);
            _nestedQueue.Enqueue(new PointerWorkItem { Ptr = ptr, Depth = depth, Path = path });
        }

        private bool TryValidateModelCandidate(
            long modelPtr,
            string path,
            float tx,
            float ty,
            float tz,
            bool fromBgaClosure,
            long sourceNodePtr,
            out CandidateRecord candidate)
        {
            candidate = null;
            if (!IsPtr(modelPtr))
                return false;

            long modelVtable = ReadPtr(modelPtr);
            if (modelVtable != _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA)
                return false;

            long root = ReadPtr(modelPtr + MODEL_SPACE_NODE);
            if (!IsPtr(root))
                return false;
            long rootVtable = ReadPtr(root);
            if (rootVtable != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA ||
                ReadPtr(root + SPACE_MODEL) != modelPtr)
                return false;

            float distance = float.NaN;
            if (TryReadNodeTransform(root, tx, ty, tz,
                out _, out _, out _, out _, out float d))
                distance = d;

            RegisterTransformProbe(modelPtr, modelVtable, path + "::Model", 3);
            RegisterTransformProbe(root, rootVtable, path + "::RootSpaceNode", 4);

            candidate = new CandidateRecord
            {
                ModelPtr = modelPtr,
                RootPtr = root,
                Path = path,
                FromBgaClosure = fromBgaClosure,
                SourceNodePtr = sourceNodePtr,
                DiscoveryDistance = distance,
            };
            return true;
        }

        private void ScanSceneClosure(CandidateRecord anchor, float tx, float ty, float tz)
        {
            var queue = new Queue<(long Ptr, int Depth, string Path)>();
            queue.Enqueue((anchor.RootPtr, 0, $"ANCHOR-0x{anchor.ModelPtr:X}"));

            while (queue.Count > 0 && _sceneNodes.Count < MAX_SCENE_NODES)
            {
                (long ptr, int depth, string path) = queue.Dequeue();
                if (!IsPtr(ptr) || depth > MAX_HIERARCHY_DEPTH || !_sceneScanned.Add(ptr))
                    continue;
                if (!_mem.ReadBytesQuiet(ptr, _objectScratch, 0, _objectScratch.Length))
                    continue;
                long vtable = ReadQword(_objectScratch, 0);
                if (vtable != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA)
                    continue;

                long owner = ReadQword(_objectScratch, SPACE_MODEL);
                if (!_sceneNodes.ContainsKey(ptr))
                {
                    _sceneNodes[ptr] = new SceneNodeRecord { Ptr = ptr, Owner = owner, Depth = depth, FirstPath = path };
                    RegisterTransformProbe(ptr, vtable, path, 4);
                    AddOwnerModelCandidate(ptr, tx, ty, tz);
                }

                for (int offset = 0, checks = 0;
                     offset + 8 <= _objectScratch.Length && checks < MAX_CHILD_POINTER_CHECKS &&
                     _sceneEdgeKeys.Count < MAX_SCENE_EDGES;
                     offset += 8, checks++)
                {
                    long child = ReadQword(_objectScratch, offset);
                    if (!IsPtr(child) || child == ptr || ReadPtr(child) != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA)
                        continue;

                    _scenePointerReferences++;
                    if (_sceneEdgeKeys.Add((ptr, child, offset)) && _scenePointerReferences <= 120)
                        Write($"[STAGE68][SCENE-POINTER-REFERENCE] from=0x{ptr:X} offset=+0x{offset:X} to=0x{child:X} owner=0x{ReadPtr(child + SPACE_MODEL):X} depth={depth}");

                    AddOwnerModelCandidate(child, tx, ty, tz);
                    if (!_sceneNodes.ContainsKey(child) && _sceneNodes.Count < MAX_SCENE_NODES && depth + 1 <= MAX_HIERARCHY_DEPTH)
                    {
                        _sceneNodes[child] = new SceneNodeRecord
                        {
                            Ptr = child,
                            Owner = ReadPtr(child + SPACE_MODEL),
                            Depth = depth + 1,
                            FirstPath = $"{path}/+0x{offset:X}",
                        };
                        RegisterTransformProbe(child, ReadPtr(child), $"{path}/+0x{offset:X}", 4);
                        queue.Enqueue((child, depth + 1, $"{path}/+0x{offset:X}"));
                    }
                }
            }
        }

        private void AddOwnerModelCandidate(long nodePtr, float tx, float ty, float tz)
        {
            long owner = ReadPtr(nodePtr + SPACE_MODEL);
            if (!IsPtr(owner) || ReadPtr(owner) != _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA)
                return;

            long root = ReadPtr(owner + MODEL_SPACE_NODE);
            if (!ValidateModelRoot(owner, root, out _, out _, out _))
                return;

            float distance = float.NaN;
            if (TryReadNodeTransform(root, tx, ty, tz,
                out _, out _, out _, out _, out float measuredDistance))
                distance = measuredDistance;

            AddCandidate(new CandidateRecord
            {
                ModelPtr = owner,
                RootPtr = root,
                Path = $"OWNER-OF-SPACE-NODE-0x{nodePtr:X}",
                FromBgaClosure = false,
                SourceNodePtr = nodePtr,
                DiscoveryDistance = distance,
            });
        }

        private void AddCandidate(CandidateRecord candidate)
        {
            if (candidate == null || !IsPtr(candidate.ModelPtr) || !IsPtr(candidate.RootPtr))
                return;

            if (_candidates.TryGetValue(candidate.ModelPtr, out CandidateRecord existing))
            {
                if (candidate.FromBgaClosure && !existing.FromBgaClosure)
                {
                    existing.FromBgaClosure = true;
                    existing.SourceNodePtr = candidate.SourceNodePtr;
                    existing.Path = candidate.Path;
                    if (float.IsFinite(candidate.DiscoveryDistance))
                        existing.DiscoveryDistance = candidate.DiscoveryDistance;
                }
                else if (!float.IsFinite(existing.DiscoveryDistance) && float.IsFinite(candidate.DiscoveryDistance))
                {
                    existing.DiscoveryDistance = candidate.DiscoveryDistance;
                }
                return;
            }

            if (_candidates.Count >= MAX_MODEL_CANDIDATES)
            {
                Write($"[STAGE68][CANDIDATE-DROPPED] reason=poolCap model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X}");
                return;
            }
            _candidates[candidate.ModelPtr] = candidate;
        }

        private static void AddCandidateToDictionary(Dictionary<long, CandidateRecord> candidates, CandidateRecord candidate)
        {
            if (candidate == null)
                return;
            if (!candidates.TryGetValue(candidate.ModelPtr, out CandidateRecord existing) ||
                (!float.IsFinite(existing.DiscoveryDistance) && float.IsFinite(candidate.DiscoveryDistance)))
                candidates[candidate.ModelPtr] = candidate;
        }

        private bool ValidateModelRoot(long modelPtr, long rootPtr,
            out long modelVtable, out long rootVtable, out long rootOwner)
        {
            modelVtable = ReadPtr(modelPtr);
            rootVtable = ReadPtr(rootPtr);
            rootOwner = ReadPtr(rootPtr + SPACE_MODEL);
            return IsPtr(modelPtr) && IsPtr(rootPtr) &&
                   modelVtable == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA &&
                   rootVtable == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA &&
                   rootOwner == modelPtr;
        }

        private void RunAssociationSample()
        {
            if (_associationStartMs == 0)
                _associationStartMs = Environment.TickCount64;

            if (!TryReadTarget(out uint liveId, out float tx, out float ty, out float tz))
            {
                _targetLostSamples++;
                Write($"[STAGE68][SAMPLE] n={_sample + 1}/{SAMPLE_COUNT} targetRead=0 candidates={_candidates.Count}");
                return;
            }

            if (liveId != _targetId)
            {
                _targetIdMismatchSamples++;
                Write($"[STAGE68][BGA-TRACE-ID-MISMATCH] n={_sample + 1}/{SAMPLE_COUNT} elapsedMs={Environment.TickCount64 - _associationStartMs} bga=0x{_targetPtr:X} lockedId=0x{_targetId:X8} liveId=0x{liveId:X8} liveXYZ=({tx:F3},{ty:F3},{tz:F3}); coordinate sample rejected from association metrics but raw values preserved in log");
                return;
            }

            float targetStep = 0f;
            if (_hasPreviousTarget)
            {
                targetStep = Distance(_previousTargetX, _previousTargetY, _previousTargetZ, tx, ty, tz);
                if (float.IsFinite(targetStep))
                {
                    _targetTotalStep += targetStep;
                    if (targetStep >= TARGET_MOVEMENT_THRESHOLD && targetStep <= MAX_ASSOCIATION_TARGET_STEP)
                        _targetMotionTransitions++;
                    else if (targetStep > MAX_ASSOCIATION_TARGET_STEP)
                    {
                        _targetOutlierTransitions++;
                        Write($"[STAGE68][TARGET-STEP-OUTLIER] n={_sample + 1}/{SAMPLE_COUNT} targetStep={targetStep:F3} maxPlausibleStep={MAX_ASSOCIATION_TARGET_STEP:F3}; excluded from association motion counts");
                    }
                }
            }
            string stepClass;
            if (!_hasPreviousTarget)
                stepClass = "INITIAL";
            else if (targetStep < BGA_STATIONARY_THRESHOLD)
                stepClass = "STATIONARY";
            else if (targetStep > MAX_ASSOCIATION_TARGET_STEP)
            {
                stepClass = "LARGE_JUMP_INCLUDED_IN_RAW_TRACE";
                _largeRawJumpTransitions++;
                _largestRawJump = MathF.Max(_largestRawJump, targetStep);
            }
            else if (targetStep >= TARGET_MOVEMENT_THRESHOLD)
                stepClass = "PLAUSIBLE_MOVE";
            else
                stepClass = "SMALL_MOVE";

            bool hadPreviousTarget = _hasPreviousTarget;
            if (hadPreviousTarget && targetStep < BGA_STATIONARY_THRESHOLD)
            {
                _targetStationaryRun++;
                _targetStationarySamples++;
                if (_targetStationaryRun == MIN_STATIONARY_SAMPLES_FOR_HANDOFF)
                {
                    _targetStationaryEpisodes++;
                    Write($"[STAGE68][BGA-STATIONARY-EPISODE] n={_sample + 1} runLength={_targetStationaryRun} threshold={BGA_STATIONARY_THRESHOLD:F2} xyz=({tx:F3},{ty:F3},{tz:F3})");
                }
            }
            else
            {
                if (hadPreviousTarget && targetStep >= BGA_STATIONARY_THRESHOLD && _targetStationaryRun >= MIN_STATIONARY_SAMPLES_FOR_HANDOFF)
                    Write($"[STAGE68][BGA-STATIONARY-EPISODE-END] n={_sample + 1} priorRunLength={_targetStationaryRun} exitStep={targetStep:F3} exitClass={stepClass}");
                _targetStationaryRun = 0;
            }

            float snapshotX = float.NaN, snapshotY = float.NaN, snapshotZ = float.NaN;
            uint snapshotId = 0;
            long snapshotAgeMs = long.MaxValue;
            bool snapshotValid = false;
            lock (_sync)
            {
                snapshotAgeMs = _latestSnapshotTicks > 0 ? Math.Max(0, Environment.TickCount64 - _latestSnapshotTicks) : long.MaxValue;
                snapshotValid = _latestSnapshotPresent && _latestSnapshotPtr == _targetPtr &&
                    snapshotAgeMs <= SNAPSHOT_STALE_MS &&
                    IsValidCoordinate(_latestSnapshotX) && IsValidCoordinate(_latestSnapshotY) && IsValidCoordinate(_latestSnapshotZ);
                if (snapshotValid)
                {
                    snapshotX = _latestSnapshotX;
                    snapshotY = _latestSnapshotY;
                    snapshotZ = _latestSnapshotZ;
                    snapshotId = _latestSnapshotId;
                    _snapshotSeenSamples++;
                    float divergence = Distance(tx, ty, tz, snapshotX, snapshotY, snapshotZ);
                    if (divergence >= SNAPSHOT_DIVERGENCE_THRESHOLD)
                        _snapshotDivergenceSamples++;
                }
                else
                {
                    _snapshotMissingSamples++;
                }
            }
            float snapshotDistance = snapshotValid ? Distance(tx, ty, tz, snapshotX, snapshotY, snapshotZ) : float.NaN;
            long elapsedMs = _associationStartMs == 0 ? 0 : Environment.TickCount64 - _associationStartMs;
            Write($"[STAGE68][BGA-TRACE] n={_sample + 1}/{SAMPLE_COUNT} elapsedMs={elapsedMs} id=0x{liveId:X8} xyz=({tx:F3},{ty:F3},{tz:F3}) deltaStep={targetStep:F3} stepClass={stepClass} stationaryRun={_targetStationaryRun} totalRawStep={_targetTotalStep:F3} entitySnapshotValid={(snapshotValid ? 1 : 0)} snapshotId=0x{snapshotId:X8} snapshotAgeMs={(snapshotAgeMs == long.MaxValue ? -1 : snapshotAgeMs)} snapshotXYZ=({FormatCoordinate(snapshotX)},{FormatCoordinate(snapshotY)},{FormatCoordinate(snapshotZ)}) snapshotDistance={FormatDistance(snapshotDistance)} snapshotDiverges={(snapshotValid && snapshotDistance >= SNAPSHOT_DIVERGENCE_THRESHOLD ? 1 : 0)}");

            _previousTargetX = tx;
            _previousTargetY = ty;
            _previousTargetZ = tz;
            _hasPreviousTarget = true;

            int validCandidates = 0;
            int near128Candidates = 0;
            int near256Candidates = 0;
            int stableRelativeCandidates = 0;

            foreach (CandidateRecord candidate in _candidates.Values.OrderBy(c => c.ModelPtr))
            {
                bool structural = ValidateModelRoot(candidate.ModelPtr, candidate.RootPtr,
                    out long modelVtable, out long rootVtable, out long owner);
                if (structural)
                    candidate.StructurallyValidSamples++;
                else
                {
                    candidate.StructurallyInvalidSamples++;
                    if (_sample < 3 || (_sample + 1) % 10 == 0)
                        Write($"[STAGE68][CANDIDATE-STRUCTURE] n={_sample + 1} model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} valid=0 modelVtable=0x{modelVtable:X} rootVtable=0x{rootVtable:X} rootOwner=0x{owner:X}");
                    continue;
                }

                if (!TryReadNodeTransform(candidate.RootPtr, tx, ty, tz,
                    out float x, out float y, out float z, out string source, out float distance))
                    continue;

                candidate.ValidTransformSamples++;
                candidate.MinDistance = MathF.Min(candidate.MinDistance, distance);
                candidate.MaxDistance = MathF.Max(candidate.MaxDistance, distance);
                candidate.DistanceSum += distance;
                candidate.LastDistance = distance;
                if (distance <= MAX_NEAR_TARGET_DISTANCE)
                {
                    candidate.Near128Samples++;
                    near128Candidates++;
                }
                if (distance <= MAX_NEAR_TARGET_DIAGNOSTIC_DISTANCE)
                {
                    candidate.Near256Samples++;
                    near256Candidates++;
                }
                validCandidates++;

                float rx = x - tx;
                float ry = y - ty;
                float rz = z - tz;
                float rootStep = 0f;
                float relativeStep = 0f;
                if (candidate.HasPrevious)
                {
                    rootStep = Distance(candidate.PreviousX, candidate.PreviousY, candidate.PreviousZ, x, y, z);
                    relativeStep = Distance(candidate.PreviousRx, candidate.PreviousRy, candidate.PreviousRz, rx, ry, rz);
                    if (float.IsFinite(rootStep))
                        candidate.TotalRootStep += rootStep;
                    if (float.IsFinite(relativeStep))
                    {
                        candidate.TotalRelativeStep += relativeStep;
                        candidate.MaxRelativeStep = MathF.Max(candidate.MaxRelativeStep, relativeStep);
                    }

                    if (IsPlausibleTargetMotion(targetStep))
                    {
                        candidate.TargetMovingObservations++;
                        float stableLimit = MathF.Max(1.0f, targetStep * 0.25f);
                        if (relativeStep <= stableLimit)
                        {
                            candidate.RelativeStableWhileTargetMoves++;
                            stableRelativeCandidates++;
                        }
                        if (rootStep >= ROOT_STEP_THRESHOLD && relativeStep <= MathF.Max(2.0f, targetStep * 0.5f))
                            candidate.CoMotionSamples++;
                    }
                }

                candidate.PreviousX = x;
                candidate.PreviousY = y;
                candidate.PreviousZ = z;
                candidate.PreviousRx = rx;
                candidate.PreviousRy = ry;
                candidate.PreviousRz = rz;
                candidate.HasPrevious = true;

                Write($"[STAGE68][ROOT-TRACE] n={_sample + 1}/{SAMPLE_COUNT} model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} source={source} rootXYZ=({x:F3},{y:F3},{z:F3}) targetXYZ=({tx:F3},{ty:F3},{tz:F3}) targetStep={targetStep:F3} rootStep={rootStep:F3} relativeStep={relativeStep:F3} distance={distance:F3} relative=({rx:F3},{ry:F3},{rz:F3}) path={candidate.Path}");
            }

            SampleTransformProbes(tx, ty, tz, targetStep, stepClass, elapsedMs);
            SampleFocusedNodeTransforms(tx, ty, tz, targetStep);
            Write($"[STAGE68][SAMPLE] n={_sample + 1}/{SAMPLE_COUNT} targetId=0x{liveId:X8} targetXYZ=({tx:F3},{ty:F3},{tz:F3}) targetStep={targetStep:F3} targetTotalStep={_targetTotalStep:F3} movingTransitions={_targetMotionTransitions} validCandidates={validCandidates} within128={near128Candidates} within256={near256Candidates} stableRelativeWhileMoving={stableRelativeCandidates}");
        }

        private void RegisterTransformProbe(long ptr, long vtable, string path, int priority)
        {
            if (!IsPtr(ptr) || !IsPtr(vtable))
                return;

            if (vtable != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA &&
                vtable != _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA &&
                (vtable < _mem.BaseAddress || vtable >= _mem.BaseAddress + IMAGE_SIZE))
                return;

            if (_transformProbes.TryGetValue(ptr, out TransformProbeRecord existing))
            {
                bool pathIsCandidateRoot = path != null && path.Contains("::RootSpaceNode", StringComparison.Ordinal);
                bool existingPathIsCandidateRoot = existing.Path != null && existing.Path.Contains("::RootSpaceNode", StringComparison.Ordinal);
                if (priority > existing.Priority || (pathIsCandidateRoot && !existingPathIsCandidateRoot))
                {
                    if (existing.Priority < 3 && priority >= 3)
                        _genericTransformProbeCount = Math.Max(0, _genericTransformProbeCount - 1);
                    existing.Priority = Math.Max(existing.Priority, priority);
                    existing.Vtable = vtable;
                    existing.Path = path;
                }
                return;
            }

            bool generic = priority < 3;
            bool isCandidateRoot = path != null && path.Contains("::RootSpaceNode", StringComparison.Ordinal);
            if (generic && _genericTransformProbeCount >= MAX_GENERIC_TRANSFORM_PROBES)
                return;
            if (_transformProbes.Count >= MAX_TRANSFORM_PROBES)
            {
                if (!isCandidateRoot)
                    return;

                // Preserve candidate model roots if the bounded probe table fills with
                // lower-value model/object/node probes. Never grow beyond the cap.
                TransformProbeRecord victim = _transformProbes.Values
                    .Where(p => p.Path == null || !p.Path.Contains("::RootSpaceNode", StringComparison.Ordinal))
                    .OrderBy(p => p.Priority)
                    .ThenByDescending(p => p.ValidSamples)
                    .FirstOrDefault();
                if (victim == null)
                    return;
                _transformProbes.Remove(victim.Ptr);
                if (victim.Priority < 3)
                    _genericTransformProbeCount = Math.Max(0, _genericTransformProbeCount - 1);
            }

            _transformProbes[ptr] = new TransformProbeRecord
            {
                Ptr = ptr,
                Vtable = vtable,
                Path = path ?? "UNKNOWN",
                Priority = priority,
            };
            if (generic)
                _genericTransformProbeCount++;
        }

        private void SampleTransformProbes(float tx, float ty, float tz, float targetStep, string stepClass, long elapsedMs)
        {
            foreach (TransformProbeRecord probe in _transformProbes.Values.OrderByDescending(p => p.Priority).ThenBy(p => p.Ptr))
            {
                if (!TryReadNodeTransform(probe.Ptr, tx, ty, tz,
                    out float x, out float y, out float z, out string source, out float distance))
                {
                    probe.InvalidSamples++;
                    continue;
                }

                probe.ValidSamples++;
                probe.LastDistance = distance;
                probe.MinTargetDistance = MathF.Min(probe.MinTargetDistance, distance);
                probe.MaxTargetDistance = MathF.Max(probe.MaxTargetDistance, distance);
                probe.TargetDistanceSum += distance;

                float probeStep = 0f;
                if (probe.HasPrevious)
                {
                    probeStep = Distance(probe.PreviousX, probe.PreviousY, probe.PreviousZ, x, y, z);
                    probe.LastStep = probeStep;
                    if (float.IsFinite(probeStep))
                    {
                        probe.TotalStep += probeStep;
                        probe.MaxStep = MathF.Max(probe.MaxStep, probeStep);
                        if (probeStep >= PROBE_MOVEMENT_THRESHOLD)
                            probe.MovingTransitions++;
                        if (_targetStationaryRun >= MIN_STATIONARY_SAMPLES_FOR_HANDOFF)
                        {
                            probe.SamplesWhileBgaStationary++;
                            if (probeStep >= PROBE_MOVEMENT_THRESHOLD)
                                probe.MovesWhileBgaStationary++;
                        }
                    }
                }

                bool likelyRelevantSample = _sample == 0 || (_sample + 1) % 10 == 0 ||
                    probeStep >= PROBE_MOVEMENT_THRESHOLD || targetStep > MAX_ASSOCIATION_TARGET_STEP ||
                    _targetStationaryRun >= MIN_STATIONARY_SAMPLES_FOR_HANDOFF;
                if (likelyRelevantSample)
                {
                    Write($"[STAGE68][TRANSFORM-PROBE] n={_sample + 1}/{SAMPLE_COUNT} elapsedMs={elapsedMs} ptr=0x{probe.Ptr:X} vtable=0x{probe.Vtable:X} priority={probe.Priority} source={source} xyz=({x:F3},{y:F3},{z:F3}) step={probeStep:F3} stepClass={stepClass} distanceToBga={distance:F3} bgaStationaryRun={_targetStationaryRun} movedWhileBgaStationary={(probeStep >= PROBE_MOVEMENT_THRESHOLD && _targetStationaryRun >= MIN_STATIONARY_SAMPLES_FOR_HANDOFF ? 1 : 0)} path={probe.Path}");
                }

                probe.PreviousX = x;
                probe.PreviousY = y;
                probe.PreviousZ = z;
                probe.HasPrevious = true;
            }
        }

        private void PrepareFocusedRootCensuses()
        {
            _focusedRootCandidates.Clear();

            List<CandidateRecord> nearCandidates = _candidates.Values
                .Where(c => float.IsFinite(c.DiscoveryDistance) && c.DiscoveryDistance <= MAX_NEAR_TARGET_DISTANCE)
                .OrderBy(c => c.DiscoveryDistance)
                .ThenBy(c => c.ModelPtr)
                .ToList();

            var selected = new List<CandidateRecord>();
            var selectedModels = new HashSet<long>();

            void AddSelection(CandidateRecord candidate)
            {
                if (candidate == null || selected.Count >= MAX_FOCUSED_ROOT_CANDIDATES ||
                    !selectedModels.Add(candidate.ModelPtr))
                    return;
                selected.Add(candidate);
            }

            foreach (CandidateRecord candidate in nearCandidates)
                AddSelection(candidate);

            int nearSelected = selected.Count;
            if (selected.Count < MAX_FOCUSED_ROOT_CANDIDATES)
            {
                // Stage 67's provenance-first fallback selected far-away owner roots and
                // omitted the strongest eventual target-associated root (discovery distance
                // 353.211, final mean distance 2.260 in the previous capture). Stage 68
                // makes measured proximity the primary criterion; provenance only breaks ties.
                IEnumerable<CandidateRecord> fallbackCandidates = _candidates.Values
                    .Where(c => c != null && !selectedModels.Contains(c.ModelPtr))
                    .OrderBy(c => float.IsFinite(c.DiscoveryDistance) ? c.DiscoveryDistance : float.MaxValue)
                    .ThenByDescending(c => c.SourceNodePtr != 0)
                    .ThenByDescending(c => !string.IsNullOrEmpty(c.Path) &&
                        c.Path.Contains("BGA+0x0B8", StringComparison.Ordinal))
                    .ThenByDescending(c => c.FromBgaClosure)
                    .ThenBy(c => c.ModelPtr);

                foreach (CandidateRecord candidate in fallbackCandidates)
                {
                    AddSelection(candidate);
                    if (selected.Count >= MAX_FOCUSED_ROOT_CANDIDATES)
                        break;
                }
            }

            Write($"[STAGE68][FOCUSED-ROOTS] candidatesWithin128AtDiscovery={nearCandidates.Count} proximitySelected={nearSelected} selected={selected.Count} cap={MAX_FOCUSED_ROOT_CANDIDATES} selectionPolicy=within128-first,then nearest discovery distance; SpaceNode-owner/BGA+0x0B8 provenance are tie-breakers only; fallback roots are provisional only");
            if (selected.Count == 0)
            {
                Write("[STAGE68][FOCUSED-ROOT-CENSUS-SKIPPED] reason=no structurally discovered model/root candidates");
                return;
            }

            foreach (CandidateRecord candidate in selected)
            {
                string selectionReason = float.IsFinite(candidate.DiscoveryDistance) &&
                    candidate.DiscoveryDistance <= MAX_NEAR_TARGET_DISTANCE
                    ? "WITHIN128_AT_DISCOVERY"
                    : candidate.SourceNodePtr != 0
                        ? "SPACE_NODE_OWNER_FALLBACK"
                        : (!string.IsNullOrEmpty(candidate.Path) &&
                           candidate.Path.Contains("BGA+0x0B8", StringComparison.Ordinal))
                            ? "BGA_0B8_PROVENANCE_FALLBACK"
                            : "BOUNDED_DISTANCE_FALLBACK";

                if (!ValidateModelRoot(candidate.ModelPtr, candidate.RootPtr, out long modelVtable, out long rootVtable, out long owner))
                {
                    Write($"[STAGE68][FOCUSED-ROOT-REJECTED] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} selectionReason={selectionReason} modelVtable=0x{modelVtable:X} rootVtable=0x{rootVtable:X} owner=0x{owner:X}");
                    continue;
                }

                _focusedRootCandidates.Add(candidate);
                Write($"[STAGE68][FOCUSED-ROOT-PROVISIONAL] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} discoveryDistance={FormatDistance(candidate.DiscoveryDistance)} selectionReason={selectionReason} path={candidate.Path}; provisional only, no association winner accepted");
                ScanModelFieldsForFocusedNodes(candidate);

                var queue = new Queue<(long Node, int Depth, string Path)>();
                var visited = new HashSet<long>();
                queue.Enqueue((candidate.RootPtr, 0, "PROVISIONAL-MODEL-ROOT"));
                foreach (FocusedNodeRecord seededNode in candidate.FocusedNodes.Values.ToList())
                    queue.Enqueue((seededNode.NodePtr, seededNode.Depth, seededNode.FirstPath));

                while (queue.Count > 0)
                {
                    var work = queue.Dequeue();
                    if (work.Depth > MAX_FOCUSED_DEPTH || !IsPtr(work.Node) || !visited.Add(work.Node))
                        continue;
                    if (!_mem.ReadBytesQuiet(work.Node, _rootCensusScratch, 0, _rootCensusScratch.Length))
                    {
                        Write($"[STAGE68][FOCUSED-NODE-READ-FAIL] model=0x{candidate.ModelPtr:X} node=0x{work.Node:X} depth={work.Depth} path={work.Path}");
                        continue;
                    }
                    long nodeVtable = ReadQword(_rootCensusScratch, 0);
                    if (nodeVtable != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA)
                    {
                        Write($"[STAGE68][FOCUSED-NODE-REJECTED] node=0x{work.Node:X} vtable=0x{nodeVtable:X} depth={work.Depth} path={work.Path}");
                        continue;
                    }

                    long nodeOwner = ReadQword(_rootCensusScratch, SPACE_MODEL);
                    Write($"[STAGE68][FOCUSED-NODE-SCAN] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} node=0x{work.Node:X} depth={work.Depth} owner=0x{nodeOwner:X} ownerMatchesModel={(nodeOwner == candidate.ModelPtr ? 1 : 0)} path={work.Path}");
                    int exactRefs = 0;
                    for (int offset = 0, checks = 0;
                         offset + 8 <= _rootCensusScratch.Length && checks < MAX_CHILD_POINTER_CHECKS &&
                         candidate.FocusedEdges.Count < MAX_FOCUSED_EDGES_PER_ROOT;
                         offset += 8, checks++)
                    {
                        long child = ReadQword(_rootCensusScratch, offset);
                        if (!IsPtr(child) || child == work.Node || ReadPtr(child) != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA)
                            continue;

                        exactRefs++;
                        AddFocusedEdge(candidate, work.Node, child, offset, work.Depth, "SPACE-NODE-FIELD-REFERENCE", $"{work.Path}/+0x{offset:X}");
                        if (child == candidate.RootPtr)
                            continue;
                        bool added = AddFocusedNode(candidate, child, work.Depth + 1, $"{work.Path}/+0x{offset:X}");
                        if (added && work.Depth + 1 <= MAX_FOCUSED_DEPTH && !visited.Contains(child))
                            queue.Enqueue((child, work.Depth + 1, $"{work.Path}/+0x{offset:X}"));
                    }
                    Write($"[STAGE68][FOCUSED-NODE-SUMMARY] node=0x{work.Node:X} depth={work.Depth} exactSpaceNodeRefs={exactRefs} cumulativeNodes={candidate.FocusedNodes.Count} cumulativeRefs={candidate.FocusedEdges.Count}");
                }

                Write($"[STAGE68][FOCUSED-ROOT-CENSUS-COMPLETE] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} selectionReason={selectionReason} nonRootNodes={candidate.FocusedNodes.Count} exactReferences={candidate.FocusedEdges.Count} nodeCap={MAX_FOCUSED_NODES_PER_ROOT} edgeCap={MAX_FOCUSED_EDGES_PER_ROOT} depthCap={MAX_FOCUSED_DEPTH}");
            }
        }

        private void ScanModelFieldsForFocusedNodes(CandidateRecord candidate)
        {
            if (!_mem.ReadBytesQuiet(candidate.ModelPtr, _rootCensusScratch, 0, _rootCensusScratch.Length))
            {
                Write($"[STAGE68][MODEL-FIELD-CENSUS-FAIL] model=0x{candidate.ModelPtr:X} bytes=0x{ROOT_CENSUS_BYTES:X}");
                return;
            }
            long modelVtable = ReadQword(_rootCensusScratch, 0);
            if (modelVtable != _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA)
            {
                Write($"[STAGE68][MODEL-FIELD-CENSUS-REJECTED] model=0x{candidate.ModelPtr:X} vtable=0x{modelVtable:X}");
                return;
            }

            int exactRefs = 0;
            for (int offset = 0; offset + 8 <= _rootCensusScratch.Length && candidate.FocusedEdges.Count < MAX_FOCUSED_EDGES_PER_ROOT; offset += 8)
            {
                long node = ReadQword(_rootCensusScratch, offset);
                if (!IsPtr(node) || ReadPtr(node) != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA)
                    continue;
                exactRefs++;
                if (node == candidate.RootPtr)
                {
                    Write($"[STAGE68][MODEL-ROOT-REFERENCE] model=0x{candidate.ModelPtr:X} offset=+0x{offset:X} root=0x{node:X} expectedRootOffset={(offset == MODEL_SPACE_NODE ? 1 : 0)}");
                    continue;
                }

                AddFocusedEdge(candidate, candidate.ModelPtr, node, offset, 0, "MODEL-FIELD-REFERENCE", $"MODEL+0x{offset:X}");
                bool added = AddFocusedNode(candidate, node, 1, $"MODEL+0x{offset:X}");
                // The discovered model-field node is seeded into the bounded queue after the model census.
                if (added)
                    Write($"[STAGE68][MODEL-REFERENCED-NODE] model=0x{candidate.ModelPtr:X} offset=+0x{offset:X} node=0x{node:X} owner=0x{ReadPtr(node + SPACE_MODEL):X}");
            }
            Write($"[STAGE68][MODEL-FIELD-CENSUS] model=0x{candidate.ModelPtr:X} bytes=0x{ROOT_CENSUS_BYTES:X} exactSpaceNodeRefs={exactRefs} rootOffset038=0x{ReadPtr(candidate.ModelPtr + MODEL_SPACE_NODE):X}");
        }

        private bool AddFocusedNode(CandidateRecord candidate, long nodePtr, int depth, string path)
        {
            if (nodePtr == candidate.RootPtr || !IsPtr(nodePtr))
                return false;
            if (candidate.FocusedNodes.ContainsKey(nodePtr))
                return false;
            if (candidate.FocusedNodes.Count >= MAX_FOCUSED_NODES_PER_ROOT)
                return false;

            candidate.FocusedNodes[nodePtr] = new FocusedNodeRecord
            {
                NodePtr = nodePtr,
                OwnerPtr = ReadPtr(nodePtr + SPACE_MODEL),
                Depth = depth,
                FirstPath = path,
            };
            return true;
        }

        private void AddFocusedEdge(CandidateRecord candidate, long source, long target, int offset, int depth, string role, string path)
        {
            if (candidate.FocusedEdges.Count >= MAX_FOCUSED_EDGES_PER_ROOT ||
                !candidate.FocusedEdgeKeys.Add((source, target, offset)))
                return;

            candidate.FocusedEdges.Add(new FocusedEdgeRecord
            {
                SourcePtr = source,
                TargetPtr = target,
                Offset = offset,
                Depth = depth,
                Role = role,
                Path = path,
            });
            long owner = ReadPtr(target + SPACE_MODEL);
            Write($"[STAGE68][FOCUSED-SPACE-NODE-REFERENCE] model=0x{candidate.ModelPtr:X} source=0x{source:X} offset=+0x{offset:X} target=0x{target:X} targetOwner=0x{owner:X} targetOwnerMatchesCandidate={(owner == candidate.ModelPtr ? 1 : 0)} role={role} depth={depth} path={path}; reference only, not yet classified as a bone edge");
        }

        private void SampleFocusedNodeTransforms(float tx, float ty, float tz, float targetStep)
        {
            foreach (CandidateRecord candidate in _focusedRootCandidates)
            {
                if (!ValidateModelRoot(candidate.ModelPtr, candidate.RootPtr, out _, out _, out _))
                {
                    if (_sample == 0 || (_sample + 1) % 10 == 0)
                        Write($"[STAGE68][FOCUSED-ROOT-STRUCTURE] n={_sample + 1} model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} valid=0; focused-node transforms skipped for this root");
                    continue;
                }
                if (!TryReadNodeTransform(candidate.RootPtr, tx, ty, tz,
                    out float rootX, out float rootY, out float rootZ, out _, out _))
                    continue;

                foreach (FocusedNodeRecord node in candidate.FocusedNodes.Values.OrderBy(n => n.Depth).ThenBy(n => n.NodePtr))
                {
                    long nodeVtable = ReadPtr(node.NodePtr);
                    long owner = ReadPtr(node.NodePtr + SPACE_MODEL);
                    if (nodeVtable == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA)
                    {
                        node.StructuralValidSamples++;
                        if (owner == candidate.ModelPtr)
                            node.OwnerMatchesCandidateSamples++;
                        if (IsPtr(owner) && ReadPtr(owner) == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA)
                            node.OwnerIsModelSamples++;
                    }
                    else
                    {
                        node.StructuralInvalidSamples++;
                        if (_sample == 0 || (_sample + 1) % 10 == 0)
                            Write($"[STAGE68][FOCUSED-NODE-STRUCTURE] n={_sample + 1} node=0x{node.NodePtr:X} valid=0 vtable=0x{nodeVtable:X} owner=0x{owner:X} path={node.FirstPath}");
                        continue;
                    }

                    if (!TryReadNodeTransform(node.NodePtr, tx, ty, tz,
                        out float x, out float y, out float z, out string source, out float distance))
                        continue;

                    node.ValidTransformSamples++;
                    node.MinTargetDistance = MathF.Min(node.MinTargetDistance, distance);
                    node.MaxTargetDistance = MathF.Max(node.MaxTargetDistance, distance);
                    node.TargetDistanceSum += distance;
                    float targetRx = x - tx, targetRy = y - ty, targetRz = z - tz;
                    float rootRx = x - rootX, rootRy = y - rootY, rootRz = z - rootZ;
                    float nodeStep = 0f, targetRelativeStep = 0f, rootRelativeStep = 0f;
                    if (node.HasPrevious)
                    {
                        nodeStep = Distance(node.PreviousX, node.PreviousY, node.PreviousZ, x, y, z);
                        targetRelativeStep = Distance(node.PreviousTargetRx, node.PreviousTargetRy, node.PreviousTargetRz, targetRx, targetRy, targetRz);
                        rootRelativeStep = Distance(node.PreviousRootRx, node.PreviousRootRy, node.PreviousRootRz, rootRx, rootRy, rootRz);
                        if (float.IsFinite(nodeStep)) node.TotalNodeStep += nodeStep;
                        if (float.IsFinite(targetRelativeStep))
                        {
                            node.TotalTargetRelativeStep += targetRelativeStep;
                            node.MaxTargetRelativeStep = MathF.Max(node.MaxTargetRelativeStep, targetRelativeStep);
                        }
                        if (float.IsFinite(rootRelativeStep))
                        {
                            node.TotalRootRelativeStep += rootRelativeStep;
                            node.MaxRootRelativeStep = MathF.Max(node.MaxRootRelativeStep, rootRelativeStep);
                        }
                        if (IsPlausibleTargetMotion(targetStep))
                        {
                            node.TargetMovingObservations++;
                            if (targetRelativeStep <= MathF.Max(1.0f, targetStep * 0.25f))
                                node.StableRelativeToTargetWhileMoving++;
                            if (nodeStep >= ROOT_STEP_THRESHOLD && targetRelativeStep <= MathF.Max(2.0f, targetStep * 0.5f))
                                node.CoMotionSamples++;
                        }
                    }

                    node.PreviousX = x; node.PreviousY = y; node.PreviousZ = z;
                    node.PreviousTargetRx = targetRx; node.PreviousTargetRy = targetRy; node.PreviousTargetRz = targetRz;
                    node.PreviousRootRx = rootRx; node.PreviousRootRy = rootRy; node.PreviousRootRz = rootRz;
                    node.HasPrevious = true;

                    if (_sample == 0 || (_sample + 1) % 5 == 0)
                    {
                        Write($"[STAGE68][FOCUSED-NODE-SAMPLE] n={_sample + 1}/{SAMPLE_COUNT} model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} node=0x{node.NodePtr:X} depth={node.Depth} owner=0x{owner:X} ownerMatchesCandidate={(owner == candidate.ModelPtr ? 1 : 0)} source={source} targetDistance={distance:F3} rootDistance={Distance(x, y, z, rootX, rootY, rootZ):F3} nodeStep={nodeStep:F3} targetRelativeStep={targetRelativeStep:F3} rootRelativeStep={rootRelativeStep:F3} relativeToTarget=({targetRx:F3},{targetRy:F3},{targetRz:F3}) relativeToRoot=({rootRx:F3},{rootRy:F3},{rootRz:F3}) path={node.FirstPath}");
                    }
                }
            }
        }

        private bool AssociationPatternStrong(CandidateRecord c)
        {
            float meanDistance = AverageDistance(c);
            int moving = c.TargetMovingObservations;
            return c.StructurallyValidSamples >= (int)(SAMPLE_COUNT * MIN_ASSOCIATION_RATIO) &&
                   c.ValidTransformSamples >= (int)(SAMPLE_COUNT * MIN_ASSOCIATION_RATIO) &&
                   c.Near128Samples >= (int)(SAMPLE_COUNT * MIN_ASSOCIATION_RATIO) &&
                   moving >= MIN_ASSOCIATION_MOVING_OBSERVATIONS &&
                   c.RelativeStableWhileTargetMoves >= Math.Ceiling(moving * MIN_ASSOCIATION_RATIO) &&
                   c.CoMotionSamples >= Math.Ceiling(moving * MIN_ASSOCIATION_RATIO) &&
                   float.IsFinite(meanDistance) && meanDistance <= MAX_ASSOCIATION_MEAN_DISTANCE &&
                   c.MaxDistance <= MAX_NEAR_TARGET_DISTANCE;
        }

        private void EmitFocusedRootResults()
        {
            if (_focusedRootCandidates.Count == 0)
            {
                Write("[STAGE68][FINAL][ROOT-HIERARCHY] status=NOT_RUN reason=no candidate root was within 128 units at discovery");
                Write("[STAGE68][FINAL][VERDICT] targetAssociationPattern=UNCONFIRMED anatomicalHierarchyProven=0");
                return;
            }

            int qualifiedRoots = 0;
            foreach (CandidateRecord candidate in _focusedRootCandidates)
            {
                bool qualified = AssociationPatternStrong(candidate);
                if (qualified) qualifiedRoots++;
                Write($"[STAGE68][FINAL][ROOT-ASSOCIATION] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} associationPattern={(qualified ? 1 : 0)} discoveryDistance={FormatDistance(candidate.DiscoveryDistance)} validStructure={candidate.StructurallyValidSamples}/{SAMPLE_COUNT} validTransforms={candidate.ValidTransformSamples}/{SAMPLE_COUNT} near128={candidate.Near128Samples}/{SAMPLE_COUNT} movingObservations={candidate.TargetMovingObservations} stableRelative={candidate.RelativeStableWhileTargetMoves} coMotion={candidate.CoMotionSamples} meanDistance={FormatDistance(AverageDistance(candidate))} maxDistance={FormatDistance(candidate.MaxDistance)} nodes={candidate.FocusedNodes.Count} references={candidate.FocusedEdges.Count}");

                foreach (FocusedNodeRecord node in candidate.FocusedNodes.Values.OrderBy(n => n.Depth).ThenBy(n => n.NodePtr))
                {
                    float meanDistance = node.ValidTransformSamples > 0 ? (float)(node.TargetDistanceSum / node.ValidTransformSamples) : float.NaN;
                    Write($"[STAGE68][FINAL][NODE] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} node=0x{node.NodePtr:X} depth={node.Depth} owner=0x{node.OwnerPtr:X} ownerMatchesCandidateSamples={node.OwnerMatchesCandidateSamples} ownerIsModelSamples={node.OwnerIsModelSamples} structureValid={node.StructuralValidSamples} structureInvalid={node.StructuralInvalidSamples} validTransforms={node.ValidTransformSamples} targetMovingObservations={node.TargetMovingObservations} stableRelativeToTarget={node.StableRelativeToTargetWhileMoving} coMotion={node.CoMotionSamples} minDistance={(node.MinTargetDistance == float.MaxValue ? "N/A" : node.MinTargetDistance.ToString("F3", CultureInfo.InvariantCulture))} meanDistance={FormatDistance(meanDistance)} maxDistance={FormatDistance(node.MaxTargetDistance)} totalNodeStep={node.TotalNodeStep:F3} totalTargetRelativeStep={node.TotalTargetRelativeStep:F3} totalRootRelativeStep={node.TotalRootRelativeStep:F3} maxTargetRelativeStep={node.MaxTargetRelativeStep:F3} maxRootRelativeStep={node.MaxRootRelativeStep:F3} path={node.FirstPath}");
                }
                foreach (FocusedEdgeRecord edge in candidate.FocusedEdges)
                    Write($"[STAGE68][FINAL][REFERENCE] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} source=0x{edge.SourcePtr:X} offset=+0x{edge.Offset:X} target=0x{edge.TargetPtr:X} role={edge.Role} depth={edge.Depth} path={edge.Path}");
            }

            Write($"[STAGE68][FINAL][ROOT-HIERARCHY] focusedRoots={_focusedRootCandidates.Count} associationPatternQualifiedRoots={qualifiedRoots} directAndNestedExactReferences={_focusedRootCandidates.Sum(c => c.FocusedEdges.Count)} anatomicalHierarchyProven=0");
            Write("[STAGE68][FINAL][VERDICT] associationPattern qualifies a target-associated root for further inspection only; exact SpaceNode pointer references are not semantic bone edges and do not prove anatomical hierarchy");
        }

        private void ResetCandidateSampling(CandidateRecord candidate)
        {
            candidate.StructurallyValidSamples = 0;
            candidate.StructurallyInvalidSamples = 0;
            candidate.ValidTransformSamples = 0;
            candidate.Near128Samples = 0;
            candidate.Near256Samples = 0;
            candidate.TargetMovingObservations = 0;
            candidate.RelativeStableWhileTargetMoves = 0;
            candidate.CoMotionSamples = 0;
            candidate.MinDistance = float.MaxValue;
            candidate.MaxDistance = 0f;
            candidate.DistanceSum = 0;
            candidate.TotalRootStep = 0f;
            candidate.TotalRelativeStep = 0f;
            candidate.MaxRelativeStep = 0f;
            candidate.LastDistance = float.NaN;
            candidate.HasPrevious = false;
        }

        private bool TryReadTarget(out uint id, out float x, out float y, out float z)
        {
            id = 0;
            x = y = z = 0f;
            if (!IsPtr(_targetPtr) || !_mem.ReadBytesQuiet(_targetPtr + BGA_ID, _bgaScratch, 0, 0x30))
                return false;

            id = BitConverter.ToUInt32(_bgaScratch, 0);
            x = BitConverter.ToSingle(_bgaScratch, 4);
            y = BitConverter.ToSingle(_bgaScratch, 8);
            z = BitConverter.ToSingle(_bgaScratch, 12);
            return IsValidCoordinate(x) && IsValidCoordinate(y) && IsValidCoordinate(z);
        }

        private bool TryReadNodeTransform(long node, float targetX, float targetY, float targetZ,
            out float x, out float y, out float z, out string source, out float targetDistance)
        {
            x = y = z = 0f;
            source = "INVALID";
            targetDistance = float.NaN;
            if (!IsPtr(node))
                return false;

            if (_mem.ReadBytesQuiet(node + SPACE_WORLD_MATRIX, _transformScratch, 0, MATRIX_BYTES) &&
                TryDecodeMatrixTranslation(_transformScratch, out float mx, out float my, out float mz))
            {
                x = mx;
                y = my;
                z = mz;
                source = "WorldMatrix148";
                targetDistance = Distance(targetX, targetY, targetZ, x, y, z);
                return float.IsFinite(targetDistance);
            }

            if (_mem.ReadBytesQuiet(node + SPACE_WORLD_TRANSLATION, _translationScratch, 0, _translationScratch.Length))
            {
                float tx = BitConverter.ToSingle(_translationScratch, 0);
                float ty = BitConverter.ToSingle(_translationScratch, 4);
                float tz = BitConverter.ToSingle(_translationScratch, 8);
                if (IsValidCoordinate(tx) && IsValidCoordinate(ty) && IsValidCoordinate(tz))
                {
                    x = tx;
                    y = ty;
                    z = tz;
                    source = "Translation178";
                    targetDistance = Distance(targetX, targetY, targetZ, x, y, z);
                    return float.IsFinite(targetDistance);
                }
            }
            return false;
        }

        private static bool TryDecodeMatrixTranslation(byte[] bytes, out float x, out float y, out float z)
        {
            x = y = z = 0f;
            if (bytes == null || bytes.Length < MATRIX_BYTES)
                return false;
            for (int i = 0; i < 16; i++)
            {
                if (!float.IsFinite(BitConverter.ToSingle(bytes, i * 4)))
                    return false;
            }

            x = BitConverter.ToSingle(bytes, 0x30);
            y = BitConverter.ToSingle(bytes, 0x34);
            z = BitConverter.ToSingle(bytes, 0x38);
            float w = BitConverter.ToSingle(bytes, 0x3C);
            return IsValidCoordinate(x) && IsValidCoordinate(y) && IsValidCoordinate(z) &&
                   float.IsFinite(w) && MathF.Abs(w) > 0.0001f;
        }

        private long ReadPtr(long address)
        {
            if (!IsPtr(address))
                return 0;
            return _mem.ReadBytesQuiet(address, _ptrScratch, 0, 8)
                ? BitConverter.ToInt64(_ptrScratch, 0)
                : 0;
        }

        private static long ReadQword(byte[] bytes, int offset) =>
            bytes != null && offset >= 0 && offset + 8 <= bytes.Length
                ? BitConverter.ToInt64(bytes, offset)
                : 0;

        private static bool IsPtr(long value) =>
            value >= 0x10000 && value < 0x0000800000000000L && (value & 0x7L) == 0;

        private static bool IsValidCoordinate(float value) =>
            float.IsFinite(value) && MathF.Abs(value) <= MAX_WORLD_COORD;

        private static float Distance(float ax, float ay, float az, float bx, float by, float bz)
        {
            float dx = bx - ax;
            float dy = by - ay;
            float dz = bz - az;
            return MathF.Sqrt(dx * dx + dy * dy + dz * dz);
        }

        private static string FormatDistance(float value) =>
            float.IsFinite(value) ? value.ToString("F3", CultureInfo.InvariantCulture) : "N/A";

        private static string FormatCoordinate(float value) =>
            float.IsFinite(value) ? value.ToString("F3", CultureInfo.InvariantCulture) : "N/A";

        private void EmitFinal(string status)
        {
            Write("");
            Write("============================================================");
            Write("[STAGE68][FINAL][RESULT]");
            Write("============================================================");
            Write($"[STAGE68][FINAL][STATUS] {status}");
            Write($"[STAGE68][FINAL][TARGET] bga=0x{_targetPtr:X} id=0x{_targetId:X8} selectionMethod={_targetSelectionMethod} preselectionSamples={_targetSelectionSamples} preselectionMovingTransitions={_targetSelectionTransitions} preselectionPlausibleStep={_targetSelectionPlausibleStep:F3} preselectionOutlierSteps={_targetSelectionOutliers} targetLostSamples={_targetLostSamples} targetIdMismatchSamples={_targetIdMismatchSamples} targetMotionTransitions={_targetMotionTransitions} targetOutlierTransitions={_targetOutlierTransitions} targetTotalStep={_targetTotalStep:F3}");
            Write($"[STAGE68][FINAL][DISCOVERY] attempts={_discoveryAttempts} objectsInspected={_discoveryObjectsInspected} lastAttemptBgaObjects={_firstHopObjectsOnLastAttempt} lastAttemptNestedObjects={_nestedObjectsOnLastAttempt} totalNestedObjectsRead={_nestedObjectsTotalRead} uniqueNestedPointersSeen={_nestedScanned.Count} pendingNested={_nestedQueue.Count} nestedReadFailures={_nestedReadFailures} directOrNestedModels={_directModelCandidates} sceneAnchors={_sceneAnchorsScanned} sceneNodes={_sceneNodes.Count} pointerReferences={_scenePointerReferences} candidatePool={_candidates.Count}");
            Write("[STAGE68][FINAL][RANKING-POLICY] measurement-order-only; no automatic candidate acceptance; association ranking remains measurement-only; focused hierarchy selection is nearest-at-discovery, not a final winner");

            int rank = 0;
            foreach (CandidateRecord c in _candidates.Values
                .OrderByDescending(c => c.RelativeStableWhileTargetMoves)
                .ThenByDescending(c => c.Near128Samples)
                .ThenByDescending(c => c.ValidTransformSamples)
                .ThenBy(c => float.IsFinite(AverageDistance(c)) ? c.TotalRelativeStep : float.MaxValue)
                .ThenBy(c => float.IsFinite(AverageDistance(c)) ? AverageDistance(c) : float.MaxValue)
                .ThenBy(c => c.ModelPtr))
            {
                rank++;
                string minDistance = c.MinDistance == float.MaxValue
                    ? "N/A"
                    : c.MinDistance.ToString("F3", CultureInfo.InvariantCulture);
                float meanDistance = AverageDistance(c);
                Write($"[STAGE68][FINAL][CANDIDATE] rank={rank} model=0x{c.ModelPtr:X} root=0x{c.RootPtr:X} fromBgaClosure={(c.FromBgaClosure ? 1 : 0)} sourceNode=0x{c.SourceNodePtr:X} path={c.Path} discoveryDistance={FormatDistance(c.DiscoveryDistance)} finalDistance={FormatDistance(c.LastDistance)} minDistance={minDistance} maxDistance={FormatDistance(c.MaxDistance)} meanDistance={FormatDistance(meanDistance)} structureValid={c.StructurallyValidSamples} structureInvalid={c.StructurallyInvalidSamples} validTransforms={c.ValidTransformSamples} near128={c.Near128Samples} near256={c.Near256Samples} targetMovingObservations={c.TargetMovingObservations} stableRelativeWhileTargetMoves={c.RelativeStableWhileTargetMoves} coMotion={c.CoMotionSamples} totalRootStep={c.TotalRootStep:F3} totalRelativeStep={c.TotalRelativeStep:F3} maxRelativeStep={c.MaxRelativeStep:F3}");
            }

            if (string.Equals(status, "NO_CANDIDATE_POOL", StringComparison.Ordinal))
            {
                Write("[STAGE68][FINAL][VERDICT] targetMovementSufficient=NOT_SAMPLED targetAssociationPattern=UNCONFIRMED anatomicalHierarchyProven=0 reason=no candidate pool was discovered; association sampling never started");
            }
            else
            {
                bool movementObserved = _targetMotionTransitions >= MIN_ASSOCIATION_MOVING_OBSERVATIONS;
                Write($"[STAGE68][FINAL][VERDICT] targetMovementSufficient={(movementObserved ? 1 : 0)} requiredMovingTransitions={MIN_ASSOCIATION_MOVING_OBSERVATIONS} targetTotalStep={_targetTotalStep:F3} movingTransitions={_targetMotionTransitions} candidateRootAssociationIsMeasurementOnly=1 anatomicalHierarchyProven=0");
            }
            Write($"[STAGE68][FINAL][BGA-TRACE-SUMMARY] stationarySamples={_targetStationarySamples} stationaryEpisodes={_targetStationaryEpisodes} currentStationaryRun={_targetStationaryRun} largeRawJumpTransitions={_largeRawJumpTransitions} largestRawJump={_largestRawJump:F3} snapshotValidSamples={_snapshotSeenSamples} snapshotMissingOrStaleSamples={_snapshotMissingSamples} snapshotDivergenceSamples={_snapshotDivergenceSamples} snapshotDivergenceThreshold={SNAPSHOT_DIVERGENCE_THRESHOLD:F2} snapshotComparison=rawBgaVsOverlayEntityDataCopyNotIndependentGameTransform");
            Write($"[STAGE68][FINAL][TRANSFORM-PROBE-SUMMARY] probes={_transformProbes.Count} genericProbes={_genericTransformProbeCount} maxProbes={MAX_TRANSFORM_PROBES} probesWithStationaryBgaMovement={_transformProbes.Values.Count(p => p.MovesWhileBgaStationary > 0)}");
            foreach (TransformProbeRecord probe in _transformProbes.Values
                .OrderByDescending(p => p.MovesWhileBgaStationary)
                .ThenByDescending(p => p.MovingTransitions)
                .ThenBy(p => p.Ptr))
            {
                float meanDistance = probe.ValidSamples > 0 ? (float)(probe.TargetDistanceSum / probe.ValidSamples) : float.NaN;
                Write($"[STAGE68][FINAL][TRANSFORM-PROBE] ptr=0x{probe.Ptr:X} vtable=0x{probe.Vtable:X} priority={probe.Priority} validSamples={probe.ValidSamples} invalidSamples={probe.InvalidSamples} movingTransitions={probe.MovingTransitions} movesWhileBgaStationary={probe.MovesWhileBgaStationary} samplesWhileBgaStationary={probe.SamplesWhileBgaStationary} totalStep={probe.TotalStep:F3} maxStep={probe.MaxStep:F3} minDistance={FormatDistance(probe.MinTargetDistance == float.MaxValue ? float.NaN : probe.MinTargetDistance)} meanDistance={FormatDistance(meanDistance)} maxDistance={FormatDistance(probe.MaxTargetDistance)} lastDistance={FormatDistance(probe.LastDistance)} path={probe.Path}");
            }
            bool rootHandoffPattern = _transformProbes.Values.Any(p =>
                p.Path != null && p.Path.Contains("::RootSpaceNode", StringComparison.Ordinal) && p.MovesWhileBgaStationary >= 2);
            bool genericHandoffPattern = _transformProbes.Values.Any(p => p.Priority < 3 && p.MovesWhileBgaStationary >= 2);
            bool anyProbeMovement = _transformProbes.Values.Any(p => p.MovesWhileBgaStationary >= 2);
            Write($"[STAGE68][FINAL][HANDOFF-PATTERN] candidateModelRootMovedDuringBgaStationarity={(rootHandoffPattern ? 1 : 0)} genericClosureObjectMovedDuringBgaStationarity={(genericHandoffPattern ? 1 : 0)} anyProbeIncludingNonRootSpaceNodesMovedDuringBgaStationarity={(anyProbeMovement ? 1 : 0)} minimumProbeMovements=2; these are candidate patterns only and do not prove a vehicle handoff");
            EmitFocusedRootResults();
            Write("[STAGE68][FINAL][NEXT] compare the selected enemy's BGA trace, entity snapshot, and transform probes against the real mount/dismount timing; do not change the renderer from this diagnostic alone");
            Write("============================================================");
            lock (_sync)
            {
                try { _writer?.Flush(); } catch { }
            }
        }

        private static bool IsPlausibleTargetMotion(float step) =>
            float.IsFinite(step) && step >= TARGET_MOVEMENT_THRESHOLD && step <= MAX_ASSOCIATION_TARGET_STEP;

        private static float AverageDistance(CandidateRecord candidate) =>
            candidate.ValidTransformSamples > 0
                ? (float)(candidate.DistanceSum / candidate.ValidTransformSamples)
                : float.NaN;

        private void CompleteCapture()
        {
            _captureComplete = true;
            try { _timer?.Change(Timeout.Infinite, Timeout.Infinite); } catch { }
        }

        private void Write(string message)
        {
            Console.WriteLine(message);
            lock (_sync)
            {
                try
                {
                    _writer?.WriteLine($"{DateTimeOffset.Now:O} {message}");
                    if (_writer != null && (message.Contains("[FINAL]", StringComparison.Ordinal) || _sample % 5 == 0))
                        _writer.Flush();
                }
                catch { }
            }
        }

        private static void SafeConsole(string message)
        {
            try { Console.WriteLine(message); } catch { }
        }

        public void Dispose()
        {
            if (Interlocked.Exchange(ref _disposed, 1) != 0)
                return;
            try { _timer?.Change(Timeout.Infinite, Timeout.Infinite); } catch { }
            try { _timer?.Dispose(); } catch { }
            lock (_sync)
            {
                try { _writer?.Flush(); } catch { }
                try { _writer?.Dispose(); } catch { }
                _writer = null;
            }
        }
    }
}
```


---

## Record 10 — `RECON_HISTORY/Stage70ResolverReachabilityRecon.cs.txt`

<sub>Original size: 132065 bytes · Original SHA-256: `3330a729da9fc724cf930705a30f5a60bffba16ab7a38fff4c1090e07dbc0f08`</sub>

```csharp
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using ROS64Hack.Engine;

namespace ROS64Hack.Core
{
    /// <summary>
    /// Stage 70 retains Stage 69 target/root and vehicle-transition telemetry, mirrors the active reader's bounded BGA+0x0B8 resolver traversal,
    /// and checks aligned pointer fields inside only the top focused model/root objects for target-local SpaceNodes.
    /// These local-field references remain diagnostic candidates, not presumed bones. Raw large BGA jumps
    /// remain visible even when excluded from the plausible-motion association heuristic.
    /// Transform probes are measurements only; no probe is assumed to be a vehicle or bone.
    ///
    /// No process-wide scan, memory writes, renderer changes, or DynamicSkeletonReader
    /// changes are performed.
    /// </summary>
    public sealed class Stage70ResolverReachabilityRecon : IDisposable
    {
        private const int BGA_ID = 0x018;
        private const long MODEL_SKELETAL_VTABLE_RVA = 0x001C1ACE0;
        private const long SPACE_NODE_VTABLE_RVA = 0x001C137C8;
        private const int MODEL_SPACE_NODE = 0x038;
        private const int BGA_NATIVE_GRAPH = 0x0B8;
        private const int ENTITY_MODEL = 0x0D8;
        private const int ENTITY_MODELS_BEGIN = 0x0E0;
        private const int ENTITY_MODELS_END = 0x0E8;
        private const int MODEL_PRIORITY_BRANCH = 0x3E8;
        private static readonly int[] RUNTIME_EDGE_OFFSETS = { 0x018, 0x318, 0x618 };
        private const int MAX_RUNTIME_MODEL_ARRAY_BYTES = 0x4000;
        private const int ACTIVE_RESOLVER_GRAPH_BYTES = 0x400;
        private const int ACTIVE_RESOLVER_MAX_DEPTH = 5;
        private const int ACTIVE_RESOLVER_MAX_OBJECTS = 128;
        private const float ACTIVE_RESOLVER_ROOT_MAX_DISTANCE = 64f;
        private const int LOCAL_MODEL_SCAN_BYTES = 0x1000;
        private const int LOCAL_ROOT_SCAN_BYTES = 0x620;
        private const int MAX_LOCAL_NODE_MATCHES_PER_ROOT = 96;
        private const int SPACE_MODEL = 0x040;
        private const int SPACE_WORLD_MATRIX = 0x148;
        private const int SPACE_WORLD_TRANSLATION = 0x178;
        private const int MATRIX_BYTES = 0x40;

        private const int SAMPLE_COUNT = 240;
        private const int SAMPLE_INTERVAL_MS = 250;
        private const int INITIAL_DELAY_MS = 500;
        private const int PRE_SAMPLE_DELAY_MS = 1000;
        private const int TARGET_SELECTION_SAMPLE_INTERVAL_MS = 250;
        private const int TARGET_SELECTION_WINDOW_MS = 4000;
        private const int TARGET_SELECTION_TIMEOUT_MS = 15000;
        private const int TARGET_SELECTION_STALE_MS = 1000;
        private const int MIN_TARGET_SELECTION_SAMPLES = 8;
        private const int MIN_TARGET_SELECTION_MOVING_TRANSITIONS = 3;
        private const float MAX_TARGET_SELECTION_STEP = 256f;
        private const float MAX_ASSOCIATION_TARGET_STEP = 256f;
        private const int BGA_READ_BYTES = 0x1000;
        private const int OBJECT_READ_BYTES = 0x1000;
        private const int ROOT_CENSUS_BYTES = 0x2000;
        private const int MAX_FOCUSED_ROOT_CANDIDATES = 4;
        private const int MAX_FOCUSED_NODES_PER_ROOT = 64;
        private const int MAX_FOCUSED_EDGES_PER_ROOT = 256;
        private const int MAX_FOCUSED_DEPTH = 7;
        private const int MAX_DISCOVERY_ATTEMPTS = 8;
        private const int MAX_FIRST_HOP_OBJECTS = 48;
        private const int MAX_NESTED_OBJECTS_PER_ATTEMPT = 192;
        private const int MAX_NESTED_DEPTH = 3;
        private const int MAX_TRANSFORM_PROBES = 192;
        private const int MAX_GENERIC_TRANSFORM_PROBES = 64;
        private const float BGA_STATIONARY_THRESHOLD = 0.10f;
        private const float PROBE_MOVEMENT_THRESHOLD = 0.50f;
        private const int MIN_STATIONARY_SAMPLES_FOR_HANDOFF = 4;
        private const long SNAPSHOT_STALE_MS = 1000;
        private const float SNAPSHOT_DIVERGENCE_THRESHOLD = 1.0f;
        private const int MAX_QUEUED_POINTERS = 4096;
        private const long IMAGE_SIZE = 0x05AEA000;
        private const int MAX_MODEL_CANDIDATES = 64;
        private const int MAX_SCENE_ANCHORS = 12;
        private const int MAX_SCENE_NODES = 64;
        private const int MAX_SCENE_EDGES = 512;
        private const int MAX_HIERARCHY_DEPTH = 6;
        private const int MAX_CHILD_POINTER_CHECKS = OBJECT_READ_BYTES / 8;
        private const float MAX_WORLD_COORD = 50000f;
        private const float ROOT_STEP_THRESHOLD = 0.05f;
        private const float TARGET_MOVEMENT_THRESHOLD = 0.5f;
        private const float MAX_NEAR_TARGET_DISTANCE = 128f;
        private const float MAX_NEAR_TARGET_DIAGNOSTIC_DISTANCE = 256f;
        private const int MIN_ASSOCIATION_MOVING_OBSERVATIONS = 20;
        private const float MIN_ASSOCIATION_RATIO = 0.80f;
        private const float MAX_ASSOCIATION_MEAN_DISTANCE = 64f;

        private readonly Mem _mem;
        private readonly object _sync = new();
        private readonly byte[] _bgaScratch = new byte[BGA_READ_BYTES];
        private readonly byte[] _objectScratch = new byte[OBJECT_READ_BYTES];
        private readonly byte[] _rootCensusScratch = new byte[ROOT_CENSUS_BYTES];
        private readonly byte[] _runtimeModelArrayScratch = new byte[MAX_RUNTIME_MODEL_ARRAY_BYTES];
        private readonly byte[] _activeResolverScratch = new byte[ACTIVE_RESOLVER_GRAPH_BYTES];
        private readonly HashSet<long> _activeResolverGraphModelPtrs = new();
        private readonly byte[] _ptrScratch = new byte[8];
        private readonly byte[] _transformScratch = new byte[MATRIX_BYTES];
        private readonly byte[] _translationScratch = new byte[12];
        private readonly Dictionary<long, CandidateRecord> _candidates = new();
        private readonly Dictionary<(long Ptr, uint EntityId), TargetMotionRecord> _targetMotionRecords = new();
        private readonly Dictionary<long, SceneNodeRecord> _sceneNodes = new();
        private readonly Dictionary<long, TransformProbeRecord> _transformProbes = new();
        private readonly List<CandidateRecord> _focusedRootCandidates = new();
        private readonly HashSet<long> _sceneScanned = new();
        private readonly HashSet<(long Parent, long Child, int Offset)> _sceneEdgeKeys = new();
        private readonly Queue<PointerWorkItem> _nestedQueue = new();
        private readonly HashSet<long> _nestedQueued = new();
        private readonly HashSet<long> _nestedScanned = new();

        private StreamWriter _writer;
        private System.Threading.Timer _timer;
        private int _started;
        private int _disposed;
        private int _timerBusy;
        private int _sample;
        private bool _targetLocked;
        private bool _discoveryComplete;
        private bool _captureComplete;
        private bool _samplingDelayScheduled;
        private bool _waitForTargetLogged;
        private long _targetSelectionStartedMs;
        private long _lastTargetSelectionSampleMs;
        private long _lastTargetSelectionWaitLogMs;
        private string _targetSelectionMethod = "NOT_SELECTED";
        private int _targetSelectionSamples;
        private int _targetSelectionTransitions;
        private int _targetSelectionOutliers;
        private double _targetSelectionPlausibleStep;
        private int _targetOutlierTransitions;

        // Latest independently published entity snapshot for the locked BGA. This is
        // compared with the raw BGA fields at every timed diagnostic sample.
        private bool _latestSnapshotPresent;
        private long _latestSnapshotPtr;
        private uint _latestSnapshotId;
        private float _latestSnapshotX, _latestSnapshotY, _latestSnapshotZ;
        private long _latestSnapshotTicks;
        private int _snapshotSeenSamples;
        private int _snapshotMissingSamples;
        private int _snapshotDivergenceSamples;
        private long _associationStartMs;
        private int _targetStationaryRun;
        private int _targetStationarySamples;
        private int _targetStationaryEpisodes;
        private int _largeRawJumpTransitions;
        private float _largestRawJump;
        private int _genericTransformProbeCount;
        private int _runtimePathArrayCount;
        private int _runtimePathArrayExactModels;
        private int _runtimePathCandidateMatches;
        private int _runtimePathAddedCandidates;
        private bool _runtimePathArrayMetadataValid;
        private bool _activeResolverGraphRan;
        private int _activeResolverGraphObjects;
        private int _activeResolverGraphExactModels;
        private int _activeResolverGraphAcceptedRoots;
        private long _activeResolverGraphBestModel;
        private long _activeResolverGraphBestRoot;
        private float _activeResolverGraphBestDistance = float.NaN;
        private int _localObjectRegionsScanned;
        private int _localExactSpaceNodePointers;
        private int _localRelevantSpaceNodePointers;
        private int _localFocusedNodesAdded;

        private long _targetPtr;
        private uint _targetId;
        private int _discoveryAttempts;
        private int _discoveryObjectsInspected;
        private int _firstHopObjectsOnLastAttempt;
        private int _nextPointerSweepOffset;
        private int _directModelCandidates;
        private int _nestedObjectsOnLastAttempt;
        private int _nestedObjectsTotalRead;
        private int _nestedReadFailures;
        private int _scenePointerReferences;
        private int _sceneAnchorsScanned;
        private int _targetLostSamples;
        private int _targetIdMismatchSamples;
        private int _targetMotionTransitions;
        private float _targetTotalStep;
        private float _previousTargetX;
        private float _previousTargetY;
        private float _previousTargetZ;
        private bool _hasPreviousTarget;

        private sealed class SceneNodeRecord
        {
            public long Ptr;
            public long Owner;
            public int Depth;
            public string FirstPath;
        }

        private sealed class TransformProbeRecord
        {
            public long Ptr;
            public long Vtable;
            public string Path;
            public int Priority;
            public int ValidSamples;
            public int InvalidSamples;
            public int MovingTransitions;
            public int MovesWhileBgaStationary;
            public int SamplesWhileBgaStationary;
            public float TotalStep;
            public float MaxStep;
            public float MinTargetDistance = float.MaxValue;
            public float MaxTargetDistance;
            public double TargetDistanceSum;
            public float LastStep;
            public float LastDistance = float.NaN;
            public string LastSource = "NONE";
            public bool HasPrevious;
            public float PreviousX, PreviousY, PreviousZ;
        }

        private sealed class TargetMotionRecord
        {
            public long Ptr;
            public uint EntityId;
            public int Samples;
            public int MovingTransitions;
            public int OutlierSteps;
            public double PlausibleTotalStep;
            public long LastSeenMs;
            public bool HasPrevious;
            public float PreviousX, PreviousY, PreviousZ;
        }

        private sealed class PointerWorkItem
        {
            public long Ptr;
            public int Depth;
            public string Path;
        }

        private sealed class CandidateRecord
        {
            public long ModelPtr;
            public long RootPtr;
            public string Path;
            public bool FromBgaClosure;
            public long SourceNodePtr;
            public float DiscoveryDistance = float.NaN;

            public int StructurallyValidSamples;
            public int StructurallyInvalidSamples;
            public int ValidTransformSamples;
            public int Near128Samples;
            public int Near256Samples;
            public int TargetMovingObservations;
            public int RelativeStableWhileTargetMoves;
            public int CoMotionSamples;

            public float MinDistance = float.MaxValue;
            public float MaxDistance;
            public double DistanceSum;
            public float TotalRootStep;
            public float TotalRelativeStep;
            public float MaxRelativeStep;
            public float LastDistance = float.NaN;

            public bool HasPrevious;
            public float PreviousX;
            public float PreviousY;
            public float PreviousZ;
            public float PreviousRx;
            public float PreviousRy;
            public float PreviousRz;
            public readonly Dictionary<long, FocusedNodeRecord> FocusedNodes = new();
            public readonly List<FocusedEdgeRecord> FocusedEdges = new();
            public readonly HashSet<(long Source, long Target, int Offset)> FocusedEdgeKeys = new();
        }

        private sealed class FocusedNodeRecord
        {
            public long NodePtr;
            public long OwnerPtr;
            public int Depth;
            public string FirstPath;
            public int StructuralValidSamples;
            public int StructuralInvalidSamples;
            public int OwnerMatchesCandidateSamples;
            public int OwnerIsModelSamples;
            public int ValidTransformSamples;
            public int TargetMovingObservations;
            public int StableRelativeToTargetWhileMoving;
            public int CoMotionSamples;
            public float MinTargetDistance = float.MaxValue;
            public float MaxTargetDistance;
            public double TargetDistanceSum;
            public float TotalNodeStep;
            public float TotalTargetRelativeStep;
            public float TotalRootRelativeStep;
            public float MaxTargetRelativeStep;
            public float MaxRootRelativeStep;
            public bool HasPrevious;
            public float PreviousX, PreviousY, PreviousZ;
            public float PreviousTargetRx, PreviousTargetRy, PreviousTargetRz;
            public float PreviousRootRx, PreviousRootRy, PreviousRootRz;
        }

        private sealed class FocusedEdgeRecord
        {
            public long SourcePtr;
            public long TargetPtr;
            public int Offset;
            public int Depth;
            public string Role;
            public string Path;
        }

        public Stage70ResolverReachabilityRecon(Mem mem)
        {
            _mem = mem ?? throw new ArgumentNullException(nameof(mem));
        }

        public void Start()
        {
            if (Interlocked.Exchange(ref _started, 1) != 0)
                return;

            try
            {
                string path = Path.Combine(Environment.CurrentDirectory, "STAGE70_RESOLVER_REACHABILITY_RECON.txt");
                _writer = new StreamWriter(
                    new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.ReadWrite))
                {
                    AutoFlush = false,
                };

                Write("============================================================");
                Write("STAGE 69 — RUNTIME EDGE-SLOT AND TARGET-ROOT ARTICULATION RECON");
                Write("============================================================");
                Write($"[STAGE70][CONFIG] samples={SAMPLE_COUNT} intervalMs={SAMPLE_INTERVAL_MS} sampleSeconds={SAMPLE_COUNT * SAMPLE_INTERVAL_MS / 1000.0:F1} preSampleDelayMs={PRE_SAMPLE_DELAY_MS}");
                Write($"[STAGE70][CONFIG] ModelSkeletalVtable=0x{_mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA:X} SpaceNodeVtable=0x{_mem.BaseAddress + SPACE_NODE_VTABLE_RVA:X}");
                Write("[STAGE70][POLICY] processWideScan=0 memoryWrites=0 rendererChanges=0 DynamicSkeletonReaderChanges=0 anatomicalWinner=0");
                Write($"[STAGE70][BUDGET] discoveryAttempts={MAX_DISCOVERY_ATTEMPTS} firstHopObjectsPerAttempt={MAX_FIRST_HOP_OBJECTS} nestedObjectsPerAttempt={MAX_NESTED_OBJECTS_PER_ATTEMPT} nestedDepth={MAX_NESTED_DEPTH} maxQueuedPointers={MAX_QUEUED_POINTERS} modelCandidates={MAX_MODEL_CANDIDATES} sceneAnchors={MAX_SCENE_ANCHORS} sceneNodes={MAX_SCENE_NODES} sceneEdges={MAX_SCENE_EDGES} sceneDepth={MAX_HIERARCHY_DEPTH} focusedRoots={MAX_FOCUSED_ROOT_CANDIDATES} rootCensusBytes=0x{ROOT_CENSUS_BYTES:X} focusedNodesPerRoot={MAX_FOCUSED_NODES_PER_ROOT} focusedEdgesPerRoot={MAX_FOCUSED_EDGES_PER_ROOT} focusedDepth={MAX_FOCUSED_DEPTH}");
                Write("[STAGE70][DISCOVERY-ORDER] priorityBgaOffsets=+0x0A8,+0x0B8,+0x128,+0x130,+0x048,+0x648; useful target routes first, high-fanout +0x648 last; aligned BGA pointer sweep; bounded nested closure; no fixed runtime object addresses");
                Write("[STAGE70][PURPOSE] retain raw BGA / handoff telemetry; compare direct runtime model paths against BGA-closure candidates; trace only the active reader's +0x18/+0x318/+0x618 slots and the diagnostic Model+0x3E8 branch");
                Write($"[STAGE70][HANDOFF-CONFIG] samples={SAMPLE_COUNT} durationSeconds={SAMPLE_COUNT * SAMPLE_INTERVAL_MS / 1000.0:F1} stationaryThreshold={BGA_STATIONARY_THRESHOLD:F2} minimumStationarySamples={MIN_STATIONARY_SAMPLES_FOR_HANDOFF} probeMoveThreshold={PROBE_MOVEMENT_THRESHOLD:F2} snapshotStaleMs={SNAPSHOT_STALE_MS} snapshotDivergenceThreshold={SNAPSHOT_DIVERGENCE_THRESHOLD:F2} maxTransformProbes={MAX_TRANSFORM_PROBES} maxGenericProbes={MAX_GENERIC_TRANSFORM_PROBES}");
                Write($"[STAGE70][FILE] {Path.GetFullPath(path)}");
                Write("[STAGE70][CAPTURE-STARTED] observing valid enemies before locking the most consistently moving target; any large raw BGA jump is logged, not erased from the trace");
                Write("------------------------------------------------------------");

                _timer = new System.Threading.Timer(TimerTick, null, INITIAL_DELAY_MS, SAMPLE_INTERVAL_MS);
            }
            catch (Exception ex)
            {
                SafeConsole($"[STAGE70][START-FAILED] {ex.GetType().Name}: {ex.Message}");
            }
        }

        public void ObserveSnapshot(List<EntityData> enemies)
        {
            if (Volatile.Read(ref _disposed) != 0 ||
                Volatile.Read(ref _started) == 0 ||
                enemies == null)
                return;

            long now = Environment.TickCount64;
            lock (_sync)
            {
                if (_targetLocked)
                {
                    EntityData lockedSnapshot = enemies.FirstOrDefault(e => e != null && e.Ptr == _targetPtr);
                    _latestSnapshotPresent = lockedSnapshot != null;
                    if (lockedSnapshot != null)
                    {
                        _latestSnapshotPtr = lockedSnapshot.Ptr;
                        _latestSnapshotId = lockedSnapshot.EntityId;
                        _latestSnapshotX = lockedSnapshot.X;
                        _latestSnapshotY = lockedSnapshot.Y;
                        _latestSnapshotZ = lockedSnapshot.Z;
                        _latestSnapshotTicks = now;
                    }
                    return;
                }

                if (_targetSelectionStartedMs == 0)
                {
                    _targetSelectionStartedMs = now;
                    _lastTargetSelectionSampleMs = now - TARGET_SELECTION_SAMPLE_INTERVAL_MS;
                    Write("[STAGE70][TARGET-SELECTION-START] sampling all valid enemy snapshots before locking; choose by plausible motion, not list order");
                }

                if (now - _lastTargetSelectionSampleMs < TARGET_SELECTION_SAMPLE_INTERVAL_MS)
                    return;
                _lastTargetSelectionSampleMs = now;

                foreach (EntityData enemy in enemies)
                {
                    if (enemy?.IsEnemy != true ||
                        !IsPtr(enemy.Ptr) || enemy.EntityId == 0 ||
                        !IsValidCoordinate(enemy.X) ||
                        !IsValidCoordinate(enemy.Y) ||
                        !IsValidCoordinate(enemy.Z))
                        continue;

                    var key = (enemy.Ptr, enemy.EntityId);
                    if (!_targetMotionRecords.TryGetValue(key, out TargetMotionRecord record))
                    {
                        record = new TargetMotionRecord { Ptr = enemy.Ptr, EntityId = enemy.EntityId };
                        _targetMotionRecords[key] = record;
                    }

                    record.LastSeenMs = now;
                    record.Samples++;
                    if (record.HasPrevious)
                    {
                        float step = Distance(record.PreviousX, record.PreviousY, record.PreviousZ,
                            enemy.X, enemy.Y, enemy.Z);
                        if (float.IsFinite(step) && step >= TARGET_MOVEMENT_THRESHOLD && step <= MAX_TARGET_SELECTION_STEP)
                        {
                            record.MovingTransitions++;
                            record.PlausibleTotalStep += step;
                        }
                        else if (float.IsFinite(step) && step > MAX_TARGET_SELECTION_STEP)
                        {
                            record.OutlierSteps++;
                        }
                    }

                    record.PreviousX = enemy.X;
                    record.PreviousY = enemy.Y;
                    record.PreviousZ = enemy.Z;
                    record.HasPrevious = true;
                }

                long elapsedMs = now - _targetSelectionStartedMs;
                List<TargetMotionRecord> live = _targetMotionRecords.Values
                    .Where(r => now - r.LastSeenMs <= TARGET_SELECTION_STALE_MS &&
                                r.Samples >= MIN_TARGET_SELECTION_SAMPLES)
                    .ToList();

                bool activeTargetFound = elapsedMs >= TARGET_SELECTION_WINDOW_MS &&
                    live.Any(r => r.MovingTransitions >= MIN_TARGET_SELECTION_MOVING_TRANSITIONS);
                bool selectionTimedOut = elapsedMs >= TARGET_SELECTION_TIMEOUT_MS;
                if (!activeTargetFound && !selectionTimedOut)
                    return;

                TargetMotionRecord selected = live
                    .OrderByDescending(r => r.MovingTransitions)
                    .ThenByDescending(r => r.PlausibleTotalStep)
                    .ThenByDescending(r => r.Samples)
                    .ThenBy(r => r.EntityId)
                    .FirstOrDefault();

                if (selected == null)
                {
                    if (now - _lastTargetSelectionWaitLogMs >= 2000)
                    {
                        _lastTargetSelectionWaitLogMs = now;
                        Write($"[STAGE70][TARGET-SELECTION-WAIT] elapsedMs={elapsedMs} validTrackedTargets={_targetMotionRecords.Count} no currently visible target has {MIN_TARGET_SELECTION_SAMPLES}+ samples");
                    }
                    return;
                }

                _targetPtr = selected.Ptr;
                _targetId = selected.EntityId;
                _targetSelectionMethod = activeTargetFound ? "MOST_MOVED_TARGET" : "BEST_AVAILABLE_TIMEOUT_FALLBACK";
                _targetSelectionSamples = selected.Samples;
                _targetSelectionTransitions = selected.MovingTransitions;
                _targetSelectionOutliers = selected.OutlierSteps;
                _targetSelectionPlausibleStep = selected.PlausibleTotalStep;
                _targetLocked = true;

                Write($"[STAGE70][TARGET-LOCK] bga=0x{_targetPtr:X} id=0x{_targetId:X8} selectionMethod={_targetSelectionMethod} preselectionSamples={_targetSelectionSamples} plausibleMovingTransitions={_targetSelectionTransitions} plausibleTotalStep={_targetSelectionPlausibleStep:F3} outlierSteps={_targetSelectionOutliers} elapsedMs={elapsedMs}");
                int rank = 0;
                foreach (TargetMotionRecord item in _targetMotionRecords.Values
                    .Where(r => now - r.LastSeenMs <= TARGET_SELECTION_STALE_MS)
                    .OrderByDescending(r => r.MovingTransitions)
                    .ThenByDescending(r => r.PlausibleTotalStep)
                    .ThenByDescending(r => r.Samples)
                    .Take(5))
                {
                    rank++;
                    Write($"[STAGE70][TARGET-SELECTION-CANDIDATE] rank={rank} bga=0x{item.Ptr:X} id=0x{item.EntityId:X8} samples={item.Samples} plausibleMovingTransitions={item.MovingTransitions} plausibleTotalStep={item.PlausibleTotalStep:F3} outlierSteps={item.OutlierSteps}");
                }
                Write("[STAGE70][TARGET-SELECTION-VERDICT] the selected enemy had the strongest plausible movement history available; this does not prove any candidate is a skeletal bone hierarchy");
            }
        }

        private void TimerTick(object state)
        {
            if (Volatile.Read(ref _disposed) != 0 || _captureComplete)
                return;
            if (Interlocked.Exchange(ref _timerBusy, 1) != 0)
                return;

            try
            {
                if (!_targetLocked)
                {
                    if (!_waitForTargetLogged)
                    {
                        Write("[STAGE70][WAIT] no live enemy target snapshot yet");
                        _waitForTargetLogged = true;
                    }
                    return;
                }

                if (!_discoveryComplete)
                {
                    _discoveryAttempts++;
                    bool found = RunDiscoveryPass();
                    if (found)
                    {
                        _discoveryComplete = true;
                        _hasPreviousTarget = false;
                        foreach (CandidateRecord c in _candidates.Values)
                            ResetCandidateSampling(c);

                        PrepareFocusedRootCensuses();
                        Write($"[STAGE70][DISCOVERY-COMPLETE] attempts={_discoveryAttempts} candidates={_candidates.Count} sceneNodes={_sceneNodes.Count} pointerReferences={_scenePointerReferences} focusedRoots={_focusedRootCandidates.Count}");
                        Write("[STAGE70][PREPARE] sampling begins in 1 second; the selected target is an enemy entity, not the local player");
                        Write("[STAGE70][MOTION-PROTOCOL] keep the selected enemy visible and moving where possible; movement by the local player does not count as target movement");
                        _samplingDelayScheduled = true;
                        _timer?.Change(PRE_SAMPLE_DELAY_MS, SAMPLE_INTERVAL_MS);
                        return;
                    }

                    if (_discoveryAttempts >= MAX_DISCOVERY_ATTEMPTS)
                    {
                        Write($"[STAGE70][DISCOVERY-EXHAUSTED] attempts={_discoveryAttempts} noCandidatePool=1 objectsInspectedLastAttempt={_firstHopObjectsOnLastAttempt}; stopping instead of repeating an unbounded scan");
                        EmitFinal("NO_CANDIDATE_POOL");
                        CompleteCapture();
                    }
                    return;
                }

                if (_samplingDelayScheduled)
                {
                    _samplingDelayScheduled = false;
                    Write("[STAGE70][ASSOCIATION-SAMPLING-START]");
                }

                if (_sample >= SAMPLE_COUNT)
                {
                    EmitFinal("SAMPLE_WINDOW_COMPLETE");
                    CompleteCapture();
                    return;
                }

                RunAssociationSample();
                _sample++;
                if (_sample >= SAMPLE_COUNT)
                {
                    EmitFinal("SAMPLE_WINDOW_COMPLETE");
                    CompleteCapture();
                }
            }
            catch (Exception ex)
            {
                Write($"[STAGE70][EXCEPTION] sample={_sample} {ex.GetType().Name}: {ex.Message}");
            }
            finally
            {
                Volatile.Write(ref _timerBusy, 0);
            }
        }

        private bool RunDiscoveryPass()
        {
            if (!TryReadTarget(out uint liveId, out float tx, out float ty, out float tz))
            {
                Write($"[STAGE70][DISCOVERY-RETRY] attempt={_discoveryAttempts} reason=lockedBgaUnreadable");
                return false;
            }

            if (liveId != _targetId)
            {
                _targetIdMismatchSamples++;
                Write($"[STAGE70][TARGET-ID-MISMATCH] locked=0x{_targetId:X8} live=0x{liveId:X8} attempt={_discoveryAttempts}");
                return false;
            }

            var directCandidates = new Dictionary<long, CandidateRecord>();
            var scannedFirstHop = new HashSet<long>();
            int firstHopObjects = 0;

            // The earlier captures found useful target-reachable model paths under BGA+0x0A8
            // and BGA+0x0B8. Inspect those roots before the high-fanout BGA+0x648 branch.
            // All pointer values are read at runtime; no process-specific address is embedded.
            int[] priorityOffsets = { 0x0A8, 0x0B8, 0x128, 0x130, 0x048, 0x648 };
            foreach (int offset in priorityOffsets)
            {
                if (firstHopObjects >= MAX_FIRST_HOP_OBJECTS)
                    break;
                long pointer = ReadPtr(_targetPtr + offset);
                Write($"[STAGE70][PRIORITY-SEED] bgaOffset=+0x{offset:X3} ptr=0x{pointer:X}");
                InspectFirstHopObject(pointer, $"BGA+0x{offset:X3}", tx, ty, tz,
                    directCandidates, scannedFirstHop, ref firstHopObjects);
            }

            int sweepStartOffset = _nextPointerSweepOffset;
            if (_mem.ReadBytesQuiet(_targetPtr, _bgaScratch, 0, _bgaScratch.Length))
            {
                var seenBgaPointers = new HashSet<long>();
                int slotCount = _bgaScratch.Length / 8;
                for (int checks = 0; checks < slotCount; checks++)
                {
                    int offset = (sweepStartOffset + checks * 8) % _bgaScratch.Length;
                    if (firstHopObjects >= MAX_FIRST_HOP_OBJECTS)
                    {
                        _nextPointerSweepOffset = offset;
                        break;
                    }

                    long pointer = ReadQword(_bgaScratch, offset);
                    _nextPointerSweepOffset = (offset + 8) % _bgaScratch.Length;
                    if (!IsPtr(pointer) || !seenBgaPointers.Add(pointer) || scannedFirstHop.Contains(pointer))
                        continue;

                    InspectFirstHopObject(pointer, $"BGA+0x{offset:X3}", tx, ty, tz,
                        directCandidates, scannedFirstHop, ref firstHopObjects);
                }
            }

            int nestedThisAttempt = ProcessNestedPointerQueue(tx, ty, tz, directCandidates);
            _nestedObjectsOnLastAttempt = nestedThisAttempt;
            _firstHopObjectsOnLastAttempt = firstHopObjects;
            _discoveryObjectsInspected += firstHopObjects + nestedThisAttempt;
            _directModelCandidates = directCandidates.Count;
            Write($"[STAGE70][DISCOVERY-SCAN] attempt={_discoveryAttempts} sweepStart=+0x{sweepStartOffset:X3} sweepNext=+0x{_nextPointerSweepOffset:X3} bgaSeedObjects={firstHopObjects} nestedObjects={nestedThisAttempt} queuedPending={_nestedQueue.Count} directOrNestedModels={directCandidates.Count} cumulativeObjects={_discoveryObjectsInspected}");

            if (directCandidates.Count == 0)
                return false;

            _candidates.Clear();
            _sceneNodes.Clear();
            _sceneScanned.Clear();
            _sceneEdgeKeys.Clear();
            _scenePointerReferences = 0;

            foreach (CandidateRecord candidate in directCandidates.Values)
                AddCandidate(candidate);

            // Stage 63 scanned only the nearest four direct candidates. That missed
            // useful provenance paths such as the previously productive BGA+0x0B8
            // closure. Stage 70 takes one candidate per known BGA path first, then
            // fills the remaining bounded anchor budget by distance.
            string[] preferredPathTokens =
            {
                "BGA+0x0A8", "BGA+0x0B8", "BGA+0x128", "BGA+0x130",
                "BGA+0x048", "BGA+0x648", "BGA+0x298", "BGA+0x118"
            };
            var anchors = new List<CandidateRecord>();
            var anchorModels = new HashSet<long>();
            foreach (string token in preferredPathTokens)
            {
                CandidateRecord routeCandidate = directCandidates.Values
                    .Where(c => !string.IsNullOrEmpty(c.Path) && c.Path.Contains(token, StringComparison.Ordinal))
                    .OrderBy(c => float.IsFinite(c.DiscoveryDistance) ? c.DiscoveryDistance : float.MaxValue)
                    .ThenBy(c => c.ModelPtr)
                    .FirstOrDefault();
                if (routeCandidate != null && anchorModels.Add(routeCandidate.ModelPtr))
                    anchors.Add(routeCandidate);
                if (anchors.Count >= MAX_SCENE_ANCHORS)
                    break;
            }

            foreach (CandidateRecord candidate in directCandidates.Values
                .OrderBy(c => float.IsFinite(c.DiscoveryDistance) ? c.DiscoveryDistance : float.MaxValue)
                .ThenBy(c => c.ModelPtr))
            {
                if (anchors.Count >= MAX_SCENE_ANCHORS)
                    break;
                if (anchorModels.Add(candidate.ModelPtr))
                    anchors.Add(candidate);
            }
            Write($"[STAGE70][SCENE-ANCHOR-PLAN] directCandidates={directCandidates.Count} selectedAnchors={anchors.Count} cap={MAX_SCENE_ANCHORS} policy=one-per-priority-path-then-nearest; tokens={string.Join(",", preferredPathTokens)}");

            foreach (CandidateRecord anchor in anchors)
            {
                if (_sceneNodes.Count >= MAX_SCENE_NODES)
                    break;
                _sceneAnchorsScanned++;
                Write($"[STAGE70][SCENE-ANCHOR] index={_sceneAnchorsScanned} model=0x{anchor.ModelPtr:X} root=0x{anchor.RootPtr:X} distance={FormatDistance(anchor.DiscoveryDistance)} directPath={anchor.Path}");
                ScanSceneClosure(anchor, tx, ty, tz);
            }

            Write($"[STAGE70][SCENE-SUMMARY] scannedAnchors={Math.Min(_sceneAnchorsScanned, MAX_SCENE_ANCHORS)} exactSpaceNodes={_sceneNodes.Count} pointerReferences={_scenePointerReferences} uniqueModelCandidates={_candidates.Count}");
            foreach (CandidateRecord candidate in _candidates.Values
                .OrderBy(c => float.IsFinite(c.DiscoveryDistance) ? c.DiscoveryDistance : float.MaxValue)
                .ThenBy(c => c.ModelPtr))
            {
                RegisterTransformProbe(candidate.ModelPtr, ReadPtr(candidate.ModelPtr), candidate.Path + "::Model", 3);
                RegisterTransformProbe(candidate.RootPtr, ReadPtr(candidate.RootPtr), candidate.Path + "::RootSpaceNode", 4);
                Write($"[STAGE70][CANDIDATE-BASELINE] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} discoveryDistance={FormatDistance(candidate.DiscoveryDistance)} fromBgaClosure={(candidate.FromBgaClosure ? 1 : 0)} sourceNode=0x{candidate.SourceNodePtr:X} path={candidate.Path}");
            }

            Write("[STAGE70][CANDIDATE-POOL-READY] no candidate was selected; every candidate root enters the same association window");
            return _candidates.Count > 0;
        }

        private void InspectFirstHopObject(
            long firstHopPtr,
            string sourceLabel,
            float tx,
            float ty,
            float tz,
            Dictionary<long, CandidateRecord> directCandidates,
            HashSet<long> scannedFirstHop,
            ref int firstHopObjects)
        {
            if (!IsPtr(firstHopPtr) || !scannedFirstHop.Add(firstHopPtr) ||
                firstHopObjects >= MAX_FIRST_HOP_OBJECTS)
                return;

            firstHopObjects++;
            long firstHopVtable = ReadPtr(firstHopPtr);
            RegisterTransformProbe(firstHopPtr, firstHopVtable, sourceLabel,
                firstHopVtable == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA ? 4 :
                firstHopVtable == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA ? 3 : 1);
            if (firstHopObjects <= 24)
                Write($"[STAGE70][FIRST-HOP] source={sourceLabel} ptr=0x{firstHopPtr:X} vtable=0x{firstHopVtable:X}");

            if (TryValidateModelCandidate(firstHopPtr, sourceLabel, tx, ty, tz, true, 0,
                out CandidateRecord directCandidate))
            {
                AddCandidateToDictionary(directCandidates, directCandidate);
                Write($"[STAGE70][DIRECT-MODEL-HIT] model=0x{directCandidate.ModelPtr:X} root=0x{directCandidate.RootPtr:X} distance={FormatDistance(directCandidate.DiscoveryDistance)} path={sourceLabel}");
                return;
            }

            if (!_mem.ReadBytesQuiet(firstHopPtr, _objectScratch, 0, _objectScratch.Length))
                return;

            // This object's full field block has already been inspected as a BGA seed;
            // do not process it a second time if a nested pointer cycles back to it.
            _nestedScanned.Add(firstHopPtr);

            long modelVtable = _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;
            long spaceNodeVtable = _mem.BaseAddress + SPACE_NODE_VTABLE_RVA;
            var localChildren = new HashSet<long>();
            for (int offset = 0, checks = 0;
                 offset + 8 <= _objectScratch.Length && checks < MAX_CHILD_POINTER_CHECKS;
                 offset += 8, checks++)
            {
                long child = ReadQword(_objectScratch, offset);
                if (!IsPtr(child) || child == firstHopPtr || !localChildren.Add(child))
                    continue;

                long childVtable = ReadPtr(child);
                string childPath = $"{sourceLabel}->0x{firstHopPtr:X}+0x{offset:X3}";
                if (childVtable == modelVtable &&
                    TryValidateModelCandidate(child, childPath, tx, ty, tz, true, 0,
                        out CandidateRecord candidate))
                {
                    AddCandidateToDictionary(directCandidates, candidate);
                    Write($"[STAGE70][MODEL-HIT][BGA-OBJECT] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} distance={FormatDistance(candidate.DiscoveryDistance)} path={candidate.Path}");
                }
                else if (childVtable == spaceNodeVtable)
                {
                    RegisterTransformProbe(child, childVtable, childPath, 4);
                    long owner = ReadPtr(child + SPACE_MODEL);
                    if (TryValidateModelCandidate(owner, $"{childPath}->SpaceNodeOwner", tx, ty, tz,
                        true, child, out CandidateRecord ownerCandidate))
                    {
                        AddCandidateToDictionary(directCandidates, ownerCandidate);
                        Write($"[STAGE70][MODEL-HIT][SPACE-NODE-OWNER] model=0x{ownerCandidate.ModelPtr:X} root=0x{ownerCandidate.RootPtr:X} sourceNode=0x{child:X} distance={FormatDistance(ownerCandidate.DiscoveryDistance)} path={ownerCandidate.Path}");
                    }
                }

                // Exact executable-image vtables are high-priority nested objects. Small
                // sentinel/container records (vtable 1) are also followed, but the global
                // pending/scan budgets prevent a broad or unbounded walk.
                if (ShouldQueueNestedPointer(childVtable) && offset + 8 <= _objectScratch.Length)
                    QueueNestedPointer(child, 1, childPath);
            }
        }

        private int ProcessNestedPointerQueue(
            float tx,
            float ty,
            float tz,
            Dictionary<long, CandidateRecord> directCandidates)
        {
            int processed = 0;
            long modelVtable = _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;
            long spaceNodeVtable = _mem.BaseAddress + SPACE_NODE_VTABLE_RVA;

            while (_nestedQueue.Count > 0 && processed < MAX_NESTED_OBJECTS_PER_ATTEMPT)
            {
                PointerWorkItem item = _nestedQueue.Dequeue();
                if (item == null || item.Depth > MAX_NESTED_DEPTH || !IsPtr(item.Ptr) ||
                    !_nestedScanned.Add(item.Ptr))
                    continue;

                if (!_mem.ReadBytesQuiet(item.Ptr, _objectScratch, 0, _objectScratch.Length))
                {
                    _nestedReadFailures++;
                    if (_nestedReadFailures <= 24)
                        Write($"[STAGE70][NESTED-READ-FAILED] ptr=0x{item.Ptr:X} depth={item.Depth} path={item.Path}");
                    continue;
                }

                processed++;
                long objectVtable = ReadQword(_objectScratch, 0);
                RegisterTransformProbe(item.Ptr, objectVtable, item.Path,
                    objectVtable == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA ? 4 :
                    objectVtable == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA ? 3 : 1);
                if (processed <= 24 || objectVtable == modelVtable || objectVtable == spaceNodeVtable)
                    Write($"[STAGE70][NESTED-OBJECT] ptr=0x{item.Ptr:X} depth={item.Depth} vtable=0x{objectVtable:X} path={item.Path}");

                if (objectVtable == modelVtable &&
                    TryValidateModelCandidate(item.Ptr, item.Path, tx, ty, tz, true, 0,
                        out CandidateRecord selfCandidate))
                {
                    AddCandidateToDictionary(directCandidates, selfCandidate);
                    Write($"[STAGE70][MODEL-HIT][NESTED-OBJECT] model=0x{selfCandidate.ModelPtr:X} root=0x{selfCandidate.RootPtr:X} distance={FormatDistance(selfCandidate.DiscoveryDistance)} path={selfCandidate.Path}");
                }
                else if (objectVtable == spaceNodeVtable)
                {
                    RegisterTransformProbe(item.Ptr, objectVtable, item.Path, 4);
                    long owner = ReadQword(_objectScratch, SPACE_MODEL);
                    if (TryValidateModelCandidate(owner, $"{item.Path}->SpaceNodeOwner", tx, ty, tz,
                        true, item.Ptr, out CandidateRecord ownerCandidate))
                    {
                        AddCandidateToDictionary(directCandidates, ownerCandidate);
                        Write($"[STAGE70][MODEL-HIT][NESTED-SPACE-NODE-OWNER] model=0x{ownerCandidate.ModelPtr:X} root=0x{ownerCandidate.RootPtr:X} sourceNode=0x{item.Ptr:X} distance={FormatDistance(ownerCandidate.DiscoveryDistance)} path={ownerCandidate.Path}");
                    }
                }

                var localChildren = new HashSet<long>();
                for (int offset = 0, checks = 0;
                     offset + 8 <= _objectScratch.Length && checks < MAX_CHILD_POINTER_CHECKS;
                     offset += 8, checks++)
                {
                    long child = ReadQword(_objectScratch, offset);
                    if (!IsPtr(child) || child == item.Ptr || !localChildren.Add(child))
                        continue;

                    long childVtable = ReadPtr(child);
                    string childPath = $"{item.Path}/+0x{offset:X3}";
                    if (childVtable == modelVtable &&
                        TryValidateModelCandidate(child, childPath, tx, ty, tz, true, 0,
                            out CandidateRecord candidate))
                    {
                        AddCandidateToDictionary(directCandidates, candidate);
                        Write($"[STAGE70][MODEL-HIT][NESTED-FIELD] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} distance={FormatDistance(candidate.DiscoveryDistance)} path={candidate.Path}");
                    }
                    else if (childVtable == spaceNodeVtable)
                    {
                        RegisterTransformProbe(child, childVtable, childPath, 4);
                        long owner = ReadPtr(child + SPACE_MODEL);
                        if (TryValidateModelCandidate(owner, $"{childPath}->SpaceNodeOwner", tx, ty, tz,
                            true, child, out CandidateRecord ownerCandidate))
                        {
                            AddCandidateToDictionary(directCandidates, ownerCandidate);
                            Write($"[STAGE70][MODEL-HIT][NESTED-OWNER] model=0x{ownerCandidate.ModelPtr:X} root=0x{ownerCandidate.RootPtr:X} sourceNode=0x{child:X} distance={FormatDistance(ownerCandidate.DiscoveryDistance)} path={ownerCandidate.Path}");
                        }
                    }

                    if (item.Depth < MAX_NESTED_DEPTH && ShouldQueueNestedPointer(childVtable))
                        QueueNestedPointer(child, item.Depth + 1, childPath);
                }
            }

            _nestedObjectsTotalRead += processed;
            Write($"[STAGE70][NESTED-CLOSURE] processedThisAttempt={processed} totalObjectsRead={_nestedObjectsTotalRead} uniquePointersSeen={_nestedScanned.Count} pending={_nestedQueue.Count} queuedCap={MAX_QUEUED_POINTERS} maxDepth={MAX_NESTED_DEPTH} readFailures={_nestedReadFailures} modelCandidates={directCandidates.Count}");
            return processed;
        }

        private bool ShouldQueueNestedPointer(long vtable)
        {
            if (vtable == 1)
                return true;

            long baseAddress = _mem.BaseAddress;
            return vtable >= baseAddress && vtable < baseAddress + IMAGE_SIZE;
        }

        private void QueueNestedPointer(long ptr, int depth, string path)
        {
            if (!IsPtr(ptr) || depth > MAX_NESTED_DEPTH || _nestedQueued.Contains(ptr) ||
                _nestedScanned.Contains(ptr) || _nestedQueued.Count >= MAX_QUEUED_POINTERS)
                return;

            _nestedQueued.Add(ptr);
            _nestedQueue.Enqueue(new PointerWorkItem { Ptr = ptr, Depth = depth, Path = path });
        }

        private bool TryValidateModelCandidate(
            long modelPtr,
            string path,
            float tx,
            float ty,
            float tz,
            bool fromBgaClosure,
            long sourceNodePtr,
            out CandidateRecord candidate)
        {
            candidate = null;
            if (!IsPtr(modelPtr))
                return false;

            long modelVtable = ReadPtr(modelPtr);
            if (modelVtable != _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA)
                return false;

            long root = ReadPtr(modelPtr + MODEL_SPACE_NODE);
            if (!IsPtr(root))
                return false;
            long rootVtable = ReadPtr(root);
            if (rootVtable != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA ||
                ReadPtr(root + SPACE_MODEL) != modelPtr)
                return false;

            float distance = float.NaN;
            if (TryReadNodeTransform(root, tx, ty, tz,
                out _, out _, out _, out _, out float d))
                distance = d;

            RegisterTransformProbe(modelPtr, modelVtable, path + "::Model", 3);
            RegisterTransformProbe(root, rootVtable, path + "::RootSpaceNode", 4);

            candidate = new CandidateRecord
            {
                ModelPtr = modelPtr,
                RootPtr = root,
                Path = path,
                FromBgaClosure = fromBgaClosure,
                SourceNodePtr = sourceNodePtr,
                DiscoveryDistance = distance,
            };
            return true;
        }

        private void ScanSceneClosure(CandidateRecord anchor, float tx, float ty, float tz)
        {
            var queue = new Queue<(long Ptr, int Depth, string Path)>();
            queue.Enqueue((anchor.RootPtr, 0, $"ANCHOR-0x{anchor.ModelPtr:X}"));

            while (queue.Count > 0 && _sceneNodes.Count < MAX_SCENE_NODES)
            {
                (long ptr, int depth, string path) = queue.Dequeue();
                if (!IsPtr(ptr) || depth > MAX_HIERARCHY_DEPTH || !_sceneScanned.Add(ptr))
                    continue;
                if (!_mem.ReadBytesQuiet(ptr, _objectScratch, 0, _objectScratch.Length))
                    continue;
                long vtable = ReadQword(_objectScratch, 0);
                if (vtable != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA)
                    continue;

                long owner = ReadQword(_objectScratch, SPACE_MODEL);
                if (!_sceneNodes.ContainsKey(ptr))
                {
                    _sceneNodes[ptr] = new SceneNodeRecord { Ptr = ptr, Owner = owner, Depth = depth, FirstPath = path };
                    RegisterTransformProbe(ptr, vtable, path, 4);
                    AddOwnerModelCandidate(ptr, tx, ty, tz);
                }

                for (int offset = 0, checks = 0;
                     offset + 8 <= _objectScratch.Length && checks < MAX_CHILD_POINTER_CHECKS &&
                     _sceneEdgeKeys.Count < MAX_SCENE_EDGES;
                     offset += 8, checks++)
                {
                    long child = ReadQword(_objectScratch, offset);
                    if (!IsPtr(child) || child == ptr || ReadPtr(child) != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA)
                        continue;

                    _scenePointerReferences++;
                    if (_sceneEdgeKeys.Add((ptr, child, offset)) && _scenePointerReferences <= 120)
                        Write($"[STAGE70][SCENE-POINTER-REFERENCE] from=0x{ptr:X} offset=+0x{offset:X} to=0x{child:X} owner=0x{ReadPtr(child + SPACE_MODEL):X} depth={depth}");

                    AddOwnerModelCandidate(child, tx, ty, tz);
                    if (!_sceneNodes.ContainsKey(child) && _sceneNodes.Count < MAX_SCENE_NODES && depth + 1 <= MAX_HIERARCHY_DEPTH)
                    {
                        _sceneNodes[child] = new SceneNodeRecord
                        {
                            Ptr = child,
                            Owner = ReadPtr(child + SPACE_MODEL),
                            Depth = depth + 1,
                            FirstPath = $"{path}/+0x{offset:X}",
                        };
                        RegisterTransformProbe(child, ReadPtr(child), $"{path}/+0x{offset:X}", 4);
                        queue.Enqueue((child, depth + 1, $"{path}/+0x{offset:X}"));
                    }
                }
            }
        }

        private void AddOwnerModelCandidate(long nodePtr, float tx, float ty, float tz)
        {
            long owner = ReadPtr(nodePtr + SPACE_MODEL);
            if (!IsPtr(owner) || ReadPtr(owner) != _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA)
                return;

            long root = ReadPtr(owner + MODEL_SPACE_NODE);
            if (!ValidateModelRoot(owner, root, out _, out _, out _))
                return;

            float distance = float.NaN;
            if (TryReadNodeTransform(root, tx, ty, tz,
                out _, out _, out _, out _, out float measuredDistance))
                distance = measuredDistance;

            AddCandidate(new CandidateRecord
            {
                ModelPtr = owner,
                RootPtr = root,
                Path = $"OWNER-OF-SPACE-NODE-0x{nodePtr:X}",
                FromBgaClosure = false,
                SourceNodePtr = nodePtr,
                DiscoveryDistance = distance,
            });
        }

        private void AddCandidate(CandidateRecord candidate)
        {
            if (candidate == null || !IsPtr(candidate.ModelPtr) || !IsPtr(candidate.RootPtr))
                return;

            if (_candidates.TryGetValue(candidate.ModelPtr, out CandidateRecord existing))
            {
                if (candidate.FromBgaClosure && !existing.FromBgaClosure)
                {
                    existing.FromBgaClosure = true;
                    existing.SourceNodePtr = candidate.SourceNodePtr;
                    existing.Path = candidate.Path;
                    if (float.IsFinite(candidate.DiscoveryDistance))
                        existing.DiscoveryDistance = candidate.DiscoveryDistance;
                }
                else if (!float.IsFinite(existing.DiscoveryDistance) && float.IsFinite(candidate.DiscoveryDistance))
                {
                    existing.DiscoveryDistance = candidate.DiscoveryDistance;
                }
                return;
            }

            if (_candidates.Count >= MAX_MODEL_CANDIDATES)
            {
                Write($"[STAGE70][CANDIDATE-DROPPED] reason=poolCap model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X}");
                return;
            }
            _candidates[candidate.ModelPtr] = candidate;
        }

        private static void AddCandidateToDictionary(Dictionary<long, CandidateRecord> candidates, CandidateRecord candidate)
        {
            if (candidate == null)
                return;
            if (!candidates.TryGetValue(candidate.ModelPtr, out CandidateRecord existing) ||
                (!float.IsFinite(existing.DiscoveryDistance) && float.IsFinite(candidate.DiscoveryDistance)))
                candidates[candidate.ModelPtr] = candidate;
        }

        private bool ValidateModelRoot(long modelPtr, long rootPtr,
            out long modelVtable, out long rootVtable, out long rootOwner)
        {
            modelVtable = ReadPtr(modelPtr);
            rootVtable = ReadPtr(rootPtr);
            rootOwner = ReadPtr(rootPtr + SPACE_MODEL);
            return IsPtr(modelPtr) && IsPtr(rootPtr) &&
                   modelVtable == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA &&
                   rootVtable == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA &&
                   rootOwner == modelPtr;
        }

        private void RunAssociationSample()
        {
            if (_associationStartMs == 0)
                _associationStartMs = Environment.TickCount64;

            if (!TryReadTarget(out uint liveId, out float tx, out float ty, out float tz))
            {
                _targetLostSamples++;
                Write($"[STAGE70][SAMPLE] n={_sample + 1}/{SAMPLE_COUNT} targetRead=0 candidates={_candidates.Count}");
                return;
            }

            if (liveId != _targetId)
            {
                _targetIdMismatchSamples++;
                Write($"[STAGE70][BGA-TRACE-ID-MISMATCH] n={_sample + 1}/{SAMPLE_COUNT} elapsedMs={Environment.TickCount64 - _associationStartMs} bga=0x{_targetPtr:X} lockedId=0x{_targetId:X8} liveId=0x{liveId:X8} liveXYZ=({tx:F3},{ty:F3},{tz:F3}); coordinate sample rejected from association metrics but raw values preserved in log");
                return;
            }

            float targetStep = 0f;
            if (_hasPreviousTarget)
            {
                targetStep = Distance(_previousTargetX, _previousTargetY, _previousTargetZ, tx, ty, tz);
                if (float.IsFinite(targetStep))
                {
                    _targetTotalStep += targetStep;
                    if (targetStep >= TARGET_MOVEMENT_THRESHOLD && targetStep <= MAX_ASSOCIATION_TARGET_STEP)
                        _targetMotionTransitions++;
                    else if (targetStep > MAX_ASSOCIATION_TARGET_STEP)
                    {
                        _targetOutlierTransitions++;
                        Write($"[STAGE70][TARGET-STEP-OUTLIER] n={_sample + 1}/{SAMPLE_COUNT} targetStep={targetStep:F3} maxPlausibleStep={MAX_ASSOCIATION_TARGET_STEP:F3}; excluded from association motion counts");
                    }
                }
            }
            string stepClass;
            if (!_hasPreviousTarget)
                stepClass = "INITIAL";
            else if (targetStep < BGA_STATIONARY_THRESHOLD)
                stepClass = "STATIONARY";
            else if (targetStep > MAX_ASSOCIATION_TARGET_STEP)
            {
                stepClass = "LARGE_JUMP_INCLUDED_IN_RAW_TRACE";
                _largeRawJumpTransitions++;
                _largestRawJump = MathF.Max(_largestRawJump, targetStep);
            }
            else if (targetStep >= TARGET_MOVEMENT_THRESHOLD)
                stepClass = "PLAUSIBLE_MOVE";
            else
                stepClass = "SMALL_MOVE";

            bool hadPreviousTarget = _hasPreviousTarget;
            if (hadPreviousTarget && targetStep < BGA_STATIONARY_THRESHOLD)
            {
                _targetStationaryRun++;
                _targetStationarySamples++;
                if (_targetStationaryRun == MIN_STATIONARY_SAMPLES_FOR_HANDOFF)
                {
                    _targetStationaryEpisodes++;
                    Write($"[STAGE70][BGA-STATIONARY-EPISODE] n={_sample + 1} runLength={_targetStationaryRun} threshold={BGA_STATIONARY_THRESHOLD:F2} xyz=({tx:F3},{ty:F3},{tz:F3})");
                }
            }
            else
            {
                if (hadPreviousTarget && targetStep >= BGA_STATIONARY_THRESHOLD && _targetStationaryRun >= MIN_STATIONARY_SAMPLES_FOR_HANDOFF)
                    Write($"[STAGE70][BGA-STATIONARY-EPISODE-END] n={_sample + 1} priorRunLength={_targetStationaryRun} exitStep={targetStep:F3} exitClass={stepClass}");
                _targetStationaryRun = 0;
            }

            float snapshotX = float.NaN, snapshotY = float.NaN, snapshotZ = float.NaN;
            uint snapshotId = 0;
            long snapshotAgeMs = long.MaxValue;
            bool snapshotValid = false;
            lock (_sync)
            {
                snapshotAgeMs = _latestSnapshotTicks > 0 ? Math.Max(0, Environment.TickCount64 - _latestSnapshotTicks) : long.MaxValue;
                snapshotValid = _latestSnapshotPresent && _latestSnapshotPtr == _targetPtr &&
                    snapshotAgeMs <= SNAPSHOT_STALE_MS &&
                    IsValidCoordinate(_latestSnapshotX) && IsValidCoordinate(_latestSnapshotY) && IsValidCoordinate(_latestSnapshotZ);
                if (snapshotValid)
                {
                    snapshotX = _latestSnapshotX;
                    snapshotY = _latestSnapshotY;
                    snapshotZ = _latestSnapshotZ;
                    snapshotId = _latestSnapshotId;
                    _snapshotSeenSamples++;
                    float divergence = Distance(tx, ty, tz, snapshotX, snapshotY, snapshotZ);
                    if (divergence >= SNAPSHOT_DIVERGENCE_THRESHOLD)
                        _snapshotDivergenceSamples++;
                }
                else
                {
                    _snapshotMissingSamples++;
                }
            }
            float snapshotDistance = snapshotValid ? Distance(tx, ty, tz, snapshotX, snapshotY, snapshotZ) : float.NaN;
            long elapsedMs = _associationStartMs == 0 ? 0 : Environment.TickCount64 - _associationStartMs;
            Write($"[STAGE70][BGA-TRACE] n={_sample + 1}/{SAMPLE_COUNT} elapsedMs={elapsedMs} id=0x{liveId:X8} xyz=({tx:F3},{ty:F3},{tz:F3}) deltaStep={targetStep:F3} stepClass={stepClass} stationaryRun={_targetStationaryRun} totalRawStep={_targetTotalStep:F3} entitySnapshotValid={(snapshotValid ? 1 : 0)} snapshotId=0x{snapshotId:X8} snapshotAgeMs={(snapshotAgeMs == long.MaxValue ? -1 : snapshotAgeMs)} snapshotXYZ=({FormatCoordinate(snapshotX)},{FormatCoordinate(snapshotY)},{FormatCoordinate(snapshotZ)}) snapshotDistance={FormatDistance(snapshotDistance)} snapshotDiverges={(snapshotValid && snapshotDistance >= SNAPSHOT_DIVERGENCE_THRESHOLD ? 1 : 0)}");

            _previousTargetX = tx;
            _previousTargetY = ty;
            _previousTargetZ = tz;
            _hasPreviousTarget = true;

            int validCandidates = 0;
            int near128Candidates = 0;
            int near256Candidates = 0;
            int stableRelativeCandidates = 0;

            foreach (CandidateRecord candidate in _candidates.Values.OrderBy(c => c.ModelPtr))
            {
                bool structural = ValidateModelRoot(candidate.ModelPtr, candidate.RootPtr,
                    out long modelVtable, out long rootVtable, out long owner);
                if (structural)
                    candidate.StructurallyValidSamples++;
                else
                {
                    candidate.StructurallyInvalidSamples++;
                    if (_sample < 3 || (_sample + 1) % 10 == 0)
                        Write($"[STAGE70][CANDIDATE-STRUCTURE] n={_sample + 1} model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} valid=0 modelVtable=0x{modelVtable:X} rootVtable=0x{rootVtable:X} rootOwner=0x{owner:X}");
                    continue;
                }

                if (!TryReadNodeTransform(candidate.RootPtr, tx, ty, tz,
                    out float x, out float y, out float z, out string source, out float distance))
                    continue;

                candidate.ValidTransformSamples++;
                candidate.MinDistance = MathF.Min(candidate.MinDistance, distance);
                candidate.MaxDistance = MathF.Max(candidate.MaxDistance, distance);
                candidate.DistanceSum += distance;
                candidate.LastDistance = distance;
                if (distance <= MAX_NEAR_TARGET_DISTANCE)
                {
                    candidate.Near128Samples++;
                    near128Candidates++;
                }
                if (distance <= MAX_NEAR_TARGET_DIAGNOSTIC_DISTANCE)
                {
                    candidate.Near256Samples++;
                    near256Candidates++;
                }
                validCandidates++;

                float rx = x - tx;
                float ry = y - ty;
                float rz = z - tz;
                float rootStep = 0f;
                float relativeStep = 0f;
                if (candidate.HasPrevious)
                {
                    rootStep = Distance(candidate.PreviousX, candidate.PreviousY, candidate.PreviousZ, x, y, z);
                    relativeStep = Distance(candidate.PreviousRx, candidate.PreviousRy, candidate.PreviousRz, rx, ry, rz);
                    if (float.IsFinite(rootStep))
                        candidate.TotalRootStep += rootStep;
                    if (float.IsFinite(relativeStep))
                    {
                        candidate.TotalRelativeStep += relativeStep;
                        candidate.MaxRelativeStep = MathF.Max(candidate.MaxRelativeStep, relativeStep);
                    }

                    if (IsPlausibleTargetMotion(targetStep))
                    {
                        candidate.TargetMovingObservations++;
                        float stableLimit = MathF.Max(1.0f, targetStep * 0.25f);
                        if (relativeStep <= stableLimit)
                        {
                            candidate.RelativeStableWhileTargetMoves++;
                            stableRelativeCandidates++;
                        }
                        if (rootStep >= ROOT_STEP_THRESHOLD && relativeStep <= MathF.Max(2.0f, targetStep * 0.5f))
                            candidate.CoMotionSamples++;
                    }
                }

                candidate.PreviousX = x;
                candidate.PreviousY = y;
                candidate.PreviousZ = z;
                candidate.PreviousRx = rx;
                candidate.PreviousRy = ry;
                candidate.PreviousRz = rz;
                candidate.HasPrevious = true;

                Write($"[STAGE70][ROOT-TRACE] n={_sample + 1}/{SAMPLE_COUNT} model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} source={source} rootXYZ=({x:F3},{y:F3},{z:F3}) targetXYZ=({tx:F3},{ty:F3},{tz:F3}) targetStep={targetStep:F3} rootStep={rootStep:F3} relativeStep={relativeStep:F3} distance={distance:F3} relative=({rx:F3},{ry:F3},{rz:F3}) path={candidate.Path}");
            }

            SampleTransformProbes(tx, ty, tz, targetStep, stepClass, elapsedMs);
            SampleFocusedNodeTransforms(tx, ty, tz, targetStep);
            Write($"[STAGE70][SAMPLE] n={_sample + 1}/{SAMPLE_COUNT} targetId=0x{liveId:X8} targetXYZ=({tx:F3},{ty:F3},{tz:F3}) targetStep={targetStep:F3} targetTotalStep={_targetTotalStep:F3} movingTransitions={_targetMotionTransitions} validCandidates={validCandidates} within128={near128Candidates} within256={near256Candidates} stableRelativeWhileMoving={stableRelativeCandidates}");
        }

        private void RegisterTransformProbe(long ptr, long vtable, string path, int priority)
        {
            if (!IsPtr(ptr) || !IsPtr(vtable))
                return;

            if (vtable != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA &&
                vtable != _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA &&
                (vtable < _mem.BaseAddress || vtable >= _mem.BaseAddress + IMAGE_SIZE))
                return;

            if (_transformProbes.TryGetValue(ptr, out TransformProbeRecord existing))
            {
                bool pathIsCandidateRoot = path != null && path.Contains("::RootSpaceNode", StringComparison.Ordinal);
                bool existingPathIsCandidateRoot = existing.Path != null && existing.Path.Contains("::RootSpaceNode", StringComparison.Ordinal);
                if (priority > existing.Priority || (pathIsCandidateRoot && !existingPathIsCandidateRoot))
                {
                    if (existing.Priority < 3 && priority >= 3)
                        _genericTransformProbeCount = Math.Max(0, _genericTransformProbeCount - 1);
                    existing.Priority = Math.Max(existing.Priority, priority);
                    existing.Vtable = vtable;
                    existing.Path = path;
                }
                return;
            }

            bool generic = priority < 3;
            bool isCandidateRoot = path != null && path.Contains("::RootSpaceNode", StringComparison.Ordinal);
            if (generic && _genericTransformProbeCount >= MAX_GENERIC_TRANSFORM_PROBES)
                return;
            if (_transformProbes.Count >= MAX_TRANSFORM_PROBES)
            {
                if (!isCandidateRoot)
                    return;

                // Preserve candidate model roots if the bounded probe table fills with
                // lower-value model/object/node probes. Never grow beyond the cap.
                TransformProbeRecord victim = _transformProbes.Values
                    .Where(p => p.Path == null || !p.Path.Contains("::RootSpaceNode", StringComparison.Ordinal))
                    .OrderBy(p => p.Priority)
                    .ThenByDescending(p => p.ValidSamples)
                    .FirstOrDefault();
                if (victim == null)
                    return;
                _transformProbes.Remove(victim.Ptr);
                if (victim.Priority < 3)
                    _genericTransformProbeCount = Math.Max(0, _genericTransformProbeCount - 1);
            }

            _transformProbes[ptr] = new TransformProbeRecord
            {
                Ptr = ptr,
                Vtable = vtable,
                Path = path ?? "UNKNOWN",
                Priority = priority,
            };
            if (generic)
                _genericTransformProbeCount++;
        }

        private void SampleTransformProbes(float tx, float ty, float tz, float targetStep, string stepClass, long elapsedMs)
        {
            foreach (TransformProbeRecord probe in _transformProbes.Values.OrderByDescending(p => p.Priority).ThenBy(p => p.Ptr))
            {
                if (!TryReadNodeTransform(probe.Ptr, tx, ty, tz,
                    out float x, out float y, out float z, out string source, out float distance))
                {
                    probe.InvalidSamples++;
                    continue;
                }

                probe.ValidSamples++;
                probe.LastDistance = distance;
                probe.MinTargetDistance = MathF.Min(probe.MinTargetDistance, distance);
                probe.MaxTargetDistance = MathF.Max(probe.MaxTargetDistance, distance);
                probe.TargetDistanceSum += distance;

                float probeStep = 0f;
                if (probe.HasPrevious)
                {
                    probeStep = Distance(probe.PreviousX, probe.PreviousY, probe.PreviousZ, x, y, z);
                    probe.LastStep = probeStep;
                    if (float.IsFinite(probeStep))
                    {
                        probe.TotalStep += probeStep;
                        probe.MaxStep = MathF.Max(probe.MaxStep, probeStep);
                        if (probeStep >= PROBE_MOVEMENT_THRESHOLD)
                            probe.MovingTransitions++;
                        if (_targetStationaryRun >= MIN_STATIONARY_SAMPLES_FOR_HANDOFF)
                        {
                            probe.SamplesWhileBgaStationary++;
                            if (probeStep >= PROBE_MOVEMENT_THRESHOLD)
                                probe.MovesWhileBgaStationary++;
                        }
                    }
                }

                bool likelyRelevantSample = _sample == 0 || (_sample + 1) % 10 == 0 ||
                    probeStep >= PROBE_MOVEMENT_THRESHOLD || targetStep > MAX_ASSOCIATION_TARGET_STEP ||
                    _targetStationaryRun >= MIN_STATIONARY_SAMPLES_FOR_HANDOFF;
                if (likelyRelevantSample)
                {
                    Write($"[STAGE70][TRANSFORM-PROBE] n={_sample + 1}/{SAMPLE_COUNT} elapsedMs={elapsedMs} ptr=0x{probe.Ptr:X} vtable=0x{probe.Vtable:X} priority={probe.Priority} source={source} xyz=({x:F3},{y:F3},{z:F3}) step={probeStep:F3} stepClass={stepClass} distanceToBga={distance:F3} bgaStationaryRun={_targetStationaryRun} movedWhileBgaStationary={(probeStep >= PROBE_MOVEMENT_THRESHOLD && _targetStationaryRun >= MIN_STATIONARY_SAMPLES_FOR_HANDOFF ? 1 : 0)} path={probe.Path}");
                }

                probe.PreviousX = x;
                probe.PreviousY = y;
                probe.PreviousZ = z;
                probe.HasPrevious = true;
            }
        }

        private void PrepareFocusedRootCensuses()
        {
            _focusedRootCandidates.Clear();
            ProbeRuntimeModelResolverPaths();

            List<CandidateRecord> nearCandidates = _candidates.Values
                .Where(c => float.IsFinite(c.DiscoveryDistance) && c.DiscoveryDistance <= MAX_NEAR_TARGET_DISTANCE)
                .OrderBy(c => c.DiscoveryDistance)
                .ThenBy(c => c.ModelPtr)
                .ToList();

            var selected = new List<CandidateRecord>();
            var selectedModels = new HashSet<long>();

            void AddSelection(CandidateRecord candidate)
            {
                if (candidate == null || selected.Count >= MAX_FOCUSED_ROOT_CANDIDATES ||
                    !selectedModels.Add(candidate.ModelPtr))
                    return;
                selected.Add(candidate);
            }

            foreach (CandidateRecord candidate in nearCandidates)
                AddSelection(candidate);

            int nearSelected = selected.Count;
            if (selected.Count < MAX_FOCUSED_ROOT_CANDIDATES)
            {
                IEnumerable<CandidateRecord> fallbackCandidates = _candidates.Values
                    .Where(c => c != null && !selectedModels.Contains(c.ModelPtr))
                    .OrderBy(c => float.IsFinite(c.DiscoveryDistance) ? c.DiscoveryDistance : float.MaxValue)
                    .ThenByDescending(c => c.SourceNodePtr != 0)
                    .ThenByDescending(c => !string.IsNullOrEmpty(c.Path) &&
                        c.Path.Contains("BGA+0x0B8", StringComparison.Ordinal))
                    .ThenByDescending(c => c.FromBgaClosure)
                    .ThenBy(c => c.ModelPtr);

                foreach (CandidateRecord candidate in fallbackCandidates)
                {
                    AddSelection(candidate);
                    if (selected.Count >= MAX_FOCUSED_ROOT_CANDIDATES)
                        break;
                }
            }

            Write($"[STAGE70][FOCUSED-ROOTS] candidatesWithin128AtDiscovery={nearCandidates.Count} proximitySelected={nearSelected} selected={selected.Count} cap={MAX_FOCUSED_ROOT_CANDIDATES} selectionPolicy=within128-first,then-nearest; provenance-is-tie-breaker-only");
            if (selected.Count == 0)
            {
                Write("[STAGE70][FOCUSED-ROOT-CENSUS-SKIPPED] reason=no structurally discovered model/root candidates");
                return;
            }

            foreach (CandidateRecord candidate in selected)
            {
                string selectionReason = float.IsFinite(candidate.DiscoveryDistance) &&
                    candidate.DiscoveryDistance <= MAX_NEAR_TARGET_DISTANCE
                    ? "WITHIN128_AT_DISCOVERY"
                    : candidate.SourceNodePtr != 0
                        ? "SPACE_NODE_OWNER_FALLBACK"
                        : (!string.IsNullOrEmpty(candidate.Path) &&
                           candidate.Path.Contains("BGA+0x0B8", StringComparison.Ordinal))
                            ? "BGA_0B8_PROVENANCE_FALLBACK"
                            : "BOUNDED_DISTANCE_FALLBACK";

                if (!ValidateModelRoot(candidate.ModelPtr, candidate.RootPtr, out long modelVtable, out long rootVtable, out long owner))
                {
                    Write($"[STAGE70][FOCUSED-ROOT-REJECTED] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} selectionReason={selectionReason} modelVtable=0x{modelVtable:X} rootVtable=0x{rootVtable:X} owner=0x{owner:X}");
                    continue;
                }

                _focusedRootCandidates.Add(candidate);
                Write($"[STAGE70][FOCUSED-ROOT-PROVISIONAL] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} discoveryDistance={FormatDistance(candidate.DiscoveryDistance)} selectionReason={selectionReason} path={candidate.Path}; provisional until movement association is measured");
                ScanRuntimeEdgeClosure(candidate);
                ScanCandidateLocalSpaceNodeFields(candidate);
            }
        }

        /// <summary>
        /// Mirrors the active DynamicSkeletonReader's candidate-entry fields without using
        /// its cache or changing its behavior. This is a read-only path comparison only.
        /// </summary>
        private void ProbeRuntimeModelResolverPaths()
        {
            if (!TryReadTarget(out uint liveId, out float tx, out float ty, out float tz))
            {
                Write("[STAGE70][RUNTIME-MODEL-PATHS] status=SKIPPED reason=raw-target-read-failed");
                return;
            }

            long nativeGraph = ReadPtr(_targetPtr + BGA_NATIVE_GRAPH);
            long nativeGraphVtable = IsPtr(nativeGraph) ? ReadPtr(nativeGraph) : 0;
            Write($"[STAGE70][RUNTIME-MODEL-PATHS] target=0x{_targetPtr:X} id=0x{liveId:X8} BGA+0x0B8=0x{nativeGraph:X} graphVtable=0x{nativeGraphVtable:X}");

            long directModel = ReadPtr(_targetPtr + ENTITY_MODEL);
            ProbeRuntimeModelValue("BGA+0x0D8", directModel, tx, ty, tz);
            ProbeActiveResolverB8Graph(tx, ty, tz);

            long begin = ReadPtr(_targetPtr + ENTITY_MODELS_BEGIN);
            long end = ReadPtr(_targetPtr + ENTITY_MODELS_END);
            long byteCount = IsPtr(begin) && IsPtr(end) && end >= begin ? end - begin : -1;
            _runtimePathArrayMetadataValid = IsPtr(begin) && IsPtr(end) && end > begin &&
                byteCount <= MAX_RUNTIME_MODEL_ARRAY_BYTES && (byteCount & 7L) == 0;
            Write($"[STAGE70][RUNTIME-MODEL-ARRAY] begin=0x{begin:X} end=0x{end:X} bytes={byteCount} valid={(_runtimePathArrayMetadataValid ? 1 : 0)} capBytes=0x{MAX_RUNTIME_MODEL_ARRAY_BYTES:X}");
            if (!_runtimePathArrayMetadataValid)
                return;

            int bytes = (int)byteCount;
            if (!_mem.ReadBytesQuiet(begin, _runtimeModelArrayScratch, 0, bytes))
            {
                Write($"[STAGE70][RUNTIME-MODEL-ARRAY] read=0 begin=0x{begin:X} bytes={bytes}");
                return;
            }

            int elements = bytes / 8;
            for (int i = 0; i < elements; i++)
            {
                long model = ReadQword(_runtimeModelArrayScratch, i * 8);
                if (!IsPtr(model))
                    continue;

                bool knownCandidate = _candidates.TryGetValue(model, out CandidateRecord existingCandidate) &&
                    existingCandidate.FromBgaClosure;
                long vtable = ReadPtr(model);
                if (vtable != _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA && !knownCandidate)
                    continue;

                _runtimePathArrayCount++;
                if (vtable == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA)
                    _runtimePathArrayExactModels++;
                if (knownCandidate)
                    _runtimePathCandidateMatches++;
                ProbeRuntimeModelValue($"BGA+0x0E0[{i}]", model, tx, ty, tz);
            }
            Write($"[STAGE70][RUNTIME-MODEL-ARRAY-SUMMARY] elements={elements} loggedModelCandidates={_runtimePathArrayCount} exactModelVtables={_runtimePathArrayExactModels} matchesBgaClosureCandidates={_runtimePathCandidateMatches}");
        }

        /// <summary>
        /// Mirrors the active resolver's BGA+0x0B8 graph limits (0x400-byte object reads,
        /// depth 5, 128 visited objects) and root acceptance gates. This is read-only and
        /// reports whether the closest spatial-owner candidate is actually reachable by
        /// the route used by DynamicSkeletonReader.
        /// </summary>
        private void ProbeActiveResolverB8Graph(float tx, float ty, float tz)
        {
            _activeResolverGraphRan = true;
            long graph = ReadPtr(_targetPtr + BGA_NATIVE_GRAPH);
            if (!IsResolverFollowablePointer(graph))
            {
                Write($"[STAGE70][ACTIVE-B8-GRAPH][SUMMARY] status=SKIPPED graph=0x{graph:X} reason=GRAPH_POINTER_INVALID");
                return;
            }

            var queue = new Queue<(long Ptr, int Depth, long Parent, int ParentOffset, string Path)>();
            var visited = new HashSet<long> { graph };
            queue.Enqueue((graph, 0, 0, -1, "BGA+0x0B8"));
            int expanded = 0;
            int readFailures = 0;
            int exactModels = 0;
            int ownerMatchedModels = 0;
            int validNearbyRoots = 0;
            int rejectedRoots = 0;

            while (queue.Count > 0 && expanded < ACTIVE_RESOLVER_MAX_OBJECTS)
            {
                var item = queue.Dequeue();
                if (item.Depth > ACTIVE_RESOLVER_MAX_DEPTH || !IsResolverFollowablePointer(item.Ptr))
                    continue;
                if (!_mem.ReadBytesQuiet(item.Ptr, _activeResolverScratch, 0, ACTIVE_RESOLVER_GRAPH_BYTES))
                {
                    readFailures++;
                    continue;
                }

                expanded++;
                long vtable = ReadQword(_activeResolverScratch, 0);
                if (vtable == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA)
                {
                    exactModels++;
                    _activeResolverGraphExactModels++;
                    _activeResolverGraphModelPtrs.Add(item.Ptr);
                    long root = ReadQword(_activeResolverScratch, MODEL_SPACE_NODE);
                    long rootVtable = IsResolverFollowablePointer(root) ? ReadPtr(root) : 0;
                    long rootOwner = IsResolverFollowablePointer(root) ? ReadPtr(root + SPACE_MODEL) : 0;
                    bool rootOwnerMatches = rootOwner == item.Ptr;
                    if (rootOwnerMatches) ownerMatchedModels++;

                    float rx = float.NaN, ry = float.NaN, rz = float.NaN, distance = float.NaN;
                    string source = "INVALID";
                    bool transformValid = IsResolverFollowablePointer(root) && TryReadResolverAcceptedTransform(
                        root, tx, ty, tz, ACTIVE_RESOLVER_ROOT_MAX_DISTANCE,
                        out rx, out ry, out rz, out source, out distance);
                    bool accepted = rootOwnerMatches && transformValid && float.IsFinite(distance) &&
                        distance <= ACTIVE_RESOLVER_ROOT_MAX_DISTANCE;
                    if (accepted)
                    {
                        validNearbyRoots++;
                        _activeResolverGraphAcceptedRoots++;
                        if (!float.IsFinite(_activeResolverGraphBestDistance) || distance < _activeResolverGraphBestDistance)
                        {
                            _activeResolverGraphBestDistance = distance;
                            _activeResolverGraphBestModel = item.Ptr;
                            _activeResolverGraphBestRoot = root;
                        }
                    }
                    else
                    {
                        rejectedRoots++;
                    }

                    bool closureMatch = _candidates.TryGetValue(item.Ptr, out CandidateRecord existing) && existing.FromBgaClosure;
                    bool ownerRouteMatch = _candidates.TryGetValue(item.Ptr, out CandidateRecord ownerCandidate) &&
                        ownerCandidate.Path != null && ownerCandidate.Path.StartsWith("OWNER-OF-SPACE-NODE-", StringComparison.Ordinal);
                    Write($"[STAGE70][ACTIVE-B8-MODEL] model=0x{item.Ptr:X} root=0x{root:X} depth={item.Depth} parent=0x{item.Parent:X} parentOffset={(item.ParentOffset >= 0 ? $"+0x{item.ParentOffset:X}" : "ROOT")} modelVtable=0x{vtable:X} rootVtable=0x{rootVtable:X} rootOwner=0x{rootOwner:X} ownerMatchesModel={(rootOwnerMatches ? 1 : 0)} transformValid={(transformValid ? 1 : 0)} transformSource={(transformValid ? source : "INVALID")} distance={(transformValid ? FormatDistance(distance) : "N/A")} acceptedWithin64={(accepted ? 1 : 0)} matchesBgaClosureCandidate={(closureMatch ? 1 : 0)} hasOwnerRouteCandidate={(ownerRouteMatch ? 1 : 0)} path={item.Path}");
                }

                if (item.Depth >= ACTIVE_RESOLVER_MAX_DEPTH)
                    continue;

                for (int i = 0; i < ACTIVE_RESOLVER_GRAPH_BYTES / 8; i++)
                {
                    long child = ReadQword(_activeResolverScratch, i * 8);
                    if (!IsResolverFollowablePointer(child) || !visited.Add(child))
                        continue;
                    queue.Enqueue((child, item.Depth + 1, item.Ptr, i * 8, $"{item.Path}/+0x{i * 8:X}"));
                    if (visited.Count >= ACTIVE_RESOLVER_MAX_OBJECTS)
                        break;
                }
            }

            _activeResolverGraphObjects = expanded;
            CandidateRecord closest = _candidates.Values
                .Where(c => float.IsFinite(c.DiscoveryDistance))
                .OrderBy(c => c.DiscoveryDistance)
                .ThenBy(c => c.ModelPtr)
                .FirstOrDefault();
            bool closestReachable = closest != null && _activeResolverGraphModelPtrs.Contains(closest.ModelPtr);
            Write($"[STAGE70][ACTIVE-B8-GRAPH][SUMMARY] status=COMPLETE graph=0x{graph:X} expanded={expanded} visited={visited.Count} readFailures={readFailures} exactModels={exactModels} ownerMatchedModels={ownerMatchedModels} acceptedWithin64Roots={validNearbyRoots} rejectedModelRoots={rejectedRoots} capObjects={ACTIVE_RESOLVER_MAX_OBJECTS} maxDepth={ACTIVE_RESOLVER_MAX_DEPTH} objectBytes=0x{ACTIVE_RESOLVER_GRAPH_BYTES:X}");
            Write($"[STAGE70][RESOLVER-SPATIAL-COMPARISON] closestSpatialModel={(closest == null ? "0x0" : $"0x{closest.ModelPtr:X}")} closestSpatialRoot={(closest == null ? "0x0" : $"0x{closest.RootPtr:X}")} discoveryDistance={(closest == null ? "N/A" : FormatDistance(closest.DiscoveryDistance))} path={(closest == null ? "NONE" : closest.Path)} reachableFromActiveB8Graph={(closestReachable ? 1 : 0)} activeB8AcceptedWinnerModel=0x{_activeResolverGraphBestModel:X} activeB8AcceptedWinnerRoot=0x{_activeResolverGraphBestRoot:X} activeB8WinnerDistance={FormatDistance(_activeResolverGraphBestDistance)}");
        }

        /// <summary>
        /// Scans only aligned pointer fields inside the selected candidate model (0x1000 bytes)
        /// and root node (0x620 bytes) for exact SpaceNode-vtable pointers. It keeps only nodes
        /// with a target/root-local transform or a candidate-owner relation, then samples their
        /// movement and follows the known runtime edge slots. It is not a process-wide scan and
        /// pointer proximity alone is never described as an anatomical edge.
        /// </summary>
        private void ScanCandidateLocalSpaceNodeFields(CandidateRecord candidate)
        {
            if (candidate == null || !TryReadTarget(out _, out float tx, out float ty, out float tz))
                return;

            bool rootTransformValid = TryReadNodeTransform(candidate.RootPtr, tx, ty, tz,
                out float rootX, out float rootY, out float rootZ, out _, out _);
            var localNodes = new List<(long Node, string Path)>();
            var foundNodes = new HashSet<long>();
            int exactPointers = 0;
            int relevantPointers = 0;
            int modelRead = 0;
            int rootRead = 0;

            ScanRegion(candidate.ModelPtr, LOCAL_MODEL_SCAN_BYTES, _objectScratch, "MODEL-LOCAL", ref modelRead);
            ScanRegion(candidate.RootPtr, LOCAL_ROOT_SCAN_BYTES, _rootCensusScratch, "ROOT-LOCAL", ref rootRead);

            void ScanRegion(long sourcePtr, int bytes, byte[] scratch, string sourceName, ref int readOk)
            {
                if (!IsPtr(sourcePtr) || !_mem.ReadBytesQuiet(sourcePtr, scratch, 0, bytes))
                {
                    Write($"[STAGE70][LOCAL-OBJECT-SCAN] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} region={sourceName} source=0x{sourcePtr:X} bytes=0x{bytes:X} read=0");
                    return;
                }

                readOk++;
                _localObjectRegionsScanned++;
                long expectedNodeVtable = _mem.BaseAddress + SPACE_NODE_VTABLE_RVA;
                for (int offset = 8; offset <= bytes - 8; offset += 8)
                {
                    long child = ReadQword(scratch, offset);
                    if (!IsPtr(child) || child == candidate.RootPtr || child == candidate.ModelPtr ||
                        ReadPtr(child) != expectedNodeVtable)
                        continue;

                    exactPointers++;
                    _localExactSpaceNodePointers++;
                    long owner = ReadPtr(child + SPACE_MODEL);
                    if (!TryReadNodeTransform(child, tx, ty, tz,
                        out float nx, out float ny, out float nz, out string transformSource, out float targetDistance))
                        continue;

                    float rootDistance = rootTransformValid
                        ? Distance(rootX, rootY, rootZ, nx, ny, nz)
                        : float.NaN;
                    bool ownerMatches = owner == candidate.ModelPtr;
                    bool nearTarget = targetDistance <= MAX_NEAR_TARGET_DISTANCE;
                    bool nearRoot = float.IsFinite(rootDistance) && rootDistance <= MAX_NEAR_TARGET_DISTANCE;
                    bool relevant = nearTarget || nearRoot || (ownerMatches && targetDistance <= MAX_NEAR_TARGET_DIAGNOSTIC_DISTANCE);
                    if (!relevant)
                        continue;

                    relevantPointers++;
                    _localRelevantSpaceNodePointers++;
                    string path = $"{sourceName}/+0x{offset:X}";
                    Write($"[STAGE70][LOCAL-SPACE-NODE-CANDIDATE] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} source=0x{sourcePtr:X} offset=+0x{offset:X} node=0x{child:X} owner=0x{owner:X} ownerMatchesCandidate={(ownerMatches ? 1 : 0)} xyz=({nx:F3},{ny:F3},{nz:F3}) sourceTransform={transformSource} targetDistance={targetDistance:F3} rootDistance={FormatDistance(rootDistance)} nearTarget={(nearTarget ? 1 : 0)} nearRoot={(nearRoot ? 1 : 0)} path={path}; candidate pointer only, not a proven bone edge");

                    AddFocusedEdge(candidate, sourcePtr, child, offset, 0, "LOCAL_OBJECT_SLOT", path);
                    if (candidate.FocusedNodes.Count < MAX_FOCUSED_NODES_PER_ROOT && AddFocusedNode(candidate, child, 1, path))
                    {
                        _localFocusedNodesAdded++;
                        RegisterTransformProbe(child, expectedNodeVtable, $"{path}::RootSpaceNode", 4);
                    }
                    if (foundNodes.Add(child) && localNodes.Count < MAX_LOCAL_NODE_MATCHES_PER_ROOT)
                        localNodes.Add((child, path));
                    if (localNodes.Count >= MAX_LOCAL_NODE_MATCHES_PER_ROOT)
                        break;
                }
            }

            // Walk only the exact runtime edge slots from locally discovered SpaceNodes.
            var queue = new Queue<(long Node, int Depth, string Path)>();
            var queuedOrVisited = new HashSet<long> { candidate.RootPtr };
            foreach (var node in localNodes)
            {
                if (queuedOrVisited.Add(node.Node))
                    queue.Enqueue((node.Node, 1, node.Path));
            }
            var processed = new HashSet<long>();
            while (queue.Count > 0 && candidate.FocusedNodes.Count < MAX_FOCUSED_NODES_PER_ROOT)
            {
                var work = queue.Dequeue();
                if (work.Depth > MAX_FOCUSED_DEPTH || !IsPtr(work.Node) || !processed.Add(work.Node) ||
                    ReadPtr(work.Node) != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA)
                    continue;
                if (!_mem.ReadBytesQuiet(work.Node, _rootCensusScratch, 0, _rootCensusScratch.Length))
                    continue;
                if (!TryReadNodeTransform(work.Node, tx, ty, tz,
                    out _, out _, out _, out _, out float distance) ||
                    (distance > MAX_NEAR_TARGET_DISTANCE && ReadPtr(work.Node + SPACE_MODEL) != candidate.ModelPtr))
                    continue;
                InspectRuntimeEdgeSlots(candidate, work.Node, work.Depth, work.Path,
                    queue, queuedOrVisited, tx, ty, tz);
            }

            Write($"[STAGE70][LOCAL-OBJECT-SCAN][SUMMARY] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} modelRegionRead={(modelRead > 0 ? 1 : 0)} rootRegionRead={(rootRead > 0 ? 1 : 0)} totalRegionsScanned={modelRead + rootRead} exactSpaceNodePointers={exactPointers} relevantTargetOrRootLocalPointers={relevantPointers} newlyFocusedNodes={candidate.FocusedNodes.Count} totalLocalFocusedNodesAdded={_localFocusedNodesAdded} references={candidate.FocusedEdges.Count} policy=model+0x0..0x{LOCAL_MODEL_SCAN_BYTES:X},root+0x0..0x{LOCAL_ROOT_SCAN_BYTES:X}; exact-vtable + spatial/owner gates; no semantic bone assumption");
        }

        private static bool IsResolverFollowablePointer(long ptr) =>
            ptr >= 0x10000 && ptr < 0x0000800000000000L;

        /// <summary>
        /// Applies DynamicSkeletonReader's transform-source preference for diagnostic
        /// resolver acceptance: use WorldMatrix148 only when it is target-local; otherwise
        /// fall back to Translation178 when that source is valid and target-local.
        /// </summary>
        private bool TryReadResolverAcceptedTransform(long node, float targetX, float targetY, float targetZ,
            float maxDistance, out float x, out float y, out float z, out string source, out float distance)
        {
            x = y = z = 0f;
            source = "INVALID";
            distance = float.NaN;
            if (!IsResolverFollowablePointer(node))
                return false;

            if (_mem.ReadBytesQuiet(node + SPACE_WORLD_MATRIX, _transformScratch, 0, MATRIX_BYTES) &&
                TryDecodeMatrixTranslation(_transformScratch, out float mx, out float my, out float mz))
            {
                float matrixDistance = Distance(targetX, targetY, targetZ, mx, my, mz);
                if (float.IsFinite(matrixDistance) && matrixDistance <= maxDistance)
                {
                    x = mx; y = my; z = mz;
                    source = "WorldMatrix148";
                    distance = matrixDistance;
                    return true;
                }
            }

            if (_mem.ReadBytesQuiet(node + SPACE_WORLD_TRANSLATION, _translationScratch, 0, _translationScratch.Length))
            {
                float tx = BitConverter.ToSingle(_translationScratch, 0);
                float ty = BitConverter.ToSingle(_translationScratch, 4);
                float tz = BitConverter.ToSingle(_translationScratch, 8);
                if (IsValidCoordinate(tx) && IsValidCoordinate(ty) && IsValidCoordinate(tz))
                {
                    float translationDistance = Distance(targetX, targetY, targetZ, tx, ty, tz);
                    if (float.IsFinite(translationDistance) && translationDistance <= maxDistance)
                    {
                        x = tx; y = ty; z = tz;
                        source = "Translation178";
                        distance = translationDistance;
                        return true;
                    }
                }
            }
            return false;
        }

        private void ProbeRuntimeModelValue(string path, long model, float tx, float ty, float tz)
        {
            if (!IsPtr(model))
            {
                Write($"[STAGE70][RUNTIME-MODEL-CANDIDATE] path={path} ptr=0x{model:X} pointerValid=0");
                return;
            }

            long modelVtable = ReadPtr(model);
            bool alreadyInPool = _candidates.ContainsKey(model);
            bool matchesClosureCandidate = _candidates.TryGetValue(model, out CandidateRecord existingCandidate) &&
                existingCandidate.FromBgaClosure;
            if (modelVtable != _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA)
            {
                Write($"[STAGE70][RUNTIME-MODEL-CANDIDATE] path={path} ptr=0x{model:X} modelVtable=0x{modelVtable:X} exactModelSkeletal=0 matchesBgaClosureCandidate={(matchesClosureCandidate ? 1 : 0)} alreadyInDiagnosticPool={(alreadyInPool ? 1 : 0)}");
                return;
            }

            long root = ReadPtr(model + MODEL_SPACE_NODE);
            bool valid = ValidateModelRoot(model, root, out _, out long rootVtable, out long rootOwner);
            float rx = float.NaN, ry = float.NaN, rz = float.NaN, distance = float.NaN;
            string source = "INVALID";
            bool transformValid = valid && TryReadResolverAcceptedTransform(root, tx, ty, tz,
                ACTIVE_RESOLVER_ROOT_MAX_DISTANCE, out rx, out ry, out rz, out source, out distance);
            string transform = transformValid
                ? $"source={source} rootXYZ=({rx:F3},{ry:F3},{rz:F3}) rootDistance={distance:F3}"
                : "source=INVALID rootDistance=N/A";

            bool addedToPool = false;
            if (valid && transformValid && !alreadyInPool && _candidates.Count < MAX_MODEL_CANDIDATES)
            {
                AddCandidate(new CandidateRecord
                {
                    ModelPtr = model,
                    RootPtr = root,
                    Path = $"RUNTIME-RESOLVER:{path}",
                    FromBgaClosure = false,
                    SourceNodePtr = 0,
                    DiscoveryDistance = distance,
                });
                addedToPool = _candidates.ContainsKey(model);
                if (addedToPool)
                    _runtimePathAddedCandidates++;
            }

            Write($"[STAGE70][RUNTIME-MODEL-CANDIDATE] path={path} ptr=0x{model:X} modelVtable=0x{modelVtable:X} root=0x{root:X} rootVtable=0x{rootVtable:X} rootOwner=0x{rootOwner:X} validReciprocal={(valid ? 1 : 0)} transformValid={(transformValid ? 1 : 0)} matchesBgaClosureCandidate={(matchesClosureCandidate ? 1 : 0)} addedToCandidatePool={(addedToPool ? 1 : 0)} {transform}");
        }

        /// <summary>
        /// Traces only the runtime reader's documented node fields (+0x18/+0x318/+0x618),
        /// plus its recorded Model+0x3E8 evidence branch. Broad qword windows are not treated
        /// as hierarchy edges in Stage 70.
        /// </summary>
        private void ScanRuntimeEdgeClosure(CandidateRecord candidate)
        {
            if (!TryReadTarget(out _, out float targetX, out float targetY, out float targetZ))
            {
                Write($"[STAGE70][RUNTIME-EDGE-CENSUS-SKIPPED] model=0x{candidate.ModelPtr:X} reason=raw-target-read-failed");
                return;
            }

            var queue = new Queue<(long Node, int Depth, string Path)>();
            var queuedOrVisited = new HashSet<long> { candidate.RootPtr };
            var processed = new HashSet<long>();
            long rootVtable = ReadPtr(candidate.RootPtr);
            Write($"[STAGE70][RUNTIME-EDGE-ROOT] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} rootVtable=0x{rootVtable:X} owner=0x{ReadPtr(candidate.RootPtr + SPACE_MODEL):X} edgeOffsets=+0x18,+0x318,+0x618");

            InspectRuntimeEdgeSlots(candidate, candidate.RootPtr, 0, "ROOT", queue, queuedOrVisited, targetX, targetY, targetZ);

            long branch = ReadPtr(candidate.ModelPtr + MODEL_PRIORITY_BRANCH);
            long branchVtable = IsPtr(branch) ? ReadPtr(branch) : 0;
            Write($"[STAGE70][RUNTIME-PRIORITY-BRANCH] model=0x{candidate.ModelPtr:X} offset=+0x{MODEL_PRIORITY_BRANCH:X} ptr=0x{branch:X} pointerValid={(IsPtr(branch) ? 1 : 0)} vtable=0x{branchVtable:X} note=diagnostic-seed-not-an-assumed-bone");
            if (IsPtr(branch) && branch != candidate.ModelPtr && branch != candidate.RootPtr)
            {
                InspectRuntimeEdgeSlots(candidate, branch, 0, "MODEL+0x3E8", queue, queuedOrVisited, targetX, targetY, targetZ);
                if (branchVtable == rootVtable && candidate.FocusedNodes.Count < MAX_FOCUSED_NODES_PER_ROOT &&
                    !queuedOrVisited.Contains(branch) && TryReadNodeTransform(branch, targetX, targetY, targetZ,
                        out _, out _, out _, out _, out float branchDistance) &&
                    branchDistance <= MAX_NEAR_TARGET_DISTANCE && AddFocusedNode(candidate, branch, 1, "MODEL+0x3E8"))
                {
                    queuedOrVisited.Add(branch);
                    queue.Enqueue((branch, 1, "MODEL+0x3E8"));
                }
            }

            while (queue.Count > 0 && candidate.FocusedNodes.Count < MAX_FOCUSED_NODES_PER_ROOT)
            {
                var work = queue.Dequeue();
                if (work.Depth > MAX_FOCUSED_DEPTH || !IsPtr(work.Node) || !processed.Add(work.Node))
                    continue;
                if (ReadPtr(work.Node) != rootVtable)
                    continue;
                if (!_mem.ReadBytesQuiet(work.Node, _rootCensusScratch, 0, _rootCensusScratch.Length))
                {
                    Write($"[STAGE70][RUNTIME-EDGE-NODE-READ-FAIL] model=0x{candidate.ModelPtr:X} node=0x{work.Node:X} depth={work.Depth} path={work.Path}");
                    continue;
                }

                long owner = ReadQword(_rootCensusScratch, SPACE_MODEL);
                if (!TryReadNodeTransform(work.Node, targetX, targetY, targetZ,
                    out float nx, out float ny, out float nz, out string source, out float distance))
                {
                    Write($"[STAGE70][RUNTIME-EDGE-NODE-REJECTED] model=0x{candidate.ModelPtr:X} node=0x{work.Node:X} depth={work.Depth} owner=0x{owner:X} reason=TRANSFORM_INVALID path={work.Path}");
                    continue;
                }
                Write($"[STAGE70][RUNTIME-EDGE-NODE] model=0x{candidate.ModelPtr:X} node=0x{work.Node:X} depth={work.Depth} owner=0x{owner:X} source={source} xyz=({nx:F3},{ny:F3},{nz:F3}) targetDistanceFromRawReference={distance:F3} path={work.Path}");
                InspectRuntimeEdgeSlots(candidate, work.Node, work.Depth, work.Path, queue, queuedOrVisited, targetX, targetY, targetZ);
            }

            Write($"[STAGE70][RUNTIME-EDGE-CENSUS-COMPLETE] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} sampledNodeCandidates={candidate.FocusedNodes.Count} exactRuntimeSlotReferences={candidate.FocusedEdges.Count} depthCap={MAX_FOCUSED_DEPTH} nodeCap={MAX_FOCUSED_NODES_PER_ROOT} policy=known-runtime-slots-only");
        }

        private void InspectRuntimeEdgeSlots(
            CandidateRecord candidate,
            long parent,
            int depth,
            string path,
            Queue<(long Node, int Depth, string Path)> queue,
            HashSet<long> queuedOrVisited,
            float targetX, float targetY, float targetZ)
        {
            if (!IsPtr(parent))
                return;

            long parentVtable = ReadPtr(parent);
            long parentOwner = ReadPtr(parent + SPACE_MODEL);
            foreach (int offset in RUNTIME_EDGE_OFFSETS)
            {
                long child = ReadPtr(parent + offset);
                if (!IsPtr(child))
                {
                    Write($"[STAGE70][RUNTIME-EDGE-SLOT] model=0x{candidate.ModelPtr:X} parent=0x{parent:X} parentVtable=0x{parentVtable:X} parentOwner=0x{parentOwner:X} offset=+0x{offset:X} child=0x{child:X} pointerValid=0 path={path}/+0x{offset:X}");
                    continue;
                }

                long childVtable = ReadPtr(child);
                bool exactNodeType = childVtable == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA;
                long childOwner = exactNodeType ? ReadPtr(child + SPACE_MODEL) : 0;
                float x = float.NaN, y = float.NaN, z = float.NaN, distance = float.NaN;
                string source = "INVALID";
                bool transformValid = exactNodeType && TryReadNodeTransform(child, targetX, targetY, targetZ,
                    out x, out y, out z, out source, out distance);
                bool local = transformValid && distance <= MAX_NEAR_TARGET_DISTANCE;
                Write($"[STAGE70][RUNTIME-EDGE-SLOT] model=0x{candidate.ModelPtr:X} parent=0x{parent:X} parentVtable=0x{parentVtable:X} parentOwner=0x{parentOwner:X} offset=+0x{offset:X} child=0x{child:X} childVtable=0x{childVtable:X} exactSpaceNode={(exactNodeType ? 1 : 0)} childOwner=0x{childOwner:X} ownerMatchesCandidate={(childOwner == candidate.ModelPtr ? 1 : 0)} transformValid={(transformValid ? 1 : 0)} transformSource={(transformValid ? source : "INVALID")} childXYZ={(transformValid ? $"({x:F3},{y:F3},{z:F3})" : "N/A")} targetDistance={(transformValid ? distance.ToString("F3", CultureInfo.InvariantCulture) : "N/A")} within128={(local ? 1 : 0)} queued={(local && depth + 1 <= MAX_FOCUSED_DEPTH ? 1 : 0)} path={path}/+0x{offset:X}");

                if (!exactNodeType)
                    continue;

                AddFocusedEdge(candidate, parent, child, offset, depth, "RUNTIME_EDGE_SLOT", $"{path}/+0x{offset:X}");
                if (child == candidate.RootPtr || !local || depth + 1 > MAX_FOCUSED_DEPTH ||
                    queuedOrVisited.Contains(child) || candidate.FocusedNodes.Count >= MAX_FOCUSED_NODES_PER_ROOT)
                    continue;

                if (AddFocusedNode(candidate, child, depth + 1, $"{path}/+0x{offset:X}"))
                {
                    queue.Enqueue((child, depth + 1, $"{path}/+0x{offset:X}"));
                    // Mark at enqueue time to avoid multiple queue entries for cycles.
                    queuedOrVisited.Add(child);
                }
            }
        }

        private bool AddFocusedNode(CandidateRecord candidate, long nodePtr, int depth, string path)
        {
            if (nodePtr == candidate.RootPtr || !IsPtr(nodePtr))
                return false;
            if (candidate.FocusedNodes.ContainsKey(nodePtr))
                return false;
            if (candidate.FocusedNodes.Count >= MAX_FOCUSED_NODES_PER_ROOT)
                return false;

            candidate.FocusedNodes[nodePtr] = new FocusedNodeRecord
            {
                NodePtr = nodePtr,
                OwnerPtr = ReadPtr(nodePtr + SPACE_MODEL),
                Depth = depth,
                FirstPath = path,
            };
            return true;
        }

        private void AddFocusedEdge(CandidateRecord candidate, long source, long target, int offset, int depth, string role, string path)
        {
            if (candidate.FocusedEdges.Count >= MAX_FOCUSED_EDGES_PER_ROOT ||
                !candidate.FocusedEdgeKeys.Add((source, target, offset)))
                return;

            candidate.FocusedEdges.Add(new FocusedEdgeRecord
            {
                SourcePtr = source,
                TargetPtr = target,
                Offset = offset,
                Depth = depth,
                Role = role,
                Path = path,
            });
            long owner = ReadPtr(target + SPACE_MODEL);
            Write($"[STAGE70][FOCUSED-SPACE-NODE-REFERENCE] model=0x{candidate.ModelPtr:X} source=0x{source:X} offset=+0x{offset:X} target=0x{target:X} targetOwner=0x{owner:X} targetOwnerMatchesCandidate={(owner == candidate.ModelPtr ? 1 : 0)} role={role} depth={depth} path={path}; reference only, not yet classified as a bone edge");
        }

        private void SampleFocusedNodeTransforms(float tx, float ty, float tz, float targetStep)
        {
            foreach (CandidateRecord candidate in _focusedRootCandidates)
            {
                if (!ValidateModelRoot(candidate.ModelPtr, candidate.RootPtr, out _, out _, out _))
                {
                    if (_sample == 0 || (_sample + 1) % 10 == 0)
                        Write($"[STAGE70][FOCUSED-ROOT-STRUCTURE] n={_sample + 1} model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} valid=0; focused-node transforms skipped for this root");
                    continue;
                }
                if (!TryReadNodeTransform(candidate.RootPtr, tx, ty, tz,
                    out float rootX, out float rootY, out float rootZ, out _, out _))
                    continue;

                foreach (FocusedNodeRecord node in candidate.FocusedNodes.Values.OrderBy(n => n.Depth).ThenBy(n => n.NodePtr))
                {
                    long nodeVtable = ReadPtr(node.NodePtr);
                    long owner = ReadPtr(node.NodePtr + SPACE_MODEL);
                    if (nodeVtable == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA)
                    {
                        node.StructuralValidSamples++;
                        if (owner == candidate.ModelPtr)
                            node.OwnerMatchesCandidateSamples++;
                        if (IsPtr(owner) && ReadPtr(owner) == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA)
                            node.OwnerIsModelSamples++;
                    }
                    else
                    {
                        node.StructuralInvalidSamples++;
                        if (_sample == 0 || (_sample + 1) % 10 == 0)
                            Write($"[STAGE70][FOCUSED-NODE-STRUCTURE] n={_sample + 1} node=0x{node.NodePtr:X} valid=0 vtable=0x{nodeVtable:X} owner=0x{owner:X} path={node.FirstPath}");
                        continue;
                    }

                    if (!TryReadNodeTransform(node.NodePtr, tx, ty, tz,
                        out float x, out float y, out float z, out string source, out float distance))
                        continue;

                    node.ValidTransformSamples++;
                    node.MinTargetDistance = MathF.Min(node.MinTargetDistance, distance);
                    node.MaxTargetDistance = MathF.Max(node.MaxTargetDistance, distance);
                    node.TargetDistanceSum += distance;
                    float targetRx = x - tx, targetRy = y - ty, targetRz = z - tz;
                    float rootRx = x - rootX, rootRy = y - rootY, rootRz = z - rootZ;
                    float nodeStep = 0f, targetRelativeStep = 0f, rootRelativeStep = 0f;
                    if (node.HasPrevious)
                    {
                        nodeStep = Distance(node.PreviousX, node.PreviousY, node.PreviousZ, x, y, z);
                        targetRelativeStep = Distance(node.PreviousTargetRx, node.PreviousTargetRy, node.PreviousTargetRz, targetRx, targetRy, targetRz);
                        rootRelativeStep = Distance(node.PreviousRootRx, node.PreviousRootRy, node.PreviousRootRz, rootRx, rootRy, rootRz);
                        if (float.IsFinite(nodeStep)) node.TotalNodeStep += nodeStep;
                        if (float.IsFinite(targetRelativeStep))
                        {
                            node.TotalTargetRelativeStep += targetRelativeStep;
                            node.MaxTargetRelativeStep = MathF.Max(node.MaxTargetRelativeStep, targetRelativeStep);
                        }
                        if (float.IsFinite(rootRelativeStep))
                        {
                            node.TotalRootRelativeStep += rootRelativeStep;
                            node.MaxRootRelativeStep = MathF.Max(node.MaxRootRelativeStep, rootRelativeStep);
                        }
                        if (IsPlausibleTargetMotion(targetStep))
                        {
                            node.TargetMovingObservations++;
                            if (targetRelativeStep <= MathF.Max(1.0f, targetStep * 0.25f))
                                node.StableRelativeToTargetWhileMoving++;
                            if (nodeStep >= ROOT_STEP_THRESHOLD && targetRelativeStep <= MathF.Max(2.0f, targetStep * 0.5f))
                                node.CoMotionSamples++;
                        }
                    }

                    node.PreviousX = x; node.PreviousY = y; node.PreviousZ = z;
                    node.PreviousTargetRx = targetRx; node.PreviousTargetRy = targetRy; node.PreviousTargetRz = targetRz;
                    node.PreviousRootRx = rootRx; node.PreviousRootRy = rootRy; node.PreviousRootRz = rootRz;
                    node.HasPrevious = true;

                    if (_sample == 0 || (_sample + 1) % 5 == 0)
                    {
                        Write($"[STAGE70][FOCUSED-NODE-SAMPLE] n={_sample + 1}/{SAMPLE_COUNT} model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} node=0x{node.NodePtr:X} depth={node.Depth} owner=0x{owner:X} ownerMatchesCandidate={(owner == candidate.ModelPtr ? 1 : 0)} source={source} targetDistance={distance:F3} rootDistance={Distance(x, y, z, rootX, rootY, rootZ):F3} nodeStep={nodeStep:F3} targetRelativeStep={targetRelativeStep:F3} rootRelativeStep={rootRelativeStep:F3} relativeToTarget=({targetRx:F3},{targetRy:F3},{targetRz:F3}) relativeToRoot=({rootRx:F3},{rootRy:F3},{rootRz:F3}) path={node.FirstPath}");
                    }
                }
            }
        }

        private bool AssociationPatternStrong(CandidateRecord c)
        {
            float meanDistance = AverageDistance(c);
            int moving = c.TargetMovingObservations;
            return c.StructurallyValidSamples >= (int)(SAMPLE_COUNT * MIN_ASSOCIATION_RATIO) &&
                   c.ValidTransformSamples >= (int)(SAMPLE_COUNT * MIN_ASSOCIATION_RATIO) &&
                   c.Near128Samples >= (int)(SAMPLE_COUNT * MIN_ASSOCIATION_RATIO) &&
                   moving >= MIN_ASSOCIATION_MOVING_OBSERVATIONS &&
                   c.RelativeStableWhileTargetMoves >= Math.Ceiling(moving * MIN_ASSOCIATION_RATIO) &&
                   c.CoMotionSamples >= Math.Ceiling(moving * MIN_ASSOCIATION_RATIO) &&
                   float.IsFinite(meanDistance) && meanDistance <= MAX_ASSOCIATION_MEAN_DISTANCE &&
                   c.MaxDistance <= MAX_NEAR_TARGET_DISTANCE;
        }

        private void EmitFocusedRootResults()
        {
            if (_focusedRootCandidates.Count == 0)
            {
                Write("[STAGE70][FINAL][ROOT-HIERARCHY] status=NOT_RUN reason=no candidate root was within 128 units at discovery");
                Write("[STAGE70][FINAL][VERDICT] targetAssociationPattern=UNCONFIRMED anatomicalHierarchyProven=0");
                return;
            }

            int qualifiedRoots = 0;
            foreach (CandidateRecord candidate in _focusedRootCandidates)
            {
                bool qualified = AssociationPatternStrong(candidate);
                if (qualified) qualifiedRoots++;
                Write($"[STAGE70][FINAL][ROOT-ASSOCIATION] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} associationPattern={(qualified ? 1 : 0)} discoveryDistance={FormatDistance(candidate.DiscoveryDistance)} validStructure={candidate.StructurallyValidSamples}/{SAMPLE_COUNT} validTransforms={candidate.ValidTransformSamples}/{SAMPLE_COUNT} near128={candidate.Near128Samples}/{SAMPLE_COUNT} movingObservations={candidate.TargetMovingObservations} stableRelative={candidate.RelativeStableWhileTargetMoves} coMotion={candidate.CoMotionSamples} meanDistance={FormatDistance(AverageDistance(candidate))} maxDistance={FormatDistance(candidate.MaxDistance)} nodes={candidate.FocusedNodes.Count} references={candidate.FocusedEdges.Count}");

                foreach (FocusedNodeRecord node in candidate.FocusedNodes.Values.OrderBy(n => n.Depth).ThenBy(n => n.NodePtr))
                {
                    float meanDistance = node.ValidTransformSamples > 0 ? (float)(node.TargetDistanceSum / node.ValidTransformSamples) : float.NaN;
                    Write($"[STAGE70][FINAL][NODE] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} node=0x{node.NodePtr:X} depth={node.Depth} owner=0x{node.OwnerPtr:X} ownerMatchesCandidateSamples={node.OwnerMatchesCandidateSamples} ownerIsModelSamples={node.OwnerIsModelSamples} structureValid={node.StructuralValidSamples} structureInvalid={node.StructuralInvalidSamples} validTransforms={node.ValidTransformSamples} targetMovingObservations={node.TargetMovingObservations} stableRelativeToTarget={node.StableRelativeToTargetWhileMoving} coMotion={node.CoMotionSamples} minDistance={(node.MinTargetDistance == float.MaxValue ? "N/A" : node.MinTargetDistance.ToString("F3", CultureInfo.InvariantCulture))} meanDistance={FormatDistance(meanDistance)} maxDistance={FormatDistance(node.MaxTargetDistance)} totalNodeStep={node.TotalNodeStep:F3} totalTargetRelativeStep={node.TotalTargetRelativeStep:F3} totalRootRelativeStep={node.TotalRootRelativeStep:F3} maxTargetRelativeStep={node.MaxTargetRelativeStep:F3} maxRootRelativeStep={node.MaxRootRelativeStep:F3} path={node.FirstPath}");
                }
                foreach (FocusedEdgeRecord edge in candidate.FocusedEdges)
                    Write($"[STAGE70][FINAL][REFERENCE] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} source=0x{edge.SourcePtr:X} offset=+0x{edge.Offset:X} target=0x{edge.TargetPtr:X} role={edge.Role} depth={edge.Depth} path={edge.Path}");
            }

            Write($"[STAGE70][FINAL][ROOT-HIERARCHY] focusedRoots={_focusedRootCandidates.Count} associationPatternQualifiedRoots={qualifiedRoots} directAndNestedExactReferences={_focusedRootCandidates.Sum(c => c.FocusedEdges.Count)} anatomicalHierarchyProven=0");
            Write("[STAGE70][FINAL][VERDICT] associationPattern qualifies a target-associated root for further inspection only; exact SpaceNode pointer references are not semantic bone edges and do not prove anatomical hierarchy");
        }

        private void ResetCandidateSampling(CandidateRecord candidate)
        {
            candidate.StructurallyValidSamples = 0;
            candidate.StructurallyInvalidSamples = 0;
            candidate.ValidTransformSamples = 0;
            candidate.Near128Samples = 0;
            candidate.Near256Samples = 0;
            candidate.TargetMovingObservations = 0;
            candidate.RelativeStableWhileTargetMoves = 0;
            candidate.CoMotionSamples = 0;
            candidate.MinDistance = float.MaxValue;
            candidate.MaxDistance = 0f;
            candidate.DistanceSum = 0;
            candidate.TotalRootStep = 0f;
            candidate.TotalRelativeStep = 0f;
            candidate.MaxRelativeStep = 0f;
            candidate.LastDistance = float.NaN;
            candidate.HasPrevious = false;
        }

        private bool TryReadTarget(out uint id, out float x, out float y, out float z)
        {
            id = 0;
            x = y = z = 0f;
            if (!IsPtr(_targetPtr) || !_mem.ReadBytesQuiet(_targetPtr + BGA_ID, _bgaScratch, 0, 0x30))
                return false;

            id = BitConverter.ToUInt32(_bgaScratch, 0);
            x = BitConverter.ToSingle(_bgaScratch, 4);
            y = BitConverter.ToSingle(_bgaScratch, 8);
            z = BitConverter.ToSingle(_bgaScratch, 12);
            return IsValidCoordinate(x) && IsValidCoordinate(y) && IsValidCoordinate(z);
        }

        private bool TryReadNodeTransform(long node, float targetX, float targetY, float targetZ,
            out float x, out float y, out float z, out string source, out float targetDistance)
        {
            x = y = z = 0f;
            source = "INVALID";
            targetDistance = float.NaN;
            if (!IsPtr(node))
                return false;

            if (_mem.ReadBytesQuiet(node + SPACE_WORLD_MATRIX, _transformScratch, 0, MATRIX_BYTES) &&
                TryDecodeMatrixTranslation(_transformScratch, out float mx, out float my, out float mz))
            {
                x = mx;
                y = my;
                z = mz;
                source = "WorldMatrix148";
                targetDistance = Distance(targetX, targetY, targetZ, x, y, z);
                return float.IsFinite(targetDistance);
            }

            if (_mem.ReadBytesQuiet(node + SPACE_WORLD_TRANSLATION, _translationScratch, 0, _translationScratch.Length))
            {
                float tx = BitConverter.ToSingle(_translationScratch, 0);
                float ty = BitConverter.ToSingle(_translationScratch, 4);
                float tz = BitConverter.ToSingle(_translationScratch, 8);
                if (IsValidCoordinate(tx) && IsValidCoordinate(ty) && IsValidCoordinate(tz))
                {
                    x = tx;
                    y = ty;
                    z = tz;
                    source = "Translation178";
                    targetDistance = Distance(targetX, targetY, targetZ, x, y, z);
                    return float.IsFinite(targetDistance);
                }
            }
            return false;
        }

        private static bool TryDecodeMatrixTranslation(byte[] bytes, out float x, out float y, out float z)
        {
            x = y = z = 0f;
            if (bytes == null || bytes.Length < MATRIX_BYTES)
                return false;
            for (int i = 0; i < 16; i++)
            {
                if (!float.IsFinite(BitConverter.ToSingle(bytes, i * 4)))
                    return false;
            }

            x = BitConverter.ToSingle(bytes, 0x30);
            y = BitConverter.ToSingle(bytes, 0x34);
            z = BitConverter.ToSingle(bytes, 0x38);
            float w = BitConverter.ToSingle(bytes, 0x3C);
            return IsValidCoordinate(x) && IsValidCoordinate(y) && IsValidCoordinate(z) &&
                   float.IsFinite(w) && MathF.Abs(w) > 0.0001f;
        }

        private long ReadPtr(long address)
        {
            if (!IsPtr(address))
                return 0;
            return _mem.ReadBytesQuiet(address, _ptrScratch, 0, 8)
                ? BitConverter.ToInt64(_ptrScratch, 0)
                : 0;
        }

        private static long ReadQword(byte[] bytes, int offset) =>
            bytes != null && offset >= 0 && offset + 8 <= bytes.Length
                ? BitConverter.ToInt64(bytes, offset)
                : 0;

        private static bool IsPtr(long value) =>
            value >= 0x10000 && value < 0x0000800000000000L && (value & 0x7L) == 0;

        private static bool IsValidCoordinate(float value) =>
            float.IsFinite(value) && MathF.Abs(value) <= MAX_WORLD_COORD;

        private static float Distance(float ax, float ay, float az, float bx, float by, float bz)
        {
            float dx = bx - ax;
            float dy = by - ay;
            float dz = bz - az;
            return MathF.Sqrt(dx * dx + dy * dy + dz * dz);
        }

        private static string FormatDistance(float value) =>
            float.IsFinite(value) ? value.ToString("F3", CultureInfo.InvariantCulture) : "N/A";

        private static string FormatCoordinate(float value) =>
            float.IsFinite(value) ? value.ToString("F3", CultureInfo.InvariantCulture) : "N/A";

        private void EmitFinal(string status)
        {
            Write("");
            Write("============================================================");
            Write("[STAGE70][FINAL][RESULT]");
            Write("============================================================");
            Write($"[STAGE70][FINAL][STATUS] {status}");
            Write($"[STAGE70][FINAL][TARGET] bga=0x{_targetPtr:X} id=0x{_targetId:X8} selectionMethod={_targetSelectionMethod} preselectionSamples={_targetSelectionSamples} preselectionMovingTransitions={_targetSelectionTransitions} preselectionPlausibleStep={_targetSelectionPlausibleStep:F3} preselectionOutlierSteps={_targetSelectionOutliers} targetLostSamples={_targetLostSamples} targetIdMismatchSamples={_targetIdMismatchSamples} targetMotionTransitions={_targetMotionTransitions} targetOutlierTransitions={_targetOutlierTransitions} targetTotalStep={_targetTotalStep:F3}");
            Write($"[STAGE70][FINAL][RUNTIME-MODEL-PATHS] arrayMetadataValid={(_runtimePathArrayMetadataValid ? 1 : 0)} arrayCandidatesLogged={_runtimePathArrayCount} exactModelVtables={_runtimePathArrayExactModels} matchesBgaClosureCandidates={_runtimePathCandidateMatches} runtimePathCandidatesAdded={_runtimePathAddedCandidates} fields=BGA+0x0B8,+0x0D8,+0x0E0,+0x0E8");
            CandidateRecord finalClosestSpatial = _candidates.Values
                .Where(c => float.IsFinite(c.DiscoveryDistance))
                .OrderBy(c => c.DiscoveryDistance)
                .ThenBy(c => c.ModelPtr)
                .FirstOrDefault();
            bool finalClosestReachable = finalClosestSpatial != null && _activeResolverGraphModelPtrs.Contains(finalClosestSpatial.ModelPtr);
            Write($"[STAGE70][FINAL][ACTIVE-B8-GRAPH] ran={(_activeResolverGraphRan ? 1 : 0)} objects={_activeResolverGraphObjects} exactModels={_activeResolverGraphExactModels} acceptedRootsWithin64={_activeResolverGraphAcceptedRoots} bestModel=0x{_activeResolverGraphBestModel:X} bestRoot=0x{_activeResolverGraphBestRoot:X} bestDistance={FormatDistance(_activeResolverGraphBestDistance)} closestSpatialModel={(finalClosestSpatial == null ? "0x0" : $"0x{finalClosestSpatial.ModelPtr:X}")} closestSpatialRoot={(finalClosestSpatial == null ? "0x0" : $"0x{finalClosestSpatial.RootPtr:X}")} closestSpatialDistance={(finalClosestSpatial == null ? "N/A" : FormatDistance(finalClosestSpatial.DiscoveryDistance))} closestSpatialReachableFromB8={(finalClosestReachable ? 1 : 0)}");
            Write($"[STAGE70][FINAL][LOCAL-OBJECT-SCAN] regionsScanned={_localObjectRegionsScanned} exactSpaceNodePointers={_localExactSpaceNodePointers} relevantTargetOrRootLocalPointers={_localRelevantSpaceNodePointers} newlyFocusedNodes={_localFocusedNodesAdded} modelBytes=0x{LOCAL_MODEL_SCAN_BYTES:X} rootBytes=0x{LOCAL_ROOT_SCAN_BYTES:X} maxRelevantPerRoot={MAX_LOCAL_NODE_MATCHES_PER_ROOT}");
            Write($"[STAGE70][FINAL][DISCOVERY] attempts={_discoveryAttempts} objectsInspected={_discoveryObjectsInspected} lastAttemptBgaObjects={_firstHopObjectsOnLastAttempt} lastAttemptNestedObjects={_nestedObjectsOnLastAttempt} totalNestedObjectsRead={_nestedObjectsTotalRead} uniqueNestedPointersSeen={_nestedScanned.Count} pendingNested={_nestedQueue.Count} nestedReadFailures={_nestedReadFailures} directOrNestedModels={_directModelCandidates} sceneAnchors={_sceneAnchorsScanned} sceneNodes={_sceneNodes.Count} pointerReferences={_scenePointerReferences} candidatePool={_candidates.Count}");
            Write("[STAGE70][FINAL][RANKING-POLICY] measurement-order-only; no automatic candidate acceptance; association ranking remains measurement-only; focused hierarchy selection is nearest-at-discovery, not a final winner");

            int rank = 0;
            foreach (CandidateRecord c in _candidates.Values
                .OrderByDescending(c => c.RelativeStableWhileTargetMoves)
                .ThenByDescending(c => c.Near128Samples)
                .ThenByDescending(c => c.ValidTransformSamples)
                .ThenBy(c => float.IsFinite(AverageDistance(c)) ? c.TotalRelativeStep : float.MaxValue)
                .ThenBy(c => float.IsFinite(AverageDistance(c)) ? AverageDistance(c) : float.MaxValue)
                .ThenBy(c => c.ModelPtr))
            {
                rank++;
                string minDistance = c.MinDistance == float.MaxValue
                    ? "N/A"
                    : c.MinDistance.ToString("F3", CultureInfo.InvariantCulture);
                float meanDistance = AverageDistance(c);
                Write($"[STAGE70][FINAL][CANDIDATE] rank={rank} model=0x{c.ModelPtr:X} root=0x{c.RootPtr:X} fromBgaClosure={(c.FromBgaClosure ? 1 : 0)} sourceNode=0x{c.SourceNodePtr:X} path={c.Path} discoveryDistance={FormatDistance(c.DiscoveryDistance)} finalDistance={FormatDistance(c.LastDistance)} minDistance={minDistance} maxDistance={FormatDistance(c.MaxDistance)} meanDistance={FormatDistance(meanDistance)} structureValid={c.StructurallyValidSamples} structureInvalid={c.StructurallyInvalidSamples} validTransforms={c.ValidTransformSamples} near128={c.Near128Samples} near256={c.Near256Samples} targetMovingObservations={c.TargetMovingObservations} stableRelativeWhileTargetMoves={c.RelativeStableWhileTargetMoves} coMotion={c.CoMotionSamples} totalRootStep={c.TotalRootStep:F3} totalRelativeStep={c.TotalRelativeStep:F3} maxRelativeStep={c.MaxRelativeStep:F3}");
            }

            if (string.Equals(status, "NO_CANDIDATE_POOL", StringComparison.Ordinal))
            {
                Write("[STAGE70][FINAL][VERDICT] targetMovementSufficient=NOT_SAMPLED targetAssociationPattern=UNCONFIRMED anatomicalHierarchyProven=0 reason=no candidate pool was discovered; association sampling never started");
            }
            else
            {
                bool movementObserved = _targetMotionTransitions >= MIN_ASSOCIATION_MOVING_OBSERVATIONS;
                Write($"[STAGE70][FINAL][VERDICT] targetMovementSufficient={(movementObserved ? 1 : 0)} requiredMovingTransitions={MIN_ASSOCIATION_MOVING_OBSERVATIONS} targetTotalStep={_targetTotalStep:F3} movingTransitions={_targetMotionTransitions} candidateRootAssociationIsMeasurementOnly=1 anatomicalHierarchyProven=0");
            }
            Write($"[STAGE70][FINAL][BGA-TRACE-SUMMARY] stationarySamples={_targetStationarySamples} stationaryEpisodes={_targetStationaryEpisodes} currentStationaryRun={_targetStationaryRun} largeRawJumpTransitions={_largeRawJumpTransitions} largestRawJump={_largestRawJump:F3} snapshotValidSamples={_snapshotSeenSamples} snapshotMissingOrStaleSamples={_snapshotMissingSamples} snapshotDivergenceSamples={_snapshotDivergenceSamples} snapshotDivergenceThreshold={SNAPSHOT_DIVERGENCE_THRESHOLD:F2} snapshotComparison=rawBgaVsOverlayEntityDataCopyNotIndependentGameTransform");
            Write($"[STAGE70][FINAL][TRANSFORM-PROBE-SUMMARY] probes={_transformProbes.Count} genericProbes={_genericTransformProbeCount} maxProbes={MAX_TRANSFORM_PROBES} probesWithStationaryBgaMovement={_transformProbes.Values.Count(p => p.MovesWhileBgaStationary > 0)}");
            foreach (TransformProbeRecord probe in _transformProbes.Values
                .OrderByDescending(p => p.MovesWhileBgaStationary)
                .ThenByDescending(p => p.MovingTransitions)
                .ThenBy(p => p.Ptr))
            {
                float meanDistance = probe.ValidSamples > 0 ? (float)(probe.TargetDistanceSum / probe.ValidSamples) : float.NaN;
                Write($"[STAGE70][FINAL][TRANSFORM-PROBE] ptr=0x{probe.Ptr:X} vtable=0x{probe.Vtable:X} priority={probe.Priority} validSamples={probe.ValidSamples} invalidSamples={probe.InvalidSamples} movingTransitions={probe.MovingTransitions} movesWhileBgaStationary={probe.MovesWhileBgaStationary} samplesWhileBgaStationary={probe.SamplesWhileBgaStationary} totalStep={probe.TotalStep:F3} maxStep={probe.MaxStep:F3} minDistance={FormatDistance(probe.MinTargetDistance == float.MaxValue ? float.NaN : probe.MinTargetDistance)} meanDistance={FormatDistance(meanDistance)} maxDistance={FormatDistance(probe.MaxTargetDistance)} lastDistance={FormatDistance(probe.LastDistance)} path={probe.Path}");
            }
            bool rootHandoffPattern = _transformProbes.Values.Any(p =>
                p.Path != null && p.Path.Contains("::RootSpaceNode", StringComparison.Ordinal) && p.MovesWhileBgaStationary >= 2);
            bool genericHandoffPattern = _transformProbes.Values.Any(p => p.Priority < 3 && p.MovesWhileBgaStationary >= 2);
            bool anyProbeMovement = _transformProbes.Values.Any(p => p.MovesWhileBgaStationary >= 2);
            Write($"[STAGE70][FINAL][HANDOFF-PATTERN] candidateModelRootMovedDuringBgaStationarity={(rootHandoffPattern ? 1 : 0)} genericClosureObjectMovedDuringBgaStationarity={(genericHandoffPattern ? 1 : 0)} anyProbeIncludingNonRootSpaceNodesMovedDuringBgaStationarity={(anyProbeMovement ? 1 : 0)} minimumProbeMovements=2; these are candidate patterns only and do not prove a vehicle handoff");
            EmitFocusedRootResults();
            Write("[STAGE70][FINAL][NEXT] use the active BGA+0x0B8 reachability verdict and target/root-local SpaceNode candidates to determine the next hierarchy step; mount/dismount attribution still requires an observed event; do not change the renderer from this diagnostic alone");
            Write("============================================================");
            lock (_sync)
            {
                try { _writer?.Flush(); } catch { }
            }
        }

        private static bool IsPlausibleTargetMotion(float step) =>
            float.IsFinite(step) && step >= TARGET_MOVEMENT_THRESHOLD && step <= MAX_ASSOCIATION_TARGET_STEP;

        private static float AverageDistance(CandidateRecord candidate) =>
            candidate.ValidTransformSamples > 0
                ? (float)(candidate.DistanceSum / candidate.ValidTransformSamples)
                : float.NaN;

        private void CompleteCapture()
        {
            _captureComplete = true;
            try { _timer?.Change(Timeout.Infinite, Timeout.Infinite); } catch { }
        }

        private void Write(string message)
        {
            Console.WriteLine(message);
            lock (_sync)
            {
                try
                {
                    _writer?.WriteLine($"{DateTimeOffset.Now:O} {message}");
                    if (_writer != null && (message.Contains("[FINAL]", StringComparison.Ordinal) || _sample % 5 == 0))
                        _writer.Flush();
                }
                catch { }
            }
        }

        private static void SafeConsole(string message)
        {
            try { Console.WriteLine(message); } catch { }
        }

        public void Dispose()
        {
            if (Interlocked.Exchange(ref _disposed, 1) != 0)
                return;
            try { _timer?.Change(Timeout.Infinite, Timeout.Infinite); } catch { }
            try { _timer?.Dispose(); } catch { }
            lock (_sync)
            {
                try { _writer?.Flush(); } catch { }
                try { _writer?.Dispose(); } catch { }
                _writer = null;
            }
        }
    }
}
```


---

## Record 11 — `SHA256SUMS.txt`

<sub>Original size: 10028 bytes · Original SHA-256: `1c6ea3883892d79c203059b6f38f27867ade8bd36a7aaa7c6a71f71ffb3061bf`</sub>

```text
a013f7d6b2fa0f7f9efd4e2182909ce99227ef1b915b6cfe468907d2dc607350  Core/DynamicSkeletonReader.cs
d2a1b8bfcd27c3e92480ad7329686cc5e262062e44c7745c7a71a55841cbcafb  Core/Mem.cs
d4a1bc83640e6d6a4ac3e4b302f0a3233a2d39ebc67b4262887a76bc54587d7c  Core/Offsets.cs
8a89b697d177cdfc60bedb8cdd2a8bc8c49099d43b33f80d4af2ce0401d61e77  Core/RuntimeDiagnostics.cs
e5fef36fd07ab0f067e2c3a9f017be104ace82d4dfe246a2c03dc6cf76dd4129  Core/SkeletonCoverageTrace.cs
e662b6c8755cea2746c1177835941e189962d7ccf293f2cee421acea01f486b2  Core/Stage53TargetInternalTrace.cs
7b653657ad63a66190eac2636830df82b94656f2e68873d4588fd1bec5e9cecc  Core/Stage54BoneHierarchyTrace.cs
01288451613b18b693f1b168598f08759c0a32c264cff9a7a9fbfef3a20a7203  Core/Stage55TargetOwnedSkeletonRecon.cs
f98c7f102d51382f5f0925db79a9373ca1af24560fd4138f74034dc7791b321c  Core/Stage56TargetClosureSkeletonRecon.cs
9c992c4ef5f4d28600b8bef826065669c8c7d462217b227ad0849a6d2084df38  Core/Stage57RootSpaceNodeCensus.cs
ccccd409cb7df2599063c98c398314304df8500b285505e9cdd3dbf004b4b1cd  Core/Stage59ExpandedClosureRawMotionRecon.cs
265d5a29fd5987aa547a1573fe90f2813e901ada9b6abf770fea1ead42e8946a  Core/Stage60TargetModelInternalRecon.cs
2fb58d8bd6ba31a75a899aee10928c1e646ef24bb70bf67c23135cb7d69538f0  Core/Stage61TargetModelAssociationRecon.cs
3c95bc4663425de11db4f17c7605b1359ae6d64d8a857872e41b02f21c9a95f0  Core/Stage62TargetOwnedPointerClosureRecon.cs
7e10466753a0942a2ed7e136deb10456a6928341ec1268ad5fb7d5c98c985da9  Core/Stage63TargetRootHierarchyRecon.cs
17ade8f27fccd0ee4bd6bf8886c533cd1259f509f179060a80e2a5259ac3e686  Core/Stage64ExpandedRootFanoutRecon.cs
d8b4da556d3b2d032e72c665962935b11d5346b7f159e0122dde87ea8f1c737a  Core/Stage66BgaPriorityClosureRecon.cs
788532a5cfbdd50da165c4e376c2cbb104e2f2e52e45328355c85bc57872e880  Core/Stage67VehicleTransitionRecon.cs
8ad6d01c3743ceb5f6e7a87a26c312a1e273175a17bd4edf8b44373d2b72a18f  Core/Stage71TargetedRouteExtendedRootRecon.cs
658aa18b92bf8dcdec6785b3c11d6173b971cb3eb8a3a59208a0cf23d66e921c  Core/Stage72ActiveEnemyRouteFieldRecon.cs
62dd44d6bab5964996303b8d6688932a1bf3aa69f875b84b91777823c9499dcb  Core/Stage73CandidateModelRootHierarchyRecon.cs
ee94f5f17fd23c92a19d1343e9d2d2b67b1357aea1d56fdaf15b4a426db6a37f  Core/Stage74ActiveEnemyModelRootHierarchyRecon.cs
c05d53e38adce0c48b0f7a66f0fb2e3c7cd81ff4a7d2afd1c810273575398f63  Core/Stage76ComprehensiveSkeletonDiscoveryRecon.cs
d15b8901719dc9c87f26f556f36f6324e36f13668751640f64e245171d93c0f8  Core/Stage78BoundedNodeHierarchyRecon.cs
fdb16e3e39edd9157a57c48515da339c4c9afc4c78c84a8390d30790fc7b6581  Core/WorldToScreen.cs
af407ad9752c4e4b27b506ca6731acddd0c5b96455246a64d495608253ef1f3a  Engine/Camera.cs
96b071186d91ff21204d699134d3583c89edb0726d43946c5c01c4e261ba1ae7  Engine/EntityData.cs
9286c360ef42590ff249b8e27847d23e006da42ce9efb3b98ef9a65e41ba46f4  Engine/EntityLoop.cs
774275d5f1664095610006b27dad258ee4b4c06066560b86799aaaef3c5a4363  Engine/PlayerReader.cs
8aaf27f5ac20c96a1b391405fba644d444af1e6541ab63b7f9faff593ae2143f  Features/Aimbot.cs
009920314c050f7d84dcc5f3b2701866835529358adca12adca3c82982fe6ce5  Features/ESP.cs
307e4fffce6269464d57629869376efeb4339e29dd6953fc4680cbd7d1bb4638  Features/EntityClassifier.cs
dcb1a0555b16a629373d3fa46132fe0f478c6aa8394ec398ac8e034e1cb97359  Features/NoClip.cs
5e7ba560c2da50707cc4ab742b77f14993cc06a3f0f568f94efda0ffc7225af9  Features/Settings.cs
792d3b0b691c1746ddce8199cd06773a81134e0e8aa6878841030b7cad51a025  NATIVE_BONE_CANDIDATE_NOTES.txt
d56cf844873bcc282340c4bb27a315e54c6a73056619a467d45e443cf9d0e358  NATIVE_BONE_LAYOUT_AUDIT.txt
b40a2c877460467475687b15c1f12d673d3686c8d203410ee1bb7e9c89ab9a2e  Overlay/HackOverlay.cs
b6dd857a67a3faacec76e1f4261eaf3046784647a3edecbccb11e7575674abcd  Overlay/MenuForm.cs
7e96eed2e8a34c39c535a64c63afadccc7578e18460eb72d0112b9b99133951f  Program.cs
f285c663accb511a351588002dcf5b5121690ef637a63159b746d99b38fd3e8e  README_BUILD.txt
486f26a1ff9a07b9f1e995627835c0eb8c59a5896b5937719babdf9226a2219f  RECON_HISTORY/STAGE47_RUNTIME_CORRUPTION_REVIEW.txt
d8986874490dc12c4bd87af2ac795e0763b0676ef5c3e5a1719ba99cadaff11b  RECON_HISTORY/STAGE49_RUNTIME_RECONCILIATION_NOTES.txt
3e43ee25e9b2334cc26aeccb795ff532ba5cc2399dbd4c6d0ac4be58ad8a44b7  RECON_HISTORY/STAGE52_EntityModelCorrelationDiagnostics_LEGACY.cs.txt
47d712a5aabae7b4a14777769e8e1097604f5084db4aaa589d34754b0769d51a  RECON_HISTORY/STAGE67_VALIDATION_REPORT.txt
3d1e45ef477fdb7cb4a59b4a4d9d1ac29d73ed5d4e7a70fa2ff1869660ba7bd3  RECON_HISTORY/STAGE68_VALIDATION_REPORT.txt
f5fd19ed524a49a050c8159a343c5afffa2714832208eef10ff34c11ca76cdc7  RECON_HISTORY/Stage68TargetRootHierarchyRecon.cs.txt
3330a729da9fc724cf930705a30f5a60bffba16ab7a38fff4c1090e07dbc0f08  RECON_HISTORY/Stage70ResolverReachabilityRecon.cs.txt
ab8acd0decdf55b63050b9f015b8a338e1bdef7068948d391cc851d9504ca3f2  ROS64Hack.csproj
e1d63c72cd72b4d7dcbc4afefd63eca30e9ab88fd770dff1fd0f20d5ae3d98fb  STAGE52_CLEANUP_AUDIT.txt
ba879f0e7b881e779c79ee182c22fa8ce7952579b2cb4e7ff61b71757d455ac8  STAGE52_CLEANUP_NOTES.txt
9c7d3a3668a1b5f8a8b99d5f91e01a6a53e473f46e1e640dcf6ac445a460807d  STAGE52_LOW_IMPACT_DIAGNOSTIC_NOTES.txt
441aeebd1e058b0475a2eb25ff67b75710ef505587c8ba99dd5e4c55a8f5c6b4  STAGE53_TARGET_INTERNAL_TRACE_NOTES.txt
90f07e5b482da776a48fa3462671fa6816c8693e2f0937f77b9bf93357fff55c  STAGE54_BONE_HIERARCHY_RECON_NOTES.txt
0d58c72112e40349eaa4e7d9d65cc1e2a5a0916f96d1174eea061b12310455f6  STAGE55_TARGET_OWNED_SKELETON_RECON_NOTES.txt
b3fcd29e15589e058dacb8326d2c47553806d0bf4455d0837ec798cc7fdc1145  STAGE56_TARGET_CLOSURE_RECON_NOTES.txt
95e8e8df980a7017ef9777079833f3db9ce234b6cc79032b2c35efcead717bb4  STAGE57_ROOT_SPACENODE_CENSUS_NOTES.txt
8196e816c774a3a9d554d4c1f1345435d15f3855e898993caa7e87f871d28209  STAGE59_EXPANDED_CLOSURE_RAW_MOTION_RECON_NOTES.txt
24870c34718bb3d8afc75a3227b62a8973809f74539179a76a4a17f62b162d70  STAGE60_TARGET_MODEL_INTERNAL_RECON_NOTES.txt
904e8eee34171d298f24ca45d5e2389b1a47b377b84dc5d82033c81467b9bded  STAGE61_TARGET_MODEL_ASSOCIATION_RECON_NOTES.txt
8fc7d5b3b779dd90a3818f5763177af54aba5d8e6fc3eaf5f73038c3286cf10c  STAGE61_VALIDATION_REPORT.txt
1f51e22787804aa51740a2393a8f510cb5bcbef21427d184cf6cac444d928a5b  STAGE62_TARGET_OWNED_POINTER_CLOSURE_RECON_NOTES.txt
3e0761fa8849fd9e540bf9b4928ec952b83a86f9ceed5db034ef54ebdcd0e888  STAGE62_VALIDATION_REPORT.txt
e8e800f7153cf6f18e91d551f64e8212db71b9229e720af222c9083fd378c1dc  STAGE63_TARGET_ROOT_HIERARCHY_RECON_NOTES.txt
92db38bdb0746d0c0490e3856fa89ae22a82ca2324dae2706635653651a15f94  STAGE63_VALIDATION_REPORT.txt
c9ef4803612fd3cbafebe6831ef70b57968357c35476d04680afe0664bf0d3c2  STAGE64_EXPANDED_ROOT_FANOUT_RECON_NOTES.txt
80129776b5ebe88a36f7edca6f76e1ae69d9edc2b52d2b6c9bbdf19ccfe819f3  STAGE64_VALIDATION_REPORT.txt
d5129d44aff233e4299ceccb5e0d4eb281db5619255e44d2d072824c68fd5962  STAGE65_ACTIVE_TARGET_ROOT_RECON_NOTES.txt
4984dd2d9deffb2e65a7ef09b220e4c6a367e901f0838842d50e0e2ccbf0b833  STAGE65_VALIDATION_REPORT.txt
f521bd8cc50f1be10dbd7f4db86be213c5b5e4a523d34a03110f97d9f67a3aac  STAGE66_BGA_PRIORITY_CLOSURE_RECON_NOTES.txt
233b4a41fe579f5a776b3e968909328bb22dada159ffcd626190a5e5e71a6542  STAGE66_VALIDATION_REPORT.txt
37dbdb1a463e871f878e1ba2f8cecb000f313f5e825ea335b6999b2bb7f68efd  STAGE67_VEHICLE_TRANSITION_RECON_NOTES.txt
c60b6554b2b934224e2275445d2a38ba83213a807316d625b6f1e34dea64b79f  STAGE68_TARGET_ROOT_HIERARCHY_RECON_NOTES.txt
2e0be9accb81643c325f5419f79f3048f7eeacd5be5ea74a3d4c5d9b0756fa47  STAGE69_VALIDATION_REPORT.txt
ee42767b674a7b4ef34db3a784f3654e18304899b20dc7c7c63a7d26ab8da3ba  STAGE70_RESOLVER_REACHABILITY_RECON_NOTES.txt
c424730149ccc6bd1bc1452241d55b99561e9c47d55672f016be4a703ec5ed77  STAGE70_VALIDATION_REPORT.txt
cb9aa780713c1befc4dcac41f034d9427ccaeda1c398cacfe27f841d11ae7259  STAGE71_TARGETED_ROUTE_EXTENDED_ROOT_RECON_NOTES.txt
c546195a53ea976e183774e6bb9c0231c1ae5b1b97501af85e441d0fa3004f85  STAGE71_VALIDATION_REPORT.txt
5a6a642cfca80729ebd114e8c81fdcd8fdf9006534ff17d745947d0094efaf5f  STAGE72_ACTIVE_ENEMY_ROUTE_FIELD_RECON_NOTES.txt
78466a2a4b010565a260346b501af6549cf46192ba75e3918ab39235c39b2c9e  STAGE72_VALIDATION_REPORT.txt
63b114cd3abe597e500a9aec03ca6a17f5c42947f5a1c15f02e0688503e8c657  STAGE73_CANDIDATE_MODEL_ROOT_HIERARCHY_RECON_NOTES.txt
b06cfa076f841571243c78b4b88851de0501f1f4b21cc1fdf861a903714f7e1a  STAGE73_VALIDATION_REPORT.txt
93e2d28c6cfe2e0a80364773680f2e24b1d2b7ad5138005aa40ae9b1c92d21f7  STAGE74_ACTIVE_ENEMY_MODEL_ROOT_HIERARCHY_RECON_NOTES.txt
43f84c3891e0596e54dac618c5a3228fdd15e1e1ca949e85d6ca1a4bb1d574e9  STAGE74_VALIDATION_REPORT.txt
e4c9636e837af7b01519fcf6f8af1c01f219cc5dedf6ee2fd84e176f60680d30  STAGE75_ACTIVE_ENEMY_MODEL_ROOT_NEIGHBORHOOD_RECON_NOTES.txt
3293f5552761fbe820ec3e1388904271faf7052205824ff237ee5a2704b4f0ca  STAGE75_VALIDATION_REPORT.txt
2ee55e0136dbae2198d3334f9dfdea3ad609c10824d0a6d3fecafc07d8f715e7  STAGE76_VALIDATION_REPORT.txt
39f16351f2c7f3be23e4b46804309aca3072e478ae2d5249cf4649dc24e2fe23  STAGE77_CANDIDATE_MOTION_TRACKING_NOTES.txt
5522f9e6398201833ed55893b6439a7cf01eb6c3dc5738f7c7b341f358837df2  STAGE77_VALIDATION_REPORT.txt
b5c6bb9ea949d3bcd6447200ecc9d12237999dcaad03d4725fb05a3fddc5bd4a  STAGE78_VALIDATION_NOTES.txt
a1f16a28bbb334cae86685ecf598552a508e5018e0466bac5fe26a5921ef6f37  STAGE80_SKELETON_COVERAGE_NOTES.txt
69b4abbfecd91283c6df2e92eb6d992ad56458375375733287df687e2588bb7c  STAGE81_FAILED_RESOLVER_TRACE_NOTES.txt
8905ed4241d5e8f345e969fd48f76640e8991f67fc89084688eaf197729a9166  STAGE81_VALIDATION_REPORT.txt
18ec265a659be2b04d250c2e4d6a171ef42c5be293d1a25b2c04bf6f6a135b2c  STAGE82_BOX_ALIGNMENT_CHANGELOG.txt
2645e92fd36a356bd1638e8265ba831f338c23bcf6cdcd991bcd94d2947b8738  STAGE82_DIAGNOSTICS_CHANGELOG.txt
bd1f01e9b9608e08d3d131ae4b58f12acfbf5e4ba133e3e2075470ab00ca4998  STAGE82_GRAPH_POINTER_FILTER_NOTES.txt
6df8fec849440419c28360968dfd416eead49ba9ae95baa90da24476ac8aa48a  STAGE82_RUNTIME_DIAGNOSTIC_REPORT.txt
995b38067f25c4133522b73e536650b26a7cf0c96e2fd31fde2c1b5ffff92bfd  STAGE82_UNIFIED_CHANGELOG.txt
229b67047882b1037af9d65ba0d03446ee76fbcff5e2e0a40a6c1eca1cd2f493  STAGE82_VALIDATION_REPORT.txt
```


---

## Record 12 — `STAGE52_CLEANUP_AUDIT.txt`

<sub>Original size: 2393 bytes · Original SHA-256: `e1d63c72cd72b4d7dcbc4afefd63eca30e9ab88fd770dff1fd0f20d5ae3d98fb`</sub>

ROS64Hack Stage 52 Cleanup Audit
================================

Scope
-----
Cleanup only. The proven entity, camera, W2S, ESP, Aimbot, and NoClip paths were not redesigned.
The skeleton runtime remains evidence-gated and the existing six-node articulation requirement was preserved.

Removed from active code
------------------------
- Historical global private-memory ModelSkeletal scan and candidate cross-product.
- Global scan buffers, candidate state, global VirtualQueryEx support used only by that scan.
- Dead diagnostic global-class scanner and global registrars.
- Dead whole-graph/model/SpaceNode periodic trackers.
- Dead native-entity expansion/traversal branch from the diagnostic.
- Dead compact object-dump helper.
- Stale Stage 45/46/47/49 runtime labels.
- Unused NoClip _accumY field.
- Unused MenuForm AccentOff field.

Focused Stage 52 behavior
-------------------------
- Resolver order remains: Entity+0xD8 -> entity model array -> bounded BGA+0xB8 graph.
- Target-owned resolver evidence remains capped at two entities.
- Focused model-path evidence now probes only MODEL+0x3E8.
- Focused diagnostic hierarchy follows +0x618, +0x318, +0x18.
- Focused diagnostic object budget is 16 total for the locked target.
- Focused motion tracks remain capped at 8 and sampled every 250 ms.
- No global scan path remains to execute or to be re-enabled by a flag.

Validation performed
--------------------
- C# source lexical string/comment check.
- C# brace/parenthesis/bracket balance check.
- Obsolete-symbol/reference scan.
- Project/source file inventory check.
- SHA-256 manifest regenerated and verified after packaging.

Validation not possible here
----------------------------
The environment has no .NET 8 SDK/compiler and is not the Windows target machine.
Therefore a Windows build and live ros64.exe test are not claimed successful.

Build regression correction
--------------------------
The first cleaned package accidentally removed the focused Stage-52 helper implementations
while leaving their call sites, and also removed the successful target-owned B8 graph-resolution
return while deleting the obsolete global fallback. Those regressions are corrected in this package.
The focused helpers are restored without restoring the global scan, and B8 graph resolution now
returns the accepted ModelSkeletal/root pair and invokes the focused neighborhood trace.


---

## Record 13 — `STAGE52_CLEANUP_NOTES.txt`

<sub>Original size: 1764 bytes · Original SHA-256: `ba879f0e7b881e779c79ee182c22fa8ce7952579b2cb4e7ff61b71757d455ac8`</sub>

STAGE 52 CLEANUP NOTES
======================

Scope
-----
This delivery cleans the Stage 52 codebase without changing the proven entity, camera, W2S,
ESP, Aimbot, or NoClip subsystems.

Removed from active runtime
---------------------------
- The disabled global private-memory ModelSkeletal scan and its candidate validation path.
- Global-scan buffers, candidate sets, VirtualQueryEx support used only by that scan.
- Stale Stage 46/47/49 runtime markers from Program.cs and HackOverlay.cs.
- The old Stage 45 diagnostic output filename and labels.
- Dead diagnostic branches for global exact-class scanning, whole-graph change tracking, and
  additional native-model-root expansion that were no longer called by the active capture path.
- Unused local helper/state left behind by those removed paths.

Focused Stage 52 path
---------------------
The active focused evidence path is now explicit:
  live enemy BGA
      -> target-owned BGA+0xB8 graph
      -> exact ModelSkeletal candidate/root
      -> MODEL+0x3E8
      -> +0x618 / +0x318 / +0x18 node links
      -> target-local transform/motion evidence

No rendering acceptance rule was relaxed. The existing articulated skeleton gate remains intact.

Important boundary
------------------
Stage 52 is cleanup plus low-impact evidence collection. It does not claim that the real bone
hierarchy has been cracked. Stage 53 should use the already-proven enemy BGA as the authoritative
anchor and add only evidence needed to identify the actual articulated hierarchy.

Validation limitation
----------------------
The Windows .NET 8 build and live game run cannot be executed in this environment. Static source
checks are performed before packaging; the user-side Windows build/live verdict remains required.


---

## Record 14 — `STAGE52_LOW_IMPACT_DIAGNOSTIC_NOTES.txt`

<sub>Original size: 2396 bytes · Original SHA-256: `9c7d3a3668a1b5f8a8b99d5f91e01a6a53e473f46e1e640dcf6ac445a460807d`</sub>

ROS64Hack Stage 52 — Cleaned Low-Impact Focused Hierarchy Diagnostic

Purpose
-------
Stage 52 is the cleaned baseline before the next diagnostic stage. Its job is to keep the proven
enemy/camera/ESP pipeline intact while removing obsolete skeleton discovery paths and producing a
small amount of target-owned evidence.

Active runtime rules
--------------------
1. Global private-memory ModelSkeletal scanning is removed from the runtime. There is no disabled
   global-scan flag and no global candidate cross-product to accidentally execute.
2. Entity model discovery checks Entity+0xD8, the Entity model array, then the bounded BGA+0xB8 graph.
3. Resolver evidence is limited to the first two eligible enemy entities. Focused model-path tracing
   uses only MODEL+0x3E8 and no longer fans out across old model sibling offsets.
4. Focused hierarchy tracing follows +0x618 first, then +0x318, then +0x18, with a hard maximum of
   16 focused objects for the locked diagnostic target.
5. Focused motion tracking remains capped at 8 candidates and samples every 250 ms.
6. The six-node articulated-motion acceptance gate is unchanged. Nothing is rendered as a bone
   merely because it is a pointer, a target-local object, or a moving object.

Expected capture output
-----------------------
- [STAGE52][BUILD-MARKER]
- [STAGE52][GLOBAL-SCAN] removed=1 mode=target-owned-only
- [STAGE52][DIAGNOSTIC-BUDGET]
- [STAGE52][MODEL-PATH]
- [DYN-SKEL][HIERARCHY-TRACE]
- [DIAG][SUMMARY] / [FINAL][PROOF]

The runtime should not emit GLOBAL_SCAN_BEGIN, GLOBAL_SCAN_SUMMARY, or GLOBAL_FALLBACK_* records.

Diagnostic capture
------------------
Set ROS64HACK_DIAGNOSTICS=1 before starting the executable. The capture locks the first eligible
live enemy from the current AOI snapshot and samples that same BGA for 120 samples at 500 ms.
Use controlled motion: stationary -> movement -> stationary, plus crouch/jump/turn/lean where
possible. Vehicle motion is optional and should not replace the target-locked sequence.

The purpose is not yet to label bones. It is to establish whether the already-proven live enemy
BGA reaches a target-owned ModelSkeletal/root and whether the focused MODEL+0x3E8 -> child-node
branch exposes target-local moving candidates.

Validation limitation
----------------------
The Windows .NET build and live game run are required on the test machine. They are not claimed here.


---

## Record 15 — `STAGE53_TARGET_INTERNAL_TRACE_NOTES.txt`

<sub>Original size: 1981 bytes · Original SHA-256: `441aeebd1e058b0475a2eb25ff67b75710ef505587c8ba99dd5e4c55a8f5c6b4`</sub>

ROS64Hack Stage 53 — Live Target Internal Skeleton Reconnaissance
===============================================================

Purpose
-------
Stage 53 is a diagnostic-only reconnaissance pass focused on the already-proven live enemy BGA.
It does not modify ESP, W2S, camera logic, aimbot logic, noclip logic, or skeleton rendering.

Question to answer
------------------
Where inside the known live enemy object is the native model/skeleton owner?

Active evidence path
--------------------
LIVE ENEMY BGA
  -> every pointer-bearing qword field in BGA +0x000..+0xFFF
  -> classify each reachable object by exact known native vtable where possible
  -> inspect a bounded set of first-hop objects
  -> scan their first 0x800 bytes for exact ModelSkeletal / SpaceNode / WorldModel pointers
  -> validate any exact ModelSkeletal hit through +0x38 root and +0x40 reciprocal owner

The BGA+0xB8 graph remains a second root because it is already established as a target-owned anchor,
but Stage 53 does not perform a broad graph BFS. It records direct field ownership and a bounded two-hop
pointer closure so the next stage can extend only the strongest path discovered here.

Capture
-------
Set ROS64HACK_DIAGNOSTICS=1. The trace locks the first eligible enemy BGA by EntityId + pointer and
uses that same pointer for the entire capture. The capture runs 120 samples at 500 ms (~60 seconds).
Use one stable target and perform stationary -> move -> stationary, then crouch/jump/turn/lean.
Vehicle motion is optional and should not replace the target-locked sequence.

Output
------
STAGE53_ATTACH_DIAGNOSTIC.txt
STAGE53_TARGET_INTERNAL_TRACE.txt

Interpretation
--------------
A ModelSkeletal hit is a discovery result, not a bone mapping. The next stage should use the exact
logged BGA field/path and live model pointer to map root/child node relationships. If no exact model is
reached, extend only the strongest target-owned path(s) shown by the Stage 53 field/object evidence.


---

## Record 16 — `STAGE54_BONE_HIERARCHY_RECON_NOTES.txt`

<sub>Original size: 2293 bytes · Original SHA-256: `90f07e5b482da776a48fa3462671fa6816c8693e2f0937f77b9bf93357fff55c`</sub>

ROS64Hack — Stage 54 target-owned bone hierarchy reconnaissance
===============================================================

Baseline
--------
Stage 53 proved the live enemy-specific bridge:
  BGA +0x128 -> wrapper +0x4F0 -> exact ModelSkeletal
  BGA +0x130 -> wrapper +0x470 -> exact same ModelSkeletal
  ModelSkeletal +0x38 -> exact SpaceNode root
  root +0x40 == ModelSkeletal

Stage 54 question
-----------------
Which exact SpaceNode objects are descendants of that proven target root, and which pointer fields
connect the nodes into a hierarchy suitable for later bone mapping?

Method
------
- Locks the first on-screen live enemy BGA by pointer + EntityId.
- Uses only the Stage 53-proven +0x128/+0x130 model bridge.
- Requires the exact ModelSkeletal vtable and the exact SpaceNode root +0x40 reciprocal.
- Reads the root and each reachable exact SpaceNode as a bounded 0x1000-byte object.
- Scans qword-aligned fields for exact SpaceNode pointers.
- A candidate child must have the exact SpaceNode vtable, +0x40 owner == the same ModelSkeletal,
  and a valid world transform close enough to the locked target.
- Records parent pointer, field offset, depth, and inter-node distance.
- Samples the target and every discovered node for 120 x 500 ms and records target-relative motion.
- Historical +0x18/+0x318/+0x618 edges are logged for comparison but are NOT assumed to be the hierarchy.

Output
------
STAGE54_BONE_HIERARCHY_TRACE.txt

Runtime scope
-------------
- No process-wide class scan.
- No memory writes.
- No changes to W2S, camera, ESP, aimbot, noclip, or the existing skeleton renderer.
- Stage 53 is retained as historical source but is not started during the Stage 54 capture.

User capture
------------
Keep one enemy visible for the full capture. Use stationary -> move -> stationary, then crouch/jump/turn/lean
where practical. The trace is automatically enabled; no environment variable is required for Stage 54.

Interpretation
--------------
A hierarchy is considered structurally proven only when the trace records at least one exact target-owned
SpaceNode edge from the proven root. Motion data is diagnostic and does not by itself label a node as a bone.
The Stage 55 implementation should consume only the exact target-owned nodes/edges recorded here.


---

## Record 17 — `STAGE55_TARGET_OWNED_SKELETON_RECON_NOTES.txt`

<sub>Original size: 1394 bytes · Original SHA-256: `0d58c72112e40349eaa4e7d9d65cc1e2a5a0916f96d1174eea061b12310455f6`</sub>

STAGE 55 TARGET-OWNED SKELETON RECON

Observed Stage 54 failure:
- BGA+0x128 wrapper and BGA+0x130 wrapper were stable, but the fixed +0x4F0/+0x470 fields produced 0x3DA3D70A48240000 instead of a valid ModelSkeletal.
- Stage 55 therefore does not assume those model offsets.

Stage 55 discovery policy:
- Lock one live enemy BGA from the existing entity snapshot.
- Read only BGA+0x128 and BGA+0x130 as the two proven wrapper anchors.
- Scan the current wrapper object itself for exact ModelSkeletal pointers.
- If direct wrapper scanning finds nothing, inspect at most 24 target-owned second-hop objects from wrapper pointer fields and scan those objects for exact ModelSkeletal pointers.
- A model candidate is accepted only when its vtable is the proven ModelSkeletal vtable, ModelSkeletal+0x38 is an exact SpaceNode, SpaceNode+0x40 reciprocates to the same model, and the root transform is target-local.
- After model/root proof, traverse only exact SpaceNode descendants whose +0x40 owner matches the selected ModelSkeletal.
- No process-wide scan and no memory writes.

ESP tracer correction:
- WorldToScreen keeps its existing loose clipping gate.
- The tracer now requires both current foot/head projections to be finite and inside the real viewport.
- When a predicted box exists, the tracer uses the same box-head anchor to keep the line visually synchronized with the displayed box.


---

## Record 18 — `STAGE56_TARGET_CLOSURE_RECON_NOTES.txt`

<sub>Original size: 1880 bytes · Original SHA-256: `b3fcd29e15589e058dacb8326d2c47553806d0bf4455d0837ec798cc7fdc1145`</sub>

STAGE 56 — TARGET CLOSURE MODEL + SKELETON RECON

Basis:
- Stage 53 actually reached an exact ModelSkeletal by scanning the locked BGA pointer closure.
- Stage 55 narrowed discovery to the wrapper objects and did not reproduce that path.
- Stage 56 restores the proven BGA closure boundary.

Discovery policy:
- No process-wide scan.
- No memory writes.
- BGA +0x128 and +0x130 are prioritized search anchors only.
- The old wrapper +0x4F0 / +0x470 values are not acceptance criteria.
- The BGA Python-type slot +0x008 is skipped.
- Up to 48 direct BGA pointer candidates and 32 target-owned first-hop objects are examined per discovery pass.
- Each first-hop object is scanned for an exact ModelSkeletal vtable.
- A model is accepted only when ModelSkeletal +0x38 is an exact SpaceNode and SpaceNode +0x40 == ModelSkeletal.
- Discovery retries from a fresh bounded pass until the structural proof is reached or the capture ends.

Hierarchy policy:
- After structural ModelSkeletal/root proof, only exact SpaceNode pointers found inside the target-owned root/node objects are recorded.
- Child traversal uses owner==selected ModelSkeletal as a strict traversal gate, while owner match is recorded as evidence.
- WorldMatrix +0x148 and Translation +0x178 are measured when valid, but transform validity is not required to accept the structural model/root proof.
- Historical root offsets +0x18/+0x318/+0x618 are logged as evidence only.

Runtime integration:
- ESP/camera/entity/aimbot logic is not changed.
- Stage 56 is started from HackOverlay in place of the previous Stage 55 diagnostic.
- Stage 53/54/55 source files are retained as historical reference but are not started.

Build note:
- The container has no .NET SDK/compiler, so no local Windows build is claimed. Static source validation was performed (brace/parenthesis/bracket balance and archive/source inventory).


---

## Record 19 — `STAGE57_ROOT_SPACENODE_CENSUS_NOTES.txt`

<sub>Original size: 1829 bytes · Original SHA-256: `95e8e8df980a7017ef9777079833f3db9ce234b6cc79032b2c35efcead717bb4`</sub>

STAGE 57 — ROOT SPACENODE CENSUS + HIERARCHY RECON

Purpose
-------
Stage 56 proved a live ModelSkeletal/root for the locked enemy but stopped traversal because exact SpaceNode children had owners that differed from the ModelSkeletal. Stage 57 tests that assumption directly.

Proven Stage 56 evidence retained as the entry condition
----------------------------------------------------------
BGA +0x0B8 -> 0x3BEF0230 -> +0x370 -> ModelSkeletal 0x346975C0
ModelSkeletal +0x38 -> root SpaceNode 0x20DC9950
root +0x40 == ModelSkeletal
root +0x318 -> exact SpaceNode 0x20DEF750, owner 0x346AD0F8
root +0x618 -> exact SpaceNode 0x20DA8650, owner 0x346B2E20
root +0xC18 -> exact-vtable candidate 0x20CF8E50, length 18.331, owner != ModelSkeletal

Stage 57 rule change
--------------------
Exact SpaceNode vtable is the structural gate. +0x40 owner is logged but is NOT used to prevent traversal.
The scan follows exact SpaceNode -> exact SpaceNode pointers up to MAX_HIERARCHY_DEPTH=6 and MAX_NODES=96.
Owner matches are retained as classification evidence. No process-wide scan, no memory writes, and no renderer changes.

Additional root census
-----------------------
The proven root is read for 0x2000 bytes and every pointer-sized field is inspected. Exact SpaceNode references are logged with field offset, owner, and current transform state.

What we need from the capture
-----------------------------
1. Whether +0x318 / +0x618 descendants expose further exact SpaceNodes.
2. Whether repeated offsets/strides emerge across descendants.
3. Whether descendants form a multi-depth graph instead of isolated root references.
4. Whether any node transform source becomes valid.
5. Whether the graph remains stable while the target moves.

Do not assign bone names yet. Do not modify DynamicSkeletonReader from this stage alone.


---

## Record 20 — `STAGE59_EXPANDED_CLOSURE_RAW_MOTION_RECON_NOTES.txt`

<sub>Original size: 3766 bytes · Original SHA-256: `8196e816c774a3a9d554d4c1f1345435d15f3855e898993caa7e87f871d28209`</sub>

STAGE 59 — OWNER CLASSIFICATION + MOTION CANDIDATE RECON
=========================================================

Purpose
-------
Stage 57 proved a live ModelSkeletal/root and exposed a 20-node / 26-edge exact-SpaceNode graph, but every
non-root child had a +0x40 owner different from the selected ModelSkeletal. Stage 57 also found transform
activity on a small number of nodes while the locked target remained stationary.

Stage 59 does NOT modify the runtime skeleton renderer or DynamicSkeletonReader.
It keeps the Stage 57 target-closure discovery and exact ModelSkeletal/root gates unchanged.

New evidence captured
---------------------
1. Owner classification for every discovered exact SpaceNode:
   - owner pointer and owner vtable
   - whether owner vtable is the exact ModelSkeletal vtable
   - owner +0x38 root pointer and root vtable
   - whether that root is an exact SpaceNode
   - whether owner root == the current node
   - whether owner-root +0x40 points back to the owner
   - whether owner root == the selected ModelSkeletal root

2. Raw transform diagnostics for the world-matrix (+0x148) and translation (+0x178) candidates:
   - read success
   - all-matrix-floats finite
   - matrix XYZ validity
   - matrix W validity
   - matrix XYZ and target distance
   - translation XYZ validity and target distance

3. Motion sampling is shortened and denser:
   - 60 samples
   - 250 ms interval
   - 15 seconds total
   - target position is tracked separately so internal node motion is distinguishable from target movement
   - model/root verification occurs every 4 samples

What this stage must establish
------------------------------
A. Whether non-root SpaceNode owners are a distinct native object class or separate ModelSkeletal-like owners.
B. Whether owner +0x38 consistently points back to the node itself, to a common root, or to another SpaceNode.
C. Which transform source actually carries usable coordinates on the discovered nodes.
D. Which nodes move relative to the locked target during a short controlled animation sequence.
E. Whether the ModelSkeletal/root remains valid throughout the useful motion window.

Capture protocol
----------------
Run the Stage 59 executable and keep one live enemy present for the entire capture.
The stage automatically locks the first valid enemy snapshot and then holds that BGA pointer.

Use one short sequence during the 15-second window:
- first ~2 seconds: target standing still
- next ~4 seconds: target runs left/right
- next ~3 seconds: crouch/uncrouch and turn
- next ~3 seconds: jump or repeated jump/land
- final ~3 seconds: stop moving

Do not intentionally kill, despawn, mount, or otherwise remove the locked target during the capture.
Vehicle motion is not required for this stage.

Output
------
STAGE59_ATTACH_DIAGNOSTIC.txt
STAGE59_OWNER_MOTION_RECON.txt

Build
-----
Windows x64 with .NET 8 SDK:
  dotnet clean
  dotnet build -c Release

Run from the project directory:
  bin\Release\net8.0-windows\ROS64Hack.exe

Important validation limitation
--------------------------------
This environment does not contain the Windows .NET SDK, so no local Windows build or live game validation
was performed here. Archive and static source checks were performed before delivery.

Scope guarantees
----------------
- target-owned-only
- process-wide scan = 0
- memory writes = 0
- renderer changes = 0
- DynamicSkeletonReader unchanged
- existing camera / W2S / ESP / Aimbot / NoClip logic unchanged except Stage 59 diagnostic startup/markers

Decision rule
-------------
Do not assign bone names or change DynamicSkeletonReader from this capture alone. The next runtime change
should only be made after the owner relationship and moving transform chain are structurally consistent.


---

## Record 21 — `STAGE60_TARGET_MODEL_INTERNAL_RECON_NOTES.txt`

<sub>Original size: 3799 bytes · Original SHA-256: `24870c34718bb3d8afc75a3227b62a8973809f74539179a76a4a17f62b162d70`</sub>

STAGE 60 — TARGET MODEL INTERNAL RECON
======================================

Why this stage exists
---------------------
Stage 59 proved an exact ModelSkeletal/root reached from the locked BGA closure, but the resulting
SpaceNode graph was not a single target skeleton. Its 34 exact SpaceNodes had 32 unique owners and
20 of those owners were themselves exact ModelSkeletal objects. One of those owner-model roots was
0x13F74650, whose WorldMatrix148/Translation178 position exactly matched the locked BGA position in
all 60 Stage 59 samples.

Stage 60 therefore does NOT select the first BGA-reached ModelSkeletal as the target skeleton.
It treats the separate exact ModelSkeletal owners exposed by Stage 59 as candidates, validates each
candidate's native class/root reciprocal relationship, ranks their roots by distance to the locked
BGA, and selects the nearest structurally-valid candidate for isolated inspection.

Stage 60 capture scope
----------------------
1. Lock one live enemy BGA and keep that pointer fixed.
2. Reproduce the bounded BGA first-hop/second-hop search only to establish the scene anchor.
3. Census the scene anchor's exact SpaceNode graph only to expose its separate ModelSkeletal owners.
4. Build a unique candidate pool of exact ModelSkeletal objects and log every candidate's model,
   root, root distance, provenance, and source node.
5. Select the nearest exact candidate to the locked BGA. Distance is ranking evidence only; exact
   vtables and the +0x40 reciprocal are the structural gates.
6. Scan only the selected target model object's 0x4000-byte region for exact SpaceNode/ModelSkeletal
   pointers.
7. Scan only the selected target model root's 0x2000-byte region for exact SpaceNode pointers.
8. Follow exact SpaceNodes from the selected root only when child +0x40 equals the selected target
   ModelSkeletal. Cross-model SpaceNodes are logged as evidence but are not traversed.
9. Sample the resulting target-owned nodes every 250 ms for 60 samples and compare node motion to
   the locked BGA movement.

What this stage must establish
------------------------------
A. Which of the distinct ModelSkeletal owners is spatially attached to the locked BGA.
B. Whether that candidate remains structurally valid for the full capture.
C. Whether the target model object directly exposes additional exact SpaceNodes.
D. Whether the target model root exposes target-owned exact SpaceNode children.
E. Whether any target-owned node moves relative to the BGA during running/crouching/jumping.
F. Whether a real target-owned hierarchy exists without crossing into other model instances.

Capture protocol
----------------
Use one live enemy for the entire capture.
During the 15-second sample window:
- first ~2 seconds: stand still
- next ~4 seconds: run left/right
- next ~3 seconds: crouch/uncrouch and turn
- next ~3 seconds: jump/land repeatedly
- final ~3 seconds: stop

Do not kill, despawn, mount, or otherwise remove the locked enemy.

Safety / scope constraints
--------------------------
- process-wide scan = 0
- memory writes = 0
- renderer changes = 0
- DynamicSkeletonReader changes = 0
- camera / W2S / ESP / Aimbot / NoClip unchanged except diagnostic wiring/markers
- no bone-name assignment
- no runtime skeleton mapping changes

Build
-----
Windows x64 with .NET 8 SDK:
  dotnet clean
  dotnet build -c Release

Run:
  bin\Release\net8.0-windows\ROS64Hack.exe

Output:
  STAGE60_ATTACH_DIAGNOSTIC.txt
  STAGE60_TARGET_MODEL_INTERNAL_RECON.txt

Validation limitation
---------------------
The analysis environment does not contain the Windows .NET SDK, so no local Windows build or live
game validation was performed here. The archive was checked for required files, balanced C# delimiters,
and diagnostic wiring consistency before delivery.


---

## Record 22 — `STAGE61_TARGET_MODEL_ASSOCIATION_RECON_NOTES.txt`

<sub>Original size: 4907 bytes · Original SHA-256: `904e8eee34171d298f24ca45d5e2389b1a47b377b84dc5d82033c81467b9bded`</sub>

STAGE 61 — TARGET MODEL ASSOCIATION RECON
=========================================

WHY THIS STAGE EXISTS
---------------------
Stage 59 found an exact SpaceNode whose owner was an exact ModelSkeletal and whose recorded world position exactly matched the locked BGA while that target was stationary. That is a promising association clue, but it did not prove co-movement.

Stage 60 repeatedly scanned the same capped first-hop set and found no direct model on its first 645 passes. Pass 646 found one model/root pair, but the chosen root was still 663.245 world units from the locked BGA, and the target-owned closure contained one node and zero edges. Stage 60 therefore did not establish which model belonged to the enemy.

STAGE 61 QUESTION
------------------
Which exact ModelSkeletal/root candidates are spatially and temporally associated with the locked enemy BGA while the target moves? Stage 61 intentionally does not choose a winner. It records comparable measurements for all candidates during the same sample window.

DISCOVERY METHOD
----------------
1. Lock the first valid enemy snapshot by BGA pointer and EntityId.
2. Re-read the current BGA ID and XYZ; stop trusting samples when the live ID does not match the locked ID.
3. Prioritize live pointer values at BGA offsets +0x048, +0x648, +0x0B8, +0x128, and +0x130 because prior captures observed useful paths around +0x048 and +0x648 and the BGA+0x0B8 native graph. No per-run pointer address is hardcoded.
4. Sweep the remaining aligned BGA pointer slots subject to the 48-first-hop-object budget. Each retry resumes from the next aligned slot instead of restarting the same capped sweep; priority offsets are still rechecked. Repeat discovery no more than 8 attempts. If no model candidate pool is found, write an explicit failure verdict and stop rather than scanning indefinitely.
5. From up to four direct BGA-derived model roots, follow exact SpaceNode pointer references under the 64-node / 512-reference / depth-6 budget. This is a pointer-reference census, not an assertion that each reference is a parent-child bone edge.
6. Collect up to 64 exact ModelSkeletal candidates whose +0x38 root is an exact SpaceNode and whose +0x40 owner reciprocally points back to that model. Candidates found through BGA closure and SpaceNode owner references remain separate records.
7. Do not select a model based on nearest initial distance. Sample all candidates in the same capture window.

ASSOCIATION SAMPLING
--------------------
- 60 samples at 250 ms (15 seconds).
- A 3-second preparation delay starts after the candidate pool is ready. Begin the motion sequence when [STAGE61][ASSOCIATION-SAMPLING-START] appears.
- First ~2 seconds: stand still.
- Next ~4 seconds: run left/right.
- Next ~3 seconds: crouch/uncrouch and turn.
- Next ~3 seconds: jump/land.
- Final ~3 seconds: stop.
- Keep the same target alive and present for the entire capture.

For each candidate root, the log records structural validity, successful transform samples, distance from target, within-128/within-256 sample counts, total root displacement, total change in the root-to-target relative offset, and counts for relative stability/co-motion while the target is moving. These are association measurements, not proof of anatomical bone identity.

IMPORTANT INTERPRETATION
------------------------
- If the target does not move sufficiently, the capture cannot distinguish a fixed nearby object from a root that follows the target. The final verdict marks this as insufficient.
- A small and stable root-to-target offset while the target is moving is stronger association evidence than proximity at one instant. It still does not prove that the root contains articulated bones.
- Candidate ordering is evidence triage only; modelAssociationProven remains 0 until the captures are reviewed.
- No bone names are assigned and no runtime skeleton behavior is modified.

SCOPE / SAFETY
--------------
- process-wide scan = 0
- Stage 61 diagnostic memory writes = 0 (existing NoClip code is unchanged)
- renderer changes = 0
- DynamicSkeletonReader changes = 0
- camera / W2S / ESP / Aimbot / NoClip logic unchanged except diagnostic wiring and stage markers
- Stage 60 diagnostic class remains in the project for comparison but is inactive

BUILD AND RUN
-------------
Windows x64 with .NET 8 SDK:
  dotnet clean
  dotnet build -c Release
  bin\Release\net8.0-windows\ROS64Hack.exe

Primary outputs:
  STAGE61_ATTACH_DIAGNOSTIC.txt
  STAGE61_TARGET_MODEL_ASSOCIATION_RECON.txt

BUILD VALIDATION LIMITATION
---------------------------
The available environment has no .NET SDK/compiler, so a real Windows build and live-game validation could not be performed here. Archive integrity and static source checks must not be mistaken for a successful compile. Run the commands above on the Windows test machine and return STAGE61_TARGET_MODEL_ASSOCIATION_RECON.txt.


---

## Record 23 — `STAGE61_VALIDATION_REPORT.txt`

<sub>Original size: 2295 bytes · Original SHA-256: `8fc7d5b3b779dd90a3818f5763177af54aba5d8e6fc3eaf5f73038c3286cf10c`</sub>

STAGE 61 PACKAGE VALIDATION REPORT
==================================

Baseline
--------
Built from the user-uploaded ROS64Hack_STAGE60_TARGET_MODEL_INTERNAL_RECON(1).zip.
The prior STAGE60_TARGET_MODEL_INTERNAL_RECON.txt capture and Stage 1-59 evidence archive were reviewed to constrain the diagnostic.

Changes
-------
Added Core/Stage61TargetModelAssociationRecon.cs.
Wired HackOverlay to start, observe, and dispose Stage61TargetModelAssociationRecon instead of starting Stage60TargetModelInternalRecon.
Updated Program.cs attach-log file name and stage markers to Stage 61.
Updated README_BUILD.txt and added STAGE61_TARGET_MODEL_ASSOCIATION_RECON_NOTES.txt.
The Stage 60 source remains in the project for comparison but is no longer started by HackOverlay.
No edits were made to camera, W2S, ESP rendering, Aimbot, NoClip, entity enumeration, or DynamicSkeletonReader source.

Static checks performed
----------------------
- Stage 60 source archive ZIP integrity: passed.
- Source delta review: only the Stage 61 diagnostic, diagnostic wiring/markers, build README, and Stage 61 notes are changed/added.
- All 25 C# source files passed the available lexical-token scan: 0 error tokens.
- All 25 C# source files passed the available delimiter-balance scan: 0 failures.
- Active overlay wiring references Stage61TargetModelAssociationRecon for construction, startup, snapshot observation, and disposal.
- Stage 61 diagnostic contains no process-wide scanning API and no process memory-write call.
- Discovery retries retain a pointer-sweep cursor, so each capped attempt advances through BGA slots rather than restarting at offset zero.
- Stage 61 code does not automatically select or declare a winning model candidate.
- ZIP round-trip and SHA256 manifest verification are performed on the final package.

Important build limitation
-------------------------
The current environment does not have dotnet, csc, or msbuild installed. A real .NET 8 compile and live ROS Legacy run could not be performed here. Static checks do not establish that compilation succeeded. Run `dotnet clean` and `dotnet build -c Release` on the Windows test machine before using the capture.

Expected output files
---------------------
STAGE61_ATTACH_DIAGNOSTIC.txt
STAGE61_TARGET_MODEL_ASSOCIATION_RECON.txt


---

## Record 24 — `STAGE62_TARGET_OWNED_POINTER_CLOSURE_RECON_NOTES.txt`

<sub>Original size: 3618 bytes · Original SHA-256: `1f51e22787804aa51740a2393a8f510cb5bcbef21427d184cf6cac444d928a5b`</sub>

STAGE 62 — TARGET-OWNED POINTER CLOSURE RECON
=============================================

WHY STAGE 62 EXISTS
-------------------
Stage 61 captured a stable live target BGA (ID 0x0015D95A) and repeatedly observed an exact native-graph vtable at BGA+0x0B8. It scanned eight passes, 48 first-hop objects per pass, and reported directModels=0, sceneAnchors=0, sceneNodes=0, and candidatePool=0.

The Stage 61 capture never reached [STAGE61][ASSOCIATION-SAMPLING-START]. Therefore targetTotalStep=0 and targetMovementTransitions=0 do not demonstrate that the target failed the motion protocol; no target motion samples were taken. Its final reason conflated an undiscovered candidate pool with insufficient movement. Stage 62 reports this state as targetMovementSufficient=NOT_SAMPLED.

STAGE 62 QUESTION
-----------------
Does a bounded, target-reachable pointer closure expose an exact ModelSkeletal/root candidate on this BGA instance when inspecting only each seed object's immediate fields is insufficient?

DISCOVERY METHOD
----------------
1. Lock one live enemy by BGA pointer + EntityId, and revalidate that ID whenever the target is sampled.
2. Prioritize live BGA fields +0x048, +0x648, +0x0B8, +0x128, and +0x130. Continue a bounded aligned-pointer sweep across the BGA bytes; no runtime object address is hardcoded.
3. Reject non-8-byte-aligned pointer values before inspecting them. This specifically avoids treating values such as the Stage 61 BGA+0x048 contents as valid object pointers solely because their numeric value falls within a broad address range.
4. Inspect up to 48 BGA-derived first-hop objects per attempt, then process up to 48 nested objects from a persistent queue. The queue follows only pointers found inside objects already reached from the locked BGA-derived seeds; depth is capped at 3 and unique queued pointers at 4096.
5. Prioritize child pointers whose first qword is a vtable within the target module image. Small records whose first qword is 1 are also followed within the same depth and queue limits.
6. Test ModelSkeletal candidates only when the exact ModelSkeletal vtable matches, +0x38 points to an exact SpaceNode, and SpaceNode+0x40 points back to the candidate ModelSkeletal. Exact SpaceNode owner objects are also checked as possible candidates.
7. If no candidate pool is found after eight attempts, emit NO_CANDIDATE_POOL and explicitly report that association sampling did not run. Do not infer failure from a zero target movement total in that case.
8. If a validated candidate pool is found, start the shared 60-sample, 250 ms association window after a three-second preparation delay. Begin the standing → run left/right → crouch/turn → jump/land → stop sequence when [STAGE62][ASSOCIATION-SAMPLING-START] appears.

INTERPRETATION
--------------
- A model candidate is not automatically accepted as the target model.
- A pointer reference is not automatically a parent-child bone edge.
- A small stable root-to-target relative offset while the target moves is association evidence, not proof of anatomical identity.
- The active renderer, DynamicSkeletonReader, camera, W2S, ESP, Aimbot, NoClip, and enemy enumeration remain unchanged.
- Process-wide scanning and diagnostic memory writes remain disabled.

BUILD AND OUTPUT
----------------
  dotnet clean
  dotnet build -c Release
  bin\Release\net8.0-windows\ROS64Hack.exe

Return:
  STAGE62_ATTACH_DIAGNOSTIC.txt
  STAGE62_TARGET_OWNED_POINTER_CLOSURE_RECON.txt

The current environment does not contain dotnet, csc, or msbuild. Static validation must not be mistaken for a successful .NET build.


---

## Record 25 — `STAGE62_VALIDATION_REPORT.txt`

<sub>Original size: 2737 bytes · Original SHA-256: `3e0761fa8849fd9e540bf9b4928ec952b83a86f9ceed5db034ef54ebdcd0e888`</sub>

STAGE 62 PACKAGE VALIDATION REPORT
==================================

Baseline
--------
Built from the Stage 61 codebase that was used to produce STAGE61_TARGET_MODEL_ASSOCIATION_RECON.txt, based on the uploaded Stage 60 package.

Evidence driving this stage
---------------------------
- Stage 61 locked BGA 0x3BDCD468, ID 0x0015D95A, with no target-loss or ID-mismatch samples reported.
- Eight discovery attempts inspected 384 first-hop objects and found zero direct model candidates and zero scene anchors/nodes.
- The capture never emitted ASSOCIATION-SAMPLING-START. Therefore targetTotalStep=0 means movement was not sampled, not that the target failed the movement protocol.
- The logged BGA+0x0B8 pointer was consistently 0x394EE3C0 with exact native-graph vtable 0x141BFDB98, but Stage 61 only validated models in each inspected object's immediate fields and did not continue those pointers through an additional bounded object depth.

Changes
-------
- Added Core/Stage62TargetOwnedPointerClosureRecon.cs.
- Retained Core/Stage61TargetModelAssociationRecon.cs for comparison; the overlay starts Stage 62 only.
- Stage 62 preserves the prioritized BGA offsets and advancing BGA scan cursor.
- Added a persistent target-reachable nested pointer queue, capped at depth 3, 48 nested object reads per discovery attempt, and 4096 unique queued pointers.
- Exact ModelSkeletal vtable, exact SpaceNode root vtable, and reciprocal root owner validation remain mandatory for each accepted model candidate.
- x64 pointer candidates now require 8-byte alignment to reject unaligned numeric fragments that were treated as pointer candidates in Stage 61.
- The final verdict distinguishes NO_CANDIDATE_POOL (movement was not sampled) from a completed sample window where the target moved insufficiently.
- Updated overlay/attach stage markers, build README, and added Stage 62 capture instructions.
- Existing camera, W2S, ESP renderer, Aimbot, NoClip, enemy enumeration, and DynamicSkeletonReader implementations remain unchanged.

Static validation
-----------------
- ZIP integrity tested after packaging.
- SHA256 manifest regenerated and every listed entry verified.
- All active C# files scanned for lexical/comment/string errors and delimiter balance.
- Stage 62 construction/start/snapshot observation/disposal references checked against overlay wiring.
- Stage 61 retained as an inactive source comparator.

Build limitation
----------------
No `dotnet`, `csc`, or `msbuild` executable is present in the packaging environment. A real .NET 8 build and live runtime execution have NOT been verified. The package must be compiled on the Windows test machine using `dotnet clean` followed by `dotnet build -c Release` before running.


---

## Record 26 — `STAGE63_TARGET_ROOT_HIERARCHY_RECON_NOTES.txt`

<sub>Original size: 4161 bytes · Original SHA-256: `e8e800f7153cf6f18e91d551f64e8212db71b9229e720af222c9083fd378c1dc`</sub>

STAGE 63 — TARGET-ASSOCIATED ROOT HIERARCHY RECON
==================================================

WHY STAGE 63 EXISTS
-------------------
Stage 62 finally produced a strong target-association pattern without making an anatomical claim. In that capture, one candidate root remained within 2.762 world units of the locked BGA across the sample window. It was structurally valid for all 60 samples, had 60 valid transforms, stayed within 128 units for 60 samples, and recorded 50/50 stable-relative observations and 50/50 co-motion observations while the target moved. Total root displacement was 758.199 units versus 757.907 units of target movement. This is strong evidence that the root tracks the target; it does not prove that the root's referenced nodes are anatomical bones.

STAGE 63 QUESTION
-----------------
Which exact SpaceNode references are present in the dynamically discovered target-associated ModelSkeletal/root object, what are their owner relationships, and do their transforms remain tied to the target or move relative to the candidate root during the same controlled movement window?

DISCOVERY AND CANDIDATE GATE
----------------------------
1. Re-discover live model/root candidates from the locked BGA at runtime. No previous run's pointer addresses are hardcoded.
2. Keep Stage 62's bounded target-reachable closure and exact ModelSkeletal / SpaceNode / reciprocal-owner validation.
3. Only roots measured within 128 world units at discovery are included in the focused root census, up to four. This is a census scope, not acceptance: every included candidate must still pass the movement association gate before it is described as a strong target-associated root.
4. The association gate requires at least 48/60 structurally valid model/root checks, at least 48/60 valid root transforms, at least 48/60 observations within 128 units, at least 20 target-moving observations, at least 80% stable-relative and co-motion observations, mean distance <=64 units, and maximum distance <=128 units.

FOCUSED ROOT CENSUS
-------------------
- Read bounded 0x2000-byte memory windows starting at the candidate ModelSkeletal and SpaceNode root. The allocation boundary/actual C++ object size is not yet proven, so offsets are treated as source-address-relative reference slots only.
- Record the model's root reference and exact SpaceNode pointers found in aligned qword slots within bounded 0x2000-byte windows starting at the candidate model, root, and discovered node addresses. Object/allocation boundaries are not assumed; every hit is reported as a raw pointer reference, not a semantic child field.
- Follow exact SpaceNode references to depth 3, maximum 64 non-root nodes and 256 unique references per candidate root.
- Record every node's exact vtable, +0x40 owner, whether its owner is the selected candidate model, whether the owner is another exact ModelSkeletal, and its traversal path.
- Sample each discovered node's world-matrix translation (with the existing +0x178 fallback) during the SAME 60-sample, 250 ms target movement window. Report node movement, target-relative movement, root-relative movement, target distance, and owner correlation.
- References and cycles remain references/cycles in the report. They are not automatically classified as semantic parent-child edges or bones.

MOTION SEQUENCE
----------------
After [STAGE63][ASSOCIATION-SAMPLING-START], perform the same sequence:
stand still ~2s; run left/right ~4s; crouch/turn ~3s; jump/land ~3s; stop ~3s.

SCOPE
-----
No process-wide scan. No diagnostic game-process writes. No changes to the live DynamicSkeletonReader, ESP renderer, W2S, camera, enemy enumeration, Aimbot, or NoClip logic. Stage 62 remains in the project as inactive comparison source; Stage 63 is the only active stage diagnostic.

BUILD AND OUTPUT
----------------
  dotnet clean
  dotnet build -c Release
  bin\Release\net8.0-windows\ROS64Hack.exe

Return:
  STAGE63_ATTACH_DIAGNOSTIC.txt
  STAGE63_TARGET_ROOT_HIERARCHY_RECON.txt

The local packaging environment does not contain dotnet/csc/msbuild. Static checks and ZIP integrity are not a substitute for the Windows .NET build.


---

## Record 27 — `STAGE63_VALIDATION_REPORT.txt`

<sub>Original size: 1312 bytes · Original SHA-256: `92db38bdb0746d0c0490e3856fa89ae22a82ca2324dae2706635653651a15f94`</sub>

STAGE 63 STATIC VALIDATION REPORT
=================================

Scope
-----
- Added Core/Stage63TargetRootHierarchyRecon.cs as an isolated diagnostic.
- Kept Core/Stage62TargetOwnedPointerClosureRecon.cs unchanged as inactive comparison source.
- Updated Overlay/HackOverlay.cs to start, observe and dispose Stage 63 only.
- Updated Program.cs attach diagnostics to Stage 63 markers and STAGE63_ATTACH_DIAGNOSTIC.txt.
- Added STAGE63_TARGET_ROOT_HIERARCHY_RECON_NOTES.txt.
- Did not edit DynamicSkeletonReader, camera, W2S, ESP, entity enumeration, Aimbot, or NoClip implementation.

Validation performed
--------------------
- ZIP integrity tested after packaging.
- SHA-256 manifest regenerated and verified against extracted package files.
- All active C# files scanned for lexical/string/comment and delimiter-balance errors.
- Stage 63 stage markers, active wiring, caps, and intended root-association/reference sampling methods checked.
- No .NET SDK, csc, or msbuild is available in this environment; no successful compilation is claimed.

Interpretation note
-------------------
A successful association-pattern gate identifies a target-associated root for focused investigation only. Exact SpaceNode references and relative transform measurements do not by themselves prove an anatomical skeleton.


---

## Record 28 — `STAGE64_EXPANDED_ROOT_FANOUT_RECON_NOTES.txt`

<sub>Original size: 2945 bytes · Original SHA-256: `c9ef4803612fd3cbafebe6831ef70b57968357c35476d04680afe0664bf0d3c2`</sub>

STAGE 64 — EXPANDED ROOT FANOUT RECON
=====================================

Stage 63 evidence
----------------
The supplied Stage 63 capture found 27 candidate models, 11 exact SpaceNodes and
8 pointer references after scanning four scene anchors. No discovered root was within
128 units of the locked target at discovery, so the focused root census was skipped.
The target then moved a total of 874.320 units over 60 samples, but none of the model
root candidates produced a sufficiently strong close/stable-relative association pattern.
The best candidate in Stage 63 was still more than 13,000 units from the target. Thus
Stage 63 did not identify the target-associated root, and its own report states that
an anatomical hierarchy was not proven.

Stage 64 question
-----------------
Did Stage 63 stop too early because it examined only the four nearest direct candidates
as scene anchors, rather than following other target-reachable model/root candidates
associated with different BGA pointer paths?

Bounded discovery change
------------------------
1. Re-discover the live target and the BGA-reachable pointer closure at runtime.
2. Retain the existing limits: 8 discovery attempts, 48 first-hop objects per attempt,
   48 nested objects per attempt, nested depth 3, 4096 queued pointers and 64 model candidates.
3. Select up to 12 scene anchors using provenance diversity first: one candidate per
   recognized BGA source path (+0x0B8, +0x648, +0x298, +0x0A8, +0x118, +0x128,
   +0x130, +0x048), then nearest unused candidates.
4. Bound the scene closure to 64 exact SpaceNodes and 512 unique references; the scene
   edge limit is enforced by the loop, not merely printed in the diagnostic header.
5. Retain exact ModelSkeletal/SpaceNode vtable and reciprocal root-owner checks.

Focused root census
-------------------
Stage 63 only censused roots already within 128 units at the initial discovery sample.
Stage 64 retains those candidates as first priority, but when fewer than four are near,
it samples up to four additional provisional roots selected by exact SpaceNode-owner
provenance, BGA+0x0B8 path provenance, then distance. This is a bounded evidence census,
not an automatic association decision. All candidate roots remain subject to the shared
60-sample movement association measurements, and all raw pointer references remain
references; no edge is labeled as a bone based on pointer existence alone.

Motion sequence
---------------
After [STAGE64][ASSOCIATION-SAMPLING-START], perform:
stand still ~2s; run left/right ~4s; crouch/turn ~3s; jump/land ~3s; stop ~3s.

Scope
-----
No process-wide scanning, no game-process writes, and no renderer/runtime skeleton
changes. The existing DynamicSkeletonReader, camera, W2S, ESP, entity enumeration,
Aimbot and NoClip remain untouched. Stage 63 remains in the project as inactive history.

Return
------
STAGE64_ATTACH_DIAGNOSTIC.txt
STAGE64_EXPANDED_ROOT_FANOUT_RECON.txt


---

## Record 29 — `STAGE64_VALIDATION_REPORT.txt`

<sub>Original size: 1681 bytes · Original SHA-256: `80129776b5ebe88a36f7edca6f76e1ae69d9edc2b52d2b6c9bbdf19ccfe819f3`</sub>

STAGE 64 STATIC VALIDATION REPORT
=================================

Scope
-----
- Added Core/Stage64ExpandedRootFanoutRecon.cs as the active Stage 64 diagnostic.
- Kept Core/Stage63TargetRootHierarchyRecon.cs byte-for-byte unchanged as inactive comparison source.
- Updated Overlay/HackOverlay.cs to start, observe and dispose Stage 64 only.
- Updated Program.cs attach diagnostics and output filename to Stage 64 markers.
- Added STAGE64_EXPANDED_ROOT_FANOUT_RECON_NOTES.txt and refreshed README_BUILD.txt.
- Did not edit DynamicSkeletonReader, camera, W2S, ESP, entity enumeration, Aimbot, or NoClip implementation.

Validation performed
--------------------
- 28 C# source files / 19,076 C# lines scanned for lexical/string/comment and delimiter-balance failures.
- Zero lexical/string/comment/delimiter-balance failures found.
- Stage 64 active wiring, Stage 63 inactive wiring, anchor count, provenance selection, focused-root fallback and edge-cap enforcement checked.
- Confirmed MAX_SCENE_EDGES participates in the scene pointer scan loop as a hard stop.
- Regenerated SHA-256 manifest; all 51 manifest entries verified against the package files.
- ZIP integrity tested; extracted package re-verified against all 51 SHA-256 entries.

Build limitation
----------------
No dotnet, csc, mcs, or msbuild executable is available in this environment. A successful C# compilation is NOT claimed; the user must run `dotnet build -c Release` on Windows.

Interpretation note
-------------------
A candidate-root census is provisional. Exact SpaceNode references, owner pointers, and correlated transforms do not by themselves prove semantic parent-child edges or anatomical bones.


---

## Record 30 — `STAGE65_ACTIVE_TARGET_ROOT_RECON_NOTES.txt`

<sub>Original size: 2857 bytes · Original SHA-256: `d5129d44aff233e4299ceccb5e0d4eb281db5619255e44d2d072824c68fd5962`</sub>

STAGE 65 — ACTIVE-TARGET ROOT AND NODE RECON

Purpose
- Address the Stage 64 capture failure: the diagnostic locked the first valid enemy and observed just one target-motion transition in 60 samples.
- Before target locking, monitor valid enemy snapshots at 250 ms intervals for up to 15 seconds.
- Prefer the currently visible enemy with the highest count of plausible movement transitions (0.5 to 256 world units per interval), after at least 4 seconds and at least 3 transitions.
- If no target qualifies by 15 seconds, lock the best available current candidate and label the choice BEST_AVAILABLE_TIMEOUT_FALLBACK; the log will not disguise this as an active-target selection.
- Exclude >256-unit single-interval jumps from target-selection scoring and from association-motion counts; log these as outliers.
- Retain Stage 64's bounded, target-reachable model discovery and SpaceNode-reference census. Exact pointers remain references, not presumed bone edges.

Stage 64 evidence that motivated the change
- The target stayed unchanged at samples 1 through 54.
- Sample 55 reported a 1511.855-unit step and samples 56 through 60 were stationary.
- Candidate model 0x391AB3B0 / root 0x16670150 had 60 valid transforms and zero measured target distance, but the capture had only one movement transition. Runtime addresses are capture-specific and are not hardcoded by Stage 65.
- Focused SpaceNode pointers frequently had owner models different from the provisional candidate. The reference graph does not prove a skeletal hierarchy.

Runtime protection boundaries
- No process-wide scan.
- No process memory writes.
- No changes to DynamicSkeletonReader, entity enumeration, camera, W2S, ESP renderer, or aimbot logic.
- Stage 64 source remains in source history; HackOverlay wires Stage 65 as the active diagnostic.

Outputs
- STAGE65_ATTACH_DIAGNOSTIC.txt
- STAGE65_ACTIVE_TARGET_ROOT_RECON.txt

Capture
1. Run the Stage 65 build while an actual enemy is visible.
2. Allow up to 15 seconds for motion-ranked enemy selection. Check selectionMethod in the lock line; MOST_MOVED_TARGET is preferred, while BEST_AVAILABLE_TIMEOUT_FALLBACK means no enemy met the movement gate.
3. Keep that enemy visible and moving during the following 15-second sample window where possible. Local-player movement alone does not count as target motion.
4. Send both logs, especially [STAGE65][FINAL][TARGET], [STAGE65][FINAL][ROOT-ASSOCIATION], [STAGE65][FINAL][NODE], and [STAGE65][FINAL][ROOT-HIERARCHY].

Build commands from the project directory
  dotnet clean
  dotnet build -c Release
  bin\Release\net8.0-windows\ROS64Hack.exe

Validation status
- ZIP integrity, manifest hashes, and source lexical/delimiter checks are run when the package is created.
- A successful .NET build is not claimed unless an actual .NET toolchain is available and executes the build.


---

## Record 31 — `STAGE65_VALIDATION_REPORT.txt`

<sub>Original size: 766 bytes · Original SHA-256: `4984dd2d9deffb2e65a7ef09b220e4c6a367e901f0838842d50e0e2ccbf0b833`</sub>

STAGE 65 STATIC VALIDATION REPORT

Package: ROS64Hack_STAGE65_ActiveTargetRootRecon
C# source files: 29
C# source lines: 20691
Lexical/comment/string/delimiter balance: PASS
Active overlay wiring: Stage65ActiveTargetRootRecon (PASS)
Stage64 historical class is included but not active (PASS)
Motion-ranked target selection and explicit timeout fallback: present (PASS)
Outlier steps excluded from target-motion evidence: present (PASS)
Renderer/DynamicSkeletonReader behavior: unchanged by design; HackOverlay changes only diagnostic wiring/startup markers
.NET compile: NOT RUN — no dotnet/csc/mcs/msbuild toolchain is available in this container

Lexical checks do not replace compilation. Run dotnet clean and dotnet build -c Release on Windows before testing.


---

## Record 32 — `STAGE66_BGA_PRIORITY_CLOSURE_RECON_NOTES.txt`

<sub>Original size: 2619 bytes · Original SHA-256: `f521bd8cc50f1be10dbd7f4db86be213c5b5e4a523d34a03110f97d9f67a3aac`</sub>

STAGE 66 — BGA-PRIORITIZED CLOSURE AND EXTENDED ASSOCIATION RECON

Purpose
Use the Stage 65 capture evidence to improve discovery coverage and prevent an under-sampled motion window from being labelled sufficient.

Evidence prompting this stage
- Stage 65 selected a target with 16 plausible movement transitions / 320.039 total units during preselection.
- The association window recorded only 5 moving transitions and 148.367 total units over 60 samples.
- Stage 65 sampled only 48 nested objects despite 1,462 queued pointers remaining, and stopped discovery after finding one direct/nested model candidate.
- No root met the association pattern; the closest ranked root averaged 102.637 units from the target and had 0 stable-relative / 0 co-motion observations.

Targeted changes
1. BGA+0x0A8 and BGA+0x0B8 are inspected before the high-fanout BGA+0x648 branch, reflecting productive routes seen in earlier captures.
2. Nested closure budget is raised from 48 to 192 objects per discovery attempt. It remains target-reachable and bounded; no process-wide scan is added.
3. Association window is extended from 60 to 120 samples at 250 ms (nominally 30 seconds).
4. targetMovementSufficient now requires the full MIN_ASSOCIATION_MOVING_OBSERVATIONS threshold (20), matching the root-association test rather than passing with only three transitions.
5. No candidate is automatically accepted. Pointer references remain references, not semantic bone edges.

Preserved
- DynamicSkeletonReader, entity enumeration, camera, W2S, ESP renderer, Aimbot, NoClip, and runtime memory-write behavior are unchanged.
- Stage 65 source and history notes remain in the package; Stage 66 is the only active recon class wired by HackOverlay.
- No fixed runtime object addresses and no process-wide memory scan.

Expected logs
- STAGE66_ATTACH_DIAGNOSTIC.txt
- STAGE66_BGA_PRIORITY_CLOSURE_RECON.txt

Capture procedure
1. Extract the whole package, open a terminal in the project directory, then run:
   dotnet clean
   dotnet build -c Release
   bin\Release\net8.0-windows\ROS64Hack.exe
2. Ensure [STAGE66][TARGET-LOCK] reports MOST_MOVED_TARGET when available.
3. Keep the selected enemy visible and moving when possible. Local-player movement does not count as target movement.
4. Wait for [STAGE66][FINAL][RESULT]. Send both Stage 66 logs.

Interpretation
- A root association remains unconfirmed unless its transform maintains the required stable-relative/co-motion pattern across enough valid target-motion samples.
- Anatomical hierarchy remains unproven until connected articulated node motion is independently demonstrated.


---

## Record 33 — `STAGE66_VALIDATION_REPORT.txt`

<sub>Original size: 966 bytes · Original SHA-256: `233b4a41fe579f5a776b3e968909328bb22dada159ffcd626190a5e5e71a6542`</sub>

STAGE 66 STATIC VALIDATION REPORT

Package: ROS64Hack_STAGE66_BgaPriorityClosureRecon
Active diagnostic: Stage66BgaPriorityClosureRecon
Stage65 diagnostic source: retained, inactive

Changes inspected:
- HackOverlay active wiring points to Stage66BgaPriorityClosureRecon.
- Attach log marker/path is Stage 66.
- Discovery order prioritizes BGA+0x0A8 and BGA+0x0B8 before BGA+0x648.
- Nested object inspection budget is 192 per attempt.
- Association window is 120 samples at 250 ms (nominally 30 seconds).
- targetMovementSufficient uses the same threshold of 20 movement transitions required by association qualification.

Protected files copied unchanged from Stage 65 package:
- Core/DynamicSkeletonReader.cs
- Engine/Camera.cs
- Core/WorldToScreen.cs
- Features/ESP.cs
- Features/Aimbot.cs
- Features/NoClip.cs
- Engine/EntityLoop.cs

Validation limits:
- Static source/structure checks only.
- A successful .NET build has NOT been verified in this environment.


---

## Record 34 — `STAGE67_VEHICLE_TRANSITION_RECON_NOTES.txt`

<sub>Original size: 2443 bytes · Original SHA-256: `37dbdb1a463e871f878e1ba2f8cecb000f313f5e825ea335b6999b2bb7f68efd`</sub>

STAGE 67 — VEHICLE-TRANSITION / TRANSFORM-HANDOFF RECON

Why this stage replaces running Stage 66 unchanged
Stage 66 improves bounded model/root discovery but does not explicitly show whether a raw
BGA coordinate freezes during a suspected mount while another candidate transform moves.
The user-reported A-to-B jump may be a transform-source handoff, but that remains a hypothesis.

Changes
1. Retains Stage 66 BGA-prioritized closure, root association, and pointer-reference census.
2. Extends the association time series to 240 samples at 250 ms (nominal 60 seconds).
3. Writes per-sample raw BGA XYZ, raw step, step category, stationary-run count, total raw
   step, and current locked-target ID. Large jumps are explicitly logged, not discarded.
4. Separately samples the latest overlay EntityData snapshot for the locked BGA and logs whether
   it is missing/stale or differs by at least 1.0 world unit from the direct raw BGA read.
5. Tracks transforms from recognized model/SpaceNode instances and a capped set of other
   executable-image objects discovered through the same target-reachable closure.
6. Logs probe coordinates and movement during BGA-stationary intervals, with final per-probe
   movement counts and distance statistics.
7. Does not label any raw probe as a vehicle, does not accept an automatic root/bone winner,
   and makes no renderer, camera, W2S, DynamicSkeletonReader, entity-enumeration, Aimbot,
   NoClip, or memory-write changes.

Interpretation conditions
- Possible handoff signal: the BGA remains stationary for at least four consecutive samples
  while at least one independently discovered object transform continues moving.
- A large raw BGA jump remains in the trace so the logs can distinguish a coordinate reset
  from ordinary plausible movement, but a jump alone does not prove mount/dismount.
- If no mount/dismount happens during the capture, this stage may still characterize root
  association and stationary intervals, but it cannot conclusively validate that specific event.
- The target-reachable pointer closure is bounded; a vehicle transform outside that closure may
  not be discovered, so a missing handoff signal does not rule out the user's hypothesis.
- Candidate transform probes are measurements only; unrelated objects can coincidentally
  expose plausible values at the tested offsets.

Required outputs
  STAGE67_ATTACH_DIAGNOSTIC.txt
  STAGE67_VEHICLE_TRANSITION_RECON.txt


---

## Record 35 — `STAGE68_TARGET_ROOT_HIERARCHY_RECON_NOTES.txt`

<sub>Original size: 2361 bytes · Original SHA-256: `c60b6554b2b934224e2275445d2a38ba83213a807316d625b6f1e34dea64b79f`</sub>

STAGE 68 — TARGET-ROOT HIERARCHY / TRANSFORM-ARTICULATION RECON

Evidence prompting Stage 68
Stage 67 found a strong target-associated model/root candidate during its full motion window:
- mean distance from the BGA: 2.260 units
- final distance from the BGA: 0.000 units
- stable relative position while the target moved: 221/234 transitions
- co-motion measurements: 224
However, Stage 67's focused census selected fallback candidates by owner/provenance before
proximity and did not include that strongest measured root in its focused hierarchy census.
Anatomical hierarchy remained unproven.

Stage 68's targeted change
1. Preserve Stage 67's bounded BGA-prioritized closure and vehicle-transition time series.
2. Fix focused-root fallback ordering: candidates within 128 units remain first; otherwise select
   the nearest structurally valid candidates by discovery distance, using owner/provenance only
   as tie-breakers. No process-specific addresses are hardcoded.
3. Continue the 240-sample time series so the selected root and each focused SpaceNode can be
   compared against the target BGA and the focused root's movement.
4. Keep raw jumps in the BGA trace and keep stationary-BGA / moving-probe counters.
5. No automatic root/bone winner, no renderer changes, no DynamicSkeletonReader changes, no
   camera/W2S changes, no entity-enumeration changes, no Aimbot/NoClip changes, no memory writes,
   and no process-wide scans.

Interpretation conditions
- A root that consistently follows the BGA is a target-associated spatial-transform candidate,
  not automatically a skeletal root.
- Nodes that move with the target may be spatial or attachment nodes. Relative movement can
  distinguish rigid co-motion from articulation candidates but does not define anatomical meaning.
- A credible bone hierarchy requires stable model ownership plus repeatable relative transforms
  during actual character articulation (for example, standing, crouching, jumping, or running).
- Vehicle handoff is still unconfirmed unless the log shows the BGA remaining stationary while a
  separate discovered transform continues moving during the real observed mount/dismount interval.
- Stage 67's EntityData snapshot comparison is not an independent game transform source.

Required outputs
  STAGE68_ATTACH_DIAGNOSTIC.txt
  STAGE68_TARGET_ROOT_HIERARCHY_RECON.txt


---

## Record 36 — `STAGE69_VALIDATION_REPORT.txt`

<sub>Original size: 2157 bytes · Original SHA-256: `2e0be9accb81643c325f5419f79f3048f7eeacd5be5ea74a3d4c5d9b0756fa47`</sub>

STAGE 69 PACKAGE VALIDATION REPORT

Base project snapshot: Stage 68 source package; active diagnostic is Stage 69.
Active diagnostic: Core/Stage69RuntimeEdgeRecon.cs
Active wiring: Overlay/HackOverlay.cs and Program.cs

Changes
1. Retained Stage 68's bounded target/root discovery, 240-sample motion association, raw BGA trace,
   candidate transform probes, and vehicle-handoff telemetry.
2. Added read-only observation of the active reader's BGA +0x0B8 graph field, +0x0D8 direct-model
   field, and +0x0E0..+0x0E8 model-array metadata. Model-array reads are bounded to 0x4000 bytes.
3. Valid reciprocal ModelSkeletal/root pairs discovered directly from those runtime fields are added
   to the diagnostic candidate pool when not already discovered by the BGA closure, provided their
   transforms are valid. This affects diagnostics only, not runtime resolution behavior.
4. Replaced broad focused pointer-window traversal with exact runtime edge-slot inspection at
   +0x18, +0x318, and +0x618, plus the diagnostic Model+0x3E8 evidence branch.
5. Descendant nodes are followed only when the vtable is the exact SpaceNode vtable, transform data
   is valid, and target distance is <=128 units. Slot candidates and rejection reasons remain logged.
6. Retained sample-time node, target-relative, and root-relative motion measurements, without assuming
   a pointer relationship is a semantic bone link.
7. Kept the active renderer, DynamicSkeletonReader behavior, camera, W2S, entity enumeration, Aimbot,
   NoClip, and ESP behavior unchanged. The Stage 68 diagnostic source and validation report are kept
   in RECON_HISTORY.

Scope assertions in source
- processWideScan=0
- diagnostic memory writes=0
- rendererChanges=0
- DynamicSkeletonReaderChanges=0
- no hardcoded per-run target/model/root addresses

Validation to perform on the Windows test machine
- dotnet clean
- dotnet build -c Release
- bin\Release\net8.0-windows\ROS64Hack.exe
- Return STAGE69_ATTACH_DIAGNOSTIC.txt and STAGE69_RUNTIME_EDGE_RECON.txt.

Not verified here
- A .NET build was not run because this environment lacks dotnet/csc/msbuild.
- No live-game behavior was tested here.


---

## Record 37 — `STAGE70_RESOLVER_REACHABILITY_RECON_NOTES.txt`

<sub>Original size: 2667 bytes · Original SHA-256: `ee42767b674a7b4ef34db3a784f3654e18304899b20dc7c7c63a7d26ab8da3ba`</sub>

STAGE 70 — RESOLVER REACHABILITY AND MODEL/ROOT-LOCAL FIELD RECON

Purpose
- Re-test Stage 69's strongest spatial-root candidate against the exact bounded BGA+0x0B8 resolver route used by DynamicSkeletonReader.
- Scan only the selected candidate model's first 0x1000 bytes and root SpaceNode's first 0x620 bytes for exact SpaceNode-vtable pointers.
- Retain only pointer fields whose transforms are within 128 units of the target/root, or are owned by the candidate model and within the bounded target-local diagnostic radius.
- Time-sample retained nodes and follow only known runtime edge slots from those nodes.

Reason for this stage
Stage 69 identified a near-target model/root with strong movement association, but its three root edge slots returned non-SpaceNode objects. The Model+0x3E8 branch led to SpaceNodes thousands of units away. The BGA+0xD8 direct-model and +0xE0/+0xE8 model-array metadata were null. The active +0x0B8 graph route was present but not reported as a matched reachability verdict. Stage 70 directly records which exact models are reachable through the active resolver route and compares that to the closest spatial-owner candidate.

Safety/bounds
- No process-wide scan. No memory writes. No runtime skeleton-reader or renderer modifications.
- BGA+0x0B8 replay uses object reads of 0x400 bytes, depth 5, at most 128 visited objects (matching DynamicSkeletonReader).
- Local pointer scan is limited to the four already selected, structurally valid candidate model/root pairs; model scan 0x1000 bytes, root scan 0x620 bytes, exact SpaceNode vtable required, up to 96 local matches/root, 64 tracked nodes/root, 256 edge records/root.
- Local pointer matches are diagnostic candidates, never automatically labeled bones. Anatomic hierarchy remains unproven until independent articulation evidence supports it.

Expected output
- STAGE70_ATTACH_DIAGNOSTIC.txt
- STAGE70_RESOLVER_REACHABILITY_RECON.txt

Decision criteria
1. If the closest spatial-owner model is reachable via BGA+0x0B8 and accepted under the active root gate, the resolver can reach the spatial candidate; continue hierarchy-edge investigation.
2. If it is not reachable while nearby owner-root candidates are found by the bounded local scene closure, the current resolver reachability gap is established, but a runtime change still requires review of a validated target-owned route.
3. If local exact SpaceNode references remain absent or show no repeatable articulation relative to the root, do not call the hierarchy proven and do not change the renderer.
4. Handoff flags remain hypotheses unless a real mount/dismount is observed and its sample timing is reported.


---

## Record 38 — `STAGE70_VALIDATION_REPORT.txt`

<sub>Original size: 2222 bytes · Original SHA-256: `c424730149ccc6bd1bc1452241d55b99561e9c47d55672f016be4a703ec5ed77`</sub>

STAGE 70 PACKAGE VALIDATION REPORT

Base project snapshot: Stage 69 source package; active diagnostic is Stage 70.
Active diagnostic: Core/Stage70ResolverReachabilityRecon.cs
Active wiring: Overlay/HackOverlay.cs and Program.cs

Changes
1. Retained bounded target/root discovery and motion association, raw BGA traces, transform probes, and vehicle-handoff hypothesis telemetry.
2. Added a read-only replay of the active DynamicSkeletonReader BGA+0x0B8 graph traversal using 0x400-byte object reads, depth 5, and a 128-object cap. It logs exact model vtables, root ownership, the reader's Matrix148/Translation178 distance-gated source preference, and whether the closest spatial-owner candidate is reachable from that graph.
3. Added bounded aligned pointer-field scans within each selected candidate model (0x1000 bytes) and root node (0x620 bytes). Only exact SpaceNode-vtable pointers with target/root-local transforms, or a matching candidate owner within the defined local diagnostic radius, are retained for time-series sampling.
4. Follows only the known runtime edge slots (+0x18/+0x318/+0x618) from locally discovered SpaceNodes under existing node/depth caps. References are diagnostic-only and are not presumed anatomical connections.
5. No renderer, DynamicSkeletonReader, camera, W2S, entity enumeration, Aimbot, NoClip, or ESP runtime behavior is changed.

Static validation
- Archive integrity is checked with unzip -t.
- SHA256SUMS.txt is regenerated from the final package and every entry is verified after ZIP creation.
- C# lexical/delimiter checks run across all active source files.
- Protected runtime files are compared byte-for-byte with the Stage 69 source snapshot.
- No stale Stage 69 active-diagnostic marker remains in Program.cs, Overlay/HackOverlay.cs, or Core/Stage70ResolverReachabilityRecon.cs.

Not verified here
- A .NET build was not run because dotnet/csc/msbuild compiler tools are unavailable in this environment.
- No live-game behavior was tested here. A Windows Release build is required.

Windows test commands
  dotnet clean
  dotnet build -c Release
  bin\Release\net8.0-windows\ROS64Hack.exe

Return
  STAGE70_ATTACH_DIAGNOSTIC.txt
  STAGE70_RESOLVER_REACHABILITY_RECON.txt


---

## Record 39 — `STAGE71_TARGETED_ROUTE_EXTENDED_ROOT_RECON_NOTES.txt`

<sub>Original size: 2821 bytes · Original SHA-256: `cb9aa780713c1befc4dcac41f034d9427ccaeda1c398cacfe27f841d11ae7259`</sub>

STAGE 71 — TARGETED ROUTE + EXTENDED ROOT SLOT RECON
==================================================

Purpose
-------
Stage 70 found a target-associated ModelSkeletal/root through this observed chain:
BGA + 0x0B8 -> graph + 0x038 -> intermediate object + 0x850 -> ModelSkeletal.
Stage 70's active-reader replay inspected at most 0x400 bytes per graph object and did not reach this model. Stage 71 tests only this previously observed field path, validates the model/root reciprocal relationship and target-local transform, then inspects the candidate root's bounded 0x2000-byte region. The directly observed slot offsets from earlier captures are +0x18, +0x318, +0x618, +0x918, +0xC18, +0xF18, and +0x1818. The additional +0x300-spaced offsets through +0x1E18 are an explicit bounded stride hypothesis test, not established fields or presumed bone edges.

Scope / protections
-------------------
- No process-wide scan.
- No process writes.
- No DynamicSkeletonReader, renderer, ESP, camera/W2S, entity enumeration, Aimbot, or NoClip behavior changes.
- Uses current runtime pointers; no captured allocation addresses are hard-coded. The field offsets are grounded in Stage 70 observations.
- If the exact route fails validation after bounded retries, capture ends without broad fallback discovery.
- Each sample verifies that the graph, intermediate object, ModelSkeletal, and root identities still match the validated route. Samples after route break are excluded from candidate/node pose metrics to avoid sampling stale pointers.
- Extended slots are structural pointer candidates only; their presence does not establish parent-child bone semantics.
- Vehicle handoff attribution is intentionally not measured in this stage.

Capture
-------
Run the usual Release build, launch ROS64Hack with the game running, keep the selected enemy visible and moving through several changes in movement/pose, and let the capture complete. Do not treat root proximity alone as proof of a skeleton.

Primary output
--------------
STAGE71_TARGETED_ROUTE_EXTENDED_ROOT_RECON.txt
Also retain STAGE71_ATTACH_DIAGNOSTIC.txt if attachment fails.

Decision questions
------------------
1. Does the dynamic BGA+0xB8 -> graph+0x38 -> intermediate+0x850 route repeatedly produce the exact ModelSkeletal and reciprocal root?
2. Does the candidate root have connected exact-SpaceNode descendants in the extended repeated-slot range that stay spatially consistent with the target and root?
3. Do those connected nodes show repeatable target/root-relative motion during target movement?

A negative answer to (1) rejects the observed route as non-repeatable for the selected target. A positive answer to (1) but negative answers to (2)/(3) means the root is associated with the target but still does not expose a proven articulated hierarchy.


---

## Record 40 — `STAGE71_VALIDATION_REPORT.txt`

<sub>Original size: 1923 bytes · Original SHA-256: `c546195a53ea976e183774e6bb9c0231c1ae5b1b97501af85e441d0fa3004f85`</sub>

STAGE 71 PACKAGE VALIDATION REPORT
==================================

Source basis: complete Stage 70 Resolver Reachability Recon codebase.

Implemented scope:
- Active diagnostic targets the previously observed BGA+0x0B8 -> graph+0x038 -> intermediate+0x850 path.
- It does not invoke the old broad discovery pass. If the targeted path is not validated within eight attempts, it emits TARGETED_ROUTE_NOT_FOUND and finishes without broad fallback discovery.
- It validates the model/root reciprocal and root-local transform before sampling. During each sample it checks graph, intermediate, model, and root identity; candidate/node transform sampling is skipped on route mismatch.
- It compares the active reader's bounded BGA+0x0B8 traversal once, then inspects the single candidate's model and root regions and the bounded extended 0x300-spaced slots through +0x1E18. These extra slots are labelled as a stride hypothesis, not known bone edges.
- Vehicle handoff attribution is explicitly out of scope.

Static validation performed in this environment:
- C# source files checked: 31. Lexical delimiter errors: 0.
- Protected runtime source files compared with Stage 70: 13. Byte-level differences: 0.
- Active Stage 70 marker/name checks in Program.cs, Overlay/HackOverlay.cs, and the Stage 71 diagnostic class: no stale active references found.
- Focused-route token checks: 6 required symbols/guards found.
- .NET compilation: NOT RUN. No dotnet, csc, or msbuild compiler is installed in this environment. The Windows build and runtime capture remain unverified until run on the user's machine.

Protected source files left byte-identical to Stage 70:
Core/DynamicSkeletonReader.cs
Core/Mem.cs
Core/Offsets.cs
Core/WorldToScreen.cs
Engine/Camera.cs
Engine/EntityLoop.cs
Engine/EntityData.cs
Engine/PlayerReader.cs
Features/Aimbot.cs
Features/ESP.cs
Features/NoClip.cs
Features/Settings.cs
Features/EntityClassifier.cs


---

## Record 41 — `STAGE72_ACTIVE_ENEMY_ROUTE_FIELD_RECON_NOTES.txt`

<sub>Original size: 2308 bytes · Original SHA-256: `5a6a642cfca80729ebd114e8c81fdcd8fdf9006534ff17d745947d0094efaf5f`</sub>

STAGE 72 — ACTIVE ENEMY ROUTE / RAW FIELD RECON
================================================

Purpose
-------
Stage 71 attempted BGA+0x0B8 -> graph+0x038 -> bridge+0x850 on one automatically selected BGA. It reached an unaligned value with no validated ModelSkeletal object. Stage 72 checks this exact route across the normal overlay's already-enumerated enemy list, preserving each live BGA pointer and EntityId in the evidence. The scope is bounded to at most 48 enemy snapshots per round for 12 rounds.

What it records
---------------
- Raw BGA bytes through +0x0E8 and the live EntityId/XYZ readback.
- BGA+0x0B8 graph value and whether the graph/vtable reads succeed.
- Graph+0x038 bridge value and whether the bridge/vtable reads succeed.
- Bridge+0x850 field bytes, the surrounding bridge bytes [bridge+0x840, +0x870), and whether the field is readable.
- Whether the field value is aligned/plausible as a pointer, whether a destination vtable read actually occurred, and whether it equals the current module's expected ModelSkeletal vtable.
- BGA+0x0D8, +0x0E0 and +0x0E8 as alternate runtime fields.
- Per-entity stability/route changes over the sample rounds.

Scope and limits
----------------
This is not a process-wide scan. It probes only the enemies delivered by the current overlay snapshot. It does not scan model/root memory, infer a skeletal hierarchy, or change the renderer, aimbot, camera, or DynamicSkeletonReader. A failure of +0x850 does not prove no other model path exists. The historical Stage 70 BGA address (0x675C6048) may be session-specific; the historical EntityId (0x0013A09E) is highlighted if it reappears, but the capture does not lock onto that stale address.

Run
---
1. Extract this ZIP to a clean working folder or use it as the full replacement project snapshot.
2. On Windows with the .NET 8 SDK installed, run `dotnet build -c Release` from the folder containing ROS64Hack.csproj.
3. Launch the normal ROS Legacy process, then run the built ROS64Hack executable at the same privilege level.
4. Let the 12-round capture finish. Collect `STAGE72_ACTIVE_ENEMY_ROUTE_FIELD_RECON.txt` and `STAGE72_ATTACH_DIAGNOSTIC.txt` from the process working directory.
5. Do not use an empty/truncated log as proof of a route result; check for `[STAGE72][FINAL][VERDICT]`.


---

## Record 42 — `STAGE72_VALIDATION_REPORT.txt`

<sub>Original size: 1845 bytes · Original SHA-256: `78466a2a4b010565a260346b501af6549cf46192ba75e3918ab39235c39b2c9e`</sub>

STAGE 72 PACKAGE VALIDATION REPORT
==================================

Source basis: complete Stage 71 Targeted Route / Extended Root Recon project ZIP.

Implemented:
- Added Core/Stage72ActiveEnemyRouteFieldRecon.cs.
- Switched Overlay/HackOverlay.cs to instantiate Stage72 and pass the current entity snapshots to it.
- Changed Program.cs active startup markers to Stage 72.
- Stage 72 samples only currently enumerated enemy snapshots (cap 48 per round, 12 rounds); there is no process-wide scan or fallback to unrelated memory sources.
- It records read success separately from pointer validity and destination-vtable reads; raw field bytes and surrounding bridge bytes are emitted on first observation or route changes.

Static validation performed in the creation environment:
- ZIP integrity: checked.
- C# source inventory lexical delimiter check: performed after writing.
- Protected runtime source files compared byte-for-byte with Stage 71: expected unchanged; report verified by the accompanying creation-time check.
- Active Overlay/Program reference checks: performed.
- .NET compilation: NOT RUN; the creation environment has no Windows .NET build toolchain. The user must run `dotnet build -c Release` on Windows before runtime capture.

Protected files intended to remain byte-identical to Stage 71:
Core/DynamicSkeletonReader.cs
Core/Mem.cs
Core/Offsets.cs
Core/WorldToScreen.cs
Engine/Camera.cs
Engine/EntityLoop.cs
Engine/EntityData.cs
Engine/PlayerReader.cs
Features/Aimbot.cs
Features/ESP.cs
Features/NoClip.cs
Features/Settings.cs
Features/EntityClassifier.cs

Important limitation:
This diagnostic can characterize the specified field route across current enemy BGAs. It cannot prove that no alternate path exists or that any candidate node is anatomical. Do not modify runtime skeleton rendering solely from its output.


---

## Record 43 — `STAGE73_CANDIDATE_MODEL_ROOT_HIERARCHY_RECON_NOTES.txt`

<sub>Original size: 2731 bytes · Original SHA-256: `63b114cd3abe597e500a9aec03ca6a17f5c42947f5a1c15f02e0688503e8c657`</sub>

STAGE 73 — CANDIDATE MODEL / ROOT / OWNER-MATCHED HIERARCHY RECON
==================================================================

Evidence basis
--------------
Stage 72 observed 10 exact ModelSkeletal-vtable matches in 11 readable +0x850 candidate-field observations for entity ID 0x001ABA7A. Stage 72 did not validate the candidate model's root or an anatomical hierarchy. The prior BGA address is not treated as stable; the exact entity ID is the capture lock.

What Stage 73 tests
-------------------
- Only the current overlay snapshot with EntityId 0x001ABA7A is used. No other enemy is probed or substituted.
- Re-check BGA ID and coordinates at the snapshot BGA pointer, then inspect BGA+0x0B8 -> graph+0x038 -> bridge+0x850.
- The field is treated as a model candidate only after its vtable equals BaseAddress+0x1C1ACE0.
- Validate candidate model+0x038 -> exact SpaceNode vtable (BaseAddress+0x1C137C8), and that root+0x040 reciprocally points to the same model.
- Before hierarchy scanning, require a readable root world translation within 128 world units of the same-round target BGA position. A structurally valid but distant/unreadable root is logged but not traversed.
- Only after that gate, scan bounded 0x300-byte regions of the root and discovered exact SpaceNodes. Child nodes are retained only when their +0x040 owner is the same candidate ModelSkeletal. Limits: 4 target-local model candidates, 32 nodes/model, depth 4.
- Sample node world translations at +0x178 across 40 rounds (500 ms interval), and record relative-to-root movement.

Run instructions
----------------
1. Extract the complete project ZIP into a clean folder.
2. On Windows with the .NET 8 SDK, run `dotnet build -c Release` from the folder containing ROS64Hack.csproj.
3. Start ROS Legacy and run the built executable at the same privilege level.
4. Allow the 40-round capture to finish; collect STAGE73_CANDIDATE_MODEL_ROOT_HIERARCHY_RECON.txt and STAGE73_ATTACH_DIAGNOSTIC.txt from the process working directory.
5. Keep that same target visible and moving; when feasible, observe running, jumping, and crouching during the 20-second capture. Confirm the final line begins `[STAGE73][FINAL][VERDICT]`. If target ID 0x001ABA7A is absent during capture, the diagnostic will report no target/route tested rather than silently choosing a different enemy.

Interpretation limits
--------------------
An exact model vtable plus reciprocal root and same-owner SpaceNode edges demonstrates structural connectivity, not that nodes are anatomical bones. The `relativeToRoot` samples can support the next test of articulation only if target movement/posture changes during capture. No renderer or runtime skeleton reader changes are included.


---

## Record 44 — `STAGE73_VALIDATION_REPORT.txt`

<sub>Original size: 2203 bytes · Original SHA-256: `b06cfa076f841571243c78b4b88851de0501f1f4b21cc1fdf861a903714f7e1a`</sub>

STAGE 73 PACKAGE VALIDATION REPORT
==================================

Source basis: complete Stage 72 project ZIP, extracted and retained as a complete project with Stage 73 as the active diagnostic.

Implemented:
- Locks to entity ID 0x001ABA7A from the normal overlay snapshot; no fallback to another enemy.
- Re-tests BGA+0x0B8 -> graph+0x038 -> bridge+0x850.
- Requires exact ModelSkeletal vtable, then exact SpaceNode root vtable and reciprocal root+0x040 == model validation.
- Requires the readable root translation to be within 128 world units of the same-round BGA position before scanning hierarchy.
- Bounded same-owner SpaceNode closure: max 4 target-local candidate models, max 32 nodes/model, depth 4, 0x300 bytes/object.
- Samples the discovered nodes' +0x178 world translations and relative-to-root positions for 40 rounds at 500 ms intervals.
- Active overlay startup/snapshot hooks point to Stage 73. Runtime renderer and DynamicSkeletonReader source are otherwise unchanged.

Protected-file comparison against Stage 72: 13/13 byte-identical.
All protected files listed below are byte-identical to Stage 72:
  Core/DynamicSkeletonReader.cs
  Core/Mem.cs
  Core/Offsets.cs
  Core/WorldToScreen.cs
  Engine/Camera.cs
  Engine/EntityLoop.cs
  Engine/EntityData.cs
  Engine/PlayerReader.cs
  Features/Aimbot.cs
  Features/ESP.cs
  Features/NoClip.cs
  Features/Settings.cs
  Features/EntityClassifier.cs

Static checks performed:
- Active diagnostic references checked in Overlay/HackOverlay.cs and Program.cs.
- Delimiter counts checked for Stage73CandidateModelRootHierarchyRecon.cs, Overlay/HackOverlay.cs, and Program.cs.
- Project/ZIP inventory and per-file SHA-256 inventory generated.
- ZIP integrity test is performed after packaging.

Compilation: NOT RUN. This environment has no dotnet, csc, or mcs compiler available. Run `dotnet build -c Release` on Windows before runtime capture.

Evidence limits: exact vtable and reciprocal root plus target-locality and owner-matched SpaceNode edges establish structural association/connectivity, not anatomical bones. Relative motion still needs review from a capture during the target's standing/running/jumping/crouching transitions.


---

## Record 45 — `STAGE74_ACTIVE_ENEMY_MODEL_ROOT_HIERARCHY_RECON_NOTES.txt`

<sub>Original size: 2460 bytes · Original SHA-256: `93e2d28c6cfe2e0a80364773680f2e24b1d2b7ad5138005aa40ae9b1c92d21f7`</sub>

ROS64HACK — STAGE 74 ACTIVE ENEMY MODEL / ROOT / OWNER-MATCHED HIERARCHY RECON
=============================================================================

Why Stage 74 exists
-------------------
Stage 73 tested only entity ID 0x001ABA7A, but that ID was absent for all 40 rounds. Therefore it tested no model route. Stage 74 removes the stale identity lock and uses the normal overlay's current enemy snapshots every round. It does not assume any historical entity ID or BGA address remains valid.

Scope
-----
- Up to 48 current overlay enemy snapshots per round, for 24 rounds at 750 ms (18-second planned sampling window after initial delay).
- For every current enemy snapshot, record current BGA pointer and entity ID, verify the raw BGA ID, and test the previously promising BGA+0x0B8 -> graph+0x038 -> bridge+0x850 route.
- Treat field readability, pointer plausibility, exact ModelSkeletal vtable, reciprocal SpaceNode root, and target-local root distance as separate gates.
- If a candidate passes the exact model vtable, reciprocal root, and <=128-world-unit same-round target-locality gates, inspect no more than four distinct models; each scan is bounded to 32 owner-matched SpaceNodes and depth 4.
- Sample accepted node world translations relative to the root over subsequent rounds. Entity IDs and BGA pointers are logged per observation and aggregated per entity ID in the final summary.
- Only entities already supplied by the overlay's live enemy snapshot are probed. No process-wide scan or memory writes occur.
- Renderer, aimbot, camera, and DynamicSkeletonReader behavior are unchanged.

Run
---
1. Extract this ZIP into a clean folder.
2. From the folder containing ROS64Hack.csproj, run: dotnet build -c Release
3. Launch ROS Legacy and run ROS64Hack at the same privilege level.
4. Keep multiple enemies loaded, preferably with one moving while standing/running/jumping/crouching, for the capture window.
5. Return STAGE74_ACTIVE_ENEMY_MODEL_ROOT_HIERARCHY_RECON.txt and STAGE74_ATTACH_DIAGNOSTIC.txt.

Interpretation
--------------
If no exact ModelSkeletal vtable appears, the route was not reproduced among the current enemy snapshots. If a root validates but lies farther than 128 units from its entity, hierarchy scanning is intentionally suppressed. Same-owner SpaceNode edges demonstrate structural connectivity only; anatomical bones still require stable relative-pose changes that correlate with deliberate articulation.


---

## Record 46 — `STAGE74_VALIDATION_REPORT.txt`

<sub>Original size: 1604 bytes · Original SHA-256: `43f84c3891e0596e54dac618c5a3228fdd15e1e1ca949e85d6ca1a4bb1d574e9`</sub>

STAGE 74 PACKAGE VALIDATION REPORT
==================================

Source basis: complete Stage 73 project ZIP. Stage 74 adds an active live-snapshot diagnostic and rewires only HackOverlay/Program diagnostic hooks and messages.

Implemented:
- Removes the Stage 73 fixed entity ID that caused all 40 rounds to be absent.
- Takes up to 48 current enemy snapshots from the existing overlay list each round (24 rounds, 750 ms interval).
- Verifies each current BGA raw ID against the snapshot's live entity ID before probing the candidate route.
- Counts route/model/root gates per entity ID and reports observed BGA/model pointer sets.
- Retains exact ModelSkeletal vtable, reciprocal SpaceNode root, <=128-unit same-round locality, owner-matched hierarchy, bounded node cap/depth, and relative-to-root motion sampling from Stage 73.
- Does not alter the renderer or DynamicSkeletonReader.

Validation performed by packaging script:
- ZIP integrity test.
- SHA-256 inventory created for each included file.
- 13 protected runtime files compared byte-for-byte to Stage 73 source ZIP.
- Static reference scan checked Stage 74 is active and Stage 73 class is not wired to HackOverlay.
- Braces and parentheses counted in the new class, Program.cs, and HackOverlay.cs.

Compilation: NOT VERIFIED here unless the package build log states otherwise. Run `dotnet build -c Release` on Windows before the live capture.

Evidence limit: no anatomy claim is made by this stage. It must identify a currently observed exact model route and validate root/owner-connected nodes before pose changes can be evaluated.


---

## Record 47 — `STAGE75_ACTIVE_ENEMY_MODEL_ROOT_NEIGHBORHOOD_RECON_NOTES.txt`

<sub>Original size: 6750 bytes · Original SHA-256: `e4c9636e837af7b01519fcf6f8af1c01f219cc5dedf6ee2fd84e176f60680d30`</sub>

ROS64HACK — STAGE 75 FINAL RUNTIME-EQUIVALENT SKELETON DIAGNOSTIC
================================================================

Purpose
-------
Stage 75 is the final diagnostic capture for this decision. Stage 74 recorded 770 enemy observations but no exact ModelSkeletal vtable matches. Its hierarchy logic was not equivalent to DynamicSkeletonReader: it read only 0x300 bytes, scanned arbitrary aligned qwords, and rejected nodes unless their +0x40 owner pointed back to the root model. This package aligns the model resolver and hierarchy probes with the live reader, and records actual child vtables for rejected edges. It does not change runtime rendering.

Candidate discovery — live resolver order
-----------------------------------------
- Sample up to 64 current overlay enemy snapshots per round, across 24 rounds at 750 ms intervals. This avoids silently dropping a normal current enemy list of the size seen in previous captures.
- Verify each snapshot's raw BGA entity ID before probing candidate fields.
- Correct raw BGA XYZ offsets: ID at +0x018, XYZ at +0x01C/+0x020/+0x024. Raw memory XYZ is compared with the overlay snapshot only as a data-quality check. Root and hierarchy locality gates use the current overlay snapshot XYZ, matching DynamicSkeletonReader.
- Respect the live resolver's BGA+0x0B8 followable-pointer gate. When that pointer is invalid, the live resolver returns before candidate discovery and Stage 75 logs that no route was tested for the entity.
- Try exact ModelSkeletal candidates in the same order as DynamicSkeletonReader: direct model pointer at BGA+0x0D8; entries in the [BGA+0x0E0, BGA+0x0E8) model array; then a bounded breadth-first traversal starting at BGA+0x0B8, capped at depth 5, 128 objects, and 0x400 bytes per object. The graph topology candidate list is cached per (entity ID, BGA address, BGA+0x0B8 pointer) during this short capture to limit repeated remote reads; each discovered model and root is revalidated on each observation.
- The model-array span must be pointer-valid, positive, 8-byte aligned, and at most 0x4000 bytes, matching the live reader's bound.
- The former bridge neighborhood (graph+0x038 followed by qwords +0x830..+0x870) is kept only as a separate supplemental census. A supplemental vtable match is never reported as a model selected by the live resolver.
- Model candidates require the exact ModelSkeletal vtable RVA 0x001C1ACE0.

Runtime-equivalent root and hierarchy logic
-------------------------------------------
- The root pointer is ModelSkeletal+0x038. Root association requires root+0x040 == candidate model. The root transform read uses the full 0x620 node window like DynamicSkeletonReader; the matrix at +0x148 is tried first, with translation at +0x178 as fallback. The chosen transform must be within 64 world units of the current overlay snapshot position. The root's own vtable is recorded but is not independently required to equal the strict SpaceNode vtable.
- Read 0x620 bytes per hierarchy node, enough to cover each qword at +0x018, +0x318, and +0x618.
- Probe only those three runtime edge slots; do not scan arbitrary aligned qwords for hierarchy edges.
- For each probed slot, log its raw value. For each pointer-like child, log the actual child vtable, module-relative RVA, owner, selected transform and position/distance, runtime type gate, target-local gate, whether it was enqueued, and the reason it was rejected or accepted. Null/non-pointer slots and unreadable children are logged explicitly. A child whose vtable cannot be read is marked unreadable rather than assigned an invented type.
- A hierarchy object is traversed only if it is the root or has a vtable matching the discovered root class or strict SpaceNode class. Child traversal requires a valid transform within 128 world units of the same-round overlay entity position. A cross-owner node can be admitted when it passes the runtime type/local gates; owner equality alone does not bypass the target-local traversal gate.
- The hierarchy traversal caps at 96 visited/accepted nodes and depth 7. For a readable node, selected transform source is retained for pose samples as the live reader does.

Motion verdict
--------------
- Pose sampling reads each accepted node through its cached transform source without an extra target-distance prefilter. The root must remain within 64 units of the target; each valid node must remain within 128 units of the root; and at least two nodes must be valid in a sample.
- Descendant motion subtracts overlay entity displacement from node world displacement, matching DynamicSkeletonReader's target-relative motion metric. The root is excluded from moving-node counts, and only currently valid, previously sampled descendants count.
- Runtime articulation thresholds reported in the log: at least 4 valid samples, at least 6 valid nodes, and at least 6 moving descendants. A descendant qualifies at 0.20 cumulative target-relative motion, or at 0.05 once 4 samples have been accumulated.
- Observe a consistent visible target through standing, running, jumping, and crouching during the capture where possible. Structural connectivity alone does not prove anatomical bones.

Expected outputs
----------------
- STAGE75_ACTIVE_ENEMY_MODEL_ROOT_NEIGHBORHOOD_RECON.txt
- STAGE75_ATTACH_DIAGNOSTIC.txt

Run
---
1. Extract the ZIP to a clean folder.
2. From the folder containing ROS64Hack.csproj, run: dotnet build -c Release
3. Launch ROS Legacy and ROS64Hack at the same privilege level.
4. Keep enemies loaded and perform the movement protocol during the approximately 18-second capture.
5. Return both logs above.

Decision rule — no Stage 76
---------------------------
Use this final Stage 75 output to choose one action. If the same live-resolver path yields six or more valid nodes with target-relative motion, investigate why the production reader/renderer fails to preserve/use the resolved hierarchy. If only 2–5 moving nodes are consistently validated, assess the node threshold against actual samples before changing it. If the root has no traversable edges, use the logged +0x018/+0x318/+0x618 child vtables and raw values to select a new traversal hypothesis. If the direct/model-array/graph route yields no exact model vtable, this capture does not support tuning the articulation threshold; the live resolver route or object type is still missing.

Safeguards
----------
No process-wide scan, memory writes, gameplay renderer changes, or DynamicSkeletonReader changes. All 13 protected runtime files remain byte-identical to the original Stage 75 package. Compilation has not been verified in this environment because the .NET SDK/compiler is unavailable; run the Windows build command before the capture.


---

## Record 48 — `STAGE75_VALIDATION_REPORT.txt`

<sub>Original size: 3865 bytes · Original SHA-256: `3293f5552761fbe820ec3e1388904271faf7052205824ff237ee5a2704b4f0ca`</sub>

STAGE 75 FINAL PACKAGE VALIDATION REPORT
========================================

Source basis
------------
Stage 74 capture log, Stage 75 original package, and Core/DynamicSkeletonReader.cs from this codebase.

Diagnostic changes
------------------
- Corrected raw BGA XYZ reads to +0x01C/+0x020/+0x024, comparing the raw values with the current overlay entity snapshot. Model/root and hierarchy distance checks use the overlay snapshot position just like DynamicSkeletonReader.
- Matched the live model resolver order after a followable BGA+0x0B8 pointer: BGA+0x0D8 direct ModelSkeletal pointer; model-array entries bounded by [BGA+0x0E0,BGA+0x0E8) and 0x4000 bytes; then a bounded BGA+0x0B8 breadth-first traversal with depth 5, 128-object limit and 0x400-byte object reads.
- Model-array fields are read as a 0x20-byte block and pointer-array entries are tested for exact ModelSkeletal vtable. The bounded graph's topology candidate list is cached by entity ID/BGA/BGA+0x0B8 during this capture to avoid repeated high-cost reads; each exact model's vtable, reciprocal root owner, 0x620 root transform window, and <=64-unit root transform are revalidated each observation. Cache usage is explicitly logged.
- The bridge qword range graph+0x038 then +0x830..+0x870 remains a separate supplemental census. Its exact vtable matches are not treated as selections from the runtime resolver route.
- Increased the hierarchy node buffer to 0x620, replaced broad aligned-qword scanning with the explicit NODE_EDGES = {0x018,0x318,0x618}, and kept the live traversal cap at 96 nodes / depth 7.
- Logged raw edge-slot values and actual readable child vtables/RVAs, owners, transform sources/positions/distances, runtime type/local gates, queue outcome and reason. Null, non-pointer and unreadable pointer slots are explicitly reported.
- Aligned root acceptance to reciprocal owner and matrix-first/translation-fallback transform within 64 units. A strict SpaceNode vtable is not incorrectly imposed on the root; child classes can match the discovered root vtable or strict SpaceNode vtable.
- Cross-owner, target-local nodes are eligible. The edge enqueue criterion mirrors the actual live implementation: matching root/SpaceNode vtable and a valid target-local transform; owner match by itself does not bypass the target-local gate.
- Pose sampling uses cached transform source, requires root within 64 units and nodes within 128 units of root, subtracts entity displacement, and reports the live articulation thresholds (4 samples, 6 valid nodes, 6 moving descendants, 0.20 cumulative target-relative motion or 0.05 after 4 samples).
- Expanded capture caps to 64 current enemy snapshots and 64 distinct models so the prior maximum of four candidate models cannot itself hide an otherwise valid current enemy. Per-capture traversal remains bounded.
- The final verdict supports one evidence-driven decision and explicitly states no Stage 76 should be built.

Protected runtime verification
------------------------------
These 13 files must remain byte-identical to the original Stage 75 package:
Core/DynamicSkeletonReader.cs
Core/Mem.cs
Core/Offsets.cs
Core/WorldToScreen.cs
Engine/Camera.cs
Engine/EntityLoop.cs
Engine/EntityData.cs
Engine/PlayerReader.cs
Features/Aimbot.cs
Features/ESP.cs
Features/NoClip.cs
Features/Settings.cs
Features/EntityClassifier.cs

Other guarantees
----------------
- No process-wide scan.
- No memory writes.
- No gameplay renderer changes.
- No DynamicSkeletonReader changes.
- The supplemental bridge census is not confused with runtime-resolver selection.
- The code emits STAGE75_ACTIVE_ENEMY_MODEL_ROOT_NEIGHBORHOOD_RECON.txt and STAGE75_ATTACH_DIAGNOSTIC.txt.

Compilation
-----------
NOT VERIFIED: the .NET SDK/compiler is unavailable in this environment. Run dotnet build -c Release on Windows before launching the diagnostic.


---

## Record 49 — `STAGE76_VALIDATION_REPORT.txt`

<sub>Original size: 2265 bytes · Original SHA-256: `2ee55e0136dbae2198d3334f9dfdea3ad609c10824d0a6d3fecafc07d8f715e7`</sub>

STAGE 76 — COMPREHENSIVE SKELETON DISCOVERY VALIDATION
=====================================================

What changed
------------
- Added one combined read-only capture comparing the direct BGA model field, model array, bounded BGA+0x0B8 graph, bridge+0x830..+0x870, historical BGA+0x048/+0x128/+0x130 routes, and bounded pointer closure from current enemy BGA objects.
- Exact ModelSkeletal-vtable pointers are retained even when root distance prevents the live resolver from selecting them.
- Reciprocal model/root ownership is recorded; root coordinates are associated against every current overlay enemy snapshot rather than requiring the source BGA to be nearest.
- Node-link discovery scans every qword-aligned field from +0x000 through +0xFF8 in a 0x1000-byte node object and logs exact-type edges, owner, transform and root-relative motion.
- Live BGA graph topology is periodically refreshed during the capture.
- Node motion is counted once per capture round, even if multiple enemy objects expose the same model.
- The active capture and attach markers now identify Stage 76, and the output file name is consistent across source and documentation.

Unchanged runtime files
-----------------------
Core/DynamicSkeletonReader.cs is byte-identical to the Stage 75 runtime-equivalent baseline.
SHA256: 6f7b87e30d4b345e3250d8e56223a4fd3a203714d7e450e633bb37bb8ddab613
The runtime skeleton reader and renderer have not been modified by this package.

Checks performed here
---------------------
- Confirmed the Stage 76 diagnostic class is defined and wired into HackOverlay.
- Confirmed the active output path is STAGE76_COMPREHENSIVE_SKELETON_DISCOVERY.txt.
- Confirmed the previous Stage 75 active overlay marker is removed.
- Checked all 35 C# files for lexical error tokens and balanced code delimiters; none were found.
- Confirmed DynamicSkeletonReader.cs matches the baseline SHA256 above.

Not verified
------------
The .NET SDK/compiler is not installed in this environment. This source package has NOT been compiled or run in-game here. Build it on Windows before testing. The discovery output can identify exact model/root/node structures and relative motion, but those observations alone do not prove that the nodes are anatomical joints.


---

## Record 50 — `STAGE77_CANDIDATE_MOTION_TRACKING_NOTES.txt`

<sub>Original size: 1559 bytes · Original SHA-256: `39f16351f2c7f3be23e4b46804309aca3072e478ae2d5249cf4649dc24e2fe23`</sub>

STAGE 77 CAPTURE PLAN
=====================

Question
--------
Do any of the exact ModelSkeletal candidates found by Stage 76 retain a valid model/root identity and expose node transforms that move coherently relative to the same enemy over repeated frames?

Data captured
-------------
- Exact ModelSkeletal vtable and reciprocal root owner on every capture round.
- Current root pointer, root world position, and nearest live enemy ID/distance each round.
- All cached exact-type node positions, regardless of root distance, with current vtable and owner.
- Parent path/edge offset, root-relative coordinates, root-distance, sample count, moving-step count, and cumulative relative movement.
- Invalidated/reused model, root, or node pointer reports.

Capture protocol
----------------
Keep one enemy visible where possible. During the 24 rounds, observe standing, running, jumping, and crouching. Do not change the target repeatedly; the goal is to determine whether a single candidate's root and nodes track one entity across movement/posture changes.

Decision rule
-------------
Prefer candidates with a consistently associated root, valid node transforms, owner/position consistency, and repeatable relative movement. A high node count alone is not sufficient. Do not enable renderer integration based on this capture alone.

Safety boundaries
-----------------
Uses current overlay enemy snapshots and previously discovered candidate routes only. No process-wide memory scan, no memory writes, no runtime skeleton-reader changes, no renderer changes.


---

## Record 51 — `STAGE77_VALIDATION_REPORT.txt`

<sub>Original size: 2761 bytes · Original SHA-256: `5522f9e6398201833ed55893b6439a7cf01eb6c3dc5738f7c7b341f358837df2`</sub>

STAGE 77 — CACHED CANDIDATE MOTION TRACKING VALIDATION
=====================================================

Purpose
-------
Stage 76 found exact ModelSkeletal objects and connected exact SpaceNode graphs, including graphs with 18, 24, and 25 nodes. However, only one node in each larger graph was within 128 units of its root, and all six motion summaries had sampleCount=1. That meant the Stage 76 run did not repeatedly sample the same cached candidates and could not establish whether their nodes followed a moving target.

Stage 77 changes
----------------
- Keeps the full Stage 76 route-discovery census.
- Revalidates every cached ModelSkeletal pointer and its current root pointer on every capture round.
- Requires the ModelSkeletal vtable and reciprocal root owner to remain valid before a cached candidate is sampled.
- Samples cached node pointers across rounds even when later BGA route scans no longer rediscover them.
- Removes the 128-unit root-distance filter from pose sampling. Root proximity is logged separately, not used to suppress node samples.
- Reads only the 0x200-byte portion needed for each repeated node sample; the full 0x1000-byte scan remains for initial hierarchy discovery.
- Rebuilds the cached node set if a valid ModelSkeletal object's root pointer changes.
- Logs each node's current vtable, owner, position, distance from root, root-relative position, and accumulated relative movement.
- Leaves Core/DynamicSkeletonReader.cs, rendering, and memory writes unchanged.

How to interpret the capture
----------------------------
A repeated node sample count greater than one makes movement comparisons possible; it is not proof of anatomical bones. A candidate remains unconfirmed unless the same root consistently tracks one enemy and its connected nodes show coherent relative movement while that enemy changes posture. Exact type matches or a large connected graph alone are insufficient.

Checks performed here
---------------------
- Confirmed Stage 77 class is wired into Overlay/HackOverlay.cs and creates STAGE77_CANDIDATE_MOTION_TRACKING.txt.
- Confirmed the sampling function no longer discards node positions solely because they are farther than 128 units from the root.
- Confirmed candidate/root identity checks are made before cached sampling.
- Confirmed the active DynamicSkeletonReader source remains byte-identical to the Stage 76 package baseline.
- Checked source delimiter balance and stage marker/output-file references.

Not verified
------------
The .NET SDK/compiler is unavailable in this environment, so this package has not been compiled or executed in-game here. Compile it on Windows before capture. The diagnostic is read-only and does not modify the runtime renderer or skeleton reader.


---

## Record 52 — `STAGE78_VALIDATION_NOTES.txt`

<sub>Original size: 2529 bytes · Original SHA-256: `b5c6bb9ea949d3bcd6447200ecc9d12237999dcaad03d4725fb05a3fddc5bd4a`</sub>

STAGE 78 — BOUNDED NODE-HIERARCHY RECONCILIATION
================================================

Evidence driving this capture
-----------------------------
Stage 77 reported 64 reciprocal model/root candidates, 43 connected multi-node graphs, and 26 candidates passing its broad relative-motion gate. But its graph walker read 0x1000 bytes per SpaceNode. The active DynamicSkeletonReader and earlier captures establish a 0x620-byte node read window, with the last known edge qword at +0x618. Stage 77 consequently treated offsets such as +0x918, +0xC18, and +0xF18—outside the verified object extent—as links. Those edges can join unrelated objects and inflate graph counts.

Stage 78 changes
----------------
- Keeps the same combined candidate sources and reciprocal ModelSkeletal/root checks.
- Bounds every SpaceNode hierarchy read and pointer-field scan to 0x620 bytes (+0x000 through +0x618).
- Labels +0x018, +0x318, and +0x618 as historically observed edge fields; other exact-type edges within the object remain exploratory rather than automatically accepted as anatomical joints.
- Repeat-samples cached candidate roots/nodes without changing the runtime skeleton reader or renderer.
- Tracks the nearest live enemy ID on each model/root sample, then reports the dominant associated entity, association percentage, root-distance distribution, node-owner consistency, and number of nodes within 128 units of the root.
- Preserves evidence from all candidates; distance and owner consistency are ranking information, not discovery filters.
- Does not write to the target process and does not perform a process-wide scan.

Required interpretation
-----------------------
A smaller graph is expected if Stage 77's out-of-bounds edges inflated node counts. A candidate is not a skeleton merely because its root belongs to a ModelSkeletal instance, its child pointers have SpaceNode vtables, or relative-motion thresholds are met. A candidate must form a plausible in-bounds node hierarchy, remain consistently associated with one enemy, and show coherent human-scale root-relative movement.

Validation
----------
The package was checked for source/reference consistency, exact `0x620` bounds, valid edge-field range, stage marker/output filename consistency, and unchanged Core/DynamicSkeletonReader.cs / renderer sources compared with Stage 77. The .NET SDK/compiler is unavailable in this environment, so the package has not been compiled or run in-game. Build in the Windows project environment before capture.


---

## Record 53 — `STAGE80_SKELETON_COVERAGE_NOTES.txt`

<sub>Original size: 6552 bytes · Original SHA-256: `a1f16a28bbb334cae86685ecf598552a508e5018e0466bac5fe26a5921ef6f37`</sub>

ROS64HACK — STAGE 80 SKELETON COVERAGE DIAGNOSTICS
==================================================

Purpose
-------
Stage 79 established that the native skeletal hierarchy can render correctly for
some live actors, but its captured console output does not identify the failure
stage for each actor whose red ESP box has no green skeleton. Stage 80 adds
low-volume, per-entity tracing so the next run can distinguish eligibility,
model/root resolution, pose sampling, projection, and the final Graphics draw gate.

Evidence from the supplied Stage 79 logs
----------------------------------------
1. In-Game Logs.txt, line 713:
   entities=20, enemies=20, visible=14, skelLoop/s=29, skelSamples/s=153,
   avgSkelLoopMs=1.02, rpm/s=7794, rpmFail/s=1101. Aggregate rejections in the
   same interval include MODEL_INVALID=2, ROOT_DISTANCE_REJECT=1, and
   B8_GRAPH_NO_MODEL=1.

2. In-Game Logs.txt, line 1103:
   visible=6, avgSkelLoopMs=5.16, rpm/s=15683, rpmFail/s=2669. This interval
   reports MODEL_INVALID=4, ROOT_DISTANCE_REJECT=3, B8_GRAPH_NO_MODEL=3, and
   B8_GRAPH_MODEL_NO_ACCEPTED_ROOT=2.

3. Training-Base Logs.txt, line 52:
   entities=28, visible=16, skelLoop/s=23, skelSamples/s=142,
   avgSkelLoopMs=12.42, rpm/s=26755, rpmFail/s=6277. Candidate rejection
   counters include MODEL_INVALID=7, ROOT_DISTANCE_REJECT=6,
   B8_GRAPH_NO_MODEL=2, and B8_GRAPH_MODEL_NO_ACCEPTED_ROOT=4.

These values are one-second aggregate counters. They prove that resolver
rejections occur and that at least one interval had high remote-memory read
pressure. They do not prove which particular boxed actor failed, and sample
rates are not unique-actor counts. The screenshots show that some skeletons
align with actor bodies while others are absent; they cannot identify the exact
internal rejection gate.

Changes in Stage 80
-------------------
- Adds [STAGE80][COVERAGE] records, keyed by entity pointer, entity ID, and
  pipeline phase. It logs state changes and repeats persistent failures no more
  than once per three seconds per entity/phase.
- ELIGIBILITY records distinguish OFFSCREEN, DISTANCE_INVALID, OUT_OF_RANGE,
  and ELIGIBLE.
- RESOLVE records report the resolver result or a specific failure reason,
  including retry cooldown, invalid graph anchor, model-discovery failure, and
  native hierarchy validation failure.
- SAMPLE records report the pose-sampling failure gate, such as root matrix
  read/validation, bone matrix-table read, coordinate validation, distance
  rejection, or too few valid bones.
- PROJECT records distinguish missing pose, invalid node count, unverified
  pose, invalid camera, stale pose, insufficient rendered segments, and
  RENDERED. Projection failure counts include projected nodes, invalid
  coordinates, projection rejections, bad parent links, unprojected links,
  and links rejected for excessive length.
- A failed sample retains the last published pose only until the existing
  150 ms freshness limit. Resolver/association failure still removes the pose.
- The legacy Stage 78 recon sampler is disabled by default to prevent its
  expensive background scan from interfering with the ordinary runtime. Set
  ROS64HACK_STAGE78_RECON=1 before launch only when intentionally collecting
  that separate recon data.
- Set ROS64HACK_SKELETON_COVERAGE=0 before launch to suppress coverage traces.

No native pointer-search depth/object cap, root-distance limit, bone radius,
maximum segment length, or minimum segment count was widened in this stage.

How to use the next run
-----------------------
1. Build and run this package on the Windows machine with the game. This
   environment did not have dotnet, csc, mcs, msbuild, or csi, so compilation
   could not be verified here.
2. Confirm startup logs include:
     [STAGE80][OVERLAY-MARKER] source=STAGE80_PER_ENTITY_SKELETON_COVERAGE_DIAGNOSTICS
     [STAGE80][STAGE78-RECON] enabled=0
3. Capture both the training-base test and one ordinary in-game session. Keep
   the full console logs. Reproduce a screen where at least one visible red ESP
   box has no green skeleton.
4. In the log, identify the missing actor by entityId and/or coordinates and
   distance. Read its latest ELIGIBILITY, RESOLVE, SAMPLE, PROJECT, and DRAW outcomes. The
   earliest failing phase is the first actionable gate; later phases may not be
   emitted when an earlier gate prevents them.
5. Send the new logs plus a screenshot from the same session. Include the
   startup marker so we can verify the tested executable contains Stage 80.

Interpreting common outcomes
----------------------------
- No Stage 80 startup marker: the running executable was not built from this
  source package or its output/log route differs. Do not diagnose the code path
  until the executable is confirmed.
- ELIGIBILITY OFFSCREEN / OUT_OF_RANGE: compare that value with the red-box
  target; this can reveal inconsistent screen/range classification.
- RESOLVE B8_GRAPH_NO_MODEL: the bounded graph walk found no accepted model.
- RESOLVE B8_GRAPH_MODEL_NO_ACCEPTED_ROOT: model candidates were found, but no
  candidate passed root acceptance.
- SAMPLE ROOT_DISTANCE_REJECT / BONE_ROOT_DISTANCE_REJECT: the sampled root or
  first bone is too far from the entity snapshot under the existing threshold.
- SAMPLE BONE_MATRIX_TABLE_READ_FAILED / BONE_MATRIX_INVALID: the matrix-table
  read or values failed validation.
- PROJECT NO_POSE: no published pose exists for that entity in the current
  snapshot.
- PROJECT STALE_POSE: a recent valid sample was not published within 150 ms.
- PROJECT TOO_FEW_SEGMENTS: the pose reached projection, but fewer than the
  configured minimum links survived coordinate, projection, parent, and length
  checks. The details field gives the rejection counts.
- PROJECT READY_TO_DRAW followed by DRAW DRAWN: the projection stage produced
  segments and the final Graphics.DrawLine calls were issued. If lines still do
  not appear for that entity, investigate the paint/compositing/window path.
- PROJECT READY_TO_DRAW followed by DRAW SKELETON_NOT_READY: check whether the
  entity data was cleared or changed between projection and painting.

Verification status
-------------------
Static source checks and patch-application checks are the only checks completed
for Stage 80 in this environment. This package is instrumentation to localize
remaining coverage failures; it is not a claim that every enemy now renders a
skeleton. A Windows build, then a fresh runtime capture, is required before a
root-cause fix can be selected without guessing.


---

## Record 54 — `STAGE81_FAILED_RESOLVER_TRACE_NOTES.txt`

<sub>Original size: 5280 bytes · Original SHA-256: `69b4abbfecd91283c6df2e92eb6d992ad56458375375733287df687e2588bb7c`</sub>

ROS64Hack — STAGE 81 FAILED-RESOLVER TRACE
==========================================

Purpose
-------
Stage 80's runtime logs distinguish visible actors with no model from actors whose
model candidates fail root acceptance. The Stage 80 detailed trace budget, however,
was consumed at the beginning of resolution and could select targets that resolved.
In addition, RuntimeDiagnostics.SkeletonEvidence writes only when its optional sink is
installed; the normal overlay does not install that legacy sink. As a result, many
traceEvidence=true calls did not appear in the saved trace.

Stage 81 change
---------------
Core/DynamicSkeletonReader.cs adds the failed-resolver replay. Overlay/HackOverlay.cs
updates the startup marker so the tested executable is distinguishable from Stage 80.

Core/DynamicSkeletonReader.cs now performs a bounded diagnostic graph replay after the
first two distinct terminal B8 graph-resolution failures. These are selected after an
actual failure, not when a candidate is first inspected. The replay writes directly to
SKELETON_DISCOVERY_TRACE.txt through the existing trace writer and flushes at the end.

Each failure trace includes:
- Entity pointer, entity ID, world coordinates, B8 anchor, terminal failure reason, and
  counters from the actual resolver attempt.
- Entity +0xD8 direct-model pointer and +0xE0/+0xE8 model-array metadata.
- The first 24 model-array slots and, for larger arrays, the final 8 slots; exact
  ModelSkeletal entries get root/owner/transform/animation inspection.
- Each object visited by a diagnostic replay using the same depth/object limits, with parent
  pointer, parent field offset, depth, observed vtable and module RVA.
- Up to 512 diagnostic-only vtable probes at the object-limit frontier and up to 32 detailed
  ModelSkeletal candidate inspections per failed entity. These diagnostic sub-limits bound
  additional remote-memory reads; the live resolver's own frontier checks are not modified.
- Detailed model candidates include root +0x38, root vtable and reciprocal owner +0x40,
  transform validity, target/root distance against the unchanged 64-unit gate, SkeletalAnim
  vtable, animation owner backlink, and bone count.
- A final summary of replay expansion, read failures, observed model candidates, frontier
  probe-budget exhaustion, detail-budget usage and remaining queue.

Runtime behavior and bounds
---------------------------
This is instrumentation, not a resolver acceptance fix. It does not change the resolver's
selected model/root, cache contents, hierarchy validation, distance limits, object/depth
limits, bone validation, projection, or drawing decisions. The only additional remote
memory reads are the diagnostic replay for at most two failed entities per process, with at
most 512 frontier vtable probes and 32 full model-candidate inspections per traced entity,
plus limited inspection of model-array sample slots. Existing successful root-neighborhood
tracing retains its prior separate cap.

Expected evidence markers
-------------------------
Look inside SKELETON_DISCOVERY_TRACE.txt for:
  FAILED_RESOLVER_BEGIN
  FAILED_ENTITY_MODEL_FIELDS
  FAILED_GRAPH_OBJECT
  FAILED_MODEL_CANDIDATE
  FAILED_GRAPH_SUMMARY
  FAILED_RESOLVER_END

Interpretation
--------------
- FAILED_GRAPH_SUMMARY exactModelObjects=0 and capFrontierModelCandidates=0 means the
  replay did not observe an exact ModelSkeletal in the nodes it visited or at its cap
  frontier. Compare the entity-owned fields and the visited parent/offset chain before
  considering any graph expansion.
- A FAILED_MODEL_CANDIDATE with ownerMatches=0 indicates a reciprocal ownership mismatch.
- rootVtableMatches=0 indicates a root candidate of the wrong native type.
- transformValid=1 with withinCurrent64UnitGate=0 indicates a spatial association failure;
  do not raise the threshold simply to accept it.
- a valid reciprocal root with a reasonable target distance but invalid animation vtable,
  animation owner backlink, or bone count points to a different model/rig validation issue.
- If the summary reaches objectLimit=128 and queueRemaining is nonzero, the trace shows
  a bounded search frontier, but does not by itself prove that an unseen descendant is a
  valid character rig. If capFrontierBudgetExhausted=1, the diagnostic replay intentionally
  stopped its own frontier probing at 512 candidates; use the original resolver counters plus
  the observed graph paths rather than treating an unprobed pointer as a missing model.

Build and runtime verification
------------------------------
Build on Windows with .NET 8:
  dotnet clean
  dotnet build -c Release

Then run the same training-base or live session where one or more visible red boxes have
no green skeleton. Keep In-Game Logs.txt and SKELETON_DISCOVERY_TRACE.txt from the same
launch. Confirm the Stage 81 startup marker is present and the new FAILED_RESOLVER markers
appear for unresolved entities.

Verification status at packaging time
-------------------------------------
Patch application and source-level structural checks are run locally. A .NET SDK/compiler
is not available in the packaging environment, so Stage 81 has not been compiled or
runtime-tested here. Do not treat this diagnostic package as proof that coverage is fixed.


---

## Record 55 — `STAGE81_VALIDATION_REPORT.txt`

<sub>Original size: 1016 bytes · Original SHA-256: `8905ed4241d5e8f345e969fd48f76640e8991f67fc89084688eaf197729a9166`</sub>

STAGE 81 VALIDATION REPORT
==========================

Baseline source: ROS64Hack_STAGE80_BuildFix.zip
Code files changed: Core/DynamicSkeletonReader.cs, Overlay/HackOverlay.cs
Behavioral scope: diagnostic-only tracing after first two distinct B8 graph resolver failures
Resolver thresholds changed: no
Resolver depth/object limits changed: no
Root-distance threshold changed: no
Bone validation thresholds changed: no
Model/root acceptance behavior changed: no

Checks to perform after package creation:
- Verify the patch applies to Stage 80 source.
- Verify patched DynamicSkeletonReader.cs matches packaged source byte-for-byte.
- Check C# delimiter balance and confirm new diagnostic methods/markers exist.
- Verify ZIP CRCs and SHA256 manifest.

Limitations:
No .NET SDK/compiler is installed in this environment. A Windows dotnet build and a fresh
runtime diagnostic capture are still required. This package localizes remaining coverage
failures; it does not claim that the missing skeletons have been fixed.


---

## Record 56 — `STAGE82_BOX_ALIGNMENT_CHANGELOG.txt`

<sub>Original size: 1507 bytes · Original SHA-256: `18ec265a659be2b04d250c2e4d6a171ef42c5be293d1a25b2c04bf6f6a135b2c`</sub>

ROS64HACK — STAGE 82 TARGETED BOX ALIGNMENT CHANGE
==================================================

Change made
-----------
Removed the separate 16 ms velocity prediction that was applied only to 3D box
coordinates. The box now uses the already-computed foot/head projection from the same
entity and camera snapshot used by the other overlay features.

Evidence / root cause
--------------------
Features/ESP.cs previously projected the current entity position, then projected a second
position advanced by velocity * 16 ms for the box only. Tracer and aim projections remained
at the current snapshot. This made the box disagree with those elements and could overshoot
when velocity estimates were based on irregular sampling or motion changed direction.

Scope
-----
Only box projection alignment was changed. This does not claim to solve snapshot sampling
latency, vehicle occupant transforms, anatomical head-bone identification, or skeleton
hierarchy correctness. The green lines from screen top are the separate ESP tracer feature,
not proof of malformed skeleton connections.

Verification status
-------------------
- Source change applied to the supplied Stage 82 package.
- Verified no remaining references to TryProjectPredictedBox, PositionHistory,
  PositionSample, StopwatchTicks, or Esp3DBoxPredictionMs in active source.
- Build/runtime behavior is not verified: dotnet/.NET SDK and C# compiler are unavailable
  in this environment. A Windows Release build and live test are required.


---

## Record 57 — `STAGE82_DIAGNOSTICS_CHANGELOG.txt`

<sub>Original size: 1685 bytes · Original SHA-256: `2645e92fd36a356bd1638e8265ba831f338c23bcf6cdcd991bcd94d2947b8738`</sub>

ROS64HACK STAGE 82 — VERBOSE COVERAGE TRACE OPT-IN
================================================

Change
------
Core/SkeletonCoverageTrace.cs now enables per-entity Stage 80 coverage messages only
when ROS64HACK_SKELETON_COVERAGE=1 is set before launching the application. The trace
is disabled by default. RuntimeDiagnostics compact summary counters remain enabled and
unchanged.

Evidence
--------
The provided STAGE78_ATTACH_DIAGNOSTIC.txt contains 3,745 lines tagged
[STAGE80][COVERAGE] out of 3,954 total lines. In this source package, the coverage trace
was enabled by default unless ROS64HACK_SKELETON_COVERAGE=0. Each reported state change
calls Console.WriteLine from the hot sampling/projection paths. This creates avoidable
synchronous console I/O during ordinary runs. The log does not prove this I/O caused all
observed timing spikes; that requires an A/B capture with identical gameplay conditions.

How to enable the trace for a focused debugging capture
-------------------------------------------------------
Set ROS64HACK_SKELETON_COVERAGE=1 in the environment before launching ROS64Hack. Omit
that variable, or set it to any value other than exactly 1, for normal low-noise runs.
The setting is read once during type initialization; changing it after the process starts
will not toggle the trace in that process.

Scope and non-claims
-------------------
This change only gates verbose coverage logging. It does not change entity enumeration,
model/root acceptance, bone hierarchy, sampling cadence, the 150 ms pose freshness limit,
box projection, aimbot targeting, or vehicle state handling. No build or live runtime
verification is claimed for this package.


---

## Record 58 — `STAGE82_GRAPH_POINTER_FILTER_NOTES.txt`

<sub>Original size: 3626 bytes · Original SHA-256: `bd1f01e9b9608e08d3d131ae4b58f12acfbf5e4ba133e3e2075470ab00ca4998`</sub>

ROS64Hack — STAGE 82 GRAPH POINTER FILTER
========================================

Why this change was made
------------------------
The Stage 81 trace showed B8_GRAPH_NO_MODEL failures where the bounded walk visited
128 candidate addresses, including the object's vtable address at parentSlot=0. That
vtable address was then read as if it were an instance object, causing code bytes to be
reported as a fake vtable. Other values that point into the main executable image were
also queued as objects. Because the graph walk admits any integer address in a very broad
user-address range, such non-object values can consume its 128-object budget.

Stage 82 change
---------------
1. Mem exposes the main module's base and ModuleMemorySize after successful attach.
2. The B8 graph resolver does not queue child pointers inside the main executable image.
3. When the current object's first qword is a main-image address (the observed native
   object/vtable pattern), offset +0 is skipped as a child edge.
4. The same filters are applied to the bounded failed-resolver diagnostic replay.
5. New trace summaries report resolverVtableSlotsSkipped,
   resolverModuleImagePointersSkipped, vtableSlotsSkipped, and
   moduleImagePointersSkipped.
6. The overlay startup marker changes to STAGE82_GRAPH_POINTER_FILTER so the running
   diagnostic build can be distinguished from Stage 81/Stage 78 logs.

Unchanged guards
----------------
- RESOLVE_MAX_DEPTH and RESOLVE_MAX_OBJECTS are unchanged.
- The 64-unit root/entity association gate is unchanged.
- ModelSkeletal, SpaceNode, SkeletalAnim, hierarchy, matrix, projection, and drawing
  validation thresholds are unchanged.
- Direct model fields and entity model-array paths remain checked before the B8 graph.
- This does not blindly accept any new model/root candidate; every candidate still passes
  the existing model/root acceptance function.

Important limitations
---------------------
This is a targeted correction to graph traversal noise, not proof that every enemy will
now render a skeleton. Some legitimate reference to a static object inside the executable
image could be skipped by the main-image child-pointer filter; the current trace did not
establish that such a reference is required for these B8 paths. The next runtime log must
show whether fewer non-object addresses consume the search budget and whether the failed
entities now reach exact ModelSkeletal candidates. If this narrows a required static route,
restore that route using a typed edge rather than reopening unrestricted image traversal.

Build/runtime verification
--------------------------
The patch is constructed from the Stage 81 source archive and checked for clean application,
source/package consistency, diff whitespace errors, and ZIP CRC/SHA-256 integrity.
No .NET SDK/compiler is installed in the packaging environment, so compilation and live
runtime behavior remain unverified here.

Build and test on Windows
-------------------------
  dotnet clean
  dotnet build -c Release

Do not launch the executable if the build fails. After a successful build, reproduce a
visible enemy with a missing skeleton and retain the overlay log plus
SKELETON_DISCOVERY_TRACE.txt from the same launch. Confirm:
  [STAGE82][OVERLAY-MARKER] source=STAGE82_GRAPH_POINTER_FILTER

For each FAILED_GRAPH_SUMMARY, compare exactModelObjects, visited, capFrontierProbes,
vtableSlotsSkipped, and moduleImagePointersSkipped against Stage 81. A reduction in
noise alone is not sufficient: confirm that the resolver reaches and accepts the intended
entity-owned model and root before judging the fix successful.


---

## Record 59 — `STAGE82_RUNTIME_DIAGNOSTIC_REPORT.txt`

<sub>Original size: 8142 bytes · Original SHA-256: `6df8fec849440419c28360968dfd416eead49ba9ae95baa90da24476ac8aa48a`</sub>

STAGE 82 RUNTIME LOG REVIEW
===========================

Inputs reviewed
---------------
- SKELETON_DISCOVERY_TRACE.txt (298 lines)
- STAGE78_ATTACH_DIAGNOSTIC.txt (3,954 lines; 3,745 coverage-event lines)
- Stage 82 source package, including the alignment patch and graph-pointer filter notes

Build identity / verification blocker
-------------------------------------
The runtime diagnostic starts with:
  [STAGE78][BUILD-MARKER] ROS64HACK_STAGE78_BOUNDED_NODE_HIERARCHY_RECON
and its capture declaration says runtimeReaderAndRendererUnchanged=1. The supplied Stage 82
source instead prints at Overlay/HackOverlay.cs:199:
  [STAGE82][OVERLAY-MARKER] source=STAGE82_GRAPH_POINTER_FILTER+SNAPSHOT_ALIGNED_BOX
That marker does not appear in either uploaded log. The diagnostic results therefore do not
prove that the newly packaged Stage 82 alignment patch was running. The second trace contains
graph-filter counters but no build marker, so its exact binary identity is also not proven.

What is proven by these logs
----------------------------
- Attach succeeded in the captured process: pid 11144, base 0x140000000, image size 0x5AEA000.
- Across 192 summary records, average read rate was 59.73/s and draw rate was 60.13/s;
  skeleton loop rate averaged 29.15/s.
- All 192 summary records report camBad/s=0.
- No [DIAG][READ-LOOP-EXCEPTION] or [DIAG][SKELETON-LOOP-EXCEPTION] messages were found.
- Some skeletons completed projection/drawing: 330 READY_TO_DRAW and 317 DRAWN outcomes.
- Incomplete coverage is substantial: 326 STALE_POSE, 205 NO_POSE, 517 SKELETON_NOT_READY,
  236 RETRY_COOLDOWN, 126 B8_GRAPH_MODEL_NO_ACCEPTED_ROOT, 13 B8_GRAPH_NO_MODEL, and 14
  TOO_FEW_SEGMENTS outcomes. Counts are event counts, not unique entities.
- The 326 stale-pose events ranged from 151.1 ms to 57,162.9 ms, with a median of 2,140.2 ms.
  The code's ApplyLatest freshness threshold is 150 ms at DynamicSkeletonReader.cs:417-423.
- Timing spikes exist in the summaries: avgReadMs max 12.32, avgDrawMs max 10.33, and
  avgSkelLoopMs max 22.05. The maxima coincide with nonzero loop-skip counters in some samples.
  The logs do not isolate a single cause for those spikes.
- Aimbot activation cannot be assessed reliably from this capture: shift/s is zero in the
  median summary record (mean 1.64, max 62). The logs do not record a verified anatomical
  head target being selected or used.
- No vehicle-transition/occupant-transform event is recorded; no vehicle fix can be verified.
- There is no allocation, managed-heap, GC, or private-bytes measurement, so a memory leak
  cannot be diagnosed from these logs.

Resolver evidence
-----------------
The focused trace has two FAILED_RESOLVER records ending in B8_GRAPH_MODEL_NO_ACCEPTED_ROOT.
The live-resolver counters report 105 expanded objects and 23 read failures for each failure. The
supplementary trace then independently walks the graph: its summary reports 128 visited objects
and reaches its own 512-probe cap-frontier budget. That cap is explicitly diagnostic-only; it is
not proof that the live resolver's scan was capped at 512 probes. For entity 0x508D0FF8, five
exact-model objects are recorded. Their root/entity distances are 148.003, 185.252, 2,618.063,
2,630.427, and 2,633.671 units, all outside the unchanged 64-unit acceptance gate; reported
boneCount values are negative. For entity 0x33C2D068, two exact-model objects are found; their
distances are 284.195 and 11,239.405 units, again outside the gate, and boneCount values are
negative. These are rejected candidates, not proof that the filter dropped a valid root. The
resolver should not accept them without new evidence linking the candidate to the entity.

Code locations consistent with observed skeleton outcomes
--------------------------------------------------------
- DynamicSkeletonReader.cs:604-675 applies a 5,000 ms retry cooldown after resolve failures.
- DynamicSkeletonReader.cs:282-292 records the resolution failure and removes the existing pose
  when revalidation/resolution fails.
- DynamicSkeletonReader.cs:301-314 retains the last good pose after a sampling failure.
- DynamicSkeletonReader.cs:417-423 rejects poses older than 150 ms, leading to NO_POSE / STALE_POSE
  rendering gaps rather than drawing stale geometry.
- DynamicSkeletonReader.cs:86 keeps the 64-unit root/entity acceptance gate; rejected candidates
  in the provided focused trace are materially farther away.
These facts explain recorded rejection and blank-pose outcomes, but not the underlying game-side
reason that a given entity's native model/root route could not be validated.

Targeted source change made after review
----------------------------------------
Core/SkeletonCoverageTrace.cs was changed so the verbose per-entity coverage trace is opt-in
via ROS64HACK_SKELETON_COVERAGE=1. The 3,745 coverage lines demonstrate that this trace dominates
the capture output, and the source calls Console.WriteLine on state changes. This is a narrow
noise/overhead reduction; the logs do not prove it is the sole source of timing spikes.
Compact summary telemetry remains enabled. No resolver, vehicle, targeting, or skeleton topology
logic was changed because this capture cannot verify the Stage 82 binary and does not establish
an alternate accepted model/root path.

Required verification sequence
------------------------------
1. Build the delivered source on Windows with dotnet clean and dotnet build -c Release.
2. Start the resulting binary and confirm the exact STAGE82 OVERLAY-MARKER is printed.
3. Run a quiet performance capture with ROS64HACK_SKELETON_COVERAGE unset; compare the compact
   summary rates, avg loop times, and skip counters under the same scene.
4. For a focused skeleton capture, set ROS64HACK_SKELETON_COVERAGE=1 before launch and capture
   STAGE82 marker plus SKELETON_DISCOVERY_TRACE from the same process.
5. Do not relax the 64-unit root gate or raise the probe limit based only on these rejected
   candidates. First capture evidence of a candidate with entity ownership, valid transform,
   plausible bone count, and a root transform close to the target.

Verification limitation
-----------------------
The packaging environment has no dotnet executable. Static content/package checks can be run
here, but compile-time correctness and runtime behavior remain unverified until the Windows build
and live capture above are completed.


STAGE 82 UNIFIED IMPLEMENTATION ADDENDUM

Additional source change after the runtime capture review:
- Coverage diagnostics are now guarded at the call sites, not merely inside SkeletonCoverageTrace.Record. This prevents interpolation and projection-detail string construction when the trace is disabled.
- The behavior of skeleton resolution, pose freshness, model/root gates, target selection, and vehicle state was not altered by this performance change.

Interpretation of the supplied latest capture:
- The runtime log contains [STAGE82][OVERLAY-MARKER] at line 97, confirming the Stage 82 overlay marker was emitted in this run. The earlier [STAGE78] banner belongs to the legacy recon/attach diagnostic preamble and should not alone be used to classify the overlay build.
- The worst skeleton-loop window is 172.87 ms with 20 skipped attempts and 9,238 failed RPM reads/s. The same capture produced SKELETON_DISCOVERY_TRACE.txt, so detailed tracing was enabled; the window is not a tracing-disabled baseline.
- Several resolver traversals expanded 96-111 graph objects. Their failed outcomes do not justify weakening the existing root ownership or 64-unit association checks.

Still evidence-gated and not implemented:
- Native anatomical head-node selection: the current pose data does not preserve a validated anatomical head designation through to the aimbot target point.
- Vehicle occupant-to-live-transform binding: the uploaded capture has no before/during/after vehicle transition evidence.
- Anatomical skeleton edge whitelist: hierarchy indices have not been mapped to a verified human-rig schema in the supplied evidence.

Build and live behavior remain unverified in this environment because no .NET SDK/compiler is installed.


---

## Record 60 — `STAGE82_UNIFIED_CHANGELOG.txt`

<sub>Original size: 2615 bytes · Original SHA-256: `995b38067f25c4133522b73e536650b26a7cf0c96e2fd31fde2c1b5ffff92bfd`</sub>

STAGE 82 UNIFIED CHANGELOG

Change 1 — expensive forensic discovery tracing is now opt-in.
- Core/DynamicSkeletonReader.cs: ROS64HACK_SKELETON_DISCOVERY_TRACE is read once at startup.
- SampleFocusedTraceCandidates no longer performs extra diagnostic sampling during normal runtime.
- Failed resolver graph replay, successful model/root neighborhood tracing, hierarchy trace tracking, and the trace file sink are disabled unless the environment variable is exactly "1".
- Overlay/HackOverlay.cs prints both opt-in diagnostic controls at startup.
- Existing compact RuntimeDiagnostics summaries and core resolver acceptance rules are retained.

Retained existing Stage 82 changes
- ESP box uses the current projected head/foot positions rather than a separate box-only motion prediction.
- Stage 82 graph-pointer filtering remains intact.
- Per-entity SkeletonCoverageTrace remains opt-in via ROS64HACK_SKELETON_COVERAGE=1.

Not changed because the supplied evidence does not establish the required native mapping
- Dynamic anatomical head-joint index and a verified projected head target.
- Vehicle occupant-to-live-transform relationship.
- Bone hierarchy filtering for a clean anatomical skeleton.
These require additional verified native evidence; inventing offsets or accepting unverified model roots would risk corrupting tracking.

Verification status
- Static source assertions and archive integrity are checked by the packaging step.
- A Windows .NET Release build and live runtime comparison are not available in this environment and are not claimed.

Change 2 — disabled coverage tracing no longer formats per-entity diagnostic strings.
- Core/SkeletonCoverageTrace.cs exposes a read-only IsEnabled flag.
- Core/DynamicSkeletonReader.cs guards coverage trace call sites before interpolation and only builds projection-detail strings when the trace is enabled for an eligible entity.
- Features/ESP.cs guards draw-trace calls before constructing diagnostic details.
- This removes avoidable string formatting/allocation from normal sampling, projection, and paint paths while preserving the opt-in trace output.

Evidence boundary
- The supplied runtime capture includes SKELETON_DISCOVERY_TRACE.txt, demonstrating that detailed discovery tracing was enabled for that capture. The 172.87 ms skeleton-loop window therefore cannot be treated as a clean baseline for normal tracing-disabled operation.
- The same capture still shows 9,238 RPM failures/s during that window and graph traversals expanding roughly 96-111 objects for failed targets. Resolver association remains a separate unresolved issue.


---

## Record 61 — `STAGE82_VALIDATION_REPORT.txt`

<sub>Original size: 1248 bytes · Original SHA-256: `229b67047882b1037af9d65ba0d03446ee76fbcff5e2e0a40a6c1eca1cd2f493`</sub>

STAGE 82 VALIDATION REPORT — UNIFIED LOW-OVERHEAD DIAGNOSTICS

Source-level checks performed:
- Box-only velocity prediction remains removed; box uses current foot/head projection values.
- ROS64HACK_SKELETON_COVERAGE=1 is required for per-entity coverage output.
- Coverage logging call sites now check IsEnabled before evaluating interpolated diagnostic strings.
- Projection-detail strings are constructed only when coverage tracing is enabled for an eligible entity.
- ROS64HACK_SKELETON_DISCOVERY_TRACE=1 is required for expensive graph/hierarchy tracing and focused extra sampling.
- Graph-pointer filters and existing model/root ownership and distance gates are retained.
- No native head-bone index, vehicle occupant transform, or anatomical connection whitelist was invented.

Build/runtime status:
- ZIP integrity verified.
- SHA256SUMS.txt regenerated for every packaged file except the manifest itself.
- Static source assertions and delimiter checks passed.
- Windows Release compilation not verified: dotnet, csc, mcs, and msbuild are not available in this environment.
- Runtime performance improvement not verified; requires a comparable capture with both ROS64HACK_SKELETON_COVERAGE and ROS64HACK_SKELETON_DISCOVERY_TRACE unset.


STAGE 84 — LOW-LATENCY SNAPSHOT + CAMERA RECOVERY CONTINUITY

- Entity/camera read request and paint invalidation request periods were reduced from 16 ms to 8 ms. This requests fresher snapshots but does not claim frame-lock or a 125 FPS presentation rate.
- Persistent active-camera invalid reads now trigger immediate cached-pool recovery while retaining the last coherent camera data and pointer as continuity evidence. Selection failures within an already-discovered pool retry after 50 ms; a cold-start retry that performs another heap scan remains throttled at 500 ms.
- Stage 84 markers identify the new source path in logs.
- The native skeleton renderer still requires a labeled runtime bone-index screenshot before a human-body-only edge whitelist and head/neck mapping can be implemented safely. No bone IDs were guessed.
- Static source/package checks were completed. Windows Release compilation and live behavior were not verified because the .NET toolchain and target process were unavailable.

## Stage 89 — Pelvic skirt branch exclusion

- Uses the supplied Stage 88 edge map to target four compact branches radiating from the pelvis-like junction.
- The exclusion is selected by hierarchy topology and subtree bounds, not hard-coded bone IDs: multi-child junction, upper-extreme branch, lower-body branch containing both legs, and at least two compact intermediate sibling subtrees.
- Excludes the four compact subtrees using existing parent-child edges only; does not create, reconnect, or bridge edges.
- Adds `excludedPelvicSkirtRoots`, `excludedPelvicSkirtEdges`, and `EXCLUDED_PELVIC_SKIRT_SUBTREE` edge-map states for live confirmation.
- Static synthetic reproduction against the supplied edge map selects branches beginning at bone IDs 13, 10, 7, and 4; a live Windows build and visual test remain required.


## Stage 90 — Dynamic head circle and neck clip
- Derives an upper head cluster from the highest valid native pose nodes within the body-centre screen corridor.
- Replaces only projected edges inside that compact cluster with a dynamically sized screen-space circle.
- Clips the existing incoming parent-child edge at the circle perimeter, preserving its lower visible neck segment without changing any native transform or hierarchy link.
- Emits dynamic `headTipBone`, `headEntryBone`, and `neckBaseBone` indices in coverage/edge-map output.


## Stage 91 — Smaller dynamic head outline

- Reduced the screen-space head-circle scale from 0.065 to 0.048 of projected body height.
- Reduced the minimum radius from 4 px to 3 px and the width padding from 2 px to 0.75 px.
- Reduced the maximum radius scale from 0.15 to 0.10 of projected body height.
- Left dynamic head-centre selection, current-pose projection, neck clipping, native transforms, parent-child topology, and pelvic-skirt exclusions unchanged.
- Runtime visual verification remains pending; the Windows .NET SDK is not available in the packaging environment.


## Stage 92 — World-space head-cluster center and tighter radius

- Replaced screen-space bounding-box center with a 3D world-space head-cluster centroid projected using the current camera snapshot.
- Tightened radius scaling and padding; radius remains derived from current projected geometry for perspective responsiveness.
- Preserved existing inferred cluster selection, neck clipping, and pelvic-skirt exclusions.
- The edge map does not establish a universal semantic Head-bone index.
- Windows build and live-angle validation remain required.

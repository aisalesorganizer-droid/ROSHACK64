# Stage 88 — Exclusion-only branch pruning

## Why Stage 87 failed

The Stage 87 capture reported 66 rendered edges on a 68-node skeleton, one excluded root
connector, and zero excluded short terminal edges. Its filter recognized only single-child
leaf chains, so forked hand/finger and attachment subtrees were not pruned.

## Stage 88 behavior

- Keeps the validated native hierarchy and its original parent-child links.
- Excludes the root-origin connector.
- At a junction, excludes a compact side subtree using the subtree's full 3D bounding extent,
  including forked descendants. The head/top and foot/bottom extremes are protected.
- Does not synthesize edges, skip across removed nodes, or join disconnected pieces.
- The screen-top tracer setting remains off by default (`Settings.EspLines = false`).
- Coverage details report `excludedRootAnchorEdges`, `excludedSmallBranchRoots`,
  `excludedSmallSubtreeEdges`, `excludedPelvicSkirtRoots`, and `excludedPelvicSkirtEdges`.
  The edge map labels this specific exclusion as `EXCLUDED_PELVIC_SKIRT_SUBTREE`.
- Optional `ROS64HACK_SKELETON_EDGE_TRACE=1` writes one visible entity's exact parent-bone →
  child-bone mapping, world/screen coordinates, and KEEP/EXCLUDED state to
  `STAGE89_SKELETON_EDGE_TRACE.txt`. It is one-shot and disabled by default.

This is a generic geometry-based pruning rule, not a semantic bone-name map. The threshold is
relative to the observed rig height (18%, clamped to 0.65–4.0 world units) and still requires
live visual validation. Major branches containing the topmost/head or bottommost/foot extent
are protected; a side branch larger than the threshold is preserved.

## CMD build and launch

From the extracted `ROS64Hack` directory, in Command Prompt:

```cmd
dotnet clean
dotnet build -c Release
if errorlevel 1 exit /b 1
set ROS64HACK_SKELETON_COVERAGE=1
set ROS64HACK_SKELETON_BONE_INDEX_DIAGNOSTICS=
bin\Release\net8.0-windows\ROS64Hack.exe
```

Expected startup marker: `[STAGE89][BUILD-MARKER] ROS64HACK_STAGE89_PELVIC_SKIRT_EXCLUSION`.

For a one-shot parent/child mapping capture, also run `set ROS64HACK_SKELETON_EDGE_TRACE=1`.
The diagnostics variable is cleared above because setting it to `1` draws cyan numeric labels
at bone positions. Those labels do not affect the skeleton edges, but obscure the requested clean
stick figure.

## Verification boundary

Static source/structure checks and package integrity are verified in this environment. A Windows
.NET 8 build and a live-game render test were not available here. On the next live capture, use the
coverage data to confirm `excludedSmallBranchRoots > 0` and that `segments` is materially below the
Stage 87 value (62–66 for 64–68 node rigs) while the torso and limbs remain connected through
existing parent-child edges.


Stage 89 additionally excludes compact intermediate branches at a pelvis-like multi-branch junction when the same junction has an upper-extreme continuation and one lower-extreme continuation, which can split into both legs on the next level. This specifically addresses the compact skirt-like branches documented in the user-provided Stage 88 edge map; it uses parent-child topology and measured subtree extents rather than fixed bone IDs.

For the supplied pose, expected targeted evidence is `excludedPelvicSkirtRoots=4` and
`excludedPelvicSkirtEdges=12`. If those counters are zero, do not assume the fix took effect; verify
the Stage 89 build marker and the one-shot edge map from the same process launch.


## Stage 91 — Dynamic head-circle / neck mapping

Set `ROS64HACK_SKELETON_COVERAGE=1` and `ROS64HACK_SKELETON_EDGE_TRACE=1` in CMD before launch. The one-shot map is `STAGE91_SKELETON_EDGE_TRACE.txt`. Its header reports `headTipBone`, `headEntryBone`, and `neckBaseBone`, all identified from that sampled pose rather than hard-coded IDs. `HEAD_NECK_CLIPPED` marks the original incoming edge whose lower portion remains visible; `HEAD_CLUSTER_REPLACED` marks edges inside the compact upper cluster that are rendered as one circle instead. This changes only projection/render geometry: sampled world transforms and native hierarchy records remain untouched.


## Stage 92 — World-space head-centre projection

The circle centre is now the 3D centroid of the selected compact head cluster, projected with the same camera snapshot as the skeleton. Radius is recomputed from the projected cluster width and a smaller body-height fallback. The current edge-map provides inferred node/bone indices only; it does not prove a canonical semantic `Head` joint ID.

## Stage 97 — viewport-gated focused capture

The current Stage 97 build selects only one diagnostic actor. At least two-thirds of the surviving skeleton segments (minimum six) must have both endpoints inside the client viewport, and the visible vertical extent must be at least 12 pixels. The cyan index labels and the one-shot edge map are bound to that same `(Ptr, EntityId)`. This avoids selecting an off-right actor through the ordinary ESP clipping tolerance and avoids index labels cluttering every skeleton.

Use this from the extracted `ROS64Hack` directory in CMD:

```cmd
dotnet clean
dotnet build -c Release
if errorlevel 1 exit /b 1
set ROS64HACK_SKELETON_COVERAGE=1
set ROS64HACK_SKELETON_EDGE_TRACE=1
set ROS64HACK_SKELETON_BONE_INDEX_DIAGNOSTICS=1
bin\Release\net8.0-windows\ROS64Hack.exe
```

Expected marker: `ROS64HACK_STAGE97_FOCUSED_ONSCREEN_BONE_DIAGNOSTICS`. Collect `STAGE97_ATTACH_DIAGNOSTIC.txt`, `STAGE97_SKELETON_EDGE_TRACE.txt`, and a screenshot from the same launch. The edge-map header must report `viewportSegments` greater than zero and `viewportBounds` inside the declared `screen` dimensions. If the header does not show those conditions, do not use the trace to infer anatomical links. Stage 97 is a diagnostic-selection correction only; it does not assert that the bone topology or matrix layout has been corrected.


## Stage 98 — native root/actor association

Stage 97's selected on-screen hierarchy is structurally traversable but may still be spatially misassociated. The resolver's previous 64-unit distance gate allowed a native ModelSkeletal/SpaceNode candidate to be accepted far from the current entity anchor. Stage 98 uses an 8-unit threshold for native root association and native hierarchy-root translation throughout resolution, cache validation, and pose sampling. The 64-unit tolerance remains only on legacy non-native node reading. This makes the native path fail closed when the candidate's root is not close to the owning entity. No bone index is assigned an anatomical name; native offsets and edge traversal are unchanged.


For the Stage 98 run, keep `ROS64HACK_SKELETON_COVERAGE=1`, `ROS64HACK_SKELETON_EDGE_TRACE=1`, and `ROS64HACK_SKELETON_BONE_INDEX_DIAGNOSTICS=1` enabled. Add `ROS64HACK_SKELETON_DISCOVERY_TRACE=1` only when a second capture is needed to inspect model candidates and `withinNative8UnitGate`; that trace increases remote-memory reads and file/console I/O. The active startup marker is `ROS64HACK_STAGE98_NATIVE_ROOT_ASSOCIATION_GUARD`.

using System;
using ROS64Hack.Engine;

namespace ROS64Hack.Features
{
    public enum EntityKind
    {
        Unknown,
        Bot,
        Player
    }

    public static class EntityClassifier
    {
        public static EntityKind Classify(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                return EntityKind.Unknown;

            string value = name.Trim();

            if (value.StartsWith("[BOT]", StringComparison.OrdinalIgnoreCase))
                return EntityKind.Bot;

            // The current EntityLoop generates synthetic Enemy#<id> names.
            // Do not mislabel these as humans because no real name source is
            // currently proven in the runtime path.
            if (value.StartsWith("Enemy#", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(value, "Player", StringComparison.OrdinalIgnoreCase))
                return EntityKind.Unknown;

            return EntityKind.Player;
        }

        public static string GetDisplayLabel(EntityData entity)
        {
            if (entity == null)
                return "[UNKNOWN]";

            string name = (entity.Name ?? string.Empty).Trim();
            EntityKind kind = Classify(name);

            // Current BGA enumeration supplies synthetic Enemy#<id> names rather than
            // a proven display-name field. Strip that implementation detail from the
            // overlay and show the requested stable player label. Unknown/non-player
            // records use [ENEMY] without exposing internal IDs.
            if (name.StartsWith("Enemy#", StringComparison.OrdinalIgnoreCase))
                return "[PLAYER]";

            return kind switch
            {
                EntityKind.Bot => "[ENEMY]",
                EntityKind.Player => "[PLAYER]",
                _ => "[ENEMY]"
            };
        }
    }
}

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using ROS64Hack.Core;
using ROS64Hack.Engine;

namespace ROS64Hack.Features
{
    /// <summary>
    /// Aimbot — FOV-ranked target acquisition using the verified dynamic neck joint.
    ///
    /// SELECTION  — The nearest valid projected aim point to the in-game reticle is
    ///              selected inside the configured 2D FOV radius. The projected 3D box
    ///              is not used as an acquisition gate.
    ///
    /// LOCKING    — The closest eligible aim point is reevaluated on each tick; a target
    ///              change resets the filter to avoid dragging from the prior target.
    ///
    /// TARGET     — Neck mode uses the lower endpoint of the verified dynamic native
    ///              neck edge from the current sampled skeleton pose. It never silently
    ///              falls back to the old static chest proxy when that pose is unavailable.
    ///
    /// TRACKING   — Frame-rate-independent screen-space filtering plus a separate
    ///              exponential mouse response.  Small deadzone and a sub-pixel
    ///              remainder accumulator reduce 1-pixel oscillation.
    ///
    /// ACTIVATION — Hold AimbotKey (default: Shift).
    /// </summary>
    public static class Aimbot
    {
        [StructLayout(LayoutKind.Sequential)]
        private struct INPUT
        {
            public uint type;
            public MOUSEINPUT mi;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct MOUSEINPUT
        {
            public int dx, dy;
            public uint mouseData, dwFlags, time;
            public IntPtr dwExtraInfo;
        }

        [DllImport("user32.dll", SetLastError = true)]
        private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(int vKey);

        private const uint INPUT_MOUSE = 0;
        private const uint MOUSEEVENTF_MOVE = 0x0001;

        private const float FilterTauSlow = 0.060f;
        private const float FilterTauFast = 0.025f;
        private const float FilterFastThresholdPx = 8.0f;
        private const float AimDeadzonePx = 1.25f;
        private const float AimResponseRate = 16.0f;
        private const float MaxAimStepPx = 32.0f;

        private static long _lockedTargetPtr;
        private static long _lastTickTicks;
        private static bool _filterInitialized;
        private static float _filteredAimX;
        private static float _filteredAimY;
        private static float _mouseRemainderX;
        private static float _mouseRemainderY;
        private static float _prevTargetRawX;
        private static float _prevTargetRawY;

        private static long _lastTargetDiagnosticTicks;

        public static void Tick(
            List<EntityData> entities,
            in CameraData cam,
            float screenW,
            float screenH,
            int overlayOriginX,
            int overlayOriginY)
        {
            bool shiftDown = IsShiftDown();
            bool activationOn = shiftDown || IsAimbotKeyDown();

            RuntimeDiagnostics.Aimbot(
                Settings.AimbotEnabled, Settings.AimbotKey,
                activationOn, shiftDown, entities?.Count ?? 0);

            if (entities == null || (!Settings.AimbotEnabled && !shiftDown))
            {
                ResetTracking();
                return;
            }

            if (!activationOn || !cam.IsValid || screenW <= 0f || screenH <= 0f)
            {
                ResetTracking();
                return;
            }

            long now = System.Diagnostics.Stopwatch.GetTimestamp();
            long freq = System.Diagnostics.Stopwatch.Frequency;
            double dt = _lastTickTicks == 0
                ? 1.0 / 60.0
                : (now - _lastTickTicks) / (double)freq;
            _lastTickTicks = now;
            dt = Math.Clamp(dt, 1.0 / 120.0, 0.050);

            // Use the in-game reticle at the viewport center. Target acquisition is
            // scored by the live projected target point and the configured FOV radius;
            // the legacy projected 3D box is not an acquisition gate.
            float cx = screenW * 0.5f;
            float cy = screenH * 0.5f;
            EntityData target = FindBestTargetWithinFov(
                entities, cx, cy, screenW, screenH, in cam,
                out PointF targetPoint,
                out string targetPointSource,
                out int enemyCount,
                out int validAimPointCount,
                out int projectedPointCount,
                out int inFovCount,
                out float fovPixels);

            if (target == null)
            {
                LogTargetingStatus(now,
                    $"state=NO_TARGET keyDown=1 bone={Settings.TargetBone} enemies={enemyCount} " +
                    $"validAimPoints={validAimPointCount} projected={projectedPointCount} " +
                    $"withinFov={inFovCount} fovPx={fovPixels:F1}");
                ResetTracking();
                return;
            }

            if (target.Ptr != _lockedTargetPtr)
            {
                _lockedTargetPtr = target.Ptr;
                _filterInitialized = false;
                _mouseRemainderX = 0f;
                _mouseRemainderY = 0f;
            }

            if (Settings.TargetBone == AimbotBone.Neck && !IsUsableTargetPoint(targetPoint))
            {
                LogTargetingStatus(now,
                    $"state=INVALID_NECK_POINT target=0x{target.Ptr:X} " +
                    $"validAimPoints={validAimPointCount} projected={projectedPointCount} " +
                    $"withinFov={inFovCount}");
                ResetTracking();
                return;
            }

            if (!_filterInitialized)
            {
                _filteredAimX = targetPoint.X;
                _filteredAimY = targetPoint.Y;
                _prevTargetRawX = targetPoint.X;
                _prevTargetRawY = targetPoint.Y;
                _filterInitialized = true;
            }
            else
            {
                float rawDx = targetPoint.X - _prevTargetRawX;
                float rawDy = targetPoint.Y - _prevTargetRawY;
                float rawStep = MathF.Sqrt(rawDx * rawDx + rawDy * rawDy);

                float tau = rawStep >= FilterFastThresholdPx
                    ? FilterTauFast
                    : FilterTauSlow;
                float alpha = 1.0f - MathF.Exp(-(float)dt / tau);

                _filteredAimX += (targetPoint.X - _filteredAimX) * alpha;
                _filteredAimY += (targetPoint.Y - _filteredAimY) * alpha;

                _prevTargetRawX = targetPoint.X;
                _prevTargetRawY = targetPoint.Y;
            }

            float response = Math.Clamp(Settings.AimbotSmoothing, 0.01f, 1.0f);
            float moveAlpha = 1.0f -
                MathF.Exp(-response * AimResponseRate * (float)dt);

            float errX = _filteredAimX - cx;
            float errY = _filteredAimY - cy;

            float stepX = MathF.Abs(errX) < AimDeadzonePx ? 0f : errX * moveAlpha;
            float stepY = MathF.Abs(errY) < AimDeadzonePx ? 0f : errY * moveAlpha;

            float stepMag = MathF.Sqrt(stepX * stepX + stepY * stepY);
            if (stepMag > MaxAimStepPx)
            {
                float scale = MaxAimStepPx / stepMag;
                stepX *= scale;
                stepY *= scale;
            }

            _mouseRemainderX += stepX;
            _mouseRemainderY += stepY;

            int movX = (int)MathF.Truncate(_mouseRemainderX);
            int movY = (int)MathF.Truncate(_mouseRemainderY);

            _mouseRemainderX -= movX;
            _mouseRemainderY -= movY;

            bool inputAttempted = movX != 0 || movY != 0;
            uint sent = 0;
            int win32Error = 0;
            if (inputAttempted)
            {
                sent = MoveMouse(movX, movY);
                if (sent == 0)
                    win32Error = Marshal.GetLastWin32Error();
            }

            string inputStatus = inputAttempted
                ? $"sent={sent}/1 win32={win32Error}"
                : "not-needed";
            LogTargetingStatus(now,
                $"state=TRACKING target=0x{target.Ptr:X} bone={Settings.TargetBone} source={targetPointSource} " +
                $"point=({targetPoint.X:F1},{targetPoint.Y:F1}) error=({errX:F1},{errY:F1}) " +
                $"inputDelta=({movX},{movY}) input={inputStatus} " +
                $"enemies={enemyCount} validAimPoints={validAimPointCount} " +
                $"projected={projectedPointCount} withinFov={inFovCount} fovPx={fovPixels:F1}");
        }

        private static EntityData FindBestTargetWithinFov(
            List<EntityData> entities,
            float pointerX,
            float pointerY,
            float screenW,
            float screenH,
            in CameraData cam,
            out PointF bestPoint,
            out string bestPointSource,
            out int enemyCount,
            out int validAimPointCount,
            out int projectedPointCount,
            out int inFovCount,
            out float fovPixels)
        {
            bestPoint = PointF.Empty;
            bestPointSource = "none";
            enemyCount = 0;
            validAimPointCount = 0;
            projectedPointCount = 0;
            inFovCount = 0;

            float screenLimit = MathF.Max(1f, MathF.Max(screenW, screenH));
            fovPixels = float.IsFinite(Settings.AimbotFOV)
                ? Math.Clamp(Settings.AimbotFOV, 1f, screenLimit)
                : 150f;
            float fovSquared = fovPixels * fovPixels;
            float bestScore = float.MaxValue;
            EntityData best = null;

            foreach (EntityData e in entities)
            {
                if (e == null || !e.IsEnemy)
                    continue;

                enemyCount++;
                if (!HasAimProjection(e))
                    continue;

                validAimPointCount++;
                PointF point = ResolveTargetPoint(e, in cam, screenW, screenH, out string pointSource);
                if (!IsUsableTargetPoint(point))
                    continue;

                projectedPointCount++;
                float dx = point.X - pointerX;
                float dy = point.Y - pointerY;
                float score = dx * dx + dy * dy;
                if (score > fovSquared)
                    continue;

                inFovCount++;
                if (score < bestScore)
                {
                    bestScore = score;
                    best = e;
                    bestPoint = point;
                    bestPointSource = pointSource;
                }
            }

            return best;
        }

        private static void LogTargetingStatus(long nowTicks, string details)
        {
            long frequency = System.Diagnostics.Stopwatch.Frequency;
            if (_lastTargetDiagnosticTicks != 0 &&
                nowTicks - _lastTargetDiagnosticTicks < frequency)
                return;

            _lastTargetDiagnosticTicks = nowTicks;
            try
            {
                Console.WriteLine($"  [STAGE96][AIM] {details}");
            }
            catch
            {
                // Diagnostics must not interrupt target sampling or mouse input.
            }
        }

        private static bool HasAimProjection(EntityData e)
        {
            if (e == null)
                return false;

            return Settings.TargetBone switch
            {
                AimbotBone.Chest => HasValidLegacyPoint(e.ChestProjected, e.ChestSX, e.ChestSY),
                // Dynamic neck data is preferred, but absence of a dynamic skeleton must
                // not disable the legacy aimbot path. Use the older projected neck proxy,
                // then the chest proxy if the neck projection is unavailable.
                AimbotBone.Neck => HasDynamicNeckAimPoint(e) ||
                                   HasValidLegacyPoint(e.NeckProjected, e.NeckSX, e.NeckSY) ||
                                   HasValidLegacyPoint(e.ChestProjected, e.ChestSX, e.ChestSY),
                AimbotBone.Body => e.FootProjected && e.HeadProjected,
                _ => e.HeadProjected,
            };
        }

        private static bool HasDynamicNeckAimPoint(EntityData e)
        {
            // Head-circle geometry is a rendering detail, not a requirement for aiming.
            // The validated neck segment and its live world-space joint are sufficient.
            return e != null &&
                   e.DynamicNeckSegmentValid &&
                   e.DynamicNeckWorldValid &&
                   float.IsFinite(e.DynamicNeckWorldX) &&
                   float.IsFinite(e.DynamicNeckWorldY) &&
                   float.IsFinite(e.DynamicNeckWorldZ);
        }

        private static bool HasValidLegacyPoint(bool projected, float x, float y) =>
            projected && IsUsableTargetPoint(new PointF(x, y));

        private static PointF ResolveTargetPoint(
            EntityData e, in CameraData cam, float screenW, float screenH, out string source)
        {
            source = "unavailable";

            if (Settings.TargetBone == AimbotBone.Neck)
            {
                // First choice: project the validated native neck joint from world space
                // against this tick's camera snapshot.
                if (HasDynamicNeckAimPoint(e))
                {
                    if (WorldToScreen.Project(
                            e.DynamicNeckWorldX, e.DynamicNeckWorldY, e.DynamicNeckWorldZ,
                            in cam, screenW, screenH, out float sx, out float sy, e.Ptr) &&
                        float.IsFinite(sx) && float.IsFinite(sy) && !(sx == 0f && sy == 0f))
                    {
                        source = "dynamic-neck-world";
                        return new PointF(sx, sy);
                    }

                    // A present dynamic joint that cannot be projected is not replaced
                    // by a different estimated point; it may be behind the current camera.
                    source = "dynamic-neck-unprojectable";
                    return PointF.Empty;
                }

                // Compatibility fallback: preserve the original screen-space target logic
                // when this enemy has no usable dynamic skeleton/neck sample.
                if (HasValidLegacyPoint(e.NeckProjected, e.NeckSX, e.NeckSY))
                {
                    source = "legacy-neck-proxy";
                    return new PointF(e.NeckSX, e.NeckSY);
                }

                // Some snapshots do not have a usable neck proxy either. Preserve the old
                // chest target as the final fallback so missing skeleton data cannot disable
                // the aimbot entirely.
                if (HasValidLegacyPoint(e.ChestProjected, e.ChestSX, e.ChestSY))
                {
                    source = "legacy-chest-proxy";
                    return new PointF(e.ChestSX, e.ChestSY);
                }

                return PointF.Empty;
            }

            PointF point = Settings.TargetBone switch
            {
                AimbotBone.Chest => new PointF(e.ChestSX, e.ChestSY),
                AimbotBone.Body => new PointF(e.FootSX, (e.FootSY + e.HeadSY) * 0.5f),
                _ => new PointF(e.HeadSX, e.HeadSY),
            };
            source = "configured-legacy-point";
            return point;
        }

        private static bool IsUsableTargetPoint(PointF p) =>
            float.IsFinite(p.X) && float.IsFinite(p.Y) && !(p.X == 0f && p.Y == 0f);

        private static void ResetTracking()
        {
            _lockedTargetPtr = 0;
            _lastTickTicks = 0;
            _filterInitialized = false;
            _filteredAimX = 0f;
            _filteredAimY = 0f;
            _mouseRemainderX = 0f;
            _mouseRemainderY = 0f;
            _prevTargetRawX = 0f;
            _prevTargetRawY = 0f;
        }

        private static uint MoveMouse(int dx, int dy)
        {
            var inp = new INPUT
            {
                type = INPUT_MOUSE,
                mi = new MOUSEINPUT
                {
                    dx = dx,
                    dy = dy,
                    dwFlags = MOUSEEVENTF_MOVE
                }
            };
            return SendInput(1, new[] { inp }, Marshal.SizeOf<INPUT>());
        }

        public static bool IsActivationDown() =>
            IsShiftDown() || IsAimbotKeyDown();

        private static bool IsAimbotKeyDown() => IsKeyDown(Settings.AimbotKey);

        private static bool IsShiftDown() =>
            IsKeyDown(Keys.ShiftKey) ||
            IsKeyDown(Keys.LShiftKey) ||
            IsKeyDown(Keys.RShiftKey);

        private static bool IsKeyDown(Keys k) =>
            (GetAsyncKeyState((int)k) & 0x8000) != 0;
    }
}

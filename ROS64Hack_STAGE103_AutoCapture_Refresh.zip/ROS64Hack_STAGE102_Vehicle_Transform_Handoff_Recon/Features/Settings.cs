namespace ROS64Hack.Features
{
    /// <summary>
    /// Global feature settings. Shared between overlay, menu, and feature classes.
    /// All fields are plain statics — no lock needed (read/write are atomic on x64 for bool/int/float).
    /// </summary>
    public static class Settings
    {
        // ── VISUAL tab ────────────────────────────────────────────────────────

        /// <summary>Show enemy player ESP (boxes + info).</summary>
        public static bool EspPlayer     = true;

        /// <summary>Draw top-centre tracer lines to enemies. Disabled by default to avoid rays obscuring the skeleton.</summary>
        public static bool EspLines      = false;

        /// <summary>Display distance (metres) under enemy label.</summary>
        public static bool EspDistance   = true;

        /// <summary>Draw 3D perspective bounding box around each enemy.</summary>
        public static bool Esp3DBox      = true;

        /// <summary>Draw the dynamically verified target-local skeleton when articulation evidence is available.</summary>
        public static bool EspSkeleton   = true;

        /// <summary>Show items on the ground (loot ESP).</summary>
        public static bool EspItem       = true;
        public static bool EspItemDist   = true;
        public static bool EspGoldItem   = false;

        /// <summary>Show vehicles.</summary>
        public static bool EspVehicle    = true;
        public static bool EspVehicleDist = true;

        /// <summary>Show supply box (airdrop) location.</summary>
        public static bool EspSupplyBox  = true;

        /// <summary>Show plane path.</summary>
        public static bool EspPlane      = false;

        // ── AIMBOT tab ────────────────────────────────────────────────────────

        /// <summary>Aimbot enabled. Hold AimbotKey to activate.</summary>
        public static bool AimbotEnabled     = false;

        /// <summary>Activation key. Default = Shift. NOTE: Shift is also weapon-swap in-game.</summary>
        public static System.Windows.Forms.Keys AimbotKey = System.Windows.Forms.Keys.ShiftKey;

        /// <summary>
        /// Response rate 0.01–1.0.
        /// 1.0 = aggressive snap. Lower = smoother/slower. Current default is tuned for reduced jitter.
        /// </summary>
        public static float AimbotSmoothing  = 0.70f;

        /// <summary>FOV radius in pixels. Enemies whose target point is outside this radius are ignored.</summary>
        public static float AimbotFOV        = 150f;

        /// <summary>Draw FOV reticle on overlay.</summary>
        public static bool ShowAimbotFOV     = true;

        /// <summary>Radius of the crosshair ring in pixels.</summary>
        public static float AimbotCursorRadius = 13f;

        /// <summary>
        /// Default targeting point. NECK requires a verified dynamic skeleton pose and targets
        /// the projected lower endpoint of the native neck edge. No static chest fallback is used.
        /// </summary>
        public static AimbotBone TargetBone  = AimbotBone.Neck;

        // ── NOCLIP tab ────────────────────────────────────────────────────────

        /// <summary>NoClip mode — writes XYZ directly to player entity in memory.</summary>
        public static bool NoClipEnabled     = false;

        /// <summary>NoClip movement speed (metres per tick).</summary>
        public static float NoClipSpeed      = 2.0f;

        /// <summary>NoClip height offset (metres).</summary>
        public static float NoClipHeight     = 0f;

        // ── MISC tab ──────────────────────────────────────────────────────────

        /// <summary>Maximum ESP draw range in metres. Enemies beyond this are skipped.</summary>
        public static float MaxESPRange      = 100000f;

        /// <summary>Draw debug overlay (range, aimbot state, FPS, camera).</summary>
        public static bool ShowDebugInfo     = true;

        /// <summary>Toggle key for showing/hiding the menu form.</summary>
        public static System.Windows.Forms.Keys MenuKey = System.Windows.Forms.Keys.Insert;

        // ── Internal constants ────────────────────────────────────────────────

        /// <summary>Camera VFOV in degrees (used for debug display only).</summary>
        public const float VFOV_DEGREES = 90f;

        /// <summary>Head height in BigWorld units above entity root.</summary>
        public const float EntityHeadHeight = 21.5f;

        /// <summary>Neck height in BigWorld units above entity root.</summary>
        public const float EntityNeckHeight = 17.63f;

        /// <summary>Temporary upper-torso/chest proxy in BigWorld units above entity root.</summary>
        public const float EntityChestHeight = 14.0f;
    }

    public enum AimbotBone { Chest, Neck, Head, Body }
}

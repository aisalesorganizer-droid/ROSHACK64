using System;
using System.Collections.Generic;
using System.Drawing;
using ROS64Hack.Core;
using ROS64Hack.Engine;

namespace ROS64Hack.Features
{
    public static class ESP
    {
        // ── Pens / Brushes / Fonts ─────────────────────────────────────────────
        //   Box  = RED 2px
        //   Line = GREEN 1px
        //   Skeleton = BLUE 2px
        //   Cursor = YELLOW 1.8px

        private static readonly Pen PenBox       = new Pen(Color.Red,  2f);
        private static readonly Pen PenLine      = new Pen(Color.Green, 1f);
        private static readonly Pen PenSkeleton  = new Pen(Color.Blue, 2f)
            { StartCap = System.Drawing.Drawing2D.LineCap.Round, EndCap = System.Drawing.Drawing2D.LineCap.Round,
              LineJoin = System.Drawing.Drawing2D.LineJoin.Round };
        private static readonly Pen PenCursor    = new Pen(Color.Yellow, 1.8f);
        private static readonly bool BoneIndexDiagnosticsEnabled = string.Equals(
            Environment.GetEnvironmentVariable("ROS64HACK_SKELETON_BONE_INDEX_DIAGNOSTICS"),
            "1",
            StringComparison.Ordinal);
        private static readonly Brush BrushBoneIndex = BoneIndexDiagnosticsEnabled
            ? new SolidBrush(Color.Cyan)
            : null;
        private static readonly Font FontBoneIndex = BoneIndexDiagnosticsEnabled
            ? new Font("Consolas", 7f, FontStyle.Bold)
            : null;
        private static readonly Brush BrushName   = new SolidBrush(Color.Red);
        private static readonly Brush BrushDist   = new SolidBrush(Color.Yellow);
        private static readonly Brush BrushShadow = new SolidBrush(Color.FromArgb(160, Color.Black));
        private static readonly Brush BrushDot    = new SolidBrush(Color.Yellow);
        private static readonly Brush BrushDebug  = new SolidBrush(Color.Yellow);

        private static readonly Font FontLabel  = new Font("Arial",    3.5f,  FontStyle.Bold);
        private static readonly Font FontSmall  = new Font("Arial",    8f,  FontStyle.Regular);
        private static readonly Font FontDebug  = new Font("Consolas", 8f);

        private static readonly StringFormat SFCenter = new StringFormat
            { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Far };

        // ── Main draw entry ───────────────────────────────────────────────────

        /// <summary>
        /// Computes all base entity projections once on the read thread. Paint, aimbot,
        /// and skeleton drawing consume these stored values instead of recomputing W2S.
        /// </summary>
        public static void UpdateProjection(
            List<EntityData> entities,
            in CameraData cam,
            float screenW, float screenH)
        {
            if (!cam.IsValid)
                return;

            foreach (var e in entities)
            {
                if (e == null || e.IsLocalPlayer || !e.IsEnemy)
                    continue;

                e.Distance = WorldToScreen.Distance(e.X, e.Y, e.Z, cam);
                bool rejected = !float.IsFinite(e.Distance) || e.Distance > Settings.MaxESPRange;
                RuntimeDiagnostics.EspRangeSample(
                    e.Ptr, e.X, e.Y, e.Z, cam, e.Distance, Settings.MaxESPRange, rejected);

                if (rejected)
                {
                    e.OnScreen = false;
                    e.FootProjected = false;
                    e.HeadProjected = false;
                    e.NeckProjected = false;
                    e.ChestProjected = false;
                    e.DynamicSkeletonSegmentCount = 0;
                    e.DynamicSkeletonValid = false;
                    RuntimeDiagnostics.EspRangeRejected();
                    continue;
                }

                bool feetOk = WorldToScreen.Project(
                    e.X, e.Y, e.Z,
                    cam, screenW, screenH,
                    out float fx, out float fy, e.Ptr);

                bool headOk = WorldToScreen.Project(
                    e.X, e.Y + Settings.EntityHeadHeight, e.Z,
                    cam, screenW, screenH,
                    out float hx, out float hy, e.Ptr);

                bool neckOk = WorldToScreen.Project(
                    e.X, e.Y + Settings.EntityNeckHeight, e.Z,
                    cam, screenW, screenH,
                    out float nx, out float ny, e.Ptr);

                bool chestOk = WorldToScreen.Project(
                    e.X, e.Y + Settings.EntityChestHeight, e.Z,
                    cam, screenW, screenH,
                    out float csx, out float csy, e.Ptr);

                e.FootSX = fx;
                e.FootSY = fy;
                e.HeadSX = hx;
                e.HeadSY = hy;
                e.NeckSX = nx;
                e.NeckSY = ny;
                e.ChestSX = csx;
                e.ChestSY = csy;
                e.FootProjected = feetOk;
                e.HeadProjected = headOk;
                e.NeckProjected = neckOk;
                e.ChestProjected = chestOk;
                e.OnScreen = feetOk || headOk || neckOk || chestOk;

                // Keep the box on the exact same entity/camera snapshot as the
                // labels, tracer endpoint, and aim projections. A separate velocity
                // lead made the box disagree with those features during acceleration,
                // direction changes, and irregular read intervals.
                e.BoxFootSX = fx;
                e.BoxFootSY = fy;
                e.BoxHeadSX = hx;
                e.BoxHeadSY = hy;
                e.BoxProjected = feetOk && headOk;
            }
        }

        public static void Draw(
            Graphics g,
            List<EntityData> entities,
            in CameraData cam,
            float screenW, float screenH)
        {
            if (!cam.IsValid)
            {
                RuntimeDiagnostics.EspCameraRejected();
                return;
            }

            float cx = screenW * 0.5f;

            // Paint consumes the projections from the same read snapshot. There is no
            // memory read and no duplicate W2S work here.
            if (Settings.EspLines)
            {
                foreach (var e in entities)
                {
                    if (!TryGetSafeTracerEndpoint(e, screenW, screenH, out float tx, out float ty))
                        continue;

                    // Use the current projected endpoint from the same entity/camera snapshot
                    // as the box. No separate box-only prediction is applied.
                    g.DrawLine(PenLine, cx, 0f, tx, ty);
                }
            }

            // Feature toggles are independent. PLAYER ESP controls labels only; it must not
            // suppress boxes, distance labels, skeleton segments, or the head indicator.
            foreach (var e in entities)
            {
                if (e?.IsEnemy != true || !e.OnScreen)
                    continue;

                try
                {
                    DrawEntity(g, e, screenW, screenH);
                }
                catch (Exception ex)
                {
                    // A malformed entity must not abort the paint pass for later actors.
                    int errorNumber = System.Threading.Interlocked.Increment(ref _entityRenderErrorCount);
                    if (errorNumber <= 16)
                    {
                        Console.WriteLine(
                            $"[ESP][ENTITY-DRAW-EXCEPTION] entity=0x{e.Ptr:X} id=0x{e.EntityId:X8} " +
                            $"error={ex.GetType().Name}: {ex.Message}");
                    }
                }
            }

            if (Settings.ShowAimbotFOV && Settings.AimbotEnabled)
                DrawAimCursor(g, screenW * 0.5f, screenH * 0.5f);

            if (Settings.ShowDebugInfo)
                DrawDebugInfo(g, cam, entities);
        }

        private static bool TryGetSafeTracerEndpoint(
            EntityData e, float screenW, float screenH, out float tx, out float ty)
        {
            tx = ty = 0f;

            if (e?.IsEnemy != true || !e.OnScreen ||
                !e.FootProjected || !e.HeadProjected)
                return false;

            float footX = e.FootSX;
            float footY = e.FootSY;
            float headX = e.HeadSX;
            float headY = e.HeadSY;

            if (!float.IsFinite(footX) || !float.IsFinite(footY) ||
                !float.IsFinite(headX) || !float.IsFinite(headY))
                return false;

            // Do not draw a tracer when either base body endpoint is outside the actual
            // viewport. WorldToScreen intentionally has a loose ±300px gate for clipping,
            // but that gate is not a valid tracer-visibility test.
            if (footX < 0f || footX > screenW || footY < 0f || footY > screenH ||
                headX < 0f || headX > screenW || headY < 0f || headY > screenH)
                return false;

            float bodyHeight = MathF.Abs(footY - headY);
            if (!float.IsFinite(bodyHeight) || bodyHeight < 4f || bodyHeight > screenH * 1.5f)
                return false;

            if (e.BoxProjected &&
                float.IsFinite(e.BoxHeadSX) && float.IsFinite(e.BoxHeadSY) &&
                e.BoxHeadSX >= 0f && e.BoxHeadSX <= screenW &&
                e.BoxHeadSY >= 0f && e.BoxHeadSY <= screenH)
            {
                tx = e.BoxHeadSX;
                ty = e.BoxHeadSY;
            }
            else
            {
                tx = headX;
                ty = headY;
            }

            return float.IsFinite(tx) && float.IsFinite(ty) &&
                   tx >= 0f && tx <= screenW && ty >= 0f && ty <= screenH;
        }

        // ── Per-entity draw ───────────────────────────────────────────────────

        private static int _entityRenderErrorCount;

        private static void DrawEntity(Graphics g, EntityData e, float screenW, float screenH)
        {
            bool bodyValid = TryGetProjectedBodyBounds(
                e, screenW, screenH,
                out float bx, out float boxTop,
                out float left, out float right, out float bottom, out float bodyHeight);

            if (bodyValid)
            {
                // 3D perspective box (red) — see Draw3DBox comments.
                if (Settings.Esp3DBox)
                    Draw3DBox(g, left, boxTop, right, bottom);

                // PLAYER ESP controls the name label only, not the other visual features.
                if (Settings.EspPlayer)
                {
                    string label = EntityClassifier.GetDisplayLabel(e);
                    g.DrawString(label, FontLabel, BrushShadow, bx + 2f, boxTop - 11f, SFCenter);
                    g.DrawString(label, FontLabel, BrushName, bx, boxTop - 13f, SFCenter);
                }

                if (Settings.EspDistance && float.IsFinite(e.Distance) && e.Distance >= 0f)
                {
                    string dist = $"[{e.Distance:F0}m]";
                    g.DrawString(dist, FontSmall, BrushShadow, bx + 2f, bottom + 2f, SFCenter);
                    g.DrawString(dist, FontSmall, BrushDist, bx, bottom, SFCenter);
                }
            }

            if (!Settings.EspSkeleton)
            {
                if (SkeletonCoverageTrace.IsEnabled)
                    SkeletonCoverageTrace.Record(e, "DRAW", "SKELETON_SETTING_DISABLED",
                        $"dynamicValid={(e.DynamicSkeletonValid ? 1 : 0)} segments={e.DynamicSkeletonSegmentCount}",
                        failure: true);
                return;
            }

            // Skeleton and head-marker visibility use the same entity/head-anchor gate and
            // selected foot/head coordinates as the stable box path. Numeric checks reject only
            // unusable geometry; they do not require both projection flags to be true.
            if (!bodyValid)
            {
                if (SkeletonCoverageTrace.IsEnabled)
                    SkeletonCoverageTrace.Record(e, "DRAW", "BODY_PROJECTION_UNAVAILABLE",
                        $"head={B(e.HeadProjected)} foot={B(e.FootProjected)} box={B(e.BoxProjected)} " +
                        $"onScreen={B(e.OnScreen)}", failure: true);
                return;
            }

            bool dynamicHeadAssociated = IsDynamicHeadGeometryAssociated(
                e, left, right, boxTop, bottom, bodyHeight, screenW, screenH);

            int visiblePoseSegments = 0;
            if (e.DynamicSkeletonValid && e.DynamicSkeletonSegmentCount > 0)
            {
                int drawn = DrawDynamicSkeleton(
                    g, e, dynamicHeadAssociated, screenW, screenH, out visiblePoseSegments);
                if (SkeletonCoverageTrace.IsEnabled)
                    SkeletonCoverageTrace.Record(e, "DRAW",
                        drawn > 0 ? "DRAWN" : "NO_DRAWABLE_SEGMENTS",
                        $"submitted={e.DynamicSkeletonSegmentCount} drawn={drawn} " +
                        $"visibleNativeSegments={visiblePoseSegments} " +
                        $"dynamicHeadAssociated={B(dynamicHeadAssociated)} bodyHeight={bodyHeight:F1}",
                        failure: drawn <= 0);
            }
            else if (SkeletonCoverageTrace.IsEnabled)
            {
                SkeletonCoverageTrace.Record(e, "DRAW", "SKELETON_NOT_READY",
                    $"dynamicValid={B(e.DynamicSkeletonValid)} segments={e.DynamicSkeletonSegmentCount} " +
                    $"headGeometry={B(e.DynamicHeadGeometryValid)} bodyHeight={bodyHeight:F1}", failure: true);
            }

            // The head marker is part of the native skeletal visualization. Never derive a
            // substitute circle from the entity box/head projection: doing so can display a
            // marker when this actor has no validated head geometry or no visible skeleton.
            DrawHeadIndicator(g, e, dynamicHeadAssociated, visiblePoseSegments, screenW, screenH);
        }

        private static string B(bool value) => value ? "1" : "0";

        private static bool TryGetProjectedBodyBounds(
            EntityData e,
            float screenW,
            float screenH,
            out float centerX,
            out float boxTop,
            out float left,
            out float right,
            out float bottom,
            out float bodyHeight)
        {
            centerX = boxTop = left = right = bottom = bodyHeight = 0f;
            if (e?.IsEnemy != true || !e.OnScreen || !e.HeadProjected ||
                !float.IsFinite(screenW) || !float.IsFinite(screenH) || screenW <= 0f || screenH <= 0f)
                return false;

            // Mirror the established box anchor selection exactly: prefer the coherent box
            // projection, otherwise retain the existing per-point projection fallback.
            centerX = e.BoxProjected ? e.BoxFootSX : e.FootSX;
            bottom = e.BoxProjected ? e.BoxFootSY : e.FootSY;
            float headY = e.BoxProjected ? e.BoxHeadSY : e.HeadSY;
            if (!float.IsFinite(centerX) || !float.IsFinite(bottom) || !float.IsFinite(headY))
                return false;

            bodyHeight = MathF.Abs(bottom - headY);
            if (!float.IsFinite(bodyHeight) || bodyHeight < 4f || bodyHeight > screenH * 1.5f)
                return false;

            float boxWidth = bodyHeight * 0.35f;
            left = centerX - boxWidth * 0.5f;
            right = centerX + boxWidth * 0.5f;
            boxTop = headY - 4f;
            if (!float.IsFinite(left) || !float.IsFinite(right) || !float.IsFinite(boxTop) || !float.IsFinite(bottom) ||
                right < 0f || left > screenW || bottom < 0f || boxTop > screenH)
                return false;

            return true;
        }

        private static bool IsDynamicHeadGeometryAssociated(
            EntityData e,
            float left,
            float right,
            float boxTop,
            float bot,
            float bodyHeight,
            float screenW,
            float screenH)
        {
            if (!e.DynamicHeadGeometryValid ||
                !float.IsFinite(e.DynamicHeadCenter.X) || !float.IsFinite(e.DynamicHeadCenter.Y) ||
                !float.IsFinite(e.DynamicHeadRadius) || e.DynamicHeadRadius < 2f || e.DynamicHeadRadius > 64f)
                return false;

            float x = e.DynamicHeadCenter.X;
            float y = e.DynamicHeadCenter.Y;
            float radius = e.DynamicHeadRadius;
            if (x + radius < 0f || x - radius > screenW ||
                y + radius < 0f || y - radius > screenH)
                return false;

            float horizontalTolerance = Math.Max(radius * 2.0f, bodyHeight * 0.12f);
            float verticalTolerance = Math.Max(radius * 2.0f, bodyHeight * 0.12f);
            return x >= left - horizontalTolerance && x <= right + horizontalTolerance &&
                   y >= boxTop - verticalTolerance && y <= boxTop + bodyHeight * 0.20f &&
                   y <= bot + verticalTolerance;
        }

        private const int MIN_VISIBLE_NATIVE_EDGES_FOR_HEAD_MARKER = 2;

        private static void DrawHeadIndicator(
            Graphics g,
            EntityData e,
            bool dynamicHeadAssociated,
            int visiblePoseSegments,
            float screenW,
            float screenH)
        {
            string suppressionReason = null;
            if (!dynamicHeadAssociated)
                suppressionReason = e.DynamicHeadGeometryValid
                    ? "NATIVE_HEAD_OUTSIDE_ENTITY_BODY"
                    : "NATIVE_HEAD_GEOMETRY_UNAVAILABLE";
            else if (!e.DynamicSkeletonValid || e.DynamicSkeletonSegmentCount <= 0)
                suppressionReason = "NATIVE_SKELETON_UNAVAILABLE";
            else if (visiblePoseSegments < MIN_VISIBLE_NATIVE_EDGES_FOR_HEAD_MARKER)
                suppressionReason = "INSUFFICIENT_VISIBLE_NATIVE_BODY_EDGES";

            if (suppressionReason != null)
            {
                if (SkeletonCoverageTrace.IsEnabled)
                    SkeletonCoverageTrace.Record(e, "DRAW", "HEAD_MARKER_SUPPRESSED",
                        $"reason={suppressionReason} visibleNativeSegments={visiblePoseSegments} " +
                        $"dynamicHeadGeometry={B(e.DynamicHeadGeometryValid)} " +
                        $"dynamicSkeleton={B(e.DynamicSkeletonValid)} segments={e.DynamicSkeletonSegmentCount}",
                        failure: true);
                return;
            }

            // Only use the head cluster measured from this entity's current native pose.
            // There is deliberately no box/head-projection fallback here.
            float centerX = e.DynamicHeadCenter.X;
            float centerY = e.DynamicHeadCenter.Y;
            float radius = e.DynamicHeadRadius;
            if (!float.IsFinite(centerX) || !float.IsFinite(centerY) ||
                !float.IsFinite(radius) || radius < 2f || radius > 64f ||
                centerX + radius < 0f || centerX - radius > screenW ||
                centerY + radius < 0f || centerY - radius > screenH)
            {
                if (SkeletonCoverageTrace.IsEnabled)
                    SkeletonCoverageTrace.Record(e, "DRAW", "HEAD_MARKER_SUPPRESSED",
                        $"reason=NATIVE_HEAD_GEOMETRY_INVALID center=({centerX:F1},{centerY:F1}) " +
                        $"radius={radius:F1} visibleNativeSegments={visiblePoseSegments}",
                        failure: true);
                return;
            }

            try
            {
                g.DrawEllipse(PenSkeleton, centerX - radius, centerY - radius, radius * 2f, radius * 2f);
            }
            catch (Exception ex)
            {
                int errorNumber = System.Threading.Interlocked.Increment(ref _entityRenderErrorCount);
                if (errorNumber <= 16)
                    Console.WriteLine($"[ESP][HEAD-MARKER-EXCEPTION] entity=0x{e.Ptr:X} " +
                                      $"id=0x{e.EntityId:X8} error={ex.GetType().Name}: {ex.Message}");
                return;
            }

            if (BoneIndexDiagnosticsEnabled && e.DynamicBoneDiagnosticTarget)
            {
                if (e.DynamicHeadTipBoneIndex >= 0)
                    DrawBoneDiagnosticLabel(g, $"H{e.DynamicHeadTipBoneIndex}", centerX, centerY - radius - 9f);
                if (e.DynamicHeadEntryBoneIndex >= 0)
                    DrawBoneDiagnosticLabel(g, $"E{e.DynamicHeadEntryBoneIndex}", centerX + 2f, centerY + 1f);
                if (e.DynamicNeckBaseBoneIndex >= 0 && e.DynamicNeckSegmentValid)
                    DrawBoneDiagnosticLabel(g, $"N{e.DynamicNeckBaseBoneIndex}", e.DynamicNeckStart.X + 2f, e.DynamicNeckStart.Y + 1f);
            }

            if (SkeletonCoverageTrace.IsEnabled)
                SkeletonCoverageTrace.Record(e, "DRAW", "HEAD_MARKER_DRAWN",
                    $"source=native_pose center=({centerX:F1},{centerY:F1}) radius={radius:F1} " +
                    $"visibleNativeSegments={visiblePoseSegments} " +
                    $"headTipBone={e.DynamicHeadTipBoneIndex} headEntryBone={e.DynamicHeadEntryBoneIndex}");
        }

        // ── 3D perspective box ────────────────────────────────────────────────
        //
        //  Draws a front-face 2D rectangle plus 5 depth edges, creating an
        //  isometric "3D box" identical to the reference Image 1.
        //
        //  Depth direction: upper-right   (ddx = +depth, ddy = -depth*0.5)
        //  Depth magnitude: 10 % of box height
        //
        //  Visible back edges: top-back horizontal + right-back vertical.
        //  Bottom-left depth line is omitted (naturally hidden in this projection).

        private static void Draw3DBox(Graphics g, float left, float top, float right, float bot)
        {
            float h    = bot - top;
            float d    = h * 0.10f;     // depth magnitude
            float ddx  =  d;            // x offset per depth step (→ right)
            float ddy  = -d * 0.50f;    // y offset per depth step (→ slightly up)

            // Front face
            g.DrawRectangle(PenBox, left, top, right - left, h);

            // Three visible depth lines from front corners
            g.DrawLine(PenBox, left,  top, left  + ddx, top + ddy);   // top-left
            g.DrawLine(PenBox, right, top, right + ddx, top + ddy);   // top-right
            g.DrawLine(PenBox, right, bot, right + ddx, bot + ddy);   // bottom-right

            // Back face: only top edge and right edge are visible
            g.DrawLine(PenBox, left  + ddx, top + ddy, right + ddx, top + ddy);   // top-back
            g.DrawLine(PenBox, right + ddx, top + ddy, right + ddx, bot + ddy);   // right-back
        }

        // ── Dynamic Moo::Node skeleton ─────────────────────────────────────────

        private static int DrawDynamicSkeleton(
            Graphics g,
            EntityData e,
            bool drawDynamicNeck,
            float screenW,
            float screenH,
            out int visiblePoseSegments)
        {
            visiblePoseSegments = 0;
            if (e?.DynamicSkeletonSegments == null || e.DynamicSkeletonSegmentCount <= 0)
                return 0;

            // Clamp corrupted/stale counts to the fixed segment buffer. Each native edge is
            // independently checked and drawn; a bad edge does not erase its valid siblings.
            int requestedCount = e.DynamicSkeletonSegmentCount;
            int segmentCount = Math.Clamp(requestedCount, 0, e.DynamicSkeletonSegments.Length);
            if (requestedCount != segmentCount)
            {
                int errorNumber = System.Threading.Interlocked.Increment(ref _entityRenderErrorCount);
                if (errorNumber <= 16)
                    Console.WriteLine($"[ESP][SEGMENT-COUNT-CLAMP] entity=0x{e.Ptr:X} id=0x{e.EntityId:X8} " +
                                      $"requested={requestedCount} available={e.DynamicSkeletonSegments.Length}");
            }

            int drawn = 0;
            bool rootLabelDrawn = false;
            bool drawBoneLabels = BoneIndexDiagnosticsEnabled && e.DynamicBoneDiagnosticTarget;
            for (int i = 0; i < segmentCount; i++)
            {
                SkeletonSegment segment = e.DynamicSkeletonSegments[i];
                if (!float.IsFinite(segment.Parent.X) || !float.IsFinite(segment.Parent.Y) ||
                    !float.IsFinite(segment.Child.X) || !float.IsFinite(segment.Child.Y))
                    continue;

                // Project() already limits screen coordinates to its finite clipping range. This
                // additional magnitude bound prevents extreme finite values reaching GDI+.
                if (MathF.Abs(segment.Parent.X) > screenCoordinateLimit ||
                    MathF.Abs(segment.Parent.Y) > screenCoordinateLimit ||
                    MathF.Abs(segment.Child.X) > screenCoordinateLimit ||
                    MathF.Abs(segment.Child.Y) > screenCoordinateLimit)
                    continue;

                try
                {
                    g.DrawLine(PenSkeleton, segment.Parent, segment.Child);
                    drawn++;

                    float dx = segment.Child.X - segment.Parent.X;
                    float dy = segment.Child.Y - segment.Parent.Y;
                    if (dx * dx + dy * dy > 1f &&
                        SegmentIntersectsViewport(segment.Parent, segment.Child, screenW, screenH))
                    {
                        visiblePoseSegments++;
                    }
                }
                catch (Exception ex)
                {
                    int errorNumber = System.Threading.Interlocked.Increment(ref _entityRenderErrorCount);
                    if (errorNumber <= 16)
                        Console.WriteLine($"[ESP][SEGMENT-DRAW-EXCEPTION] entity=0x{e.Ptr:X} " +
                                          $"id=0x{e.EntityId:X8} segment={i} " +
                                          $"error={ex.GetType().Name}: {ex.Message}");
                    continue;
                }

                if (drawBoneLabels)
                {
                    if (!rootLabelDrawn && segment.ParentIsHierarchyRoot && segment.ParentBoneIndex >= 0)
                    {
                        string rootLabel = segment.ParentBoneIndex.ToString();
                        g.DrawString(rootLabel, FontBoneIndex, BrushShadow,
                            segment.Parent.X + 2f, segment.Parent.Y + 2f);
                        g.DrawString(rootLabel, FontBoneIndex, BrushBoneIndex,
                            segment.Parent.X + 1f, segment.Parent.Y + 1f);
                        rootLabelDrawn = true;
                    }

                    if (segment.ChildBoneIndex >= 0)
                    {
                        string childLabel = segment.ChildBoneIndex.ToString();
                        g.DrawString(childLabel, FontBoneIndex, BrushShadow,
                            segment.Child.X + 2f, segment.Child.Y + 2f);
                        g.DrawString(childLabel, FontBoneIndex, BrushBoneIndex,
                            segment.Child.X + 1f, segment.Child.Y + 1f);
                    }
                }
            }

            // The clipped neck is part of native head geometry. Draw it only after at least
            // two native body edges have been successfully drawn through the viewport; this
            // prevents a lone neck line/circle from impersonating a complete skeleton.
            if (drawDynamicNeck &&
                visiblePoseSegments >= MIN_VISIBLE_NATIVE_EDGES_FOR_HEAD_MARKER &&
                e.DynamicNeckSegmentValid &&
                float.IsFinite(e.DynamicNeckStart.X) && float.IsFinite(e.DynamicNeckStart.Y) &&
                float.IsFinite(e.DynamicNeckEnd.X) && float.IsFinite(e.DynamicNeckEnd.Y) &&
                MathF.Abs(e.DynamicNeckStart.X) <= screenCoordinateLimit &&
                MathF.Abs(e.DynamicNeckStart.Y) <= screenCoordinateLimit &&
                MathF.Abs(e.DynamicNeckEnd.X) <= screenCoordinateLimit &&
                MathF.Abs(e.DynamicNeckEnd.Y) <= screenCoordinateLimit)
            {
                try
                {
                    g.DrawLine(PenSkeleton, e.DynamicNeckStart, e.DynamicNeckEnd);
                    drawn++;
                }
                catch (Exception ex)
                {
                    int errorNumber = System.Threading.Interlocked.Increment(ref _entityRenderErrorCount);
                    if (errorNumber <= 16)
                        Console.WriteLine($"[ESP][NECK-DRAW-EXCEPTION] entity=0x{e.Ptr:X} " +
                                          $"id=0x{e.EntityId:X8} error={ex.GetType().Name}: {ex.Message}");
                }
            }
            return drawn;
        }

        private static bool SegmentIntersectsViewport(PointF start, PointF end, float screenW, float screenH)
        {
            if (!float.IsFinite(start.X) || !float.IsFinite(start.Y) ||
                !float.IsFinite(end.X) || !float.IsFinite(end.Y) ||
                !float.IsFinite(screenW) || !float.IsFinite(screenH) ||
                screenW <= 0f || screenH <= 0f)
                return false;

            double dx = (double)end.X - start.X;
            double dy = (double)end.Y - start.Y;
            double tEnter = 0d;
            double tExit = 1d;

            return ClipViewportEdge(-dx, start.X, ref tEnter, ref tExit) &&
                   ClipViewportEdge(dx, screenW - start.X, ref tEnter, ref tExit) &&
                   ClipViewportEdge(-dy, start.Y, ref tEnter, ref tExit) &&
                   ClipViewportEdge(dy, screenH - start.Y, ref tEnter, ref tExit) &&
                   tEnter <= tExit;
        }

        private static bool ClipViewportEdge(double p, double q, ref double tEnter, ref double tExit)
        {
            if (Math.Abs(p) < 1e-12d)
                return q >= 0d;

            double ratio = q / p;
            if (p < 0d)
            {
                if (ratio > tExit)
                    return false;
                if (ratio > tEnter)
                    tEnter = ratio;
            }
            else
            {
                if (ratio < tEnter)
                    return false;
                if (ratio < tExit)
                    tExit = ratio;
            }

            return true;
        }

        private const float screenCoordinateLimit = 100000f;

        private static void DrawBoneDiagnosticLabel(Graphics g, string label, float x, float y)
        {
            g.DrawString(label, FontBoneIndex, BrushShadow, x + 1f, y + 1f);
            g.DrawString(label, FontBoneIndex, BrushBoneIndex, x, y);
        }

        // ── Aimbot reticle ────────────────────────────────────────────────────
        //
        //  Matches reference Image 2 precisely:
        //   ┌─────────────────────────────────────────────────────┐
        //   │  •  Outer ring  (radius = AimbotCursorRadius)       │
        //   │  •  Gap between ring edge and arm start             │
        //   │  •  Arms extend OUTWARD from ring (never inside)    │
        //   │  •  Bottom arm is shorter (classic mil-spec reticle)│
        //   │  •  Filled centre dot                               │
        //   └─────────────────────────────────────────────────────┘
        //
        //  Geometry (all from ring edge outward):
        //    Left : cx − r − gap − arm  →  cx − r − gap
        //    Right: cx + r + gap        →  cx + r + gap + arm
        //    Top  : cy − r − gap − arm  →  cy − r − gap
        //    Bot  : cy + r + gap        →  cy + r + gap + arm*0.65

        private static void DrawAimCursor(Graphics g, float cx, float cy)
        {
            float r   = Math.Clamp(Settings.AimbotCursorRadius, 8f, 22f);
            const float gap = 4.0f;    // space between ring edge and arm start
            float arm = r * 0.75f;    // arm length
            const float dot = 2.5f;   // centre dot radius

            // Outer ring
            g.DrawEllipse(PenCursor, cx - r, cy - r, r * 2f, r * 2f);

            // Left arm  (entirely left of ring)
            g.DrawLine(PenCursor,
                cx - r - gap - arm, cy,
                cx - r - gap,       cy);

            // Right arm
            g.DrawLine(PenCursor,
                cx + r + gap,       cy,
                cx + r + gap + arm, cy);

            // Top arm
            g.DrawLine(PenCursor,
                cx, cy - r - gap - arm,
                cx, cy - r - gap);

            // Bottom arm — shorter, classic look
            g.DrawLine(PenCursor,
                cx, cy + r + gap,
                cx, cy + r + gap + arm * 0.60f);

            // Filled centre dot
            g.FillEllipse(BrushDot, cx - dot, cy - dot, dot * 2f, dot * 2f);
        }

        // ── Debug overlay ─────────────────────────────────────────────────────

        private static int  _frameCount;
        private static long _lastFpsTick = System.Diagnostics.Stopwatch.GetTimestamp();
        private static int  _fps;

        private static void DrawDebugInfo(
            Graphics g, in CameraData cam, List<EntityData> entities)
        {
            _frameCount++;
            long now  = System.Diagnostics.Stopwatch.GetTimestamp();
            long freq = System.Diagnostics.Stopwatch.Frequency;
            if (now - _lastFpsTick >= freq)
            {
                _fps        = _frameCount;
                _frameCount = 0;
                _lastFpsTick = now;
            }

            int visible = 0;
            foreach (var e in entities) if (e?.IsEnemy == true && e.OnScreen) visible++;

            var lines = new[]
            {
                $"FPS:     {_fps}",
                $"Visible: {visible}  Total: {entities.Count}",
                $"CAM:     {(cam.IsValid ? "OK" : "SEARCHING...")}",
                cam.IsValid
                    ? $"POS:     {cam.PosX:F0} {cam.PosY:F0} {cam.PosZ:F0}"
                    : "POS:     --",
                cam.IsValid
                    ? $"FOC:     {cam.YFocal:F3} / {cam.XFocal:F3}"
                    : "FOC:     --",
                $"AIMBOT:  {(Aimbot.IsActivationDown() ? "ACTIVE" : (Settings.AimbotEnabled ? "READY" : "OFF"))}",
                $"TARGET:  {Settings.TargetBone}",
                $"FOV:     {Settings.AimbotFOV:F0} px",
                $"SMOOTH:  {Settings.AimbotSmoothing:F2}",
                $"NOCLIP:  {(Settings.NoClipEnabled ? "ON" : "OFF")}",
                $"RANGE:   {Settings.MaxESPRange:F0} m",
            };

            float y = 8f;
            foreach (var line in lines)
            {
                g.DrawString(line, FontDebug, BrushShadow, 9f, y + 1f);
                g.DrawString(line, FontDebug, BrushDebug,  8f, y);
                y += 14f;
            }
        }
    }
}

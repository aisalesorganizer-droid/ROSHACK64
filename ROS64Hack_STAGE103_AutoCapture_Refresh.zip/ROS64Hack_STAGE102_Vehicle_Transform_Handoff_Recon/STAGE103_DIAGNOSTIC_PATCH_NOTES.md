# Stage 103 — Automatic vehicle telemetry capture

Based on source package commit `897b2588e37f08f2d278a0627f4f9a6786c7af2f`. The diagnostic no longer requires a hand-picked entity ID or a manually edited vehicle marker. Use the same Stage 102 launch process. The diagnostic still uses the existing `ROS64HACK_VEHICLE_RECON=1` switch if your build has not already enabled it.

## Automatic capture
Every approximately 250 ms, it records each valid visible enemy from the normal entity snapshot: entity ID, runtime pointer, XYZ, measured interval, movement state, stationary run and episode counters, movement transitions, total sampled movement, and large jumps. It records disappearance/reappearance and runtime pointer changes. A final roster summary ranks entities that exhibited stationary runs or large jumps.

Bulk entity telemetry goes directly to the diagnostic file with batched flushes to reduce console overhead. Existing bounded transform probing continues for the automatically selected target. If transform discovery fails, all-enemy position tracing continues and the summary explicitly reports transform association as unavailable.

## Run
Run the executable as you did for Stage 102, reproduce the vehicle entry/travel/exit behavior, and send `STAGE102_VEHICLE_TRANSITION_RECON.txt`. No target ID or marker file needs to be configured.

## Limits
The roster comes from the normal entity snapshot and is not an independent native transform. Automatic vehicle occupancy remains unknown because no validated occupancy field was established. Candidate transforms remain evidence-only. This package improves diagnostics; it does not claim an authoritative occupant transform has been proven.

## Validation
- Required source token and no-manual-input checks: PASS.
- All ZIP payloads, uncompressed sizes, and CRCs: verified during packaging.
- .NET compilation and live-session behavior: not run in this environment.

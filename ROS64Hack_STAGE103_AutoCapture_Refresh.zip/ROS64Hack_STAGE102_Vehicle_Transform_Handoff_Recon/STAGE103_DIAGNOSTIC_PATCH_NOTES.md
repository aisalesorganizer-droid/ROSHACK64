# Stage 103 — Automatic vehicle telemetry capture

Based on source package commit `f70479db119690609d6052dfad112ecb97571873`. No hand-picked entity ID or manually edited vehicle marker is required. Run the same Stage 102 launch process with the existing `ROS64HACK_VEHICLE_RECON=1` enable switch.

## Automatic capture
Every approximately 250 ms, the diagnostic records every valid visible enemy from the normal entity snapshot: entity ID, runtime pointer, XYZ, measured interval, movement state, stationary run/episode counters, movement transitions, total movement, and large jumps. It also records disappearance/reappearance and pointer changes. The final roster summary lists entities with stationary episodes or large jumps.

The diagnostic keeps recording the roster for the full 120-second window even if the transform-target sample window finishes earlier. Bulk traces are written to the diagnostic file with batched flushing. Bounded transform probes continue for the automatically selected target. If transform discovery fails, all-enemy tracing continues and the final verdict marks transform association unavailable.

## Run
Launch exactly as for Stage 102, reproduce the vehicle entry/travel/exit behavior, then send `STAGE102_VEHICLE_TRANSITION_RECON.txt`. No target ID or marker file must be set.

## Limits
The roster comes from the normal entity snapshot and is not an independent native transform. Automatic vehicle occupancy remains unknown because no validated occupancy field was established. Candidate transforms remain evidence-only. This is diagnostic instrumentation, not a claimed occupant-transform fix.

## Validation status
- No manual target-ID or marker-file inputs remain in source.
- ZIP payload sizes and CRCs validated during packaging.
- .NET build and live-session behavior not run in this environment.

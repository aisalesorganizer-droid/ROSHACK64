using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

namespace ROS64Hack.Core
{
    /// <summary>
    /// 64-bit external memory reader. All addresses are absolute VAs.
    /// Use BaseAddress to compute image-relative addresses: BaseAddress + OFFSET.
    /// </summary>
    public class Mem : IDisposable
    {
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, int dwProcessId);

        [DllImport("kernel32.dll")]
        private static extern bool CloseHandle(IntPtr hObject);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool ReadProcessMemory(
            IntPtr hProcess, IntPtr lpBaseAddress,
            byte[] lpBuffer, int nSize, out int lpBytesRead);

        [DllImport("kernel32.dll", EntryPoint = "ReadProcessMemory", SetLastError = true)]
        private static extern bool ReadProcessMemoryDirect(
            IntPtr hProcess, IntPtr lpBaseAddress,
            IntPtr lpBuffer, int nSize, out IntPtr lpBytesRead);

        [DllImport("kernel32.dll")]
        private static extern bool WriteProcessMemory(
            IntPtr hProcess, IntPtr lpBaseAddress,
            byte[] lpBuffer, int nSize, out int lpBytesWritten);

        private const uint PROCESS_VM_READ      = 0x0010;
        private const uint PROCESS_VM_WRITE     = 0x0020;
        private const uint PROCESS_VM_OPERATION = 0x0008;
        private const uint PROCESS_QUERY_INFO   = 0x0400;

        private IntPtr _handle = IntPtr.Zero;
        public IntPtr Handle => _handle;
        public long BaseAddress { get; private set; }
        public long ModuleSize { get; private set; }
        public bool IsAttached => _handle != IntPtr.Zero;

        /// <summary>
        /// True when an address lies inside the main executable image. Graph resolver
        /// candidates are heap/runtime objects; executable-image addresses are commonly
        /// vtables, code, or static data and must not be blindly queued as child objects.
        /// </summary>
        public bool IsMainModuleAddress(long address) =>
            BaseAddress > 0 && ModuleSize > 0 &&
            address >= BaseAddress && address - BaseAddress < ModuleSize;

        /// <summary>Most recent attach result, including why a retry failed.</summary>
        public string LastAttachStatus { get; private set; } = "NOT_ATTEMPTED";
        public int LastAttachPid { get; private set; }
        public int LastAttachWin32Error { get; private set; }

        private int _attachCheckCount;
        private string _lastSimilarProcessSummary = "<not-enumerated-yet>";

        public bool Attach(string processName)
        {
            _attachCheckCount++;
            LastAttachPid = 0;
            LastAttachWin32Error = 0;

            if (string.IsNullOrWhiteSpace(processName))
            {
                LastAttachStatus = "INVALID_PROCESS_NAME";
                return false;
            }

            Process[] procs;
            try
            {
                procs = Process.GetProcessesByName(processName);
            }
            catch (Exception ex)
            {
                LastAttachStatus = $"PROCESS_ENUMERATION_FAILED type={ex.GetType().Name} message={ex.Message}";
                return false;
            }

            if (procs.Length == 0)
            {
                // Refresh the broader candidate list only once every five retries;
                // exact-name lookup still runs every second so attachment remains responsive.
                if (_attachCheckCount == 1 || _attachCheckCount % 5 == 0)
                    _lastSimilarProcessSummary = DescribeSimilarProcesses();
                LastAttachStatus = $"PROCESS_NOT_FOUND target='{processName}.exe' exactMatches=0 similarProcesses={_lastSimilarProcessSummary}";
                return false;
            }

            string lastFailure = "PROCESS_FOUND_BUT_ATTACH_FAILED";
            foreach (Process proc in procs)
            {
                try
                {
                    int pid = proc.Id;
                    LastAttachPid = pid;

                    IntPtr handle = OpenProcess(
                        PROCESS_VM_READ | PROCESS_VM_WRITE |
                        PROCESS_VM_OPERATION | PROCESS_QUERY_INFO,
                        false, pid);

                    if (handle == IntPtr.Zero)
                    {
                        int error = Marshal.GetLastWin32Error();
                        LastAttachWin32Error = error;
                        lastFailure = $"OPEN_PROCESS_FAILED pid={pid} win32={error} message='{new Win32Exception(error).Message}'";
                        continue;
                    }

                    try
                    {
                        // Prefer the exact main-module name, preserving existing base resolution.
                        ProcessModuleCollection modules = proc.Modules;
                        foreach (ProcessModule mod in modules)
                        {
                            string name = mod.ModuleName.ToLowerInvariant();
                            if (name == processName.ToLowerInvariant() + ".exe" ||
                                name == processName.ToLowerInvariant())
                            {
                                _handle = handle;
                                BaseAddress = (long)mod.BaseAddress;
                                ModuleSize = Math.Max(0, mod.ModuleMemorySize);
                                LastAttachStatus = $"ATTACHED pid={pid} module={mod.ModuleName} base=0x{BaseAddress:X} size=0x{ModuleSize:X}";
                                return true;
                            }
                        }

                        // Preserve the pre-existing fallback when Windows lists modules but
                        // does not expose one with the expected executable name.
                        if (modules.Count > 0)
                        {
                            _handle = handle;
                            BaseAddress = (long)modules[0].BaseAddress;
                            ModuleSize = Math.Max(0, modules[0].ModuleMemorySize);
                            LastAttachStatus = $"ATTACHED_WITH_FIRST_MODULE_FALLBACK pid={pid} module={modules[0].ModuleName} base=0x{BaseAddress:X} size=0x{ModuleSize:X}";
                            return true;
                        }

                        CloseHandle(handle);
                        lastFailure = $"MODULE_LIST_EMPTY pid={pid}; OpenProcess succeeded but no module base was available";
                    }
                    catch (Exception ex)
                    {
                        CloseHandle(handle);
                        int error = Marshal.GetLastWin32Error();
                        LastAttachWin32Error = error;
                        lastFailure = $"MODULE_ENUMERATION_FAILED pid={pid} type={ex.GetType().Name} message='{ex.Message}' win32={error}";
                    }
                }
                catch (Exception ex)
                {
                    lastFailure = $"PROCESS_QUERY_FAILED type={ex.GetType().Name} message='{ex.Message}'";
                }
                finally
                {
                    proc.Dispose();
                }
            }

            LastAttachStatus = lastFailure;
            return false;
        }

        private static string DescribeSimilarProcesses()
        {
            var matches = new List<string>();
            try
            {
                foreach (Process process in Process.GetProcesses())
                {
                    using (process)
                    {
                        string name;
                        int pid;
                        try
                        {
                            name = process.ProcessName;
                            pid = process.Id;
                        }
                        catch
                        {
                            continue;
                        }

                        // Exclude this utility itself; its name contains "ros" and
                        // would otherwise be a misleading candidate on every wait.
                        if (!string.Equals(name, "ROS64Hack", StringComparison.OrdinalIgnoreCase) &&
                            (name.IndexOf("ros", StringComparison.OrdinalIgnoreCase) >= 0 ||
                             name.IndexOf("rules", StringComparison.OrdinalIgnoreCase) >= 0 ||
                             name.IndexOf("survival", StringComparison.OrdinalIgnoreCase) >= 0))
                        {
                            matches.Add($"{name}(PID={pid})");
                            if (matches.Count >= 8)
                                break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return $"<enumeration-failed:{ex.GetType().Name}>";
            }

            return matches.Count == 0 ? "<none-with-ros-rules-or-survival-in-name>" : "[" + string.Join(",", matches) + "]";
        }

        public bool ReadBytes(long address, byte[] buffer, int size) =>
            ReadBytes(address, buffer, 0, size);

        /// <summary>Read process memory without updating runtime RPM diagnostics.</summary>
        public bool ReadBytesQuiet(long address, byte[] buffer, int bufferOffset, int size)
        {
            if (buffer == null || bufferOffset < 0 || size < 0 || bufferOffset + size > buffer.Length)
                return false;

            if (bufferOffset == 0)
            {
                bool ok = ReadProcessMemory(_handle, (IntPtr)address, buffer, size, out int read);
                return ok && read == size;
            }

            return ReadBytesQuietDirect(address, buffer, bufferOffset, size);
        }

        /// <summary>
        /// Read directly into a caller-owned buffer at the specified offset.
        /// This avoids the temporary byte[] allocation required by the standard
        /// ReadProcessMemory(byte[]) overload.
        /// </summary>
        public unsafe bool ReadBytesQuietDirect(long address, byte[] buffer, int bufferOffset, int size)
        {
            if (buffer == null || bufferOffset < 0 || size < 0 || bufferOffset + size > buffer.Length)
                return false;

            fixed (byte* p = buffer)
            {
                IntPtr dst = (IntPtr)(p + bufferOffset);
                bool ok = ReadProcessMemoryDirect(_handle, (IntPtr)address, dst, size, out IntPtr read);
                return ok && read.ToInt64() == size;
            }
        }

        public bool ReadBytes(long address, byte[] buffer, int bufferOffset, int size)
        {
            if (buffer == null || bufferOffset < 0 || size < 0 || bufferOffset + size > buffer.Length)
                return false;

            RuntimeDiagnostics.RpmCall();

            bool ok;
            int read;
            if (bufferOffset == 0)
            {
                ok = ReadProcessMemory(_handle, (IntPtr)address, buffer, size, out read);
            }
            else
            {
                // Reuse the direct pinned path so chunk assembly never allocates.
                ok = ReadBytesQuietDirectTracked(address, buffer, bufferOffset, size, out read);
            }

            if (!ok || read != size)
            {
                RuntimeDiagnostics.ReadFailure(address, size, read, Marshal.GetLastWin32Error(), null);
                return false;
            }

            return true;
        }

        private unsafe bool ReadBytesQuietDirectTracked(long address, byte[] buffer, int bufferOffset, int size, out int read)
        {
            read = 0;
            fixed (byte* p = buffer)
            {
                IntPtr dst = (IntPtr)(p + bufferOffset);
                bool ok = ReadProcessMemoryDirect(_handle, (IntPtr)address, dst, size, out IntPtr rawRead);
                read = rawRead.ToInt64() > int.MaxValue ? int.MaxValue : (int)rawRead.ToInt64();
                return ok;
            }
        }

        public T Read<T>(long address) where T : struct => Read<T>(address, null);

        public T Read<T>(long address, string tag) where T : struct
        {
            int size = Marshal.SizeOf<T>();
            var buf = new byte[size];
            RuntimeDiagnostics.RpmCall();
            bool ok = ReadProcessMemory(_handle, (IntPtr)address, buf, size, out int read);
            if (!ok || read != size)
            {
                RuntimeDiagnostics.ReadFailure(address, size, read, Marshal.GetLastWin32Error(), tag);
                return default;
            }

            var h = GCHandle.Alloc(buf, GCHandleType.Pinned);
            try
            {
                return Marshal.PtrToStructure<T>(h.AddrOfPinnedObject());
            }
            finally
            {
                h.Free();
            }
        }

        public long ReadLong(long a) => Read<long>(a);
        public long ReadLong(long a, string tag) => Read<long>(a, tag);
        public ulong ReadUlong(long a) => Read<ulong>(a);
        public ulong ReadUlong(long a, string tag) => Read<ulong>(a, tag);
        public int ReadInt(long a) => Read<int>(a);
        public int ReadInt(long a, string tag) => Read<int>(a, tag);
        public uint ReadUint(long a) => Read<uint>(a);
        public uint ReadUint(long a, string tag) => Read<uint>(a, tag);
        public float ReadFloat(long a) => Read<float>(a);
        public float ReadFloat(long a, string tag) => Read<float>(a, tag);
        public byte ReadByte(long a) => Read<byte>(a);
        public byte ReadByte(long a, string tag) => Read<byte>(a, tag);
        public bool ReadBool(long a) => ReadByte(a) != 0;
        public bool ReadBool(long a, string tag) => ReadByte(a, tag) != 0;

        public string ReadString(long address, int maxLen = 64)
        {
            var buf = new byte[maxLen];
            RuntimeDiagnostics.RpmCall();
            ReadProcessMemory(_handle, (IntPtr)address, buf, maxLen, out int read);
            int end = Array.IndexOf(buf, (byte)0);
            return Encoding.ASCII.GetString(buf, 0, end < 0 ? read : end);
        }

        public bool WriteFloat(long address, float value)
        {
            var buf = BitConverter.GetBytes(value);
            return WriteProcessMemory(_handle, (IntPtr)address, buf, buf.Length, out _);
        }

        public bool WriteLong(long address, long value)
        {
            var buf = BitConverter.GetBytes(value);
            return WriteProcessMemory(_handle, (IntPtr)address, buf, buf.Length, out _);
        }

        public void Dispose()
        {
            if (_handle != IntPtr.Zero)
            {
                CloseHandle(_handle);
                _handle = IntPtr.Zero;
            }
            BaseAddress = 0;
            ModuleSize = 0;
        }
    }
}

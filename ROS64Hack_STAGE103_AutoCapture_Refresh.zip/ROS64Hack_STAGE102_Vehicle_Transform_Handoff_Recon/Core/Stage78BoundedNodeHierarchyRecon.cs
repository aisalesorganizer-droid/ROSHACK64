using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using ROS64Hack.Engine;

namespace ROS64Hack.Core
{
    /// <summary>
    /// Stage 78 bounded-node hierarchy reconciliation diagnostic. It combines the previously promising direct, array,
    /// graph, bridge, and legacy wrapper routes in one bounded read-only capture. Exact-type node
    /// edges are scanned across a 0x1000-byte object; association distance is evidence, not a filter.
    /// DynamicSkeletonReader and the renderer remain unchanged.
    /// </summary>
    public sealed class Stage78BoundedNodeHierarchyRecon : IDisposable
    {
        private const int BGA_ID = 0x018;
        private const int BGA_X = 0x01C;
        private const int BGA_Y = 0x020;
        private const int BGA_Z = 0x024;
        private const int BGA_NATIVE_GRAPH = 0x0B8;
        private const int BGA_DIRECT_MODEL = 0x0D8;
        private const int BGA_MODEL_ARRAY_BEGIN = 0x0E0;
        private const int BGA_MODEL_ARRAY_END = 0x0E8;
        private const int BGA_SCENE_WRAPPER = 0x048;
        private const int BGA_MODEL_WRAPPER_A = 0x128;
        private const int BGA_MODEL_WRAPPER_B = 0x130;
        private const int LEGACY_OBJECT_SCAN_BYTES = 0x1000;
        private const int LEGACY_MAX_ROOT_OBJECTS = 20;
        private const int LEGACY_MAX_SECOND_HOP_OBJECTS = 24;
        private const int LEGACY_MAX_CHILDREN_PER_ROOT = 8;
        private const int LEGACY_RESCAN_INTERVAL_ROUNDS = 4;
        private const int GRAPH_BRIDGE_OFFSET = 0x038;
        private const int BRIDGE_FIELD_CENTER = 0x850;
        private const int BRIDGE_SCAN_MIN = 0x830;
        private const int BRIDGE_SCAN_MAX = 0x870;
        private const int BRIDGE_SCAN_STEP = 0x008;
        private const int MODEL_SPACE_NODE = 0x038;
        private const int SPACE_MODEL = 0x040;
        private const int SPACE_WORLD_MATRIX = 0x148;
        private const int SPACE_WORLD_TRANSLATION = 0x178;
        private const int MATRIX_BYTES = 0x40;
        private const long MODEL_SKELETAL_VTABLE_RVA = 0x001C1ACE0;
        private const long SPACE_NODE_VTABLE_RVA = 0x001C137C8;
        private const int BGA_READ_BYTES = 0x680;
        private const int ENTITY_MODEL_BLOCK_BYTES = 0x020;
        private const int MODEL_ARRAY_MAX_BYTES = 0x4000;
        private const int RESOLVE_MAX_DEPTH = 5;
        private const int RESOLVE_MAX_OBJECTS = 128;
        private const int RESOLVE_OBJECT_BYTES = 0x400;
        // Match the established DynamicSkeletonReader SpaceNode read extent. The last qword at +0x618 ends exactly at +0x620.
        private const int NODE_OBJECT_BYTES = 0x620;
        private static readonly int[] HISTORICALLY_OBSERVED_NODE_EDGES = { 0x018, 0x318, 0x618 };
        private const int SAMPLE_ROUNDS = 24;
        private const int SAMPLE_INTERVAL_MS = 750;
        private const int INITIAL_DELAY_MS = 1000;
        private const int MAX_ENEMIES_PER_ROUND = 64;
        private const int MAX_DISTINCT_MODELS = 64;
        // Keep the live reader's hierarchy traversal cap; distance is logged rather than used to suppress discovery.
        private const int MAX_NODES_PER_MODEL = 96;
        private const int MAX_HIERARCHY_DEPTH = 7;
        private const float MAX_WORLD_COORD = 50000f;
        private const float MAX_RUNTIME_ROOT_DISTANCE = 128f;
        private const float MAX_TARGET_NODE_DISTANCE = 128f;
        private const float POSITION_MATCH_TOLERANCE = 2.0f;
        private const float MOVEMENT_EPSILON = 0.02f;
        // Mirror DynamicSkeletonReader articulation gates exactly.
        private const int MIN_ARTICULATED_NODES = 6;
        private const int MIN_ARTICULATION_SAMPLES = 4;
        private const float ARTICULATION_RELATIVE_STEP = 0.05f;
        private const float ARTICULATION_TOTAL_RELATIVE_MOTION = 0.20f;

        private readonly Mem _mem;
        private readonly object _sync = new();
        private readonly byte[] _bgaScratch = new byte[BGA_READ_BYTES];
        private readonly byte[] _entityModelScratch = new byte[ENTITY_MODEL_BLOCK_BYTES];
        private readonly byte[] _modelArrayScratch = new byte[MODEL_ARRAY_MAX_BYTES];
        private readonly byte[] _scratch8 = new byte[8];
        private readonly Dictionary<long, ModelRecord> _models = new();
        private readonly Dictionary<uint, EntityStats> _entityStats = new();
        private readonly Dictionary<string, OffsetStats> _offsetStats = new(StringComparer.Ordinal);
        // Topology is cached per live entity/BGA+0x0B8 pointer for this short capture; model
        // roots and transforms are revalidated on every observation.
        private readonly Dictionary<(uint Id, long Bga, long B8), ResolverGraphCache> _resolverGraphCache = new();
        private readonly Dictionary<long, long> _objectVtableCache = new();
        private StreamWriter _writer;
        private System.Threading.Timer _timer;
        private List<TargetSnapshot> _latest = new();
        private int _started, _disposed, _timerBusy, _sample;
        private bool _captureComplete;
        private int _emptySnapshotRounds, _nonEmptySnapshotRounds, _rawIdMismatches, _entityObservations;
        private int _exactModelHits, _rootValidatedHits, _rootWithinRuntimeRadiusHits, _positionCloseHits;
        private int _liveResolverSelectionObservations;
        private float _nearestRootDistance = float.MaxValue;

        private sealed class TargetSnapshot
        {
            public long Ptr;
            public uint Id;
            public float X, Y, Z, Distance;
        }

        private sealed class EntityStats
        {
            public uint Id;
            public int Observations, BgaReads, RawIdMatches, RawIdMismatches, GraphPointers, BridgePointers;
            public int PositionClose, PositionFar, ExactModels, ValidRoots, RuntimeRadiusRoots, LiveResolverSelections;
            public readonly HashSet<long> BgaPointers = new();
            public readonly HashSet<long> ModelPointers = new();
            public readonly HashSet<long> LiveResolverModels = new();
            public readonly HashSet<string> ResolverPaths = new(StringComparer.Ordinal);
            public readonly HashSet<string> ExactSources = new(StringComparer.Ordinal);
        }

        private sealed class OffsetStats
        {
            public string Source;
            public int Reads, ReadFailures, PointerLike, VtableReads, VtableReadFailures, ExactModelHits;
            public readonly Dictionary<long, int> VtableCounts = new();
            public readonly Dictionary<long, int> ModelPointerCounts = new();
        }

        private sealed class ModelCandidate
        {
            public long Model;
            public bool RuntimeResolverSelected;
            public readonly HashSet<string> Sources = new(StringComparer.Ordinal);
        }

        private sealed class ResolverGraphModel
        {
            public long Model, Parent;
            public int Depth, ParentOffset;
        }

        private sealed class ResolverGraphCache
        {
            public long B8;
            public bool CacheHit;
            public int Expanded, ReadFailures;
            public readonly List<ResolverGraphModel> Models = new();
        }

        private sealed class CandidateValidation
        {
            public long Model, Root, RootVtable, RootOwner;
            public string Sources;
            public bool RootRead, RootVtableRead, RootOwnerRead, RootValidated;
            public bool RootPositionValid, RootWithinRuntimeRadius;
            public string RootTransformSource = "N/A";
            public float RootX, RootY, RootZ, RootDistance = float.NaN;
        }

        private sealed class Observation
        {
            public bool BgaRead, RawIdMatch, GraphRead, BridgeRead;
            public bool TargetPositionValid, PositionCloseToSnapshot, ModelBlockRead;
            public bool ModelArrayMetadataValid, ModelArrayReadSucceeded, ResolverGraphCacheHit;
            public uint RawId;
            public long Graph, Bridge, ResolverSelectedModel;
            public float X, Y, Z, PositionDelta = float.NaN, ResolverSelectedRootDistance = float.NaN;
            public string ResolverSelectionReason = "NONE";
            public int ModelArrayCandidateCount, ModelArrayExactCandidates, ModelArrayRootRejected;
            public int ResolverGraphExpanded, ResolverGraphReadFailures, ResolverGraphExactModels, ResolverGraphRootAccepted;
            public long Field850, Vtable850;
            public bool Field850Read, Field850PointerLike, Vtable850Read, Exact850;
            public long DirectModel, ArrayBegin, ArrayEnd;
            public readonly List<ModelCandidate> ExactModels = new();
            public readonly List<CandidateValidation> Validations = new();
        }

        private sealed class NodeRecord
        {
            public long Ptr, Owner, Vtable;
            public string TransformSource = "Translation178";
            public int Depth;
            public long Parent;
            public int ParentOffset;
            public int Samples, MovingSteps;
            public float LastRelX, LastRelY, LastRelZ;
            public bool HasLastRelative;
            public float LastWorldX, LastWorldY, LastWorldZ;
            public bool HasPreviousWorld;
            // This accumulates node displacement after subtracting target/entity displacement,
            // which is the exact quantity DynamicSkeletonReader uses for articulation gating.
            public double TotalRelativeStep;
            public float MaxRelativeStep;
            public float FirstRelX, FirstRelY, FirstRelZ;
        }

        private sealed class ModelRecord
        {
            public long Model, Root, RootVtable;
            public string RootTransformSource = "Translation178";
            public int Validations, ClosureScans, Edges, SampleCount, LastValidNodeCount, LastNodesWithin128, ArticulatingNodeCount;
            public int LastMotionSampleRound;
            public bool HasPreviousTarget, ArticulationVerified;
            public float PreviousTargetX, PreviousTargetY, PreviousTargetZ;
            public float LastRootDistance = float.NaN;
            public readonly HashSet<uint> EntityIds = new();
            public readonly HashSet<uint> SourceEntityIds = new();
            public readonly Dictionary<uint, int> NearestAssociationRoundCounts = new();
            public readonly List<float> NearestRootDistances = new();
            public readonly HashSet<string> Sources = new(StringComparer.Ordinal);
            public readonly Dictionary<long, NodeRecord> Nodes = new();
            public readonly HashSet<string> EdgeKeys = new(StringComparer.Ordinal);
        }

        public Stage78BoundedNodeHierarchyRecon(Mem mem)
        {
            _mem = mem ?? throw new ArgumentNullException(nameof(mem));
            for (int offset = BRIDGE_SCAN_MIN; offset <= BRIDGE_SCAN_MAX; offset += BRIDGE_SCAN_STEP)
                _offsetStats[$"bridge+0x{offset:X}"] = new OffsetStats { Source = $"bridge+0x{offset:X}" };
            _offsetStats["BGA+0x0D8"] = new OffsetStats { Source = "BGA+0x0D8" };
            _offsetStats["BGA+0x0E0"] = new OffsetStats { Source = "BGA+0x0E0" };
            _offsetStats["BGA+0x0E8"] = new OffsetStats { Source = "BGA+0x0E8" };
            _offsetStats["MODEL_ARRAY"] = new OffsetStats { Source = "MODEL_ARRAY" };
            _offsetStats["BGA+0x0B8_GRAPH"] = new OffsetStats { Source = "BGA+0x0B8_GRAPH" };
            _offsetStats["LEGACY_BGA_INTERNAL"] = new OffsetStats { Source = "LEGACY_BGA_INTERNAL" };
        }

        public void Start()
        {
            if (Interlocked.Exchange(ref _started, 1) != 0) return;
            try
            {
                string path = Path.Combine(Environment.CurrentDirectory, "STAGE78_BOUNDED_NODE_HIERARCHY_RECON.txt");
                _writer = new StreamWriter(new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.ReadWrite)) { AutoFlush = false };
                Write("============================================================");
                Write("STAGE 77 — CACHED CANDIDATE MOTION TRACKING");
                Write("============================================================");
                Write($"[STAGE78][CONFIG] rounds={SAMPLE_ROUNDS} intervalMs={SAMPLE_INTERVAL_MS} plannedSeconds={SAMPLE_ROUNDS * SAMPLE_INTERVAL_MS / 1000.0:F1} maxEnemySnapshotsPerRound={MAX_ENEMIES_PER_ROUND} bridgeWindow=+0x{BRIDGE_SCAN_MIN:X}..+0x{BRIDGE_SCAN_MAX:X} step=0x{BRIDGE_SCAN_STEP:X} legacyAnchors=[BGA+0x048,BGA+0x128,BGA+0x130] maxLegacyRootObjects={LEGACY_MAX_ROOT_OBJECTS} maxSecondHopObjects={LEGACY_MAX_SECOND_HOP_OBJECTS} maxModels={MAX_DISTINCT_MODELS} maxNodesPerModel={MAX_NODES_PER_MODEL} nodeObjectBytes=0x{NODE_OBJECT_BYTES:X} maxEdgeSlot=+0x{NODE_OBJECT_BYTES-8:X} historicallyObservedEdges=[+0x018,+0x318,+0x618] graphTraversal=all-qword-fields-within-verified-object exact-node-vtables maxDepth={MAX_HIERARCHY_DEPTH} targetDistanceIsRankingOnly=1");
                Write($"[STAGE78][EXPECTED] ModelSkeletalVtable=0x{_mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA:X} SpaceNodeVtable=0x{_mem.BaseAddress + SPACE_NODE_VTABLE_RVA:X}");
                Write("[STAGE78][COORDINATE-FIX] BGA ID=+0x018; XYZ=+0x01C/+0x020/+0x024. Stage 74 diagnostic mistakenly read XYZ from +0x020/+0x024/+0x028.");
                Write("[STAGE78][MODEL-SOURCES] test together: BGA+0x0D8 direct model; [BGA+0x0E0,BGA+0x0E8) array; BGA+0x0B8 bounded object graph; graph+0x038 bridge+0x830..+0x870; legacy BGA+0x048/+0x128/+0x130 wrapper paths and bounded target-owned pointer closure");
                Write("[STAGE78][SUPPLEMENTAL] graph+0x038 bridge qwords +0x830..+0x870 are recorded as supplemental evidence only; these candidates are never counted as selected by the live resolver");
                Write("[STAGE78][ROOT-COORDINATES] root/model gates use the current overlay entity snapshot XYZ like DynamicSkeletonReader; raw BGA XYZ (+0x01C/+0x020/+0x024) is only a coordinate-consistency cross-check");
                Write("[STAGE78][CANDIDATE-POLICY] preserve exact ModelSkeletal vtable and reciprocal model/root ownership; record every candidate root regardless of distance to the BGA that exposed it; rank against all current enemy snapshots; hierarchy crawl checks every qword field in the full 0x1000 node object for exact root/SpaceNode vtables; no owner or target-distance gate during discovery");
                Write("[STAGE78][EDGE-PROBE] scan qword-aligned fields only within SpaceNode extent +0x000..+0x618; only +0x018/+0x318/+0x618 are historically observed edge offsets; retain other in-bounds typed edges as unconfirmed; never read node fields beyond +0x620");
                Write("[STAGE78][MOTION-PROTOCOL] keep one target visible while standing, running, jumping, and crouching; cached exact-model candidates are sampled every round regardless of their source BGA or node distance");
                Write("[STAGE78][MOTION-FIX] repeat-sample every cached model/root/node each round; report root-to-nearest-entity ID and distance history; record node-owner consistency and within-128 root proximity separately; exact vtable and reciprocal root-owner checks validate cached candidates");
                Write("[STAGE78][POLICY] currentOverlayEnemySnapshotsOnly=1 processWideScan=0 memoryWrites=0 rendererChanges=0 DynamicSkeletonReaderChanges=0; broad candidates are diagnostic only");
                Write($"[STAGE78][FILE] {Path.GetFullPath(path)}");
                Write("------------------------------------------------------------");
                _timer = new System.Threading.Timer(TimerTick, null, INITIAL_DELAY_MS, SAMPLE_INTERVAL_MS);
            }
            catch (Exception ex) { SafeConsole($"[STAGE78][START-FAILED] {ex.GetType().Name}: {ex.Message}"); }
        }

        public void ObserveSnapshot(List<EntityData> entities)
        {
            if (Volatile.Read(ref _disposed) != 0 || Volatile.Read(ref _started) == 0 || entities == null) return;
            var next = entities
                .Where(e => e != null && e.IsEnemy && e.EntityId != 0 && IsPtr(e.Ptr) && IsValidCoordinate(e.X) && IsValidCoordinate(e.Y) && IsValidCoordinate(e.Z))
                .Select(e => new TargetSnapshot { Ptr = e.Ptr, Id = e.EntityId, X = e.X, Y = e.Y, Z = e.Z, Distance = float.IsFinite(e.Distance) ? e.Distance : float.MaxValue })
                .GroupBy(e => (e.Ptr, e.Id)).Select(g => g.First())
                .OrderBy(e => e.Distance).ThenBy(e => e.Id).Take(MAX_ENEMIES_PER_ROUND).ToList();
            lock (_sync) _latest = next;
        }

        private void TimerTick(object state)
        {
            if (Volatile.Read(ref _disposed) != 0 || _captureComplete || Interlocked.Exchange(ref _timerBusy, 1) != 0) return;
            try
            {
                List<TargetSnapshot> snapshot;
                lock (_sync) snapshot = _latest.Select(Copy).ToList();
                _sample++;
                if (snapshot.Count == 0)
                {
                    _emptySnapshotRounds++;
                    Write($"[STAGE78][ROUND] n={_sample}/{SAMPLE_ROUNDS} validEnemySnapshots=0 status=WAITING_FOR_OVERLAY_SNAPSHOT routesProbed=0");
                }
                else
                {
                    _nonEmptySnapshotRounds++;
                    Write($"[STAGE78][ROUND] n={_sample}/{SAMPLE_ROUNDS} validEnemySnapshots={snapshot.Count} targetIdentitySource=live-overlay-snapshot");
                    int roundExactModels = 0, roundValidRoots = 0, roundRuntimeRadiusRoots = 0, roundPositionClose = 0, roundResolverSelections = 0;
                    foreach (TargetSnapshot target in snapshot)
                    {
                        _entityObservations++;
                        if (!_entityStats.TryGetValue(target.Id, out EntityStats stats))
                        {
                            stats = new EntityStats { Id = target.Id };
                            _entityStats[target.Id] = stats;
                        }
                        stats.Observations++;
                        stats.BgaPointers.Add(target.Ptr);

                        Observation o = ObserveTarget(target);
                        if (o.BgaRead) stats.BgaReads++;
                        if (o.BgaRead && !o.RawIdMatch) { _rawIdMismatches++; stats.RawIdMismatches++; }
                        if (o.RawIdMatch) stats.RawIdMatches++;
                        if (o.GraphRead && IsPtr(o.Graph)) stats.GraphPointers++;
                        if (o.BridgeRead && IsPtr(o.Bridge)) stats.BridgePointers++;
                        if (o.TargetPositionValid && o.PositionCloseToSnapshot) { stats.PositionClose++; _positionCloseHits++; roundPositionClose++; }
                        else if (o.TargetPositionValid) stats.PositionFar++;
                        if (o.ResolverSelectedModel != 0)
                        {
                            _liveResolverSelectionObservations++;
                            roundResolverSelections++;
                            stats.LiveResolverSelections++;
                            stats.LiveResolverModels.Add(o.ResolverSelectedModel);
                            stats.ResolverPaths.Add(o.ResolverSelectionReason);
                        }

                        foreach (ModelCandidate candidate in o.ExactModels)
                        {
                            stats.ExactModels++;
                            _exactModelHits++;
                            roundExactModels++;
                            stats.ModelPointers.Add(candidate.Model);
                            foreach (string source in candidate.Sources) stats.ExactSources.Add(source);
                            _models.TryGetValue(candidate.Model, out ModelRecord existingModel);
                            CandidateValidation validation = ValidateCandidate(target, o, candidate, existingModel);
                            o.Validations.Add(validation);
                            if (validation.RootValidated) { _rootValidatedHits++; stats.ValidRoots++; roundValidRoots++; }
                            if (validation.RootWithinRuntimeRadius) { _rootWithinRuntimeRadiusHits++; stats.RuntimeRadiusRoots++; roundRuntimeRadiusRoots++; }

                            Write($"[STAGE78][MODEL-CANDIDATE] round={_sample} entityId=0x{target.Id:X8} bga=0x{target.Ptr:X} model=0x{candidate.Model:X} liveResolverSelected={(candidate.RuntimeResolverSelected ? 1 : 0)} sources=[{string.Join(",", candidate.Sources.OrderBy(s => s, StringComparer.Ordinal))}] rawXYZ=({o.X:F3},{o.Y:F3},{o.Z:F3}) snapshotXYZ=({target.X:F3},{target.Y:F3},{target.Z:F3}) rawSnapshotDelta={(float.IsFinite(o.PositionDelta) ? o.PositionDelta.ToString("F3") : "N/A")} modelRoot=0x{validation.Root:X} rootVtableRead={(validation.RootVtableRead ? 1 : 0)} rootVtable={(validation.RootVtableRead ? $"0x{validation.RootVtable:X}" : "N/A")} ownerRead={(validation.RootOwnerRead ? 1 : 0)} rootOwner=0x{validation.RootOwner:X} reciprocalRootValid={(validation.RootValidated ? 1 : 0)} rootXYZ={(validation.RootPositionValid ? $"({validation.RootX:F3},{validation.RootY:F3},{validation.RootZ:F3})" : "UNREADABLE_OR_INVALID")} rootTransformSource={validation.RootTransformSource} rootDistance={(validation.RootPositionValid ? validation.RootDistance.ToString("F3") : "N/A")} rootWithinRuntimeRadius={(validation.RootWithinRuntimeRadius ? 1 : 0)}");

                            if (!validation.RootValidated)
                                continue;

                            TargetSnapshot associatedTarget = target;
                            float associatedDistance = float.NaN;
                            if (validation.RootPositionValid)
                            {
                                TargetSnapshot nearest = FindNearestTarget(snapshot, validation.RootX, validation.RootY, validation.RootZ, out float nearestDistance);
                                if (nearest != null)
                                {
                                    associatedTarget = nearest;
                                    associatedDistance = nearestDistance;
                                }
                            }
                            Write($"[STAGE78][ROOT-ASSOCIATION] sourceEntityId=0x{target.Id:X8} sourceBga=0x{target.Ptr:X} model=0x{candidate.Model:X} root=0x{validation.Root:X} rootXYZ={(validation.RootPositionValid ? $"({validation.RootX:F3},{validation.RootY:F3},{validation.RootZ:F3})" : "UNREADABLE")} sourceRootDistance={(float.IsFinite(validation.RootDistance) ? validation.RootDistance.ToString("F3") : "N/A")} nearestEntityId=0x{associatedTarget.Id:X8} nearestBga=0x{associatedTarget.Ptr:X} nearestRootDistance={(float.IsFinite(associatedDistance) ? associatedDistance.ToString("F3") : "N/A")} withinRuntimeRadiusOfNearest={(float.IsFinite(associatedDistance) && associatedDistance <= MAX_RUNTIME_ROOT_DISTANCE ? 1 : 0)} discoveryDiscardedForDistance=0");
                            _models.TryGetValue(candidate.Model, out ModelRecord model);
                            if (model != null && model.Root != validation.Root)
                            {
                                Write($"[STAGE78][MODEL-ROOT-CHANGED] sourceEntityId=0x{target.Id:X8} model=0x{candidate.Model:X} oldRoot=0x{model.Root:X} newRoot=0x{validation.Root:X} action=discard-old-cached-hierarchy-and-revalidate");
                                _models.Remove(candidate.Model);
                                model = null;
                            }
                            if (model == null)
                            {
                                if (_models.Count >= MAX_DISTINCT_MODELS)
                                {
                                    Write($"[STAGE78][MODEL-CAP] sourceEntityId=0x{target.Id:X8} candidateModel=0x{candidate.Model:X} cap={MAX_DISTINCT_MODELS}; candidate remains logged but graph crawl cap reached");
                                    continue;
                                }
                                model = new ModelRecord { Model = candidate.Model, Root = validation.Root, RootVtable = validation.RootVtable, RootTransformSource = validation.RootTransformSource };
                                _models[candidate.Model] = model;
                                DiscoverOwnedHierarchy(model, associatedTarget, validation);
                                if (model.Nodes.TryGetValue(model.Root, out NodeRecord rootNodeRecord))
                                    model.RootTransformSource = rootNodeRecord.TransformSource;
                            }
                            model.SourceEntityIds.Add(target.Id);
                            model.EntityIds.Add(associatedTarget.Id);
                            foreach (string source in candidate.Sources) model.Sources.Add(source);
                            model.Validations++;
                            model.LastRootDistance = associatedDistance;
                            if (float.IsFinite(associatedDistance) && associatedDistance < _nearestRootDistance) _nearestRootDistance = associatedDistance;
                        }

                        string candidateOffsets = string.Join(",", o.ExactModels.SelectMany(m => m.Sources).Distinct().OrderBy(s => s, StringComparer.Ordinal));
                        Write($"[STAGE78][ENTITY] round={_sample} snapshotBga=0x{target.Ptr:X} snapshotId=0x{target.Id:X8} snapshotXYZ=({target.X:F3},{target.Y:F3},{target.Z:F3}) bgaRead={(o.BgaRead ? 1 : 0)} rawId={(o.BgaRead ? $"0x{o.RawId:X8}" : "UNREADABLE")} rawIdMatch={(o.RawIdMatch ? 1 : 0)} rawXYZ={(o.TargetPositionValid ? $"({o.X:F3},{o.Y:F3},{o.Z:F3})" : "UNREADABLE_OR_INVALID")} rawSnapshotDelta={(float.IsFinite(o.PositionDelta) ? o.PositionDelta.ToString("F3") : "N/A")} coordClose={(o.PositionCloseToSnapshot ? 1 : 0)} graph=0x{o.Graph:X} bridge=0x{o.Bridge:X} graphRead={(o.GraphRead ? 1 : 0)} bridgeRead={(o.BridgeRead ? 1 : 0)} resolverSelectedModel=0x{o.ResolverSelectedModel:X} resolverPath={o.ResolverSelectionReason} resolverRootDistance={(float.IsFinite(o.ResolverSelectedRootDistance) ? o.ResolverSelectedRootDistance.ToString("F3") : "N/A")} graphCacheHit={(o.ResolverGraphCacheHit ? 1 : 0)} graphExpanded={o.ResolverGraphExpanded} graphExactModels={o.ResolverGraphExactModels} graphRootAccepted={o.ResolverGraphRootAccepted} modelBlockRead={(o.ModelBlockRead ? 1 : 0)} modelArrayValid={(o.ModelArrayMetadataValid ? 1 : 0)} modelArrayRead={(o.ModelArrayReadSucceeded ? 1 : 0)} modelArraySlots={o.ModelArrayCandidateCount} modelArrayExactCandidates={o.ModelArrayExactCandidates} modelArrayRootRejected={o.ModelArrayRootRejected} BGA_D8=0x{o.DirectModel:X} BGA_E0=0x{o.ArrayBegin:X} BGA_E8=0x{o.ArrayEnd:X} field850=0x{o.Field850:X} field850Read={(o.Field850Read ? 1 : 0)} field850Ptr={(o.Field850PointerLike ? 1 : 0)} vtable850Read={(o.Vtable850Read ? 1 : 0)} vtable850={(o.Vtable850Read ? $"0x{o.Vtable850:X}" : "N/A")} exact850={(o.Exact850 ? 1 : 0)} exactModelCount={o.ExactModels.Count} exactModelSources=[{candidateOffsets}]");
                    }
                    // Models discovered during any route pass remain in the candidate pool.
                    // Revalidate their identity and sample their cached node graph every round,
                    // even when the current BGA scan no longer exposes that model pointer.
                    RevalidateCachedCandidatesAndSample(snapshot);
                    Write($"[STAGE78][ROUND-SUMMARY] round={_sample} entityObservations={snapshot.Count} rawPositionCloseToSnapshot={roundPositionClose} liveResolverSelections={roundResolverSelections} exactModelskeletalCandidates={roundExactModels} reciprocalRoots={roundValidRoots} targetRuntimeRadiusRoots={roundRuntimeRadiusRoots} cachedCandidates={_models.Count} cachedMotionSamples={_models.Values.Sum(m => m.SampleCount)}");
                }
                lock (_sync) { try { _writer?.Flush(); } catch { } }
                if (_sample >= SAMPLE_ROUNDS)
                {
                    EmitFinal(); _captureComplete = true;
                    try { _timer?.Change(Timeout.Infinite, Timeout.Infinite); } catch { }
                    lock (_sync) { try { _writer?.Flush(); } catch { } }
                }
            }
            catch (Exception ex)
            {
                Write($"[STAGE78][EXCEPTION] round={_sample} {ex.GetType().Name}: {ex.Message}");
                if (_sample >= SAMPLE_ROUNDS) { try { EmitFinal(); } catch { } _captureComplete = true; try { _timer?.Change(Timeout.Infinite, Timeout.Infinite); } catch { } }
            }
            finally { Volatile.Write(ref _timerBusy, 0); }
        }

        private Observation ObserveTarget(TargetSnapshot target)
        {
            var o = new Observation();
            Array.Clear(_bgaScratch, 0, _bgaScratch.Length);
            o.BgaRead = _mem.ReadBytesQuiet(target.Ptr, _bgaScratch, 0, _bgaScratch.Length);
            if (!o.BgaRead) return o;
            o.RawId = BitConverter.ToUInt32(_bgaScratch, BGA_ID);
            o.RawIdMatch = target.Id != 0 && o.RawId == target.Id;
            o.X = BitConverter.ToSingle(_bgaScratch, BGA_X);
            o.Y = BitConverter.ToSingle(_bgaScratch, BGA_Y);
            o.Z = BitConverter.ToSingle(_bgaScratch, BGA_Z);
            o.TargetPositionValid = IsValidCoordinate(o.X) && IsValidCoordinate(o.Y) && IsValidCoordinate(o.Z);
            if (o.TargetPositionValid)
            {
                float dx = o.X - target.X, dy = o.Y - target.Y, dz = o.Z - target.Z;
                o.PositionDelta = MathF.Sqrt(dx * dx + dy * dy + dz * dz);
                o.PositionCloseToSnapshot = o.PositionDelta <= POSITION_MATCH_TOLERANCE;
            }
            o.Graph = ReadQword(_bgaScratch, BGA_NATIVE_GRAPH);
            if (!o.RawIdMatch) return o;

            // This is a discovery pass, not a mirror of the live resolver's early returns.
            // Probe direct/array/B8 sources even when the live B8 gate would stop the runtime.
            if (IsFollowablePointer(o.Graph))
            {
                o.GraphRead = TryReadQword(o.Graph, out _);
                o.BridgeRead = TryReadQword(o.Graph + GRAPH_BRIDGE_OFFSET, out o.Bridge);
                if (o.BridgeRead && IsFollowablePointer(o.Bridge))
                    ProbeSupplementalBridgeNeighborhood(o);
            }
            else
            {
                o.ResolverSelectionReason = "B8_INVALID";
                Write($"[STAGE78][LIVE-GATE-OBSERVATION] entityId=0x{target.Id:X8} bga=0x{target.Ptr:X} BGA+0x0B8=0x{o.Graph:X} liveResolverWouldReturnEarly=1 discoveryContinues=1");
            }
            ProbeLiveResolverRoute(target, o);
            ProbeLegacyBgaInternalRoutes(target, o);
            return o;
        }

        private void ProbeLiveResolverRoute(TargetSnapshot target, Observation o)
        {
            long expectedModelVtable = _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;
            string reason;
            long root;
            float rootDistance;

            // This is the order in DynamicSkeletonReader.TryFindModelAndRoot: direct model,
            // then the [begin,end) model array, then bounded graph traversal from BGA+0x0B8.
            Array.Clear(_entityModelScratch, 0, _entityModelScratch.Length);
            o.ModelBlockRead = _mem.ReadBytesQuiet(target.Ptr + BGA_DIRECT_MODEL,
                _entityModelScratch, 0, _entityModelScratch.Length);
            if (o.ModelBlockRead)
            {
                o.DirectModel = ReadQword(_entityModelScratch, 0);
                o.ArrayBegin = ReadQword(_entityModelScratch, BGA_MODEL_ARRAY_BEGIN - BGA_DIRECT_MODEL);
                o.ArrayEnd = ReadQword(_entityModelScratch, BGA_MODEL_ARRAY_END - BGA_DIRECT_MODEL);
                _offsetStats["BGA+0x0E0"].Reads++;
                _offsetStats["BGA+0x0E8"].Reads++;
                Write($"[STAGE78][RESOLVER-MODEL-BLOCK] entityId=0x{target.Id:X8} bga=0x{target.Ptr:X} read=1 directD8=0x{o.DirectModel:X} modelArrayBeginE0=0x{o.ArrayBegin:X} modelArrayEndE8=0x{o.ArrayEnd:X}");

                if (TryProbeModelVtable("BGA+0x0D8", o.DirectModel, expectedModelVtable, out long directVtable))
                {
                    AddExactCandidate(o, o.DirectModel, "DISCOVERY:BGA+0x0D8_EXACT_VTABLE");
                    bool accepted = TryAcceptRuntimeModelRoot(target, o.DirectModel, out root, out rootDistance, out string rootSource, out reason, modelVtableAlreadyVerified: true);
                    Write($"[STAGE78][RESOLVER-DIRECT] entityId=0x{target.Id:X8} model=0x{o.DirectModel:X} modelVtable=0x{directVtable:X} root=0x{root:X} rootSource={rootSource} rootDistance={(float.IsFinite(rootDistance) ? rootDistance.ToString("F3") : "N/A")} accepted={(accepted ? 1 : 0)} reason={reason}");
                    if (accepted)
                    {
                        o.ResolverSelectedModel = o.DirectModel;
                        o.ResolverSelectedRootDistance = rootDistance;
                        o.ResolverSelectionReason = "ENTITY_D8_RESOLVED";
                        AddExactCandidate(o, o.DirectModel, "LIVE_RESOLVER:BGA+0x0D8", true);
                    }
                }
                else
                {
                    Write($"[STAGE78][RESOLVER-DIRECT] entityId=0x{target.Id:X8} model=0x{o.DirectModel:X} modelVtable={(IsFollowablePointer(o.DirectModel) ? $"0x{directVtable:X}" : "N/A")} accepted=0 reason={(IsFollowablePointer(o.DirectModel) ? "MODEL_VTABLE_MISMATCH_OR_READ_FAILED" : "MODEL_INVALID")}");
                }

                long arrayBytes = o.ArrayEnd - o.ArrayBegin;
                o.ModelArrayMetadataValid = IsFollowablePointer(o.ArrayBegin) && IsFollowablePointer(o.ArrayEnd) &&
                    o.ArrayEnd >= o.ArrayBegin && arrayBytes > 0 && arrayBytes <= _modelArrayScratch.Length && (arrayBytes & 7L) == 0;
                Write($"[STAGE78][RESOLVER-MODEL-ARRAY] entityId=0x{target.Id:X8} begin=0x{o.ArrayBegin:X} end=0x{o.ArrayEnd:X} bytes={(o.ModelArrayMetadataValid ? arrayBytes : -1)} valid={(o.ModelArrayMetadataValid ? 1 : 0)} maxBytes=0x{_modelArrayScratch.Length:X}");
                if (o.ModelArrayMetadataValid)
                {
                    int bytes = (int)arrayBytes;
                    o.ModelArrayReadSucceeded = _mem.ReadBytesQuiet(o.ArrayBegin, _modelArrayScratch, 0, bytes);
                    if (!o.ModelArrayReadSucceeded)
                    {
                        _offsetStats["MODEL_ARRAY"].ReadFailures++;
                        Write($"[STAGE78][RESOLVER-MODEL-ARRAY] entityId=0x{target.Id:X8} read=0 bytes={bytes} reason=ARRAY_READ_FAILED");
                    }
                    else
                    {
                        o.ModelArrayCandidateCount = bytes / 8;
                        for (int i = 0; i < o.ModelArrayCandidateCount; i++)
                        {
                            OffsetStats arrayStats = _offsetStats["MODEL_ARRAY"];
                            arrayStats.Reads++;
                            long value = ReadQword(_modelArrayScratch, i * 8);
                            if (!IsFollowablePointer(value))
                            {
                                Write($"[STAGE78][RESOLVER-MODEL-ARRAY-CANDIDATE] entityId=0x{target.Id:X8} index={i} slot=+0x{i * 8:X} value=0x{value:X} modelVtable=N/A accepted=0 reason=MODEL_INVALID");
                                continue;
                            }
                            if (!TryProbeModelVtable("MODEL_ARRAY", value, expectedModelVtable, out long arrayVtable, countRead: false))
                            {
                                Write($"[STAGE78][RESOLVER-MODEL-ARRAY-CANDIDATE] entityId=0x{target.Id:X8} index={i} slot=+0x{i * 8:X} value=0x{value:X} modelVtable=0x{arrayVtable:X} accepted=0 reason=MODEL_VTABLE_MISMATCH_OR_READ_FAILED");
                                continue;
                            }
                            o.ModelArrayExactCandidates++;
                            AddExactCandidate(o, value, $"DISCOVERY:MODEL_ARRAY+0x{i * 8:X}_EXACT_VTABLE");
                            bool accepted = TryAcceptRuntimeModelRoot(target, value, out root, out rootDistance, out string source, out reason, modelVtableAlreadyVerified: true);
                            Write($"[STAGE78][RESOLVER-MODEL-ARRAY-CANDIDATE] entityId=0x{target.Id:X8} index={i} slot=+0x{i * 8:X} value=0x{value:X} modelVtable=0x{arrayVtable:X} root=0x{root:X} rootSource={source} rootDistance={(float.IsFinite(rootDistance) ? rootDistance.ToString("F3") : "N/A")} accepted={(accepted ? 1 : 0)} reason={reason}");
                            if (!accepted)
                            {
                                o.ModelArrayRootRejected++;
                                continue;
                            }
                            if (o.ResolverSelectedModel == 0)
                            {
                                o.ResolverSelectedModel = value;
                                o.ResolverSelectedRootDistance = rootDistance;
                                o.ResolverSelectionReason = $"ENTITY_MODEL_ARRAY_RESOLVED_INDEX_{i}";
                                AddExactCandidate(o, value, $"LIVE_RESOLVER:MODEL_ARRAY+0x{i * 8:X}", true);
                            }
                        }
                        // Continue through the array so all exact candidates are recorded.
                    }
                }
            }
            else
            {
                Write($"[STAGE78][RESOLVER-MODEL-BLOCK] entityId=0x{target.Id:X8} bga=0x{target.Ptr:X} read=0 address=0x{target.Ptr + BGA_DIRECT_MODEL:X}; continuing to BGA+0x0B8 graph fallback");
            }

            ResolverGraphCache graphCache = GetOrBuildResolverGraphCache(target, o.Graph);
            o.ResolverGraphCacheHit = graphCache.CacheHit;
            graphCache.CacheHit = false; // cache-hit status belongs to this observation, not later rounds
            o.ResolverGraphExpanded = graphCache.Expanded;
            o.ResolverGraphReadFailures = graphCache.ReadFailures;
            o.ResolverGraphExactModels = graphCache.Models.Count;
            long bestModel = 0;
            float bestDistance = float.MaxValue;
            ResolverGraphModel bestCandidate = null;
            foreach (ResolverGraphModel graphCandidate in graphCache.Models)
            {
                AddExactCandidate(o, graphCandidate.Model,
                    $"B8_GRAPH:depth_{graphCandidate.Depth}_slot_0x{graphCandidate.ParentOffset:X}");
                bool accepted = TryAcceptRuntimeModelRoot(target, graphCandidate.Model, out root, out rootDistance, out string source, out reason);
                if (accepted) o.ResolverGraphRootAccepted++;
                Write($"[STAGE78][RESOLVER-GRAPH-MODEL] entityId=0x{target.Id:X8} model=0x{graphCandidate.Model:X} depth={graphCandidate.Depth} parent=0x{graphCandidate.Parent:X} parentOffset=+0x{graphCandidate.ParentOffset:X} root=0x{root:X} rootSource={source} rootDistance={(float.IsFinite(rootDistance) ? rootDistance.ToString("F3") : "N/A")} accepted={(accepted ? 1 : 0)} reason={reason}");
                if (accepted && rootDistance < bestDistance)
                {
                    bestDistance = rootDistance;
                    bestModel = graphCandidate.Model;
                    bestCandidate = graphCandidate;
                }
            }
            if (bestModel != 0 && bestCandidate != null && o.ResolverSelectedModel == 0)
            {
                o.ResolverSelectedModel = bestModel;
                o.ResolverSelectedRootDistance = bestDistance;
                o.ResolverSelectionReason = "B8_GRAPH_RESOLVED_BEST_ROOT";
                AddExactCandidate(o, bestModel,
                    $"LIVE_RESOLVER:BGA+0x0B8_GRAPH_BEST_DEPTH_{bestCandidate.Depth}_SLOT_0x{bestCandidate.ParentOffset:X}", true);
            }
            else if (o.ResolverSelectedModel == 0)
            {
                o.ResolverSelectionReason = "B8_GRAPH_NO_ACCEPTED_MODEL_ROOT";
            }
            Write($"[STAGE78][RESOLVER-GRAPH-SUMMARY] entityId=0x{target.Id:X8} b8=0x{o.Graph:X} cacheHit={(o.ResolverGraphCacheHit ? 1 : 0)} expanded={graphCache.Expanded} readFailures={graphCache.ReadFailures} exactModelVtableCandidates={graphCache.Models.Count} rootAcceptedThisRound={o.ResolverGraphRootAccepted} selectedModel=0x{o.ResolverSelectedModel:X} selectedRootDistance={(float.IsFinite(o.ResolverSelectedRootDistance) ? o.ResolverSelectedRootDistance.ToString("F3") : "N/A")} reason={o.ResolverSelectionReason}");
        }

        private ResolverGraphCache GetOrBuildResolverGraphCache(TargetSnapshot target, long b8)
        {
            var key = (target.Id, target.Ptr, b8);
            if (_resolverGraphCache.TryGetValue(key, out ResolverGraphCache existing))
            {
                // Refresh on the same cadence as the broader legacy route probes so a live
                // graph change during the capture is not hidden by a one-time topology cache.
                bool refreshThisRound = _sample == 1 || (_sample - 1) % LEGACY_RESCAN_INTERVAL_ROUNDS == 0;
                if (!refreshThisRound)
                {
                    existing.CacheHit = true;
                    return existing;
                }
                _resolverGraphCache.Remove(key);
                Write($"[STAGE78][RESOLVER-GRAPH-CACHE-REFRESH] entityId=0x{target.Id:X8} bga=0x{target.Ptr:X} b8=0x{b8:X} round={_sample} reason=PERIODIC_LIVE_GRAPH_RECHECK");
            }

            var cache = new ResolverGraphCache { B8 = b8 };
            var queue = new Queue<(long Ptr, int Depth, long Parent, int ParentOffset)>();
            var visited = new HashSet<long>();
            queue.Enqueue((b8, 0, 0, -1));
            visited.Add(b8);
            long expectedModelVtable = _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;

            while (queue.Count > 0 && cache.Expanded < RESOLVE_MAX_OBJECTS)
            {
                var item = queue.Dequeue();
                if (item.Depth > RESOLVE_MAX_DEPTH || !IsFollowablePointer(item.Ptr)) continue;
                if (!TryReadBytes(item.Ptr, RESOLVE_OBJECT_BYTES, out byte[] bytes))
                {
                    cache.ReadFailures++;
                    _offsetStats["BGA+0x0B8_GRAPH"].ReadFailures++;
                    Write($"[STAGE78][RESOLVER-GRAPH-OBJECT] entityId=0x{target.Id:X8} ptr=0x{item.Ptr:X} depth={item.Depth} parent=0x{item.Parent:X} parentOffset=+0x{item.ParentOffset:X} read=0 reason=GRAPH_READ_FAILED");
                    continue;
                }

                cache.Expanded++;
                _offsetStats["BGA+0x0B8_GRAPH"].Reads++;
                long vtable = ReadQword(bytes, 0);
                if (vtable == expectedModelVtable)
                {
                    cache.Models.Add(new ResolverGraphModel { Model = item.Ptr, Depth = item.Depth, Parent = item.Parent, ParentOffset = item.ParentOffset });
                    _offsetStats["BGA+0x0B8_GRAPH"].ExactModelHits++;
                    _offsetStats["BGA+0x0B8_GRAPH"].ModelPointerCounts[item.Ptr] = 1;
                    Write($"[STAGE78][RESOLVER-GRAPH-MODEL-DISCOVERED] entityId=0x{target.Id:X8} model=0x{item.Ptr:X} depth={item.Depth} parent=0x{item.Parent:X} parentOffset=+0x{item.ParentOffset:X} modelVtable=0x{vtable:X} root=0x{ReadQword(bytes, MODEL_SPACE_NODE):X}");
                }
                if (item.Depth >= RESOLVE_MAX_DEPTH) continue;

                for (int offset = 0; offset < RESOLVE_OBJECT_BYTES; offset += 8)
                {
                    long child = ReadQword(bytes, offset);
                    if (!IsFollowablePointer(child) || !visited.Add(child)) continue;
                    queue.Enqueue((child, item.Depth + 1, item.Ptr, offset));
                    if (visited.Count >= RESOLVE_MAX_OBJECTS) break;
                }
            }
            if (_resolverGraphCache.Count >= 64) _resolverGraphCache.Remove(_resolverGraphCache.Keys.First());
            _resolverGraphCache[key] = cache;
            Write($"[STAGE78][RESOLVER-GRAPH-CACHE-BUILT] entityId=0x{target.Id:X8} bga=0x{target.Ptr:X} b8=0x{b8:X} expanded={cache.Expanded} readFailures={cache.ReadFailures} exactModelVtableCandidates={cache.Models.Count} maxObjects={RESOLVE_MAX_OBJECTS} maxDepth={RESOLVE_MAX_DEPTH} objectBytes=0x{RESOLVE_OBJECT_BYTES:X} traversal=bounded-target-owned-graph-only");
            return cache;
        }

        private bool TryProbeModelVtable(string source, long model, long expectedModelVtable, out long vtable, bool countRead = true)
        {
            vtable = 0;
            OffsetStats stats = _offsetStats[source];
            if (countRead) stats.Reads++;
            if (!IsFollowablePointer(model)) return false;
            stats.PointerLike++;
            stats.ModelPointerCounts[model] = stats.ModelPointerCounts.TryGetValue(model, out int modelCount) ? modelCount + 1 : 1;
            if (!TryReadQword(model, out vtable))
            {
                stats.VtableReadFailures++;
                return false;
            }
            stats.VtableReads++;
            stats.VtableCounts[vtable] = stats.VtableCounts.TryGetValue(vtable, out int vtCount) ? vtCount + 1 : 1;
            bool exact = vtable == expectedModelVtable;
            if (exact) stats.ExactModelHits++;
            return exact;
        }

        private bool TryAcceptRuntimeModelRoot(TargetSnapshot target, long model,
            out long root, out float rootDistance, out string transformSource, out string reason,
            bool modelVtableAlreadyVerified = false)
        {
            root = 0;
            rootDistance = float.NaN;
            transformSource = "N/A";
            reason = "MODEL_INVALID";
            if (!IsFollowablePointer(model)) return false;
            if (!modelVtableAlreadyVerified)
            {
                long expectedModelVtable = _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;
                if (!TryReadQword(model, out long modelVtable) || modelVtable != expectedModelVtable)
                {
                    reason = "MODEL_VTABLE_MISMATCH_OR_READ_FAILED";
                    return false;
                }
            }
            if (!TryReadQword(model + MODEL_SPACE_NODE, out root) || !IsFollowablePointer(root))
            {
                reason = "ROOT_INVALID";
                return false;
            }
            if (!TryReadQword(root + SPACE_MODEL, out long rootOwner))
            {
                reason = "ROOT_OWNER_READ_FAILED";
                return false;
            }
            if (rootOwner != model)
            {
                reason = "ROOT_MODEL_MISMATCH";
                return false;
            }
            if (!TryGetTargetPositionForRootGate(target, out float tx, out float ty, out float tz))
            {
                reason = "TARGET_POSITION_INVALID";
                return false;
            }
            // The 0x1000 diagnostic window includes the reader's full 0x620 transform window.
            if (!TryReadBytes(root, NODE_OBJECT_BYTES, out byte[] rootBytes))
            {
                reason = "ROOT_TRANSFORM_WINDOW_READ_FAILED";
                return false;
            }
            if (!TrySelectTransformSourceFromBuffer(rootBytes, tx, ty, tz, MAX_RUNTIME_ROOT_DISTANCE,
                    out transformSource, out float rootX, out float rootY, out float rootZ, out bool tooFar))
            {
                reason = tooFar ? "ROOT_DISTANCE_REJECT" : "ROOT_TRANSFORM_INVALID";
                return false;
            }
            rootDistance = Distance(tx, ty, tz, rootX, rootY, rootZ);
            if (!float.IsFinite(rootDistance) || rootDistance > MAX_RUNTIME_ROOT_DISTANCE)
            {
                reason = "ROOT_DISTANCE_REJECT";
                return false;
            }
            reason = "ACCEPTED";
            return true;
        }

        private static bool TryGetTargetPositionForRootGate(TargetSnapshot target, out float x, out float y, out float z)
        {
            x = target.X; y = target.Y; z = target.Z;
            return IsValidCoordinate(x) && IsValidCoordinate(y) && IsValidCoordinate(z);
        }

        private void ProbeLegacyBgaInternalRoutes(TargetSnapshot target, Observation o)
        {
            // Full wrapper/object scans are intentionally less frequent than the main route probes.
            // Each pass remains rooted in the current live enemy BGA; there is no process-wide scan.
            if (_sample != 1 && (_sample - 1) % LEGACY_RESCAN_INTERVAL_ROUNDS != 0)
                return;

            long expectedModelVtable = _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;
            var knownSeeds = new List<(int Offset, long Ptr)>
            {
                (BGA_SCENE_WRAPPER, ReadQword(_bgaScratch, BGA_SCENE_WRAPPER)),
                (BGA_MODEL_WRAPPER_A, ReadQword(_bgaScratch, BGA_MODEL_WRAPPER_A)),
                (BGA_MODEL_WRAPPER_B, ReadQword(_bgaScratch, BGA_MODEL_WRAPPER_B)),
            };
            var seeds = new List<(int Offset, long Ptr)>(knownSeeds);
            var seedPointers = new HashSet<long>(knownSeeds.Where(s => IsPtr(s.Ptr)).Select(s => s.Ptr));

            // Add other direct BGA pointer fields as candidates after the three historically
            // productive anchors. A hard cap prevents a noisy entity object from exploding reads.
            for (int offset = 0; offset + 8 <= _bgaScratch.Length && seeds.Count < LEGACY_MAX_ROOT_OBJECTS; offset += 8)
            {
                long ptr = ReadQword(_bgaScratch, offset);
                if (!IsPtr(ptr) || !seedPointers.Add(ptr)) continue;
                if (offset == BGA_NATIVE_GRAPH || offset == BGA_DIRECT_MODEL ||
                    offset == BGA_MODEL_ARRAY_BEGIN || offset == BGA_MODEL_ARRAY_END)
                    continue;
                seeds.Add((offset, ptr));
            }

            var secondHop = new List<(long Ptr, string Path)>();
            var secondHopSeen = new HashSet<long>();
            int objectReads = 0, exactModels = 0, secondHopScanned = 0;
            Write($"[STAGE78][LEGACY-ROUTE-BEGIN] entityId=0x{target.Id:X8} bga=0x{target.Ptr:X} rawIdMatch=1 seedCount={seeds.Count} rescanRound={_sample} anchors=BGA+0x048,+0x128,+0x130");

            foreach (var seed in seeds)
            {
                if (!IsPtr(seed.Ptr)) continue;
                if (!TryReadObjectVariableSize(seed.Ptr, out byte[] bytes))
                {
                    Write($"[STAGE78][LEGACY-OBJECT] entityId=0x{target.Id:X8} path=BGA+0x{seed.Offset:X} ptr=0x{seed.Ptr:X} read=0");
                    continue;
                }
                objectReads++;
                ScanObjectFieldsForModels(target, o, bytes, seed.Ptr,
                    $"BGA+0x{seed.Offset:X}", expectedModelVtable, secondHop, secondHopSeen, ref exactModels);
            }

            foreach (var item in secondHop.Take(LEGACY_MAX_SECOND_HOP_OBJECTS))
            {
                if (!TryReadObjectVariableSize(item.Ptr, out byte[] bytes)) continue;
                secondHopScanned++;
                ScanObjectFieldsForModels(target, o, bytes, item.Ptr, item.Path,
                    expectedModelVtable, null, null, ref exactModels);
            }

            Write($"[STAGE78][LEGACY-ROUTE-END] entityId=0x{target.Id:X8} bga=0x{target.Ptr:X} rootObjectsRead={objectReads} secondHopCandidates={secondHop.Count} secondHopObjectsRead={secondHopScanned} exactModelHits={exactModels} distinctCandidatesNow={o.ExactModels.Select(m => m.Model).Distinct().Count()} policy=bounded-live-BGA-closure-only");
        }

        private void ScanObjectFieldsForModels(
            TargetSnapshot target, Observation observation, byte[] bytes, long objectPtr, string path,
            long expectedModelVtable, List<(long Ptr, string Path)> secondHop,
            HashSet<long> secondHopSeen, ref int exactModels)
        {
            if (bytes == null) return;
            int childObjectsAdded = 0;
            OffsetStats legacyStats = _offsetStats["LEGACY_BGA_INTERNAL"];
            for (int offset = 0; offset + 8 <= bytes.Length; offset += 8)
            {
                long value = ReadQword(bytes, offset);
                legacyStats.Reads++;
                if (!IsPtr(value) || value == objectPtr) continue;
                legacyStats.PointerLike++;
                if (!TryReadQword(value, out long vtable)) { legacyStats.VtableReadFailures++; continue; }
                legacyStats.VtableReads++;
                legacyStats.VtableCounts[vtable] = legacyStats.VtableCounts.TryGetValue(vtable, out int legacyVtableCount) ? legacyVtableCount + 1 : 1;
                if (vtable == expectedModelVtable)
                {
                    legacyStats.ExactModelHits++;
                    legacyStats.ModelPointerCounts[value] = legacyStats.ModelPointerCounts.TryGetValue(value, out int legacyModelCount) ? legacyModelCount + 1 : 1;
                    AddExactCandidate(observation, value, $"LEGACY:{path}+0x{offset:X}");
                    exactModels++;
                    Write($"[STAGE78][LEGACY-MODEL-HIT] entityId=0x{target.Id:X8} sourceBga=0x{target.Ptr:X} path={path}+0x{offset:X} model=0x{value:X} modelVtable=0x{vtable:X}");
                    continue;
                }
                if (secondHop == null || secondHopSeen == null || childObjectsAdded >= LEGACY_MAX_CHILDREN_PER_ROOT)
                    continue;
                if (secondHopSeen.Add(value))
                {
                    secondHop.Add((value, $"{path}+0x{offset:X}"));
                    childObjectsAdded++;
                }
            }
        }

        private bool TryReadObjectVariableSize(long pointer, out byte[] bytes)
        {
            bytes = null;
            if (!IsPtr(pointer)) return false;
            int[] sizes = { LEGACY_OBJECT_SCAN_BYTES, 0x800, 0x400, 0x200 };
            foreach (int size in sizes)
            {
                if (TryReadBytes(pointer, size, out bytes)) return true;
            }
            return false;
        }

        private static TargetSnapshot FindNearestTarget(
            List<TargetSnapshot> targets, float x, float y, float z, out float nearestDistance)
        {
            TargetSnapshot nearest = null;
            nearestDistance = float.MaxValue;
            if (targets == null || !IsValidCoordinate(x) || !IsValidCoordinate(y) || !IsValidCoordinate(z))
                return null;
            foreach (TargetSnapshot candidate in targets)
            {
                float distance = Distance(x, y, z, candidate.X, candidate.Y, candidate.Z);
                if (!float.IsFinite(distance) || distance >= nearestDistance) continue;
                nearestDistance = distance;
                nearest = candidate;
            }
            if (nearest == null) nearestDistance = float.NaN;
            return nearest;
        }

        private void ProbeSupplementalBridgeNeighborhood(Observation o)
        {
            if (!IsFollowablePointer(o.Bridge)) return;
            for (int offset = BRIDGE_SCAN_MIN; offset <= BRIDGE_SCAN_MAX; offset += BRIDGE_SCAN_STEP)
            {
                string source = $"bridge+0x{offset:X}";
                OffsetStats stats = _offsetStats[source];
                stats.Reads++;
                if (!TryReadQword(o.Bridge + offset, out long value)) { stats.ReadFailures++; continue; }
                if (offset == BRIDGE_FIELD_CENTER)
                {
                    o.Field850 = value;
                    o.Field850Read = true;
                    o.Field850PointerLike = IsFollowablePointer(value);
                }
                if (!IsFollowablePointer(value)) continue;
                stats.PointerLike++;
                stats.ModelPointerCounts[value] = stats.ModelPointerCounts.TryGetValue(value, out int modelCount) ? modelCount + 1 : 1;
                if (!TryReadQword(value, out long vtable)) { stats.VtableReadFailures++; continue; }
                stats.VtableReads++;
                stats.VtableCounts[vtable] = stats.VtableCounts.TryGetValue(vtable, out int vtCount) ? vtCount + 1 : 1;
                if (offset == BRIDGE_FIELD_CENTER) { o.Vtable850 = vtable; o.Vtable850Read = true; }
                if (vtable != _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA) continue;
                stats.ExactModelHits++;
                AddExactCandidate(o, value, $"SUPPLEMENTAL_BRIDGE+0x{offset:X}");
            }
            o.Exact850 = o.ExactModels.Any(m => m.Sources.Contains("SUPPLEMENTAL_BRIDGE+0x850"));
        }

        private static void AddExactCandidate(Observation o, long model, string source, bool runtimeResolverSelected = false)
        {
            ModelCandidate candidate = o.ExactModels.FirstOrDefault(m => m.Model == model);
            if (candidate == null) { candidate = new ModelCandidate { Model = model }; o.ExactModels.Add(candidate); }
            candidate.Sources.Add(source);
            candidate.RuntimeResolverSelected |= runtimeResolverSelected;
        }

        private CandidateValidation ValidateCandidate(TargetSnapshot target, Observation o, ModelCandidate candidate, ModelRecord existingModel)
        {
            var v = new CandidateValidation { Model = candidate.Model, Sources = string.Join(",", candidate.Sources.OrderBy(s => s, StringComparer.Ordinal)) };
            v.RootRead = TryReadQword(candidate.Model + MODEL_SPACE_NODE, out v.Root) && IsFollowablePointer(v.Root);
            if (!v.RootRead) return v;

            // DynamicSkeletonReader validates the reciprocal owner; it does not require the
            // root's vtable to be the strict SpaceNode vtable. The actual root class is retained
            // and used when classifying descendant edge targets.
            if (!TryReadBytes(v.Root, NODE_OBJECT_BYTES, out byte[] rootBytes)) return v;
            v.RootVtable = ReadQword(rootBytes, 0);
            v.RootVtableRead = true;
            v.RootOwner = ReadQword(rootBytes, SPACE_MODEL);
            v.RootOwnerRead = true;
            v.RootValidated = v.RootOwner == candidate.Model;
            if (!v.RootValidated) return v;

            v.RootPositionValid = TryInspectTransformFromBuffer(rootBytes, out string inspectedSource,
                out float inspectX, out float inspectY, out float inspectZ);
            if (v.RootPositionValid)
            {
                v.RootTransformSource = inspectedSource;
                v.RootX = inspectX; v.RootY = inspectY; v.RootZ = inspectZ;
                v.RootDistance = Distance(target.X, target.Y, target.Z, v.RootX, v.RootY, v.RootZ);
            }

            if (!IsValidCoordinate(target.X) || !IsValidCoordinate(target.Y) || !IsValidCoordinate(target.Z)) return v;
            bool runtimeTransformAccepted;
            string selectedSource;
            float selectedX, selectedY, selectedZ;
            string cachedRootSource = existingModel != null && existingModel.Root == v.Root
                ? existingModel.RootTransformSource : null;
            if (!string.IsNullOrEmpty(cachedRootSource))
            {
                selectedSource = cachedRootSource;
                runtimeTransformAccepted = TryReadWorldPositionBySource(rootBytes, cachedRootSource,
                    target.X, target.Y, target.Z, MAX_RUNTIME_ROOT_DISTANCE, out selectedX, out selectedY, out selectedZ);
            }
            else
            {
                runtimeTransformAccepted = TrySelectTransformSourceFromBuffer(rootBytes,
                    target.X, target.Y, target.Z, MAX_RUNTIME_ROOT_DISTANCE, out selectedSource,
                    out selectedX, out selectedY, out selectedZ, out _);
            }
            if (runtimeTransformAccepted)
            {
                v.RootTransformSource = selectedSource;
                v.RootX = selectedX; v.RootY = selectedY; v.RootZ = selectedZ;
                v.RootDistance = Distance(target.X, target.Y, target.Z, selectedX, selectedY, selectedZ);
                v.RootPositionValid = float.IsFinite(v.RootDistance);
                v.RootWithinRuntimeRadius = v.RootPositionValid && v.RootDistance <= MAX_RUNTIME_ROOT_DISTANCE;
            }
            else if (!string.IsNullOrEmpty(cachedRootSource))
            {
                // Keep the cached source just as the live pose cache does, but report that
                // source's actual position even when it falls outside the 64-unit root gate.
                v.RootTransformSource = cachedRootSource;
                if (TryReadWorldPositionBySource(rootBytes, cachedRootSource, target.X, target.Y, target.Z,
                        float.MaxValue, out selectedX, out selectedY, out selectedZ))
                {
                    v.RootX = selectedX; v.RootY = selectedY; v.RootZ = selectedZ;
                    v.RootDistance = Distance(target.X, target.Y, target.Z, selectedX, selectedY, selectedZ);
                    v.RootPositionValid = float.IsFinite(v.RootDistance);
                }
                else
                {
                    v.RootPositionValid = false;
                }
            }
            return v;
        }

        private void DiscoverOwnedHierarchy(ModelRecord model, TargetSnapshot target, CandidateValidation validatedRoot)
        {
            model.ClosureScans++;
            var queue = new Queue<(long Ptr, int Depth, long Parent, int ParentOffset)>();
            var visited = new HashSet<long>();
            queue.Enqueue((model.Root, 0, 0, -1));
            visited.Add(model.Root);
            long strictSpaceNodeVtable = _mem.BaseAddress + SPACE_NODE_VTABLE_RVA;
            int readFailures = 0, edgeSlots = 0, exactNodeEdges = 0, edgeReadFailures = 0;
            int nodesWithTransform = 0, nodesNearRoot = 0;
            var encounteredVtables = new Dictionary<long, int>();

            float rootX = validatedRoot.RootX, rootY = validatedRoot.RootY, rootZ = validatedRoot.RootZ;
            bool rootPositionValid = validatedRoot.RootPositionValid &&
                IsValidCoordinate(rootX) && IsValidCoordinate(rootY) && IsValidCoordinate(rootZ);
            string rootPositionText = rootPositionValid ? $"({rootX:F3},{rootY:F3},{rootZ:F3})" : "UNREADABLE";
            Write($"[STAGE78][GRAPH-BEGIN] model=0x{model.Model:X} root=0x{model.Root:X} rootVtable=0x{model.RootVtable:X} strictSpaceNodeVtable=0x{strictSpaceNodeVtable:X} nodeObjectBytes=0x{NODE_OBJECT_BYTES:X} maxNodes={MAX_NODES_PER_MODEL} maxDepth={MAX_HIERARCHY_DEPTH} rootPositionValid={(rootPositionValid ? 1 : 0)} rootXYZ={rootPositionText} gates=exact-node-vtable-only owner-and-target-distance-do-not-block-discovery");

            while (queue.Count > 0 && visited.Count <= MAX_NODES_PER_MODEL)
            {
                var item = queue.Dequeue();
                if (item.Depth > MAX_HIERARCHY_DEPTH || !IsPtr(item.Ptr)) continue;
                if (!TryReadBytes(item.Ptr, NODE_OBJECT_BYTES, out byte[] bytes))
                {
                    readFailures++;
                    Write($"[STAGE78][NODE-READ-FAILED] model=0x{model.Model:X} node=0x{item.Ptr:X} depth={item.Depth} readBytes=0x{NODE_OBJECT_BYTES:X}");
                    continue;
                }

                long vtable = ReadQword(bytes, 0);
                long owner = ReadQword(bytes, SPACE_MODEL);
                bool isRoot = item.Ptr == model.Root;
                bool typeMatch = isRoot || vtable == model.RootVtable || vtable == strictSpaceNodeVtable;
                if (!typeMatch)
                {
                    encounteredVtables[vtable] = encounteredVtables.TryGetValue(vtable, out int count) ? count + 1 : 1;
                    continue;
                }

                bool hasTransform = TryInspectTransformFromBuffer(bytes, out string transformSource,
                    out float x, out float y, out float z);
                float rootDistance = hasTransform && rootPositionValid ? Distance(rootX, rootY, rootZ, x, y, z) : float.NaN;
                bool nearRoot = float.IsFinite(rootDistance) && rootDistance <= MAX_TARGET_NODE_DISTANCE;
                if (hasTransform)
                {
                    nodesWithTransform++;
                    if (nearRoot) nodesNearRoot++;
                    if (!model.Nodes.TryGetValue(item.Ptr, out NodeRecord node))
                    {
                        node = new NodeRecord
                        {
                            Ptr = item.Ptr, Owner = owner, Vtable = vtable,
                            TransformSource = transformSource, Depth = item.Depth,
                            Parent = item.Parent, ParentOffset = item.ParentOffset
                        };
                        model.Nodes[item.Ptr] = node;
                    }
                    else
                    {
                        node.Owner = owner;
                        node.Vtable = vtable;
                        node.TransformSource = transformSource;
                    }
                }

                if (item.Parent != 0)
                {
                    string edgeKey = $"{item.Parent:X}:{item.ParentOffset:X}:{item.Ptr:X}";
                    if (model.EdgeKeys.Add(edgeKey)) model.Edges++;
                    string transformText = hasTransform ? $"{transformSource}:({x:F3},{y:F3},{z:F3})" : "INVALID";
                    string rootDistanceText = float.IsFinite(rootDistance) ? rootDistance.ToString("F3") : "N/A";
                    Write($"[STAGE78][NODE-EDGE] model=0x{model.Model:X} parent=0x{item.Parent:X} slot=+0x{item.ParentOffset:X} child=0x{item.Ptr:X} depth={item.Depth} childVtable=0x{vtable:X} owner=0x{owner:X} ownerMatchesModel={(owner == model.Model ? 1 : 0)} transform={transformText} rootDistance={rootDistanceText} within128OfRoot={(nearRoot ? 1 : 0)}");
                }

                if (item.Depth >= MAX_HIERARCHY_DEPTH || visited.Count >= MAX_NODES_PER_MODEL)
                    continue;

                // Test every qword-aligned pointer field, not only +0x18/+0x318/+0x618.
                // The scan is bounded to the verified SpaceNode extent. Historically observed edge offsets are labeled separately from other in-bounds typed-pointer candidates.
                for (int offset = 0; offset + 8 <= bytes.Length; offset += 8)
                {
                    edgeSlots++;
                    long child = ReadQword(bytes, offset);
                    if (!IsPtr(child) || child == item.Ptr) continue;
                    if (!TryGetObjectVtable(child, out long childVtable))
                    {
                        edgeReadFailures++;
                        continue;
                    }
                    bool childTypeMatch = childVtable == model.RootVtable || childVtable == strictSpaceNodeVtable;
                    if (!childTypeMatch) continue;
                    exactNodeEdges++;
                    string edgeClass = Array.IndexOf(HISTORICALLY_OBSERVED_NODE_EDGES, offset) >= 0
                        ? "HISTORICALLY_OBSERVED_EDGE" : "UNCONFIRMED_IN_BOUNDS_TYPED_LINK";
                    bool duplicate = visited.Contains(child);
                    bool capBlocked = visited.Count >= MAX_NODES_PER_MODEL;
                    Write($"[STAGE78][EDGE-CANDIDATE] model=0x{model.Model:X} parent=0x{item.Ptr:X} parentDepth={item.Depth} slot=+0x{offset:X} child=0x{child:X} childVtable=0x{childVtable:X} childTypeMatch=1 alreadyVisited={(duplicate ? 1 : 0)} depthBlocked=0 capBlocked={(capBlocked ? 1 : 0)} queue={(!duplicate && !capBlocked ? 1 : 0)} edgeClass={edgeClass} ownerAndDistanceGates=NOT_APPLIED");
                    if (!duplicate && !capBlocked)
                    {
                        visited.Add(child);
                        queue.Enqueue((child, item.Depth + 1, item.Ptr, offset));
                    }
                }
            }

            string topVtables = string.Join(",", encounteredVtables.OrderByDescending(kv => kv.Value).Take(12)
                .Select(kv => $"0x{kv.Key:X}:{kv.Value}"));
            Write($"[STAGE78][GRAPH-END] model=0x{model.Model:X} root=0x{model.Root:X} visitedExactNodes={visited.Count} transformNodes={nodesWithTransform} nodesWithin128OfRoot={nodesNearRoot} connectedEdges={model.Edges} qwordSlotsExamined={edgeSlots} exactTypedEdgeCandidates={exactNodeEdges} pointerReadFailures={edgeReadFailures} objectReadFailures={readFailures} encounteredOtherVtables=[{topVtables}]");
        }

        private bool TryGetObjectVtable(long ptr, out long vtable)
        {
            vtable = 0;
            if (!IsPtr(ptr)) return false;
            if (_objectVtableCache.TryGetValue(ptr, out vtable)) return true;
            if (!TryReadQword(ptr, out vtable)) return false;
            if (_objectVtableCache.Count > 50000) _objectVtableCache.Clear();
            _objectVtableCache[ptr] = vtable;
            return true;
        }

        private void RevalidateCachedCandidatesAndSample(List<TargetSnapshot> snapshot)
        {
            if (snapshot == null || snapshot.Count == 0) return;
            long expectedModelVtable = _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;
            long strictSpaceNodeVtable = _mem.BaseAddress + SPACE_NODE_VTABLE_RVA;
            TargetSnapshot anchor = snapshot[0];

            foreach (ModelRecord model in _models.Values.ToArray())
            {
                if (model.LastMotionSampleRound == _sample) continue;
                model.LastMotionSampleRound = _sample;

                if (!TryReadQword(model.Model, out long modelVtable) || modelVtable != expectedModelVtable)
                {
                    Write($"[STAGE78][CACHED-CANDIDATE-SKIP] round={_sample} model=0x{model.Model:X} reason=MODEL_VTABLE_NO_LONGER_EXACT vtable={(modelVtable != 0 ? $"0x{modelVtable:X}" : "UNREADABLE")} nodeCount={model.Nodes.Count}");
                    continue;
                }
                if (!TryReadQword(model.Model + MODEL_SPACE_NODE, out long currentRoot) || !IsFollowablePointer(currentRoot))
                {
                    Write($"[STAGE78][CACHED-CANDIDATE-SKIP] round={_sample} model=0x{model.Model:X} reason=ROOT_POINTER_INVALID");
                    continue;
                }
                if (!TryReadBytes(currentRoot, 0x200, out byte[] rootBytes))
                {
                    Write($"[STAGE78][CACHED-CANDIDATE-SKIP] round={_sample} model=0x{model.Model:X} root=0x{currentRoot:X} reason=ROOT_READ_FAILED");
                    continue;
                }
                long currentRootVtable = ReadQword(rootBytes, 0);
                long currentRootOwner = ReadQword(rootBytes, SPACE_MODEL);
                if (currentRootOwner != model.Model ||
                    (currentRootVtable != model.RootVtable && currentRootVtable != strictSpaceNodeVtable))
                {
                    Write($"[STAGE78][CACHED-CANDIDATE-SKIP] round={_sample} model=0x{model.Model:X} root=0x{currentRoot:X} rootVtable=0x{currentRootVtable:X} rootOwner=0x{currentRootOwner:X} expectedOwner=0x{model.Model:X} reason=ROOT_TYPE_OR_RECIPROCAL_OWNER_MISMATCH");
                    continue;
                }

                string rootSource = model.RootTransformSource;
                float rootX = 0f, rootY = 0f, rootZ = 0f;
                bool rootPositionValid = !string.IsNullOrEmpty(rootSource) &&
                    TryReadWorldPositionBySource(rootBytes, rootSource, anchor.X, anchor.Y, anchor.Z,
                        float.MaxValue, out rootX, out rootY, out rootZ);
                if (!rootPositionValid)
                {
                    rootPositionValid = TryInspectTransformFromBuffer(rootBytes, out rootSource,
                        out rootX, out rootY, out rootZ);
                }
                if (!rootPositionValid)
                {
                    Write($"[STAGE78][CACHED-CANDIDATE-SKIP] round={_sample} model=0x{model.Model:X} root=0x{currentRoot:X} reason=ROOT_TRANSFORM_UNREADABLE");
                    continue;
                }

                TargetSnapshot associated = FindNearestTarget(snapshot, rootX, rootY, rootZ, out float rootDistance);
                if (associated == null)
                    associated = snapshot.FirstOrDefault(e => model.EntityIds.Contains(e.Id) || model.SourceEntityIds.Contains(e.Id)) ?? anchor;
                model.EntityIds.Add(associated.Id);
                model.NearestAssociationRoundCounts[associated.Id] =
                    model.NearestAssociationRoundCounts.TryGetValue(associated.Id, out int associationCount) ? associationCount + 1 : 1;
                if (float.IsFinite(rootDistance)) model.NearestRootDistances.Add(rootDistance);
                model.LastRootDistance = rootDistance;

                Write($"[STAGE78][ASSOCIATION-SAMPLE] round={_sample} model=0x{model.Model:X} root=0x{currentRoot:X} nearestEntityId=0x{associated.Id:X8} rootDistance={(float.IsFinite(rootDistance) ? rootDistance.ToString("F3") : "N/A")} samplesForEntity={model.NearestAssociationRoundCounts[associated.Id]} associationIsNearestSnapshot=1");

                if (currentRoot != model.Root)
                {
                    Write($"[STAGE78][CACHED-ROOT-CHANGED] round={_sample} model=0x{model.Model:X} oldRoot=0x{model.Root:X} newRoot=0x{currentRoot:X} action=discard-old-node-cache-and-rebuild");
                    model.Root = currentRoot;
                    model.RootVtable = currentRootVtable;
                    model.RootTransformSource = rootSource;
                    model.Nodes.Clear();
                    model.EdgeKeys.Clear();
                    model.Edges = 0;
                    model.SampleCount = 0;
                    model.HasPreviousTarget = false;
                    model.ArticulatingNodeCount = 0;
                    model.ArticulationVerified = false;
                    var validation = new CandidateValidation
                    {
                        Model = model.Model,
                        Root = currentRoot,
                        RootVtable = currentRootVtable,
                        RootOwner = currentRootOwner,
                        RootRead = true,
                        RootVtableRead = true,
                        RootOwnerRead = true,
                        RootValidated = true,
                        RootPositionValid = true,
                        RootTransformSource = rootSource,
                        RootX = rootX,
                        RootY = rootY,
                        RootZ = rootZ,
                        RootDistance = rootDistance
                    };
                    DiscoverOwnedHierarchy(model, associated, validation);
                    if (model.Nodes.TryGetValue(model.Root, out NodeRecord rootNode))
                        model.RootTransformSource = rootNode.TransformSource;
                }
                else
                {
                    model.RootVtable = currentRootVtable;
                    model.RootTransformSource = rootSource;
                }

                Write($"[STAGE78][CACHED-CANDIDATE] round={_sample} model=0x{model.Model:X} root=0x{model.Root:X} associatedEntityId=0x{associated.Id:X8} rootDistance={rootDistance:F3} rootOwner=0x{currentRootOwner:X} nodeCount={model.Nodes.Count} vtableValidated=1 reciprocalRootValidated=1 poseSample=1");
                SampleNodeMotion(model, associated);
            }
        }

        private void SampleNodeMotion(ModelRecord model, TargetSnapshot target)
        {
            const int sampleBytes = 0x200; // vtable, owner, matrix and translation fields only
            long strictSpaceNodeVtable = _mem.BaseAddress + SPACE_NODE_VTABLE_RVA;
            var current = new Dictionary<long, (float X, float Y, float Z, float RootDistance)>();
            byte[] rootBytes = null;
            if (!TryReadBytes(model.Root, sampleBytes, out rootBytes))
            {
                model.LastValidNodeCount = 0;
                model.LastNodesWithin128 = 0;
                Write($"[STAGE78][POSE-SAMPLE-SKIPPED] round={_sample} model=0x{model.Model:X} root=0x{model.Root:X} reason=ROOT_READ_FAILED");
                return;
            }
            string rootSource = model.RootTransformSource;
            float rootX = 0f, rootY = 0f, rootZ = 0f;
            if (string.IsNullOrEmpty(rootSource) ||
                !TryReadWorldPositionBySource(rootBytes, rootSource, target.X, target.Y, target.Z,
                    float.MaxValue, out rootX, out rootY, out rootZ))
            {
                if (!TryInspectTransformFromBuffer(rootBytes, out rootSource, out rootX, out rootY, out rootZ))
                {
                    model.LastValidNodeCount = 0;
                    model.LastNodesWithin128 = 0;
                    Write($"[STAGE78][POSE-SAMPLE-SKIPPED] round={_sample} model=0x{model.Model:X} root=0x{model.Root:X} reason=ROOT_TRANSFORM_INVALID");
                    return;
                }
                model.RootTransformSource = rootSource;
            }
            current[model.Root] = (rootX, rootY, rootZ, 0f);

            foreach (NodeRecord node in model.Nodes.Values)
            {
                if (node.Ptr == model.Root) continue;
                if (!TryReadBytes(node.Ptr, sampleBytes, out byte[] bytes))
                {
                    Write($"[STAGE78][NODE-SAMPLE-SKIPPED] round={_sample} model=0x{model.Model:X} node=0x{node.Ptr:X} reason=NODE_READ_FAILED");
                    continue;
                }
                long vtable = ReadQword(bytes, 0);
                if (vtable != node.Vtable || (vtable != model.RootVtable && vtable != strictSpaceNodeVtable))
                {
                    Write($"[STAGE78][NODE-SAMPLE-SKIPPED] round={_sample} model=0x{model.Model:X} node=0x{node.Ptr:X} previousVtable=0x{node.Vtable:X} currentVtable=0x{vtable:X} reason=NODE_VTABLE_CHANGED");
                    continue;
                }
                long owner = ReadQword(bytes, SPACE_MODEL);
                if (owner != node.Owner)
                    Write($"[STAGE78][NODE-OWNER-CHANGED] round={_sample} model=0x{model.Model:X} node=0x{node.Ptr:X} oldOwner=0x{node.Owner:X} newOwner=0x{owner:X}");
                node.Owner = owner;
                string source = node.TransformSource;
                float x = 0f, y = 0f, z = 0f;
                if (string.IsNullOrEmpty(source) ||
                    !TryReadWorldPositionBySource(bytes, source, target.X, target.Y, target.Z,
                        float.MaxValue, out x, out y, out z))
                {
                    if (!TryInspectTransformFromBuffer(bytes, out source, out x, out y, out z))
                    {
                        Write($"[STAGE78][NODE-SAMPLE-SKIPPED] round={_sample} model=0x{model.Model:X} node=0x{node.Ptr:X} reason=NODE_TRANSFORM_INVALID");
                        continue;
                    }
                    node.TransformSource = source;
                }
                float distance = Distance(rootX, rootY, rootZ, x, y, z);
                current[node.Ptr] = (x, y, z, distance);
            }

            int validNodes = current.Count;
            int nearRootNodes = current.Values.Count(p => float.IsFinite(p.RootDistance) && p.RootDistance <= MAX_TARGET_NODE_DISTANCE);
            model.LastValidNodeCount = validNodes;
            model.LastNodesWithin128 = nearRootNodes;

            bool havePreviousRoot = model.HasPreviousTarget;
            float rootDx = havePreviousRoot ? rootX - model.PreviousTargetX : 0f;
            float rootDy = havePreviousRoot ? rootY - model.PreviousTargetY : 0f;
            float rootDz = havePreviousRoot ? rootZ - model.PreviousTargetZ : 0f;
            model.SampleCount++;

            foreach (NodeRecord node in model.Nodes.Values)
            {
                if (!current.TryGetValue(node.Ptr, out var pose)) continue;
                float x = pose.X, y = pose.Y, z = pose.Z;
                float rx = x - rootX, ry = y - rootY, rz = z - rootZ;
                node.Samples++;
                if (!node.HasLastRelative)
                {
                    node.FirstRelX = rx; node.FirstRelY = ry; node.FirstRelZ = rz; node.HasLastRelative = true;
                }
                else
                {
                    float dx = rx - node.LastRelX, dy = ry - node.LastRelY, dz = rz - node.LastRelZ;
                    float step = MathF.Sqrt(dx * dx + dy * dy + dz * dz);
                    if (float.IsFinite(step) && step > node.MaxRelativeStep) node.MaxRelativeStep = step;
                }
                node.LastRelX = rx; node.LastRelY = ry; node.LastRelZ = rz;
                if (node.Ptr != model.Root && node.HasPreviousWorld && havePreviousRoot)
                {
                    float relativeDx = (x - node.LastWorldX) - rootDx;
                    float relativeDy = (y - node.LastWorldY) - rootDy;
                    float relativeDz = (z - node.LastWorldZ) - rootDz;
                    float relativeStep = MathF.Sqrt(relativeDx * relativeDx + relativeDy * relativeDy + relativeDz * relativeDz);
                    if (float.IsFinite(relativeStep))
                    {
                        node.TotalRelativeStep += relativeStep;
                        if (relativeStep >= MOVEMENT_EPSILON) node.MovingSteps++;
                    }
                }
                node.LastWorldX = x; node.LastWorldY = y; node.LastWorldZ = z; node.HasPreviousWorld = true;
                Write($"[STAGE78][NODE-POSE] round={_sample} associatedEntityId=0x{target.Id:X8} model=0x{model.Model:X} root=0x{model.Root:X} node=0x{node.Ptr:X} vtable=0x{node.Vtable:X} depth={node.Depth} parent=0x{node.Parent:X} parentOffset=+0x{node.ParentOffset:X} owner=0x{node.Owner:X} ownerMatchesModel={(node.Owner == model.Model ? 1 : 0)} cachedSource={node.TransformSource} world=({x:F3},{y:F3},{z:F3}) rootDistance={pose.RootDistance:F3} within128OfRoot={(pose.RootDistance <= MAX_TARGET_NODE_DISTANCE ? 1 : 0)} relativeToRoot=({rx:F3},{ry:F3},{rz:F3}) accumulatedRootRelativeMotion={node.TotalRelativeStep:F4}");
            }

            model.PreviousTargetX = rootX; model.PreviousTargetY = rootY; model.PreviousTargetZ = rootZ;
            model.HasPreviousTarget = true;
            model.ArticulatingNodeCount = model.Nodes.Values.Count(n => n.Ptr != model.Root && current.ContainsKey(n.Ptr) && n.HasPreviousWorld &&
                (n.TotalRelativeStep >= ARTICULATION_TOTAL_RELATIVE_MOTION ||
                 (n.TotalRelativeStep >= ARTICULATION_RELATIVE_STEP && model.SampleCount >= MIN_ARTICULATION_SAMPLES)));
            if (!model.ArticulationVerified && model.SampleCount >= MIN_ARTICULATION_SAMPLES &&
                validNodes >= MIN_ARTICULATED_NODES && model.ArticulatingNodeCount >= MIN_ARTICULATED_NODES)
            {
                model.ArticulationVerified = true;
                Write($"[STAGE78][RELATIVE-MOTION-GATE] model=0x{model.Model:X} associatedEntityId=0x{target.Id:X8} samples={model.SampleCount} validNodesAllDistances={validNodes} nodesWithin128={nearRootNodes} relativeMovingNodes={model.ArticulatingNodeCount} accepted=1 meaning=relative-motion-evidence-only anatomicalBonesProven=0");
            }
            Write($"[STAGE78][MOTION-SUMMARY] round={_sample} model=0x{model.Model:X} associatedEntityId=0x{target.Id:X8} sampleCount={model.SampleCount} validNodesAllDistances={validNodes} nodesWithin128OfRoot={nearRootNodes} relativeMovingNodes={model.ArticulatingNodeCount} relativeMotionGatePassed={(model.ArticulationVerified ? 1 : 0)}");
        }

        private void EmitFinal()
        {
            int validatedModels = _models.Values.Count(m => m.Validations > 0);
            int connectedGraphModels = _models.Values.Count(m => m.Edges > 0);
            int hierarchyModels = _models.Values.Count(m => m.Nodes.Count > 1 && m.Edges > 0);
            Write("------------------------------------------------------------");
            int modelsWithSixNodes = _models.Values.Count(m => m.Nodes.Count >= 6);
            int modelsWithMotionEvidence = _models.Values.Count(m => m.ArticulatingNodeCount > 0);
            int modelsPassingArticulationGate = _models.Values.Count(m => m.ArticulationVerified);
            int rawIdMatchesTotal = _entityStats.Values.Sum(entity => entity.RawIdMatches);
            int allExactVtableHits = _offsetStats.Values.Sum(stats => stats.ExactModelHits);
            int runtimeRouteExactVtableHits = _offsetStats["BGA+0x0D8"].ExactModelHits +
                _offsetStats["MODEL_ARRAY"].ExactModelHits + _offsetStats["BGA+0x0B8_GRAPH"].ExactModelHits;
            int supplementalExactVtableHits = _offsetStats.Values
                .Where(stats => stats.Source.StartsWith("bridge+", StringComparison.Ordinal))
                .Sum(stats => stats.ExactModelHits);
            Write($"[STAGE78][FINAL][SUMMARY] rounds={_sample} roundsWithEnemySnapshots={_nonEmptySnapshotRounds} emptySnapshotRounds={_emptySnapshotRounds} entityObservations={_entityObservations} distinctEntityIds={_entityStats.Count} rawIdMatches={rawIdMatchesTotal} rawIdMismatches={_rawIdMismatches} rawPositionCloseToSnapshot={_positionCloseHits} liveResolverSelectionObservations={_liveResolverSelectionObservations} liveResolverSelectedEntities={_entityStats.Values.Count(e => e.LiveResolverSelections > 0)} exactModelVtableHitsByRoute={allExactVtableHits} liveResolverRouteExactHits={runtimeRouteExactVtableHits} supplementalBridgeExactHits={supplementalExactVtableHits} candidatesScheduledForRootInspection={_exactModelHits} reciprocalRootValidHits={_rootValidatedHits} rootWithinRuntimeRadiusHits={_rootWithinRuntimeRadiusHits} distinctReciprocalRootModels={_models.Count} modelsWithValidatedRoot={validatedModels} modelsWithConnectedExactTypeGraphs={connectedGraphModels} modelsWithConnectedMultiNodeGraphs={hierarchyModels} modelsWithSixNodes={modelsWithSixNodes} modelsWithRelativeMotion={modelsWithMotionEvidence} modelsPassingArticulationGate={modelsPassingArticulationGate} nearestRootDistance={(_nearestRootDistance < float.MaxValue ? _nearestRootDistance : -1f):F3}");
            foreach (OffsetStats stats in _offsetStats.Values.OrderBy(s => SourceOrder(s.Source)))
            {
                string topVtables = string.Join(",", stats.VtableCounts.OrderByDescending(kv => kv.Value).ThenBy(kv => kv.Key).Take(4).Select(kv => $"0x{kv.Key:X}:{kv.Value}"));
                string commonModels = string.Join(",", stats.ModelPointerCounts.OrderByDescending(kv => kv.Value).ThenBy(kv => kv.Key).Take(4).Select(kv => $"0x{kv.Key:X}:{kv.Value}"));
                Write($"[STAGE78][FINAL][OFFSET] source={stats.Source} reads={stats.Reads} readFailures={stats.ReadFailures} pointerLike={stats.PointerLike} vtableReads={stats.VtableReads} vtableReadFailures={stats.VtableReadFailures} exactModelVtableHits={stats.ExactModelHits} topVtables=[{topVtables}] recurringFieldValues=[{commonModels}]");
            }
            foreach (EntityStats entity in _entityStats.Values.OrderByDescending(e => e.ExactModels).ThenByDescending(e => e.RuntimeRadiusRoots).ThenBy(e => e.Id))
            {
                string bgaPtrs = string.Join(",", entity.BgaPointers.OrderBy(p => p).Select(p => $"0x{p:X}"));
                string modelPtrs = string.Join(",", entity.ModelPointers.OrderBy(p => p).Select(p => $"0x{p:X}"));
                string sources = string.Join(",", entity.ExactSources.OrderBy(s => s, StringComparer.Ordinal));
                string resolverModels = string.Join(",", entity.LiveResolverModels.OrderBy(p => p).Select(p => $"0x{p:X}"));
                string resolverPaths = string.Join(",", entity.ResolverPaths.OrderBy(s => s, StringComparer.Ordinal));
                Write($"[STAGE78][FINAL][ENTITY] entityId=0x{entity.Id:X8} observations={entity.Observations} bgaReads={entity.BgaReads} rawIdMatches={entity.RawIdMatches} rawIdMismatches={entity.RawIdMismatches} graphPointers={entity.GraphPointers} bridgePointers={entity.BridgePointers} rawPositionClose={entity.PositionClose} rawPositionFar={entity.PositionFar} liveResolverSelections={entity.LiveResolverSelections} liveResolverModels=[{resolverModels}] resolverPaths=[{resolverPaths}] exactModelCandidates={entity.ExactModels} reciprocalRoots={entity.ValidRoots} runtimeRadiusRoots={entity.RuntimeRadiusRoots} distinctBgaPointers={entity.BgaPointers.Count} bgaPointers=[{bgaPtrs}] modelPointers=[{modelPtrs}] sources=[{sources}]");
            }
            foreach (ModelRecord model in _models.Values.OrderByDescending(m => m.Validations).ThenBy(m => m.Model))
            {
                string ids = string.Join(",", model.EntityIds.OrderBy(id => id).Select(id => $"0x{id:X8}"));
                string sourceIds = string.Join(",", model.SourceEntityIds.OrderBy(id => id).Select(id => $"0x{id:X8}"));
                string sources = string.Join(",", model.Sources.OrderBy(s => s, StringComparer.Ordinal));
                var dominantAssociation = model.NearestAssociationRoundCounts.OrderByDescending(kv => kv.Value).ThenBy(kv => kv.Key).FirstOrDefault();
                int associationSamples = model.NearestAssociationRoundCounts.Values.Sum();
                double dominantAssociationPct = associationSamples > 0 ? dominantAssociation.Value * 100.0 / associationSamples : 0.0;
                List<float> finiteRootDistances = model.NearestRootDistances.Where(float.IsFinite).OrderBy(d => d).ToList();
                float medianRootDistance = finiteRootDistances.Count == 0 ? float.NaN :
                    (finiteRootDistances.Count % 2 == 1 ? finiteRootDistances[finiteRootDistances.Count / 2] :
                    (finiteRootDistances[finiteRootDistances.Count / 2 - 1] + finiteRootDistances[finiteRootDistances.Count / 2]) * 0.5f);
                int rootOwnerMatchedNodes = model.Nodes.Values.Count(n => n.Ptr != model.Root && n.Owner == model.Model);
                int rootOwnerTestedNodes = model.Nodes.Values.Count(n => n.Ptr != model.Root);
                Write($"[STAGE78][FINAL][MODEL] model=0x{model.Model:X} root=0x{model.Root:X} rootVtable=0x{model.RootVtable:X} nearestAssociatedEntityIds=[{ids}] sourceEntityIds=[{sourceIds}] sources=[{sources}] rootValidations={model.Validations} graphNodeCount={model.Nodes.Count} graphEdgeCount={model.Edges} sampleCount={model.SampleCount} lastValidNodesAllDistances={model.LastValidNodeCount} lastNodesWithin128={model.LastNodesWithin128} childOwnerMatchesModel={rootOwnerMatchedNodes}/{rootOwnerTestedNodes} relativeMovingNodes={model.ArticulatingNodeCount} broadRelativeMotionGatePassed={(model.ArticulationVerified ? 1 : 0)} nearestAssociationSamples={associationSamples} dominantNearestEntityId={(dominantAssociation.Value > 0 ? $"0x{dominantAssociation.Key:X8}" : "N/A")} dominantAssociationCount={dominantAssociation.Value} dominantAssociationPct={dominantAssociationPct:F1} rootDistancesWithin128={finiteRootDistances.Count(d => d <= MAX_RUNTIME_ROOT_DISTANCE)} nearestRootDistanceMedian={(float.IsFinite(medianRootDistance) ? medianRootDistance.ToString("F3") : "N/A")} nearestRootDistanceMin={(finiteRootDistances.Count > 0 ? finiteRootDistances[0].ToString("F3") : "N/A")} nearestRootDistanceMax={(finiteRootDistances.Count > 0 ? finiteRootDistances[^1].ToString("F3") : "N/A")} lastNearestRootDistance={(float.IsFinite(model.LastRootDistance) ? model.LastRootDistance : -1f):F3} closureScans={model.ClosureScans}");
                foreach (NodeRecord node in model.Nodes.Values.OrderBy(n => n.Depth).ThenBy(n => n.Ptr))
                    Write($"[STAGE78][FINAL][NODE-MOTION] model=0x{model.Model:X} node=0x{node.Ptr:X} vtable=0x{node.Vtable:X} depth={node.Depth} parent=0x{node.Parent:X} parentOffset=+0x{node.ParentOffset:X} owner=0x{node.Owner:X} ownerMatchesModel={(node.Owner == model.Model ? 1 : 0)} source={node.TransformSource} samples={node.Samples} movingSteps={node.MovingSteps} totalRootRelativeMotion={node.TotalRelativeStep:F4} maxRootRelativeStep={node.MaxRelativeStep:F4} firstRelativeToRoot=({node.FirstRelX:F3},{node.FirstRelY:F3},{node.FirstRelZ:F3}) lastRelativeToRoot=({node.LastRelX:F3},{node.LastRelY:F3},{node.LastRelZ:F3})");
            }
            string verdict;
            if (_entityObservations == 0) verdict = "NO_VALID_ENEMY_SNAPSHOTS_NO_ROUTE_TESTED";
            else if (rawIdMatchesTotal == 0) verdict = "NO_RAW_BGA_ID_MATCHES_MODEL_ROUTE_NOT_TESTED";
            else if (_exactModelHits == 0) verdict = "NO_EXACT_MODELSKELETAL_CANDIDATES_IN_ANY_TESTED_ROUTE";
            else if (_rootValidatedHits == 0) verdict = "EXACT_MODEL_CANDIDATES_FOUND_BUT_NO_RECIPROCAL_MODEL_ROOT_VALIDATED";
            else if (connectedGraphModels == 0) verdict = "RECIPROCAL_MODEL_ROOTS_FOUND_BUT_NO_CONNECTED_EXACT_TYPE_NODE_EDGES";
            else if (hierarchyModels == 0) verdict = "EXACT_TYPE_NODE_EDGES_FOUND_BUT_TRANSFORMED_NODE_SET_IS_INSUFFICIENT";
            else if (_models.Values.Any(m => m.ArticulationVerified)) verdict = "CONNECTED_NODE_GRAPH_AND_ROOT_RELATIVE_MOTION_GATE_MET_REVIEW_ANATOMICAL_MAPPING";
            else if (_models.Values.Any(m => m.Nodes.Count >= 2 && m.Nodes.Count <= 5 && m.ArticulatingNodeCount > 0)) verdict = "SMALL_CONNECTED_NODE_GRAPH_SHOWS_RELATIVE_MOTION_REVIEW_NODE_THRESHOLD";
            else if (_models.Values.Any(m => m.Nodes.Count >= 6)) verdict = "SIX_OR_MORE_EXACT_TYPE_NODES_FOUND_BUT_RELATIVE_MOTION_GATE_NOT_MET";
            else verdict = "RECIPROCAL_ROOTS_FOUND_BUT_TOO_FEW_TRANSFORMED_CONNECTED_NODES";
            Write($"[STAGE78][FINAL][VERDICT] {verdict} candidateSourcesCombined=1 legacyBgaWrapperRoutes=1 graphEdgeScan=all-qword-fields-within-verified-SpaceNode-extent nodeObjectBytes=0x{NODE_OBJECT_BYTES:X} outOfBoundsLinksExcluded=1 relativeMotionReference=root rootDistanceIsDiscoveryFilter=0 nodeOwnerIsDiscoveryFilter=0 liveResolverSelectionRequiredForVerdict=0 runtimeReaderChanged=0 rendererChanged=0 anatomicalHierarchyProven=0");
            Write("[STAGE78][FINAL][LIMIT] Stage 77 read 0x1000 bytes per SpaceNode and treated offsets beyond the established 0x620 object extent as links. Stage 78 excludes those out-of-bounds fields. An exact typed edge or broad relative-motion gate still does not prove an anatomical joint.");
            Write("[STAGE78][FINAL][NEXT] prioritize graphs whose in-bounds links follow historically observed edge offsets, whose root stays near one dominant enemy ID across rounds, whose child transforms cluster near the root, and whose node ownership is consistent; do not integrate into the renderer until coherent articulated movement is proven");
            Write("============================================================");
            lock (_sync) { try { _writer?.Flush(); } catch { } }
        }

        private bool TryReadQword(long address, out long value)
        {
            value = 0;
            if (!IsFollowablePointer(address)) return false;
            return _mem.ReadBytesQuiet(address, _scratch8, 0, 8) && AssignQword(_scratch8, out value);
        }

        private bool TryReadBytes(long address, int size, out byte[] bytes)
        {
            bytes = null;
            if (!IsFollowablePointer(address) || size <= 0 || size > 0x1000) return false;
            var buffer = new byte[size];
            if (!_mem.ReadBytesQuiet(address, buffer, 0, size)) return false;
            bytes = buffer;
            return true;
        }

        private static bool TryReadWorldPositionBySource(
            byte[] buffer, string source, float targetX, float targetY, float targetZ, float maxDistance,
            out float x, out float y, out float z)
        {
            x = y = z = 0f;
            if (string.Equals(source, "WorldMatrix148", StringComparison.Ordinal))
            {
                if (!TryDecodeMatrixTranslation(buffer, SPACE_WORLD_MATRIX, out x, out y, out z)) return false;
            }
            else
            {
                if (buffer == null || SPACE_WORLD_TRANSLATION + 12 > buffer.Length) return false;
                x = BitConverter.ToSingle(buffer, SPACE_WORLD_TRANSLATION + 0);
                y = BitConverter.ToSingle(buffer, SPACE_WORLD_TRANSLATION + 4);
                z = BitConverter.ToSingle(buffer, SPACE_WORLD_TRANSLATION + 8);
                if (!IsValidCoordinate(x) || !IsValidCoordinate(y) || !IsValidCoordinate(z)) return false;
            }
            return maxDistance >= MAX_WORLD_COORD || Distance(targetX, targetY, targetZ, x, y, z) <= maxDistance;
        }

        private static bool TryInspectTransformFromBuffer(byte[] buffer, out string source, out float x, out float y, out float z)
        {
            source = "N/A"; x = y = z = 0f;
            if (TryDecodeMatrixTranslation(buffer, SPACE_WORLD_MATRIX, out x, out y, out z))
            {
                source = "WorldMatrix148";
                return true;
            }
            if (buffer != null && SPACE_WORLD_TRANSLATION + 12 <= buffer.Length)
            {
                float tx = BitConverter.ToSingle(buffer, SPACE_WORLD_TRANSLATION + 0);
                float ty = BitConverter.ToSingle(buffer, SPACE_WORLD_TRANSLATION + 4);
                float tz = BitConverter.ToSingle(buffer, SPACE_WORLD_TRANSLATION + 8);
                if (IsValidCoordinate(tx) && IsValidCoordinate(ty) && IsValidCoordinate(tz))
                {
                    source = "Translation178"; x = tx; y = ty; z = tz;
                    return true;
                }
            }
            return false;
        }

        // Mirrors DynamicSkeletonReader.TrySelectTransformSourceFromBuffer: matrix first,
        // then +0x178 translation fallback, accepting only transforms within maxDistance.
        private static bool TrySelectTransformSourceFromBuffer(
            byte[] buffer, float targetX, float targetY, float targetZ, float maxDistance,
            out string source, out float x, out float y, out float z, out bool hadTooFarTransform)
        {
            source = "Translation178"; x = y = z = 0f; hadTooFarTransform = false;
            if (TryDecodeMatrixTranslation(buffer, SPACE_WORLD_MATRIX, out float mx, out float my, out float mz))
            {
                float d = Distance(targetX, targetY, targetZ, mx, my, mz);
                if (float.IsFinite(d) && d <= maxDistance)
                {
                    source = "WorldMatrix148"; x = mx; y = my; z = mz;
                    return true;
                }
                if (float.IsFinite(d)) hadTooFarTransform = true;
            }
            if (buffer != null && SPACE_WORLD_TRANSLATION + 12 <= buffer.Length)
            {
                float tx = BitConverter.ToSingle(buffer, SPACE_WORLD_TRANSLATION + 0);
                float ty = BitConverter.ToSingle(buffer, SPACE_WORLD_TRANSLATION + 4);
                float tz = BitConverter.ToSingle(buffer, SPACE_WORLD_TRANSLATION + 8);
                if (IsValidCoordinate(tx) && IsValidCoordinate(ty) && IsValidCoordinate(tz))
                {
                    float d = Distance(targetX, targetY, targetZ, tx, ty, tz);
                    if (float.IsFinite(d) && d <= maxDistance)
                    {
                        source = "Translation178"; x = tx; y = ty; z = tz;
                        return true;
                    }
                    if (float.IsFinite(d)) hadTooFarTransform = true;
                }
            }
            return false;
        }

        private static bool TryDecodeMatrixTranslation(byte[] buffer, int offset, out float x, out float y, out float z)
        {
            x = y = z = 0f;
            if (buffer == null || offset < 0 || offset + MATRIX_BYTES > buffer.Length) return false;
            for (int i = 0; i < 16; i++)
                if (!float.IsFinite(BitConverter.ToSingle(buffer, offset + i * 4))) return false;
            x = BitConverter.ToSingle(buffer, offset + 0x30);
            y = BitConverter.ToSingle(buffer, offset + 0x34);
            z = BitConverter.ToSingle(buffer, offset + 0x38);
            float w = BitConverter.ToSingle(buffer, offset + 0x3C);
            return IsValidCoordinate(x) && IsValidCoordinate(y) && IsValidCoordinate(z) && float.IsFinite(w) && MathF.Abs(w) > 0.0001f;
        }

        private static float Distance(float x1, float y1, float z1, float x2, float y2, float z2)
        {
            float dx = x1 - x2, dy = y1 - y2, dz = z1 - z2;
            return MathF.Sqrt(dx * dx + dy * dy + dz * dz);
        }

        private static bool IsFollowablePointer(long value) => value >= 0x10000 && value < 0x0000800000000000L;

        private string FormatVtableRva(long vtable)
        {
            long baseAddress = _mem.BaseAddress;
            return vtable >= baseAddress && vtable - baseAddress < 0x10000000
                ? $"0x{vtable - baseAddress:X}"
                : "OUTSIDE_MODULE";
        }

        private void Write(string message)
        {
            try { _writer?.WriteLine($"{DateTimeOffset.Now:O} {message}"); } catch { }
            SafeConsole(message);
        }

        private static TargetSnapshot Copy(TargetSnapshot e) => e == null ? null : new TargetSnapshot { Ptr = e.Ptr, Id = e.Id, X = e.X, Y = e.Y, Z = e.Z, Distance = e.Distance };
        private static long ReadQword(byte[] bytes, int offset) => bytes != null && offset >= 0 && offset + 8 <= bytes.Length ? BitConverter.ToInt64(bytes, offset) : 0;
        private static bool AssignQword(byte[] bytes, out long value) { value = 0; if (bytes == null || bytes.Length < 8) return false; value = BitConverter.ToInt64(bytes, 0); return true; }
        private static bool IsPtr(long value) => value >= 0x10000 && value < 0x0000800000000000L && (value & 7L) == 0;
        private static bool IsValidCoordinate(float value) => float.IsFinite(value) && MathF.Abs(value) <= MAX_WORLD_COORD;
        private static int SourceOrder(string source)
        {
            int marker = source.IndexOf("0x", StringComparison.Ordinal);
            if (marker < 0) return 0x20000;
            int start = marker + 2;
            int end = start;
            while (end < source.Length && Uri.IsHexDigit(source[end])) end++;
            if (end == start) return 0x20000;
            int offset = Convert.ToInt32(source.Substring(start, end - start), 16);
            return source.StartsWith("BGA", StringComparison.Ordinal) ? 0x10000 + offset : offset;
        }
        private static void SafeConsole(string message) { try { Console.WriteLine(message); } catch { } }

        public void Dispose()
        {
            if (Interlocked.Exchange(ref _disposed, 1) != 0) return;
            try { _timer?.Change(Timeout.Infinite, Timeout.Infinite); } catch { }
            try { _timer?.Dispose(); } catch { }
            lock (_sync) { try { _writer?.Flush(); } catch { } try { _writer?.Dispose(); } catch { } _writer = null; }
        }
    }
}

using System;
using System.Collections.Generic;
using ROS64Hack.Engine;

namespace ROS64Hack.Core
{
    /// <summary>
    /// Low-volume, per-entity diagnostics for the skeleton pipeline. Logs outcome changes
    /// immediately and repeats persistent failures every few seconds, avoiding per-frame spam.
    /// Opt in with ROS64HACK_SKELETON_COVERAGE=1 before launch. Disabled by default
    /// so repeated per-entity state transitions do not add synchronous console I/O to
    /// normal runtime. Compact RuntimeDiagnostics summaries remain available.
    /// </summary>
    internal static class SkeletonCoverageTrace
    {
        private const long FailureRepeatIntervalMs = 3000;
        private const long StateRetentionMs = 60000;
        private const long PruneIntervalMs = 10000;
        private const int MaximumTrackedStates = 2048;

        private sealed class State
        {
            public string Outcome;
            public long LastLogMs;
            public long LastSeenMs;
        }

        private static readonly bool Enabled = string.Equals(
            Environment.GetEnvironmentVariable("ROS64HACK_SKELETON_COVERAGE"),
            "1",
            StringComparison.Ordinal);
        internal static bool IsEnabled => Enabled;

        private static readonly object Sync = new();
        private static readonly Dictionary<(long Entity, uint EntityId, string Phase), State> States = new();
        private static long _lastPruneMs;

        public static void Record(
            EntityData entity,
            string phase,
            string outcome,
            string details = null,
            bool failure = false)
        {
            if (!Enabled || entity == null || entity.Ptr == 0 ||
                string.IsNullOrWhiteSpace(phase) || string.IsNullOrWhiteSpace(outcome))
                return;

            long now = Environment.TickCount64;
            bool shouldWrite = false;
            lock (Sync)
            {
                var key = (entity.Ptr, entity.EntityId, phase);
                if (!States.TryGetValue(key, out State state))
                {
                    state = new State();
                    States[key] = state;
                    shouldWrite = true;
                }
                else if (!string.Equals(state.Outcome, outcome, StringComparison.Ordinal))
                {
                    shouldWrite = true;
                }
                else if (failure && now - state.LastLogMs >= FailureRepeatIntervalMs)
                {
                    shouldWrite = true;
                }

                state.Outcome = outcome;
                state.LastSeenMs = now;
                if (shouldWrite)
                    state.LastLogMs = now;

                if (now - _lastPruneMs >= PruneIntervalMs || States.Count > MaximumTrackedStates)
                {
                    var expired = new List<(long Entity, uint EntityId, string Phase)>();
                    foreach (var pair in States)
                    {
                        if (now - pair.Value.LastSeenMs > StateRetentionMs)
                            expired.Add(pair.Key);
                    }
                    foreach (var staleKey in expired)
                        States.Remove(staleKey);

                    if (States.Count > MaximumTrackedStates)
                    {
                        while (States.Count > MaximumTrackedStates)
                        {
                            (long Entity, uint EntityId, string Phase) oldestKey = default;
                            long oldestSeen = long.MaxValue;
                            foreach (var pair in States)
                            {
                                if (pair.Value.LastSeenMs < oldestSeen)
                                {
                                    oldestSeen = pair.Value.LastSeenMs;
                                    oldestKey = pair.Key;
                                }
                            }
                            if (oldestSeen == long.MaxValue)
                                break;
                            States.Remove(oldestKey);
                        }
                    }
                    _lastPruneMs = now;
                }
            }

            if (!shouldWrite)
                return;

            string safeDetails = (details ?? string.Empty).Replace('\r', ' ').Replace('\n', ' ');
            try
            {
                Console.WriteLine(
                    $"  [STAGE80][COVERAGE] phase={phase} outcome={outcome} " +
                    $"entity=0x{entity.Ptr:X} entityId=0x{entity.EntityId:X8} " +
                    $"onScreen={(entity.OnScreen ? 1 : 0)} distance={entity.Distance:F1} " +
                    $"xyz=({entity.X:F2},{entity.Y:F2},{entity.Z:F2}) details={safeDetails}");
            }
            catch
            {
                // Diagnostics must never interrupt skeleton sampling or the overlay loop.
            }
        }
    }
}

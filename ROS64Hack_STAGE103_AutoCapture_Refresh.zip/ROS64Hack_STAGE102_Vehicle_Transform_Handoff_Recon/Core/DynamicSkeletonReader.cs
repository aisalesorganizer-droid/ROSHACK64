using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using ROS64Hack.Engine;
using ROS64Hack.Features;

namespace ROS64Hack.Core
{
    /// <summary>
    /// Evidence-gated target-local skeleton pose reader.
    ///
    /// Reconciled rules:
    ///   1. BGA +0xB8 remains the live native graph anchor.
    ///   2. Entity +0xD8 / +0xE0..+0xE8 are attempted before the bounded BGA graph walk.
    ///   3. ModelSkeletal +0x38 is the candidate root. The root is accepted only when
    ///      its +0x40 reciprocal points back to the same ModelSkeletal and its transform
    ///      is target-local.
    ///   4. SpaceNode +0x148 supplies the root world transform and entity-association
    ///      check only. SpaceNode child pointers are not used as anatomical bone links.
    ///   5. Bone hierarchy comes from SkeletalAnim's native parent/next-sibling/first-child
    ///      table; per-bone model-space matrices come from its native +0xCE0 matrix table.
    ///   6. The root's reciprocal ModelSkeletal ownership and world transform validate the
    ///      entity association. Every bone matrix and hierarchy link is checked before use.
    ///   7. A valid idle pose is accepted; articulation is not a prerequisite for a skeleton.
    ///      Sampling remains independent from camera projection and snapshot painting.
    /// </summary>
    public sealed class DynamicSkeletonReader
    {
        // Detailed graph tracing performs additional remote-memory reads and synchronous
        // file I/O. Keep it entirely out of the normal hot path unless explicitly enabled
        // before process launch for a focused diagnostic capture.
        private static readonly bool DiscoveryTraceEnabled = string.Equals(
            Environment.GetEnvironmentVariable("ROS64HACK_SKELETON_DISCOVERY_TRACE"),
            "1",
            StringComparison.Ordinal);
        // One-shot edge map for a focused live capture. Disabled unless explicitly enabled
        // before launch; it writes exact native parent-child IDs and filter decisions.
        private static readonly bool SkeletonEdgeTraceEnabled = string.Equals(
            Environment.GetEnvironmentVariable("ROS64HACK_SKELETON_EDGE_TRACE"),
            "1",
            StringComparison.Ordinal);
        private static readonly bool BoneIndexDiagnosticsEnabled = string.Equals(
            Environment.GetEnvironmentVariable("ROS64HACK_SKELETON_BONE_INDEX_DIAGNOSTICS"),
            "1",
            StringComparison.Ordinal);
        private const int MAX_SKELETON_EDGE_TRACE_ENTITIES = 1;
        private const int MAX_DIAGNOSTIC_CANDIDATE_SKIP_LOGS = 12;
        private const float HEAD_CLUSTER_DEPTH_SCALE = 0.11f;
        private const float HEAD_CLUSTER_MIN_DEPTH = 1.25f;
        private const float HEAD_CLUSTER_MAX_DEPTH = 3.5f;
        private const float HEAD_CENTER_CORRIDOR_SCALE = 0.18f;
        private const float HEAD_CENTER_CORRIDOR_MIN_PIXELS = 3f;
        // Stage 92: center from the compact head cluster in world space, then project with
        // the same camera snapshot as the pose. Keep the outline tight and perspective-aware.
        private const float HEAD_RADIUS_MIN_SCALE = 0.022f;
        private const float HEAD_RADIUS_SCALE = 0.032f;
        private const float HEAD_RADIUS_MAX_SCALE = 0.065f;
        private const float HEAD_RADIUS_MIN_PIXELS = 2.0f; // Matches the synthetic renderer small-scale head-ring minimum.
        private const float HEAD_RADIUS_PADDING_PIXELS = 0.25f;

        private const int BGA_NATIVE_GRAPH = 0x0B8;
        private const int ENTITY_MODEL = 0x0D8;
        private const int ENTITY_MODELS_BEGIN = 0x0E0;
        private const int ENTITY_MODELS_END = 0x0E8;

        private const int MODEL_SPACE_NODE = 0x038;
        private const int SPACE_MODEL = 0x040;
        private const int SPACE_WORLD_TRANSLATION = 0x178;
        private const int SPACE_WORLD_MATRIX = 0x148;
        private const int MATRIX_BYTES = 0x40;

        // Native rig path confirmed by the captured ros64.exe image:
        // ModelSkeletal +0x660 -> SkeletalAnim; SkeletalAnim +0x30 bone count,
        // +0x32 per-bone hierarchy records, +0xCE0 model-space bone matrices,
        // and +0xCF0 reciprocal owner ModelSkeletal.
        private const int MODEL_SKELETAL_ANIM = 0x660;
        private const int SKELETAL_ANIM_BONE_COUNT = 0x030;
        private const int SKELETAL_ANIM_HIERARCHY = 0x032;
        private const int SKELETAL_ANIM_BONE_MATRICES = 0xCE0;
        private const int SKELETAL_ANIM_MODEL_BACKLINK = 0xCF0;
        private const int BONE_HIERARCHY_RECORD_BYTES = 4;
        private const int BONE_MATRIX_BYTES = 0x40;

        private const long MODEL_SKELETAL_VTABLE_RVA = 0x001C1ACE0;
        private const long SPACE_NODE_VTABLE_RVA = 0x001C137C8;
        private const long SKELETAL_ANIM_VTABLE_RVA = 0x001C1AC30;

        private static readonly int[] NODE_EDGES = { 0x018, 0x318, 0x618 };

        private const int RESOLVE_MAX_DEPTH = 5;
        private const int RESOLVE_MAX_OBJECTS = 128;
        private const int RESOLVE_OBJECT_BYTES = 0x400;
        // Stage 52 is target-owned only. The historical global ModelSkeletal memory scan
        // is removed from the runtime so it cannot be reintroduced accidentally by a
        // disabled flag or stale fallback branch. Focused trace limits remain explicit.
        private const int FOCUSED_TRACE_MAX_CANDIDATES = 8;
        private const int FOCUSED_TRACE_SAMPLE_LIMIT = 40;
        private const int FOCUSED_TRACE_REPORT_INTERVAL = 10;
        private const long FOCUSED_TRACE_SAMPLE_INTERVAL_MS = 250;
        private const long FOCUSED_TRACE_MAX_AGE_MS = 10000;

        // Focused object paths actually observed in the previous captures. These are
        // diagnostic probes, not extra acceptance rules or presumed bone offsets.
        private static readonly int[] MODEL_EVIDENCE_OFFSETS = { 0x3E8 };
        private const int SKELETON_MAX_DEPTH = 7;
        private const int SKELETON_MAX_NODES = 96;
        private const int NODE_PROBE_BYTES = 0x620;

        private const long B8_RECHECK_INTERVAL_MS = 1000;
        private const long ROOT_VALIDATE_INTERVAL_MS = 2000;
        // Failed target-owned model/root lookup is throttled to prevent repeated remote reads
        // for the same unresolved entity.
        private const long FAILED_RESOLVE_RETRY_INTERVAL_MS = 5000;

        private const float MAX_COORD = 50000f;
        // Historical/unclassified node-walk fallback only. Native skeletal rigs must be
        // tightly associated with the entity that supplied their candidate object graph.
        private const float MAX_LEGACY_ROOT_TARGET_DISTANCE = 64f;
        // In verified native captures the SpaceNode world translation matched BGA/entity
        // position; 8 units is a conservative fail-closed allowance for snapshot drift.
        private const float MAX_NATIVE_ROOT_TARGET_DISTANCE = 8f;
        private const float MAX_ROOT_NODE_RADIUS = 128f;
        // Stage 98 edge maps show retained native edges no longer than 6.15 world units.
        // Eight units leaves margin for animation/sample variation while rejecting gross
        // parent-child geometry corruption that the old 160-unit cap admitted.
        private const float MAX_SEGMENT_LENGTH = 8f;
        // In this build, the native hierarchy root is the lowest body anchor in the captured
        // rigs. Permit minor pose noise but reject nodes materially below that ground anchor.
        private const float MAX_BONE_BELOW_NATIVE_ROOT = 1.5f;
        private const int MIN_RENDER_SEGMENTS = 6;

        // Stage 89 exclusion-only pruning. In addition to the compact-subtree filter,
        // identify the skirt-like pelvic fan from topology and geometry: a junction with at
        // least five child branches, one branch containing the upper/head extreme, and one
        // branch containing the lower/foot extreme (the legs may split one level lower).
        // Small intermediate branches from that junction are excluded as whole subtrees. No
        // bone IDs are hard-coded and no links are synthesized or reconnected.
        private const float SMALL_BRANCH_BODY_HEIGHT_SCALE = 0.18f;
        private const float SMALL_BRANCH_MIN_EXTENT = 0.65f;
        private const float SMALL_BRANCH_MAX_EXTENT = 4.00f;
        private const float BODY_EXTREME_GUARD_SCALE = 0.08f;
        private const int PELVIC_FAN_MIN_CHILDREN = 5;
        private const int PELVIC_FAN_MIN_BOTTOM_BRANCHES = 1;
        private const int PELVIC_SKIRT_MAX_SUBTREE_NODES = 5;
        private const float PELVIC_SKIRT_MAX_BRANCH_HEIGHT_SCALE = 0.36f;
        private const float PELVIC_SKIRT_MAX_ROOT_EDGE_SCALE = 0.15f;
        private const float PELVIC_SKIRT_MAX_TOTAL_EXTENT_SCALE = 0.44f;

        // Evidence gate: a target may translate rigidly without being an articulated rig.
        // We require several non-root nodes to demonstrate target-relative movement over
        // multiple samples before exposing the pose to the renderer.
        private const int MIN_ARTICULATED_NODES = 6;
        private const int MIN_ARTICULATION_SAMPLES = 4;
        private const float ARTICULATION_RELATIVE_STEP = 0.05f;
        private const float ARTICULATION_TOTAL_RELATIVE_MOTION = 0.20f;

        private const int PAGE_SIZE = 0x1000;
        private const int MAX_SAMPLE_PAGES = 96;
        private const long PAGE_MASK = ~0xFFFL;

        private readonly Mem _mem;
        private readonly object _resolverEvidenceSync = new();
        private readonly HashSet<long> _resolverEvidenceEntities = new();
        private readonly HashSet<long> _failedResolverTraceEntities = new();
        private readonly HashSet<long> _hierarchyTraceEntities = new();
        private readonly HashSet<long> _modelPathTraceEntities = new();
        private readonly HashSet<long> _skeletonEdgeTraceEntities = new();
        private long _boneDiagnosticTargetPtr;
        private uint _boneDiagnosticTargetEntityId;
        private int _diagnosticCandidateSkipLogCount;
        private const int MAX_RESOLVER_EVIDENCE_ENTITIES = 2;
        private const int MAX_FAILED_RESOLVER_TRACE_ENTITIES = 2;
        private const int MAX_FAILED_TRACE_FRONTIER_PROBES = 512;
        private const int MAX_FAILED_TRACE_MODEL_DETAILS = 32;
        private const int MAX_HIERARCHY_TRACE_ENTITIES = 2;
        private const int MAX_MODEL_PATH_TRACE_ENTITIES = 2;
        private const int MAX_MODEL_ARRAY_EVIDENCE_CANDIDATES = 64;
        private readonly Dictionary<long, ResolutionCache> _cache = new();
        private readonly object _poseLock = new();
        private readonly Dictionary<long, PoseState> _latestPoses = new();
        // Reused only by ApplyLatest (the overlay read thread). This avoids per-frame
        // PointF/bool/pose-array allocations while projecting the latest pose.
        private readonly PointF[] _applyProjected = new PointF[SKELETON_MAX_NODES];
        private readonly bool[] _applyValid = new bool[SKELETON_MAX_NODES];
        private readonly long[] _applyPtrs = new long[SKELETON_MAX_NODES];
        private readonly int[] _applyParents = new int[SKELETON_MAX_NODES];
        private readonly int[] _applyBoneIndices = new int[SKELETON_MAX_NODES];
        private readonly float[] _applyX = new float[SKELETON_MAX_NODES];
        private readonly float[] _applyY = new float[SKELETON_MAX_NODES];
        private readonly float[] _applyZ = new float[SKELETON_MAX_NODES];
        private readonly int[] _applyChildCounts = new int[SKELETON_MAX_NODES];
        private readonly int[] _subtreeNodeCounts = new int[SKELETON_MAX_NODES];
        private readonly float[] _subtreeMinX = new float[SKELETON_MAX_NODES];
        private readonly float[] _subtreeMaxX = new float[SKELETON_MAX_NODES];
        private readonly float[] _subtreeMinY = new float[SKELETON_MAX_NODES];
        private readonly float[] _subtreeMaxY = new float[SKELETON_MAX_NODES];
        private readonly float[] _subtreeMinZ = new float[SKELETON_MAX_NODES];
        private readonly float[] _subtreeMaxZ = new float[SKELETON_MAX_NODES];
        private readonly bool[] _excludedSmallBranchRoot = new bool[SKELETON_MAX_NODES];
        private readonly bool[] _pelvicSkirtCandidate = new bool[SKELETON_MAX_NODES];
        private readonly bool[] _excludedPelvicSkirtBranchRoot = new bool[SKELETON_MAX_NODES];
        private readonly bool[] _excludedSkeletonEdge = new bool[SKELETON_MAX_NODES];
        private readonly bool[] _headClusterNode = new bool[SKELETON_MAX_NODES];
        private readonly bool[] _headGeometryEdge = new bool[SKELETON_MAX_NODES];
        private int _headTipNode = -1;
        private int _headEntryNode = -1;
        private int _neckBaseNode = -1;
        private int _excludedHeadClusterEdges;
        private int _excludedRootAnchorEdges;
        private int _excludedSmallSubtreeEdges;
        private int _excludedSmallBranchRoots;
        private int _excludedPelvicSkirtRoots;
        private int _excludedPelvicSkirtEdges;

        private readonly byte[] _resolveScratch = new byte[RESOLVE_OBJECT_BYTES];
        private readonly byte[] _entityModelScratch = new byte[0x20];
        private readonly HashSet<(long Model, long Root)> _tracedModelRoots = new();
        private readonly Dictionary<(long Entity, long Node), FocusedTraceTrack> _focusedTraceTracks = new();
        private readonly Dictionary<long, long> _failedResolveRetryAt = new();
        private readonly object _traceSync = new();
        private StreamWriter _skeletonTraceWriter;
        private bool _traceDisposed;
        private long _nextFocusedTraceSampleMs;
        private int _focusedPathConsoleRecords;
        private int _traceLinesSinceFlush;
        private readonly byte[] _modelArrayScratch = new byte[0x4000];
        private readonly byte[] _nodeScratch = new byte[NODE_PROBE_BYTES];
        // Covers the node vtable, owner at +0x40, +0x148 matrix, and +0x178 translation.
        // Used to validate child pointers without overwriting the current node's edge slots.
        private readonly byte[] _edgeProbeScratch = new byte[0x190];
        private readonly long[] _samplePageBases = new long[MAX_SAMPLE_PAGES];
        private readonly byte[][] _samplePageBuffers = new byte[MAX_SAMPLE_PAGES][];
        private readonly int[] _samplePageForNode = new int[SKELETON_MAX_NODES];
        private readonly int[] _samplePageOffsetForNode = new int[SKELETON_MAX_NODES];
        private readonly byte[] _boneHierarchyScratch = new byte[SKELETON_MAX_NODES * BONE_HIERARCHY_RECORD_BYTES];
        private readonly byte[] _boneMatrixScratch = new byte[SKELETON_MAX_NODES * BONE_MATRIX_BYTES];
        private readonly byte[] _rootWorldMatrixScratch = new byte[MATRIX_BYTES];
        private readonly HashSet<long> _activeEntities = new HashSet<long>(64);
        private int _samplePageCount;
        private int _entityIdentityChangeLogCount;

        private enum TransformSource : byte
        {
            Translation178 = 1,
            WorldMatrix148 = 2,
            SkeletalBoneMatrix = 3,
        }

        private sealed class CachedNode
        {
            public long Ptr;
            public long Vtable;
            public int ParentIndex;
            public int BoneIndex = -1;
            public TransformSource Source;

            public float X, Y, Z;
            public bool PositionValid;

            public float PreviousX, PreviousY, PreviousZ;
            public bool HasPrevious;
            public float TotalRelativeMotion;
        }

        private sealed class FocusedTraceTrack
        {
            public long EntityPtr;
            public long ModelPtr;
            public long RootPtr;
            public long NodePtr;
            public string Path;
            public long StartedMs;
            public int Samples;
            public int ValidSamples;
            public bool Complete;
            public bool HasPrevious;
            public float FirstX, FirstY, FirstZ;
            public float PreviousX, PreviousY, PreviousZ;
            public float FirstRelativeX, FirstRelativeY, FirstRelativeZ;
            public float PreviousRelativeX, PreviousRelativeY, PreviousRelativeZ;
            public float TotalNodeStep;
            public float TotalRelativeStep;
            public float MaxNodeStep;
            public float MaxRelativeStep;
            public float MinTargetDistance = float.MaxValue;
            public TransformSource Source;
        }

        private sealed class ResolutionCache
        {
            public uint EntityId;
            public long B8;
            public long Model;
            public long RootNode;
            public long RootVtable;
            public long SkeletalAnim;
            public long BoneMatrixTable;
            public int BoneCount;
            public bool SkeletalBoneHierarchy;
            public CachedNode[] Nodes = Array.Empty<CachedNode>();
            public long NextB8CheckMs;
            public long NextRootValidateMs;
            public bool HasSample;
            public int SampleCount;
            public bool LastEntityValid;
            public float LastEntityX, LastEntityY, LastEntityZ;
            public bool SkeletonVerified;
        }

        private sealed class PoseState
        {
            public uint EntityId;
            public long SampleTicks;
            public bool SkeletonVerified;
            public int NodeCount;
            public readonly long[] NodePtrs = new long[SKELETON_MAX_NODES];
            public readonly int[] Parents = new int[SKELETON_MAX_NODES];
            // Native skeletal-bone table index for each topologically ordered node.
            // Legacy SpaceNode candidates use -1 and are intentionally unlabelled.
            public readonly int[] BoneIndices = new int[SKELETON_MAX_NODES];
            public readonly float[] X = new float[SKELETON_MAX_NODES];
            public readonly float[] Y = new float[SKELETON_MAX_NODES];
            public readonly float[] Z = new float[SKELETON_MAX_NODES];
        }

        public DynamicSkeletonReader(Mem mem)
        {
            _mem = mem ?? throw new ArgumentNullException(nameof(mem));
            for (int i = 0; i < _samplePageBuffers.Length; i++)
                _samplePageBuffers[i] = new byte[PAGE_SIZE];
        }

        /// <summary>
        /// Performs only remote-memory skeleton discovery/sampling and publishes immutable
        /// world-space poses. It intentionally does not perform camera projection.
        /// </summary>
        public void Update(List<EntityData> entities)
        {
            if (entities == null || entities.Count == 0)
                return;

            long nowMs = Environment.TickCount64;
            bool coverageTraceEnabled = SkeletonCoverageTrace.IsEnabled;
            _activeEntities.Clear();

            foreach (EntityData entity in entities)
            {
                if (entity == null || !entity.IsEnemy)
                    continue;

                _activeEntities.Add(entity.Ptr);

                if (!entity.OnScreen)
                {
                    if (coverageTraceEnabled)
                        SkeletonCoverageTrace.Record(entity, "ELIGIBILITY", "OFFSCREEN",
                            "entity snapshot marks this target off-screen", failure: true);
                    continue;
                }
                if (!float.IsFinite(entity.Distance))
                {
                    if (coverageTraceEnabled)
                        SkeletonCoverageTrace.Record(entity, "ELIGIBILITY", "DISTANCE_INVALID",
                            $"distance={entity.Distance}", failure: true);
                    continue;
                }
                if (entity.Distance > Settings.MaxESPRange)
                {
                    if (coverageTraceEnabled)
                        SkeletonCoverageTrace.Record(entity, "ELIGIBILITY", "OUT_OF_RANGE",
                            $"distance={entity.Distance:F1} maxRange={Settings.MaxESPRange:F1}", failure: true);
                    continue;
                }

                if (coverageTraceEnabled)
                    SkeletonCoverageTrace.Record(entity, "ELIGIBILITY", "ELIGIBLE",
                        $"distance={entity.Distance:F1} maxRange={Settings.MaxESPRange:F1}");

                if (!TryResolve(entity, nowMs, out ResolutionCache cache, out string resolveFailure))
                {
                    string resolveCode = CoverageOutcomeCode(resolveFailure, "RESOLVE_UNAVAILABLE");
                    if (coverageTraceEnabled)
                        SkeletonCoverageTrace.Record(
                            entity, "RESOLVE", resolveCode,
                            $"reason={resolveFailure ?? "UNKNOWN"} xyz=({entity.X:F2},{entity.Y:F2},{entity.Z:F2})",
                            failure: true);
                    // A failed model/root revalidation can mean the previous pose is no longer
                    // associated with this entity. Drop it rather than drawing the wrong rig.
                    RemovePose(entity.Ptr);
                    continue;
                }

                if (coverageTraceEnabled)
                    SkeletonCoverageTrace.Record(
                        entity, "RESOLVE", "OK",
                        $"model=0x{cache.Model:X} root=0x{cache.RootNode:X} anim=0x{cache.SkeletalAnim:X} " +
                        $"bones={cache.BoneCount} nodes={cache.Nodes.Length}");
                RuntimeDiagnostics.SkeletonResolved(cache.Nodes.Length);

                long sampleStarted = Stopwatch.GetTimestamp();
                if (!SamplePose(entity, cache, out string sampleFailure))
                {
                    cache.HasSample = false;
                    string sampleCode = CoverageOutcomeCode(sampleFailure, "POSE_SAMPLE_FAILED");
                    if (coverageTraceEnabled)
                        SkeletonCoverageTrace.Record(
                            entity, "SAMPLE", sampleCode,
                            $"reason={sampleFailure ?? "UNKNOWN"} model=0x{cache.Model:X} " +
                            $"root=0x{cache.RootNode:X} matrixTable=0x{cache.BoneMatrixTable:X} bones={cache.BoneCount}",
                            failure: true);
                    // Keep the last good sample briefly. ApplyLatest independently rejects it
                    // once it exceeds its existing 150 ms freshness limit, preventing a single
                    // failed RPM read from instantly blanking an otherwise valid skeleton.
                    continue;
                }

                cache.HasSample = true;
                PublishPose(entity, cache);
                if (coverageTraceEnabled)
                    SkeletonCoverageTrace.Record(
                        entity, "SAMPLE", "OK",
                        $"nodes={cache.Nodes.Length} verified={(cache.SkeletonVerified ? 1 : 0)} " +
                        $"movingNodes={CountRelativeMovingNodes(cache)}");

                double elapsedMs = (Stopwatch.GetTimestamp() - sampleStarted) * 1000.0 / Stopwatch.Frequency;
                RuntimeDiagnostics.SkeletonSample(
                    cache.Nodes.Length,
                    CountRelativeMovingNodes(cache),
                    cache.SkeletonVerified,
                    elapsedMs);
            }

            if (DiscoveryTraceEnabled)
                SampleFocusedTraceCandidates(entities, nowMs);
            PruneCaches();
            PrunePoses();
        }

        /// <summary>
        /// Projects the latest verified world-space pose using the current camera snapshot.
        /// No process memory is accessed here.
        /// </summary>
        public void ApplyLatest(
            List<EntityData> entities,
            in CameraData cam,
            float screenW,
            float screenH)
        {
            if (entities == null)
                return;

            bool coverageTraceEnabled = SkeletonCoverageTrace.IsEnabled;
            foreach (EntityData entity in entities)
            {
                if (entity == null)
                    continue;

                entity.DynamicBoneDiagnosticTarget =
                    _boneDiagnosticTargetPtr != 0 &&
                    entity.Ptr == _boneDiagnosticTargetPtr &&
                    entity.EntityId == _boneDiagnosticTargetEntityId;

                if (!entity.IsEnemy)
                    continue;

                entity.DynamicSkeletonSegmentCount = 0;
                entity.DynamicSkeletonValid = false;
                entity.DynamicHeadGeometryValid = false;
                entity.DynamicHeadCenter = PointF.Empty;
                entity.DynamicHeadRadius = 0f;
                entity.DynamicNeckSegmentValid = false;
                entity.DynamicNeckStart = PointF.Empty;
                entity.DynamicNeckEnd = PointF.Empty;
                entity.DynamicNeckWorldValid = false;
                entity.DynamicNeckWorldX = 0f;
                entity.DynamicNeckWorldY = 0f;
                entity.DynamicNeckWorldZ = 0f;
                entity.DynamicHeadTipBoneIndex = -1;
                entity.DynamicHeadEntryBoneIndex = -1;
                entity.DynamicNeckBaseBoneIndex = -1;

                bool coverageTarget = entity.OnScreen && float.IsFinite(entity.Distance) &&
                                      entity.Distance <= Settings.MaxESPRange;
                bool poseFound;
                int nodeCount = 0;
                bool verified = false;
                long sampleTicks = 0;
                lock (_poseLock)
                {
                    poseFound = _latestPoses.TryGetValue(entity.Ptr, out PoseState currentPose);
                    if (poseFound && currentPose.EntityId != entity.EntityId)
                    {
                        // Native addresses can be recycled. A fresh actor at the same BGA
                        // pointer must never inherit the previous actor's projected pose.
                        _latestPoses.Remove(entity.Ptr);
                        poseFound = false;
                    }
                    if (poseFound)
                    {
                        nodeCount = currentPose.NodeCount;
                        verified = currentPose.SkeletonVerified;
                        sampleTicks = currentPose.SampleTicks;
                        if (nodeCount >= 2 && nodeCount <= SKELETON_MAX_NODES)
                        {
                            // The sampler updates these arrays in place, so copy all fields
                            // while holding the same lock used by PublishPose.
                            Array.Copy(currentPose.NodePtrs, _applyPtrs, nodeCount);
                            Array.Copy(currentPose.Parents, _applyParents, nodeCount);
                            Array.Copy(currentPose.BoneIndices, _applyBoneIndices, nodeCount);
                            Array.Copy(currentPose.X, _applyX, nodeCount);
                            Array.Copy(currentPose.Y, _applyY, nodeCount);
                            Array.Copy(currentPose.Z, _applyZ, nodeCount);
                        }
                    }
                }

                if (!poseFound)
                {
                    if (coverageTarget && coverageTraceEnabled)
                        SkeletonCoverageTrace.Record(entity, "PROJECT", "NO_POSE",
                            "no latest sampled pose is stored for this entity", failure: true);
                    continue;
                }

                if (nodeCount < 2 || nodeCount > SKELETON_MAX_NODES)
                {
                    if (coverageTarget && coverageTraceEnabled)
                        SkeletonCoverageTrace.Record(entity, "PROJECT", "INVALID_NODE_COUNT",
                            $"nodeCount={nodeCount} max={SKELETON_MAX_NODES}", failure: true);
                    continue;
                }

                if (!verified)
                {
                    if (coverageTarget && coverageTraceEnabled)
                        SkeletonCoverageTrace.Record(entity, "PROJECT", "POSE_NOT_VERIFIED",
                            $"nodes={nodeCount}", failure: true);
                    continue;
                }

                if (!cam.IsValid)
                {
                    if (coverageTarget && coverageTraceEnabled)
                        SkeletonCoverageTrace.Record(entity, "PROJECT", "CAMERA_INVALID",
                            "current camera snapshot is invalid", failure: true);
                    continue;
                }

                double ageMs = (Stopwatch.GetTimestamp() - sampleTicks) * 1000.0 / Stopwatch.Frequency;
                if (!double.IsFinite(ageMs) || ageMs > 150.0)
                {
                    if (coverageTarget && coverageTraceEnabled)
                        SkeletonCoverageTrace.Record(entity, "PROJECT", "STALE_POSE",
                            $"ageMs={ageMs:F1} freshnessLimitMs=150", failure: true);
                    continue;
                }

                Array.Clear(_applyValid, 0, nodeCount);
                BuildExcludedSkeletonEdgeMask(nodeCount);
                int projectedNodes = 0;
                int invalidCoordinates = 0;
                int projectionRejected = 0;
                for (int i = 0; i < nodeCount; i++)
                {
                    if (!IsValidCoordinate(_applyX[i]) ||
                        !IsValidCoordinate(_applyY[i]) ||
                        !IsValidCoordinate(_applyZ[i]))
                    {
                        invalidCoordinates++;
                        continue;
                    }

                    if (!WorldToScreen.Project(
                            _applyX[i], _applyY[i], _applyZ[i],
                            cam, screenW, screenH,
                            out float sx, out float sy, entity.Ptr, allowOffscreen: true))
                    {
                        projectionRejected++;
                        continue;
                    }

                    _applyProjected[i] = new PointF(sx, sy);
                    _applyValid[i] = true;
                    projectedNodes++;
                }

                // Align with the v6 synthetic render-data contract: source-invalid/projected-invalid
                // nodes are never bridged, and outlier native edges cannot leave detached fragments.
                int spatiallyRejectedNodes = RejectImplausiblePoseSubtrees(nodeCount);
                BuildExcludedSkeletonEdgeMask(nodeCount, respectProjectionValidity: true);

                bool headGeometryBuilt = BuildDynamicHeadGeometry(entity, nodeCount, in cam, screenW, screenH);
                int segments = 0;
                int invalidParentLinks = 0;
                int unprojectedLinks = 0;
                int longLinks = 0;
                int invalidLengthLinks = 0;
                for (int i = 1; i < nodeCount && segments < EntityData.MaxDynamicSkeletonSegments; i++)
                {
                    // Exclusion only: do not bridge over excluded nodes or manufacture
                    // substitute edges. The surviving segments are untouched native edges.
                    if (_excludedSkeletonEdge[i] || _headGeometryEdge[i])
                        continue;

                    int parent = _applyParents[i];
                    if (parent < 0 || parent >= nodeCount)
                    {
                        invalidParentLinks++;
                        continue;
                    }
                    if (!_applyValid[i] || !_applyValid[parent])
                    {
                        unprojectedLinks++;
                        continue;
                    }

                    float worldLength = Distance(
                        _applyX[i], _applyY[i], _applyZ[i],
                        _applyX[parent], _applyY[parent], _applyZ[parent]);
                    if (!float.IsFinite(worldLength))
                    {
                        invalidLengthLinks++;
                        continue;
                    }
                    if (worldLength > MAX_SEGMENT_LENGTH)
                    {
                        longLinks++;
                        continue;
                    }

                    entity.DynamicSkeletonSegments[segments++] = new SkeletonSegment
                    {
                        Parent = _applyProjected[parent],
                        Child = _applyProjected[i],
                        ParentBoneIndex = _applyBoneIndices[parent],
                        ChildBoneIndex = _applyBoneIndices[i],
                        ParentIsHierarchyRoot = _applyParents[parent] < 0,
                    };
                }

                entity.DynamicSkeletonSegmentCount = segments;
                // Render any surviving native parent-child edges. MIN_RENDER_SEGMENTS remains
                // the stronger evidence threshold for choosing a diagnostic actor, not an
                // all-or-nothing gate that suppresses otherwise valid edges for this actor.
                entity.DynamicSkeletonValid = segments > 0;

                // Bone-index diagnostics and the one-shot edge map must refer to the same
                // actor, and that actor must have most of its skeleton inside the real
                // viewport. EntityData.OnScreen is deliberately more permissive for clipping
                // and allowed an entirely off-right target to consume the one-shot trace.
                if (entity.DynamicSkeletonValid &&
                    TrySelectBoneDiagnosticTarget(entity, segments, screenW, screenH))
                {
                    entity.DynamicBoneDiagnosticTarget = true;
                    if (SkeletonEdgeTraceEnabled)
                        WriteSkeletonEdgeTraceOnce(entity, nodeCount, ageMs, screenW, screenH, segments);
                }

                if (entity.DynamicSkeletonValid)
                {
                    if (coverageTarget && coverageTraceEnabled)
                    {
                        string projectDetails =
                            $"nodes={nodeCount} projectedNodes={projectedNodes} invalidCoords={invalidCoordinates} " +
                            $"projectionRejected={projectionRejected} spatiallyRejectedNodes={spatiallyRejectedNodes} invalidParentLinks={invalidParentLinks} " +
                            $"unprojectedLinks={unprojectedLinks} longLinks={longLinks} " +
                            $"invalidLengthLinks={invalidLengthLinks} excludedRootAnchorEdges={_excludedRootAnchorEdges} " +
                            $"excludedSmallBranchRoots={_excludedSmallBranchRoots} " +
                            $"excludedSmallSubtreeEdges={_excludedSmallSubtreeEdges} " +
                            $"excludedPelvicSkirtRoots={_excludedPelvicSkirtRoots} " +
                            $"excludedPelvicSkirtEdges={_excludedPelvicSkirtEdges} " +
                            $"headGeometry={(headGeometryBuilt ? 1 : 0)} " +
                            $"headTipBone={entity.DynamicHeadTipBoneIndex} " +
                            $"headEntryBone={entity.DynamicHeadEntryBoneIndex} " +
                            $"neckBaseBone={entity.DynamicNeckBaseBoneIndex} " +
                            $"headRadius={entity.DynamicHeadRadius:F1} " +
                            $"headClusterEdges={_excludedHeadClusterEdges} segments={segments} ageMs={ageMs:F1} " +
                            $"diagnosticMinSegments={MIN_RENDER_SEGMENTS}";
                        SkeletonCoverageTrace.Record(entity, "PROJECT", "READY_TO_DRAW", projectDetails);
                    }
                }
                else
                {
                    // Keep the segment count at zero only when no native edge survived. Do not
                    // clear a valid partial graph just because it has fewer than the diagnostic
                    // target's six-edge coverage threshold.
                    if (coverageTarget && coverageTraceEnabled)
                    {
                        string projectDetails =
                            $"nodes={nodeCount} projectedNodes={projectedNodes} invalidCoords={invalidCoordinates} " +
                            $"projectionRejected={projectionRejected} spatiallyRejectedNodes={spatiallyRejectedNodes} invalidParentLinks={invalidParentLinks} " +
                            $"unprojectedLinks={unprojectedLinks} longLinks={longLinks} " +
                            $"invalidLengthLinks={invalidLengthLinks} excludedRootAnchorEdges={_excludedRootAnchorEdges} " +
                            $"excludedSmallBranchRoots={_excludedSmallBranchRoots} " +
                            $"excludedSmallSubtreeEdges={_excludedSmallSubtreeEdges} " +
                            $"excludedPelvicSkirtRoots={_excludedPelvicSkirtRoots} " +
                            $"excludedPelvicSkirtEdges={_excludedPelvicSkirtEdges} " +
                            $"headGeometry={(headGeometryBuilt ? 1 : 0)} " +
                            $"headTipBone={entity.DynamicHeadTipBoneIndex} " +
                            $"headEntryBone={entity.DynamicHeadEntryBoneIndex} " +
                            $"neckBaseBone={entity.DynamicNeckBaseBoneIndex} " +
                            $"headRadius={entity.DynamicHeadRadius:F1} " +
                            $"headClusterEdges={_excludedHeadClusterEdges} segments={segments} ageMs={ageMs:F1} " +
                            $"diagnosticMinSegments={MIN_RENDER_SEGMENTS}";
                        SkeletonCoverageTrace.Record(entity, "PROJECT", "NO_VALID_SEGMENTS",
                            projectDetails, failure: true);
                    }
                }
            }
        }

        /// <summary>
        /// Rejects spatially implausible native child edges as whole subtrees. Parents are
        /// stored before their descendants by the validated tree walk. This prevents a bad
        /// matrix or actor-foreign branch from appearing as a disconnected fragment and
        /// prevents a below-root foot outlier from extending through the ground. The root
        /// connector is intentionally exempt: the observed rig has a separate root anchor
        /// edge that is excluded from drawing and is longer than ordinary skeletal edges.
        /// </summary>
        private int RejectImplausiblePoseSubtrees(int nodeCount)
        {
            if (nodeCount < 2 || !IsValidCoordinate(_applyY[0]))
                return 0;

            int rejected = 0;
            float nativeRootY = _applyY[0];
            for (int i = 1; i < nodeCount; i++)
            {
                if (!_applyValid[i])
                    continue;

                int parent = _applyParents[i];
                if (parent < 0 || parent >= i || !_applyValid[parent])
                {
                    _applyValid[i] = false;
                    rejected++;
                    continue;
                }

                if (_applyY[i] < nativeRootY - MAX_BONE_BELOW_NATIVE_ROOT)
                {
                    _applyValid[i] = false;
                    rejected++;
                    continue;
                }

                // The observed root-origin connector is a non-anatomical edge excluded from
                // rendering and can be longer than a limb segment. Other excluded edges still
                // receive the length check so a corrupt side branch cannot influence head bounds.
                if (_excludedSkeletonEdge[i] && _applyParents[parent] < 0)
                    continue;

                float length = Distance(
                    _applyX[parent], _applyY[parent], _applyZ[parent],
                    _applyX[i], _applyY[i], _applyZ[i]);
                if (!float.IsFinite(length) || length > MAX_SEGMENT_LENGTH)
                {
                    _applyValid[i] = false;
                    rejected++;
                }
            }
            return rejected;
        }

        /// <summary>
        /// Derives the head cluster and neck endpoint from the current projected native pose.
        /// No bone index is assumed: find the highest pose node near the skeleton's body center,
        /// walk back to the node where its upper cluster joins the lower trunk, then replace only
        /// edges fully inside that compact upper cluster with a screen-space circle. The native
        /// incoming edge is clipped at the circle boundary to preserve its lower neck portion.
        /// </summary>
        private bool BuildDynamicHeadGeometry(EntityData entity, int nodeCount, in CameraData cam, float screenW, float screenH)
        {
            Array.Clear(_headClusterNode, 0, nodeCount);
            Array.Clear(_headGeometryEdge, 0, nodeCount);
            _headTipNode = _headEntryNode = _neckBaseNode = -1;
            _excludedHeadClusterEdges = 0;

            float minScreenX = float.PositiveInfinity;
            float maxScreenX = float.NegativeInfinity;
            float minScreenY = float.PositiveInfinity;
            float maxScreenY = float.NegativeInfinity;
            float minWorldY = float.PositiveInfinity;
            float maxWorldY = float.NegativeInfinity;
            int validCount = 0;
            for (int i = 0; i < nodeCount; i++)
            {
                if (!_applyValid[i])
                    continue;
                PointF p = _applyProjected[i];
                minScreenX = MathF.Min(minScreenX, p.X);
                maxScreenX = MathF.Max(maxScreenX, p.X);
                minScreenY = MathF.Min(minScreenY, p.Y);
                maxScreenY = MathF.Max(maxScreenY, p.Y);
                minWorldY = MathF.Min(minWorldY, _applyY[i]);
                maxWorldY = MathF.Max(maxWorldY, _applyY[i]);
                validCount++;
            }

            if (validCount < 8 || !float.IsFinite(minScreenX) || !float.IsFinite(maxScreenX) ||
                !float.IsFinite(minScreenY) || !float.IsFinite(maxScreenY) ||
                !float.IsFinite(minWorldY) || !float.IsFinite(maxWorldY))
                return false;

            float screenBodyHeight = maxScreenY - minScreenY;
            float worldBodyHeight = maxWorldY - minWorldY;
            if (!float.IsFinite(screenBodyHeight) || screenBodyHeight < 4f ||
                !float.IsFinite(worldBodyHeight) || worldBodyHeight < 1f)
                return false;

            float bodyCenterX = (minScreenX + maxScreenX) * 0.5f;
            if (entity.BoxProjected && float.IsFinite(entity.BoxHeadSX) &&
                float.IsFinite(entity.BoxFootSX) &&
                entity.BoxHeadSX >= -100f && entity.BoxHeadSX <= 10000f &&
                entity.BoxFootSX >= -100f && entity.BoxFootSX <= 10000f)
            {
                bodyCenterX = (entity.BoxHeadSX + entity.BoxFootSX) * 0.5f;
            }

            // At long range, a fixed 10px corridor can include hands/side branches and shift
            // the marker away from the head. Shrink the corridor with projected body scale.
            float centerCorridor = Math.Clamp(
                screenBodyHeight * HEAD_CENTER_CORRIDOR_SCALE,
                HEAD_CENTER_CORRIDOR_MIN_PIXELS,
                16f);
            int headTip = -1;
            float bestWorldY = float.NegativeInfinity;
            float bestScreenY = float.PositiveInfinity;
            for (int i = 0; i < nodeCount; i++)
            {
                if (!_applyValid[i] || MathF.Abs(_applyProjected[i].X - bodyCenterX) > centerCorridor)
                    continue;

                // BigWorld's Y axis is vertical. Within the body-centre corridor, the highest
                // native point is more robust than relying on a model-specific bone number.
                if (_applyY[i] > bestWorldY + 0.001f ||
                    (MathF.Abs(_applyY[i] - bestWorldY) <= 0.001f && _applyProjected[i].Y < bestScreenY))
                {
                    bestWorldY = _applyY[i];
                    bestScreenY = _applyProjected[i].Y;
                    headTip = i;
                }
            }
            if (headTip < 0 || !float.IsFinite(bestWorldY))
                return false;

            float clusterDepth = Math.Clamp(
                worldBodyHeight * HEAD_CLUSTER_DEPTH_SCALE,
                HEAD_CLUSTER_MIN_DEPTH,
                HEAD_CLUSTER_MAX_DEPTH);
            float clusterFloor = bestWorldY - clusterDepth;

            // Walk upward through the existing parent chain while nodes remain in the compact
            // upper cluster. The first node whose parent falls below this band is the cluster
            // entry; its parent is the lower endpoint of the existing neck segment.
            int headEntry = headTip;
            int guard = 0;
            while (guard++ < nodeCount)
            {
                int parent = _applyParents[headEntry];
                if (parent < 0 || parent >= nodeCount || !_applyValid[parent] ||
                    _applyY[parent] < clusterFloor)
                    break;
                headEntry = parent;
            }

            int neckBase = _applyParents[headEntry];
            if (neckBase < 0 || neckBase >= nodeCount || neckBase == headEntry ||
                !_applyValid[neckBase] || _applyY[neckBase] >= clusterFloor ||
                _excludedSkeletonEdge[headEntry])
                return false;

            float nativeNeckEdgeLength = Distance(
                _applyX[neckBase], _applyY[neckBase], _applyZ[neckBase],
                _applyX[headEntry], _applyY[headEntry], _applyZ[headEntry]);
            if (!float.IsFinite(nativeNeckEdgeLength) || nativeNeckEdgeLength > MAX_SEGMENT_LENGTH)
                return false;

            // The head cluster is the compact upper portion of this native subtree. Mark no
            // nodes outside the subtree, even if another limb is raised above the head.
            float headMinX = float.PositiveInfinity;
            float headMaxX = float.NegativeInfinity;
            float headMinY = float.PositiveInfinity;
            float headMaxY = float.NegativeInfinity;
            double headWorldSumX = 0.0;
            double headWorldSumY = 0.0;
            double headWorldSumZ = 0.0;
            int headClusterCount = 0;
            for (int i = 0; i < nodeCount; i++)
            {
                if (!_applyValid[i] || _applyY[i] < clusterFloor || !IsDescendantOrSelf(i, headEntry, nodeCount))
                    continue;

                _headClusterNode[i] = true;
                PointF p = _applyProjected[i];
                headMinX = MathF.Min(headMinX, p.X);
                headMaxX = MathF.Max(headMaxX, p.X);
                headMinY = MathF.Min(headMinY, p.Y);
                headMaxY = MathF.Max(headMaxY, p.Y);
                headWorldSumX += _applyX[i];
                headWorldSumY += _applyY[i];
                headWorldSumZ += _applyZ[i];
                headClusterCount++;
            }

            if (headClusterCount < 2 || !float.IsFinite(headMinX) || !float.IsFinite(headMaxX) ||
                !float.IsFinite(headMinY) || !float.IsFinite(headMaxY))
            {
                Array.Clear(_headClusterNode, 0, nodeCount);
                return false;
            }

            // Do not average projected screen coordinates: perspective projection is nonlinear,
            // so that creates camera-angle-dependent drift. Compute the compact cluster's 3D
            // world-space centroid first, then project it using this exact frame's camera.
            float headCenterWorldX = (float)(headWorldSumX / headClusterCount);
            float headCenterWorldY = (float)(headWorldSumY / headClusterCount);
            float headCenterWorldZ = (float)(headWorldSumZ / headClusterCount);
            if (!WorldToScreen.Project(
                    headCenterWorldX, headCenterWorldY, headCenterWorldZ,
                    in cam, screenW, screenH, out float centerX, out float centerY, entity.Ptr, allowOffscreen: true))
            {
                Array.Clear(_headClusterNode, 0, nodeCount);
                return false;
            }

            // Radius comes from this frame's projected head-cluster width (therefore naturally
            // responds to perspective/depth), with a smaller body-height fallback and minimal pad.
            float headRadiusMin = Math.Max(HEAD_RADIUS_MIN_PIXELS, screenBodyHeight * HEAD_RADIUS_MIN_SCALE);
            float headRadiusMax = Math.Max(headRadiusMin + 0.25f, screenBodyHeight * HEAD_RADIUS_MAX_SCALE);
            float projectedHalfWidth = (headMaxX - headMinX) * 0.5f + HEAD_RADIUS_PADDING_PIXELS;
            float radius = Math.Clamp(
                Math.Max(projectedHalfWidth, screenBodyHeight * HEAD_RADIUS_SCALE),
                headRadiusMin,
                headRadiusMax);

            if (!float.IsFinite(centerX) || !float.IsFinite(centerY) ||
                !float.IsFinite(radius) || radius < HEAD_RADIUS_MIN_PIXELS || radius > 64f)
            {
                Array.Clear(_headClusterNode, 0, nodeCount);
                return false;
            }

            // Remove the incoming full-length neck/head edge and all edges within the head
            // cluster. The lower part of that same incoming edge is drawn separately, clipped
            // to the circle perimeter. No bone transforms or parent-child records are modified.
            for (int i = 0; i < nodeCount; i++)
            {
                if (!_headClusterNode[i])
                    continue;
                if (i == headEntry ||
                    (_applyParents[i] >= 0 && _applyParents[i] < nodeCount &&
                     _headClusterNode[_applyParents[i]]))
                {
                    _headGeometryEdge[i] = true;
                    _excludedHeadClusterEdges++;
                }
            }

            PointF neckStart = _applyProjected[neckBase];
            float dx = neckStart.X - centerX;
            float dy = neckStart.Y - centerY;
            float distance = MathF.Sqrt(dx * dx + dy * dy);
            if (!float.IsFinite(distance) || distance <= radius + 0.5f)
            {
                Array.Clear(_headClusterNode, 0, nodeCount);
                Array.Clear(_headGeometryEdge, 0, nodeCount);
                _excludedHeadClusterEdges = 0;
                return false;
            }

            float scaleToCircle = radius / distance;
            entity.DynamicNeckStart = neckStart;
            entity.DynamicNeckEnd = new PointF(centerX + dx * scaleToCircle, centerY + dy * scaleToCircle);
            entity.DynamicNeckWorldX = _applyX[neckBase];
            entity.DynamicNeckWorldY = _applyY[neckBase];
            entity.DynamicNeckWorldZ = _applyZ[neckBase];
            entity.DynamicNeckWorldValid =
                float.IsFinite(entity.DynamicNeckWorldX) &&
                float.IsFinite(entity.DynamicNeckWorldY) &&
                float.IsFinite(entity.DynamicNeckWorldZ);
            entity.DynamicNeckSegmentValid = true;
            entity.DynamicHeadCenter = new PointF(centerX, centerY);
            entity.DynamicHeadRadius = radius;
            entity.DynamicHeadGeometryValid = true;
            entity.DynamicHeadTipBoneIndex = _applyBoneIndices[headTip];
            entity.DynamicHeadEntryBoneIndex = _applyBoneIndices[headEntry];
            entity.DynamicNeckBaseBoneIndex = _applyBoneIndices[neckBase];
            _headTipNode = headTip;
            _headEntryNode = headEntry;
            _neckBaseNode = neckBase;
            return true;
        }

        private bool IsDescendantOrSelf(int node, int ancestor, int nodeCount)
        {
            int current = node;
            int guard = 0;
            while (current >= 0 && current < nodeCount && guard++ < nodeCount)
            {
                if (current == ancestor)
                    return true;
                current = _applyParents[current];
            }
            return false;
        }

        private bool TrySelectBoneDiagnosticTarget(
            EntityData entity, int segmentCount, float screenW, float screenH)
        {
            if (!BoneIndexDiagnosticsEnabled && !SkeletonEdgeTraceEnabled)
                return false;

            // Keep labels attached to the same actor for the entire process run. A pointer
            // match without an EntityId match is not sufficient because native addresses
            // can be recycled.
            if (_boneDiagnosticTargetPtr != 0)
                return entity.Ptr == _boneDiagnosticTargetPtr &&
                       entity.EntityId == _boneDiagnosticTargetEntityId;

            int viewportSegments = 0;
            float minX = float.PositiveInfinity;
            float minY = float.PositiveInfinity;
            float maxX = float.NegativeInfinity;
            float maxY = float.NegativeInfinity;
            for (int i = 0; i < segmentCount; i++)
            {
                SkeletonSegment segment = entity.DynamicSkeletonSegments[i];
                if (!IsInsideViewport(segment.Parent, screenW, screenH) ||
                    !IsInsideViewport(segment.Child, screenW, screenH))
                    continue;

                viewportSegments++;
                minX = MathF.Min(minX, MathF.Min(segment.Parent.X, segment.Child.X));
                minY = MathF.Min(minY, MathF.Min(segment.Parent.Y, segment.Child.Y));
                maxX = MathF.Max(maxX, MathF.Max(segment.Parent.X, segment.Child.X));
                maxY = MathF.Max(maxY, MathF.Max(segment.Parent.Y, segment.Child.Y));
            }

            int requiredViewportSegments = Math.Max(MIN_RENDER_SEGMENTS, (segmentCount * 2 + 2) / 3);
            bool usefulBodyExtent = viewportSegments >= requiredViewportSegments &&
                                    float.IsFinite(minY) && float.IsFinite(maxY) &&
                                    maxY - minY >= 12f;
            if (!usefulBodyExtent)
            {
                if (SkeletonEdgeTraceEnabled && _diagnosticCandidateSkipLogCount < MAX_DIAGNOSTIC_CANDIDATE_SKIP_LOGS)
                {
                    _diagnosticCandidateSkipLogCount++;
                    Console.WriteLine(
                        $"  [STAGE98][EDGE-TRACE-SKIP] entity=0x{entity.Ptr:X} entityId=0x{entity.EntityId:X8} " +
                        $"reason=INSUFFICIENT_IN_VIEWPORT_BODY_EDGES viewportSegments={viewportSegments}/{segmentCount} " +
                        $"required={requiredViewportSegments} bounds=({FormatBounds(minX, minY, maxX, maxY)}) " +
                        $"screen={screenW:F0}x{screenH:F0}");
                }
                return false;
            }

            _boneDiagnosticTargetPtr = entity.Ptr;
            _boneDiagnosticTargetEntityId = entity.EntityId;
            Console.WriteLine(
                $"  [STAGE98][DIAGNOSTIC-TARGET] entity=0x{entity.Ptr:X} entityId=0x{entity.EntityId:X8} " +
                $"viewportSegments={viewportSegments}/{segmentCount} " +
                $"bounds=({FormatBounds(minX, minY, maxX, maxY)}) " +
                $"screen={screenW:F0}x{screenH:F0} labels={(BoneIndexDiagnosticsEnabled ? 1 : 0)} " +
                $"edgeTrace={(SkeletonEdgeTraceEnabled ? 1 : 0)}");
            return true;
        }

        private static bool IsInsideViewport(PointF point, float screenW, float screenH) =>
            float.IsFinite(point.X) && float.IsFinite(point.Y) &&
            point.X >= 0f && point.X <= screenW &&
            point.Y >= 0f && point.Y <= screenH;

        private static string FormatBounds(float minX, float minY, float maxX, float maxY) =>
            float.IsFinite(minX) && float.IsFinite(minY) &&
            float.IsFinite(maxX) && float.IsFinite(maxY)
                ? $"{minX:F1},{minY:F1}..{maxX:F1},{maxY:F1}"
                : "NONE";

        private void WriteSkeletonEdgeTraceOnce(
            EntityData entity, int nodeCount, double ageMs, float screenW, float screenH, int segments)
        {
            if (!SkeletonEdgeTraceEnabled || entity == null || entity.Ptr == 0)
                return;

            lock (_resolverEvidenceSync)
            {
                if (_skeletonEdgeTraceEntities.Contains(entity.Ptr) ||
                    _skeletonEdgeTraceEntities.Count >= MAX_SKELETON_EDGE_TRACE_ENTITIES)
                    return;
                _skeletonEdgeTraceEntities.Add(entity.Ptr);
            }

            try
            {
                int viewportSegments = 0;
                float minX = float.PositiveInfinity;
                float minY = float.PositiveInfinity;
                float maxX = float.NegativeInfinity;
                float maxY = float.NegativeInfinity;
                for (int i = 0; i < segments; i++)
                {
                    SkeletonSegment segment = entity.DynamicSkeletonSegments[i];
                    if (!IsInsideViewport(segment.Parent, screenW, screenH) ||
                        !IsInsideViewport(segment.Child, screenW, screenH))
                        continue;
                    viewportSegments++;
                    minX = MathF.Min(minX, MathF.Min(segment.Parent.X, segment.Child.X));
                    minY = MathF.Min(minY, MathF.Min(segment.Parent.Y, segment.Child.Y));
                    maxX = MathF.Max(maxX, MathF.Max(segment.Parent.X, segment.Child.X));
                    maxY = MathF.Max(maxY, MathF.Max(segment.Parent.Y, segment.Child.Y));
                }

                var lines = new List<string>(nodeCount + 2)
                {
                    $"[STAGE98][EDGE-MAP] entity=0x{entity.Ptr:X} entityId=0x{entity.EntityId:X8} " +
                    $"nodes={nodeCount} segments={segments} viewportSegments={viewportSegments} " +
                    $"viewportBounds=({FormatBounds(minX, minY, maxX, maxY)}) poseAgeMs={ageMs:F1} " +
                    $"screen={screenW:F0}x{screenH:F0} headGeometry={(entity.DynamicHeadGeometryValid ? 1 : 0)} " +
                    $"headTipBone={entity.DynamicHeadTipBoneIndex} headEntryBone={entity.DynamicHeadEntryBoneIndex} " +
                    $"neckBaseBone={entity.DynamicNeckBaseBoneIndex} headCenter=({entity.DynamicHeadCenter.X:F1},{entity.DynamicHeadCenter.Y:F1}) " +
                    $"headRadius={entity.DynamicHeadRadius:F1} headClusterEdges={_excludedHeadClusterEdges} " +
                    $"excludedRootAnchorEdges={_excludedRootAnchorEdges} " +
                    $"excludedSmallBranchRoots={_excludedSmallBranchRoots} " +
                    $"excludedSmallSubtreeEdges={_excludedSmallSubtreeEdges} " +
                    $"excludedPelvicSkirtRoots={_excludedPelvicSkirtRoots} " +
                    $"excludedPelvicSkirtEdges={_excludedPelvicSkirtEdges}",
                    "[STAGE98][EDGE-MAP] format=childNode childBone parentNode parentBone worldXYZ screenXY state"
                };

                for (int i = 0; i < nodeCount; i++)
                {
                    int parent = _applyParents[i];
                    int parentBone = parent >= 0 && parent < nodeCount ? _applyBoneIndices[parent] : -1;
                    string state;
                    if (parent < 0)
                        state = "ROOT_NO_EDGE";
                    else if (_headGeometryEdge[i])
                        state = i == _headEntryNode ? "HEAD_NECK_CLIPPED" : "HEAD_CLUSTER_REPLACED";
                    else if (_excludedSkeletonEdge[i])
                    {
                        bool rootAnchor = _applyParents[parent] < 0;
                        state = rootAnchor ? "EXCLUDED_ROOT_ANCHOR" :
                            (IsInsideExcludedPelvicSkirtBranch(i, nodeCount) ? "EXCLUDED_PELVIC_SKIRT_SUBTREE" :
                            (IsInsideExcludedSmallBranch(i, nodeCount) ? "EXCLUDED_SMALL_SUBTREE" : "EXCLUDED_OTHER"));
                    }
                    else if (!_applyValid[i] || !_applyValid[parent])
                        state = "KEEP_UNPROJECTED";
                    else
                        state = "KEEP";

                    string screen = _applyValid[i]
                        ? $"({_applyProjected[i].X:F1},{_applyProjected[i].Y:F1})"
                        : "NONE";
                    lines.Add(
                        $"[STAGE98][EDGE-MAP] childNode={i} childBone={_applyBoneIndices[i]} " +
                        $"parentNode={parent} parentBone={parentBone} " +
                        $"worldXYZ=({_applyX[i]:F3},{_applyY[i]:F3},{_applyZ[i]:F3}) " +
                        $"screenXY={screen} state={state}");
                }

                string path = Path.Combine(Environment.CurrentDirectory, "STAGE98_SKELETON_EDGE_TRACE.txt");
                File.AppendAllLines(path, lines, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[STAGE98][EDGE-MAP-WRITE-FAILED] {ex.GetType().Name}: {ex.Message}");
            }
        }

        private bool IsInsideExcludedPelvicSkirtBranch(int node, int nodeCount)
        {
            int ancestor = node;
            int guard = 0;
            while (ancestor >= 0 && ancestor < nodeCount && guard++ < nodeCount)
            {
                if (_excludedPelvicSkirtBranchRoot[ancestor])
                    return true;
                ancestor = _applyParents[ancestor];
            }
            return false;
        }

        private bool IsInsideExcludedSmallBranch(int node, int nodeCount)
        {
            int ancestor = node;
            int guard = 0;
            while (ancestor >= 0 && ancestor < nodeCount && guard++ < nodeCount)
            {
                if (_excludedSmallBranchRoot[ancestor])
                    return true;
                ancestor = _applyParents[ancestor];
            }
            return false;
        }

        /// <summary>
        /// Removes clutter by pruning compact side subtrees from the existing native tree.
        /// It never creates a replacement edge or bridges across a removed branch. Candidate
        /// pruning begins only at a junction, uses the full subtree's 3D bounds (including
        /// forked descendants), and protects branches containing the highest/head or lowest/
        /// foot extent so the principal spine and leg paths are not discarded as "small".
        /// </summary>
        private void BuildExcludedSkeletonEdgeMask(int nodeCount, bool respectProjectionValidity = false)
        {
            Array.Clear(_excludedSkeletonEdge, 0, nodeCount);
            Array.Clear(_excludedSmallBranchRoot, 0, nodeCount);
            Array.Clear(_pelvicSkirtCandidate, 0, nodeCount);
            Array.Clear(_excludedPelvicSkirtBranchRoot, 0, nodeCount);
            Array.Clear(_applyChildCounts, 0, nodeCount);
            Array.Clear(_subtreeNodeCounts, 0, nodeCount);
            _excludedRootAnchorEdges = 0;
            _excludedSmallSubtreeEdges = 0;
            _excludedSmallBranchRoots = 0;
            _excludedPelvicSkirtRoots = 0;
            _excludedPelvicSkirtEdges = 0;

            float minY = float.PositiveInfinity;
            float maxY = float.NegativeInfinity;

            // Seed per-node subtree bounds and collect the original tree's child counts.
            for (int i = 0; i < nodeCount; i++)
            {
                bool valid = (!respectProjectionValidity || _applyValid[i]) &&
                    IsValidCoordinate(_applyX[i]) &&
                    IsValidCoordinate(_applyY[i]) && IsValidCoordinate(_applyZ[i]);
                if (valid)
                {
                    _subtreeMinX[i] = _subtreeMaxX[i] = _applyX[i];
                    _subtreeMinY[i] = _subtreeMaxY[i] = _applyY[i];
                    _subtreeMinZ[i] = _subtreeMaxZ[i] = _applyZ[i];
                    minY = MathF.Min(minY, _applyY[i]);
                    maxY = MathF.Max(maxY, _applyY[i]);
                }
                else
                {
                    _subtreeMinX[i] = _subtreeMinY[i] = _subtreeMinZ[i] = float.PositiveInfinity;
                    _subtreeMaxX[i] = _subtreeMaxY[i] = _subtreeMaxZ[i] = float.NegativeInfinity;
                }

                _subtreeNodeCounts[i] = valid ? 1 : 0;
                int parent = _applyParents[i];
                if (valid && parent >= 0 && parent < nodeCount && parent != i &&
                    (!respectProjectionValidity || _applyValid[parent]))
                    _applyChildCounts[parent]++;
            }

            float bodyHeight = maxY - minY;
            if (!float.IsFinite(bodyHeight) || bodyHeight <= 0f)
                return;

            // Parent indices precede child indices in the validated traversal. Folding in
            // reverse order gives every node its complete descendant bounds/count in O(n).
            for (int child = nodeCount - 1; child >= 1; child--)
            {
                int parent = _applyParents[child];
                if (parent < 0 || parent >= child)
                    continue;

                _subtreeNodeCounts[parent] += _subtreeNodeCounts[child];
                if (_subtreeNodeCounts[child] <= 0 ||
                    !float.IsFinite(_subtreeMinX[child]) ||
                    !float.IsFinite(_subtreeMaxX[child]))
                    continue;

                _subtreeMinX[parent] = MathF.Min(_subtreeMinX[parent], _subtreeMinX[child]);
                _subtreeMaxX[parent] = MathF.Max(_subtreeMaxX[parent], _subtreeMaxX[child]);
                _subtreeMinY[parent] = MathF.Min(_subtreeMinY[parent], _subtreeMinY[child]);
                _subtreeMaxY[parent] = MathF.Max(_subtreeMaxY[parent], _subtreeMaxY[child]);
                _subtreeMinZ[parent] = MathF.Min(_subtreeMinZ[parent], _subtreeMinZ[child]);
                _subtreeMaxZ[parent] = MathF.Max(_subtreeMaxZ[parent], _subtreeMaxZ[child]);
            }

            // Keep the root-origin connector excluded, as in Stage 87.
            for (int child = 0; child < nodeCount; child++)
            {
                int parent = _applyParents[child];
                if (parent < 0 || parent >= nodeCount || parent == child)
                    continue;
                if (_applyParents[parent] < 0)
                {
                    _excludedSkeletonEdge[child] = true;
                    _excludedRootAnchorEdges++;
                }
            }

            float maxSmallBranchExtent = Math.Clamp(
                bodyHeight * SMALL_BRANCH_BODY_HEIGHT_SCALE,
                SMALL_BRANCH_MIN_EXTENT,
                SMALL_BRANCH_MAX_EXTENT);
            float extremeGuard = bodyHeight * BODY_EXTREME_GUARD_SCALE;

            // Stage 89 targeted correction: exclude the compact "skirt" branches radiating
            // from the pelvis-like junction. The junction is recognized from the original
            // hierarchy rather than a bone index: it has >=5 direct children, at least one
            // child subtree reaches the upper/head extreme, and >=1 child subtree reaches the
            // lower/foot extreme (the legs can branch again one level down). Other short branches
            // at that same junction are the extra hip/skirt fan, not the leg chains or torso.
            // The observed Stage 88 edge map had this pattern at the pelvis: a trunk branch, a
            // lower-body subtree containing both leg continuations, and four compact branches.
            float pelvicSkirtMaxHeight = bodyHeight * PELVIC_SKIRT_MAX_BRANCH_HEIGHT_SCALE;
            float pelvicSkirtMaxRootEdge = bodyHeight * PELVIC_SKIRT_MAX_ROOT_EDGE_SCALE;
            float pelvicSkirtMaxExtent = bodyHeight * PELVIC_SKIRT_MAX_TOTAL_EXTENT_SCALE;
            for (int parent = 0; parent < nodeCount; parent++)
            {
                if (_applyChildCounts[parent] < PELVIC_FAN_MIN_CHILDREN)
                    continue;

                int upperExtremeBranches = 0;
                int lowerExtremeBranches = 0;
                for (int child = 0; child < nodeCount; child++)
                {
                    if (_applyParents[child] != parent)
                        continue;
                    if (_subtreeMaxY[child] >= maxY - extremeGuard)
                        upperExtremeBranches++;
                    if (_subtreeMinY[child] <= minY + extremeGuard)
                        lowerExtremeBranches++;
                }

                if (upperExtremeBranches < 1 ||
                    lowerExtremeBranches < PELVIC_FAN_MIN_BOTTOM_BRANCHES)
                    continue;

                int candidateCount = 0;
                for (int child = 0; child < nodeCount; child++)
                {
                    if (_applyParents[child] != parent ||
                        _subtreeMaxY[child] >= maxY - extremeGuard ||
                        _subtreeMinY[child] <= minY + extremeGuard ||
                        _subtreeNodeCounts[child] > PELVIC_SKIRT_MAX_SUBTREE_NODES)
                        continue;

                    float branchHeight = _subtreeMaxY[child] - _subtreeMinY[child];
                    if (!float.IsFinite(branchHeight) || branchHeight > pelvicSkirtMaxHeight)
                        continue;

                    float edgeLength = Distance(
                        _applyX[parent], _applyY[parent], _applyZ[parent],
                        _applyX[child], _applyY[child], _applyZ[child]);
                    float spanX = _subtreeMaxX[child] - _subtreeMinX[child];
                    float spanY = _subtreeMaxY[child] - _subtreeMinY[child];
                    float spanZ = _subtreeMaxZ[child] - _subtreeMinZ[child];
                    float subtreeDiagonal = Distance(0f, 0f, 0f, spanX, spanY, spanZ);
                    float totalExtent = edgeLength + subtreeDiagonal;
                    if (!float.IsFinite(edgeLength) || edgeLength > pelvicSkirtMaxRootEdge ||
                        !float.IsFinite(totalExtent) || totalExtent > pelvicSkirtMaxExtent)
                        continue;

                    _pelvicSkirtCandidate[child] = true;
                    candidateCount++;
                }

                // Require at least two compact sibling branches before applying this special
                // pelvic-fan rule. This avoids treating a lone short shoulder/arm edge as a skirt.
                if (candidateCount < 2)
                {
                    for (int child = 0; child < nodeCount; child++)
                        if (_applyParents[child] == parent)
                            _pelvicSkirtCandidate[child] = false;
                    continue;
                }

                for (int child = 0; child < nodeCount; child++)
                {
                    if (!_pelvicSkirtCandidate[child])
                        continue;
                    _excludedSmallBranchRoot[child] = true;
                    _excludedPelvicSkirtBranchRoot[child] = true;
                    _excludedSmallBranchRoots++;
                    _excludedPelvicSkirtRoots++;
                    _pelvicSkirtCandidate[child] = false;
                }
            }

            // Mark only the roots of other compact side subtrees. They are candidates only when
            // the parent is a junction: single-child torso/arm/leg chains remain untouched.
            for (int start = 0; start < nodeCount; start++)
            {
                int parent = _applyParents[start];
                if (parent < 0 || parent >= nodeCount || parent == start ||
                    _applyChildCounts[parent] < 2 || _excludedSkeletonEdge[start] ||
                    _excludedSmallBranchRoot[start])
                    continue;

                // An already marked ancestor owns this whole subtree; do not double-count
                // nested candidate roots.
                bool insideExcludedBranch = false;
                int ancestor = parent;
                int guard = 0;
                while (ancestor >= 0 && ancestor < nodeCount && guard++ < nodeCount)
                {
                    if (_excludedSmallBranchRoot[ancestor])
                    {
                        insideExcludedBranch = true;
                        break;
                    }
                    ancestor = _applyParents[ancestor];
                }
                if (insideExcludedBranch)
                    continue;

                if (!float.IsFinite(_subtreeMinX[start]) ||
                    !float.IsFinite(_subtreeMaxX[start]) ||
                    !float.IsFinite(_subtreeMinY[start]) ||
                    !float.IsFinite(_subtreeMaxY[start]) ||
                    !float.IsFinite(_subtreeMinZ[start]) ||
                    !float.IsFinite(_subtreeMaxZ[start]))
                    continue;

                // Never remove a branch which contains either vertical extremity. This is
                // the guard that protects the head/top and foot/bottom paths across poses.
                if (_subtreeMinY[start] <= minY + extremeGuard ||
                    _subtreeMaxY[start] >= maxY - extremeGuard)
                    continue;

                float edgeLength = Distance(
                    _applyX[parent], _applyY[parent], _applyZ[parent],
                    _applyX[start], _applyY[start], _applyZ[start]);
                float spanX = _subtreeMaxX[start] - _subtreeMinX[start];
                float spanY = _subtreeMaxY[start] - _subtreeMinY[start];
                float spanZ = _subtreeMaxZ[start] - _subtreeMinZ[start];
                float subtreeDiagonal = Distance(0f, 0f, 0f, spanX, spanY, spanZ);
                float conservativeExtent = edgeLength + subtreeDiagonal;
                if (!float.IsFinite(conservativeExtent) ||
                    conservativeExtent > maxSmallBranchExtent)
                    continue;

                _excludedSmallBranchRoot[start] = true;
                _excludedSmallBranchRoots++;
            }

            // Exclude the complete incoming-edge set for every marked branch root and all
            // descendants. The surviving links are exactly the original parent-child links.
            for (int node = 0; node < nodeCount; node++)
            {
                int ancestor = node;
                int guard = 0;
                bool excluded = false;
                bool pelvicSkirt = false;
                while (ancestor >= 0 && ancestor < nodeCount && guard++ < nodeCount)
                {
                    if (_excludedSmallBranchRoot[ancestor])
                    {
                        excluded = true;
                        pelvicSkirt = _excludedPelvicSkirtBranchRoot[ancestor];
                        break;
                    }
                    ancestor = _applyParents[ancestor];
                }

                if (excluded && !_excludedSkeletonEdge[node])
                {
                    _excludedSkeletonEdge[node] = true;
                    _excludedSmallSubtreeEdges++;
                    if (pelvicSkirt)
                        _excludedPelvicSkirtEdges++;
                }
            }
        }

        private void PublishPose(EntityData entity, ResolutionCache cache)
        {
            long entityPtr = entity.Ptr;
            lock (_poseLock)
            {
                if (!_latestPoses.TryGetValue(entityPtr, out PoseState pose))
                {
                    pose = new PoseState();
                    _latestPoses[entityPtr] = pose;
                }

                pose.EntityId = entity.EntityId;
                int count = Math.Min(cache.Nodes.Length, SKELETON_MAX_NODES);
                pose.NodeCount = count;
                pose.SkeletonVerified = cache.SkeletonVerified;
                pose.SampleTicks = Stopwatch.GetTimestamp();

                for (int i = 0; i < count; i++)
                {
                    CachedNode node = cache.Nodes[i];
                    pose.NodePtrs[i] = node.Ptr;
                    pose.Parents[i] = node.ParentIndex;
                    pose.BoneIndices[i] = node.BoneIndex;
                    pose.X[i] = node.X;
                    pose.Y[i] = node.Y;
                    pose.Z[i] = node.Z;
                }
            }
        }

        private static string CoverageOutcomeCode(string reason, string fallback)
        {
            if (string.IsNullOrWhiteSpace(reason))
                return fallback;
            int separator = reason.IndexOfAny(new[] { ' ', ':' });
            return separator > 0 ? reason.Substring(0, separator) : reason;
        }

        private void RemovePose(long entityPtr)
        {
            lock (_poseLock)
            {
                _latestPoses.Remove(entityPtr);
            }
        }

        private void PrunePoses()
        {
            lock (_poseLock)
            {
                if (_latestPoses.Count <= _activeEntities.Count + 32)
                    return;

                var remove = new List<long>();
                foreach (long ptr in _latestPoses.Keys)
                {
                    if (!_activeEntities.Contains(ptr))
                        remove.Add(ptr);
                }

                foreach (long ptr in remove)
                    _latestPoses.Remove(ptr);
            }
        }

        private void PruneCaches()
        {
            if (_failedResolveRetryAt.Count > 0)
            {
                var expiredEntities = new List<long>();
                foreach (long ptr in _failedResolveRetryAt.Keys)
                    if (!_activeEntities.Contains(ptr)) expiredEntities.Add(ptr);
                foreach (long ptr in expiredEntities) _failedResolveRetryAt.Remove(ptr);
            }

            if (_cache.Count <= _activeEntities.Count + 32)
                return;

            var remove = new List<long>();
            foreach (long ptr in _cache.Keys)
            {
                if (!_activeEntities.Contains(ptr))
                    remove.Add(ptr);
            }

            foreach (long ptr in remove)
                _cache.Remove(ptr);
        }

        private bool TryResolve(
            EntityData entity,
            long nowMs,
            out ResolutionCache resolved,
            out string failureReason)
        {
            resolved = null;
            failureReason = null;

            // The resolver cache is keyed by native pointer for speed, but that pointer
            // alone is not a stable actor identity. Invalidate both the cached rig and its
            // published pose when the same address now reports a different entity ID.
            if (_cache.TryGetValue(entity.Ptr, out ResolutionCache identityCache) &&
                identityCache.EntityId != entity.EntityId)
            {
                _cache.Remove(entity.Ptr);
                _failedResolveRetryAt.Remove(entity.Ptr);
                RemovePose(entity.Ptr);
                if (_entityIdentityChangeLogCount < 16)
                {
                    _entityIdentityChangeLogCount++;
                    Console.WriteLine(
                        $"  [DYN-SKEL][ENTITY-IDENTITY-CHANGE] ptr=0x{entity.Ptr:X} " +
                        $"oldId=0x{identityCache.EntityId:X8} newId=0x{entity.EntityId:X8} " +
                        "action=DROP_CACHED_RIG_AND_POSE");
                }
            }

            if (_failedResolveRetryAt.TryGetValue(entity.Ptr, out long retryAt))
            {
                if (nowMs < retryAt)
                {
                    failureReason = "RETRY_COOLDOWN";
                    return false;
                }
                _failedResolveRetryAt.Remove(entity.Ptr);
            }

            if (_cache.TryGetValue(entity.Ptr, out ResolutionCache cached))
            {
                if (nowMs < cached.NextB8CheckMs)
                {
                    resolved = cached;
                    if (cached.Nodes.Length <= 1)
                    {
                        failureReason = "CACHED_HIERARCHY_TOO_SMALL";
                        return false;
                    }
                    return true;
                }

                long b8 = _mem.ReadLong(entity.Ptr + BGA_NATIVE_GRAPH, "DYN.b8_check");
                cached.NextB8CheckMs = nowMs + B8_RECHECK_INTERVAL_MS;

                if (IsFollowablePointer(b8) && b8 == cached.B8)
                {
                    if (nowMs < cached.NextRootValidateMs || ValidateCachedRoot(cached, entity))
                    {
                        cached.NextRootValidateMs = nowMs + ROOT_VALIDATE_INTERVAL_MS;
                        resolved = cached;
                        if (cached.Nodes.Length <= 1)
                        {
                            failureReason = "CACHED_HIERARCHY_TOO_SMALL";
                            RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_TOO_SMALL", entity.Ptr);
                            return false;
                        }
                        return true;
                    }
                }

                if (!IsFollowablePointer(b8))
                    RuntimeDiagnostics.SkeletonResolveRejected("B8_INVALID", entity.Ptr);

                _cache.Remove(entity.Ptr);
            }

            long freshB8 = _mem.ReadLong(entity.Ptr + BGA_NATIVE_GRAPH, "DYN.b8");
            if (!IsFollowablePointer(freshB8))
            {
                RuntimeDiagnostics.SkeletonResolveRejected("B8_INVALID", entity.Ptr);
                failureReason = "B8_INVALID";
                _failedResolveRetryAt[entity.Ptr] = nowMs + FAILED_RESOLVE_RETRY_INTERVAL_MS;
                return false;
            }

            if (!TryFindModelAndRoot(entity, freshB8, out long model, out long rootNode,
                    out string discoveryFailure))
            {
                failureReason = discoveryFailure ?? "MODEL_DISCOVERY_FAILED";
                _failedResolveRetryAt[entity.Ptr] = nowMs + FAILED_RESOLVE_RETRY_INTERVAL_MS;
                return false;
            }

            long rootVtable = _mem.ReadLong(rootNode, "DYN.root_vtable");
            if (!IsFollowablePointer(rootVtable))
            {
                RuntimeDiagnostics.SkeletonResolveRejected("ROOT_INVALID", entity.Ptr);
                failureReason = "ROOT_INVALID";
                _failedResolveRetryAt[entity.Ptr] = nowMs + FAILED_RESOLVE_RETRY_INTERVAL_MS;
                return false;
            }

            if (!TryBuildNativeBoneHierarchy(
                    rootNode, model, rootVtable, entity,
                    out CachedNode[] nodes,
                    out long skeletalAnim,
                    out long boneMatrixTable,
                    out int boneCount))
            {
                WriteDiscoveryTrace(
                    $"HIERARCHY_REJECT entity=0x{entity.Ptr:X} model=0x{model:X} root=0x{rootNode:X} " +
                    "reason=NATIVE_BONE_HIERARCHY_INVALID");
                failureReason = "NATIVE_BONE_HIERARCHY_INVALID";
                _failedResolveRetryAt[entity.Ptr] = nowMs + FAILED_RESOLVE_RETRY_INTERVAL_MS;
                return false;
            }
            _failedResolveRetryAt.Remove(entity.Ptr);

            var cache = new ResolutionCache
            {
                EntityId = entity.EntityId,
                B8 = freshB8,
                Model = model,
                RootNode = rootNode,
                RootVtable = rootVtable,
                SkeletalAnim = skeletalAnim,
                BoneMatrixTable = boneMatrixTable,
                BoneCount = boneCount,
                SkeletalBoneHierarchy = true,
                Nodes = nodes,
                NextB8CheckMs = nowMs + B8_RECHECK_INTERVAL_MS,
                NextRootValidateMs = nowMs + ROOT_VALIDATE_INTERVAL_MS,
                HasSample = false,
                SkeletonVerified = true,
            };

            _cache[entity.Ptr] = cache;
            resolved = cache;

            Console.WriteLine(
                $"  [DYN-SKEL][RESOLVED] entity=0x{entity.Ptr:X} entityId=0x{entity.EntityId:X8} " +
                $"model=0x{model:X} root=0x{rootNode:X} rootVtable=0x{rootVtable:X} " +
                $"skeletalAnim=0x{skeletalAnim:X} boneMatrices=0x{boneMatrixTable:X} " +
                $"boneCount={boneCount} validatedHierarchyNodes={nodes.Length}");
            return nodes.Length > 1;
        }

        private bool TryFindModelAndRoot(
            EntityData entity, long b8, out long model, out long rootNode, out string failureReason)
        {
            model = 0;
            rootNode = 0;
            failureReason = null;
            // Only route routine resolver-evidence messages when their optional sink is
            // actually active. Stage 80's normal overlay does not install that legacy sink;
            // failed entities are traced by the direct-to-file Stage 81 replay below.
            bool traceEvidence = RuntimeDiagnostics.SkeletonEvidenceCaptureActive &&
                BeginResolverEvidence(entity, b8);
            if (traceEvidence)
            {
                RuntimeDiagnostics.SkeletonEvidence(
                    $"RESOLVE_BEGIN entity=0x{entity.Ptr:X} entityId=0x{entity.EntityId:X8} " +
                    $"xyz=({entity.X:F3},{entity.Y:F3},{entity.Z:F3}) b8=0x{b8:X} " +
                    $"expectedModelVtable=0x{_mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA:X} " +
                    $"maxDepth={RESOLVE_MAX_DEPTH} maxObjects={RESOLVE_MAX_OBJECTS}");
            }

            bool entityModelBlockRead = false;
            bool modelArrayMetadataValid = false;
            bool modelArrayReadSucceeded = false;
            int modelArrayCandidates = 0;
            int modelArrayAccepted = 0;

            long directModel = 0;
            long modelBegin = 0;
            long modelEnd = 0;

            int graphExpanded = 0;
            int graphModelCandidates = 0;
            int graphReadFailures = 0;
            int graphVtableSlotsSkipped = 0;
            int graphModuleImagePointersSkipped = 0;

            entityModelBlockRead = _mem.ReadBytesQuiet(
                entity.Ptr + ENTITY_MODEL,
                _entityModelScratch,
                0,
                _entityModelScratch.Length);

            if (entityModelBlockRead)
            {
                directModel = BitConverter.ToInt64(_entityModelScratch, 0);
                if (traceEvidence)
                    RuntimeDiagnostics.SkeletonEvidence(
                        $"ENTITY_MODEL_BLOCK entity=0x{entity.Ptr:X} read=1 fieldD8=0x{directModel:X} " +
                        $"expectedVtable=0x{_mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA:X}");
                if (TryAcceptModelRoot(directModel, entity, out rootNode, traceEvidence, "ENTITY+0xD8"))
                {
                    model = directModel;
                    if (traceEvidence)
                        RuntimeDiagnostics.SkeletonEvidence(
                            $"RESOLVE_TERMINAL entity=0x{entity.Ptr:X} reason=ENTITY_D8_RESOLVED " +
                            $"model=0x{model:X} root=0x{rootNode:X}");
                    return true;
                }

                modelBegin = BitConverter.ToInt64(
                    _entityModelScratch,
                    ENTITY_MODELS_BEGIN - ENTITY_MODEL);
                modelEnd = BitConverter.ToInt64(
                    _entityModelScratch,
                    ENTITY_MODELS_END - ENTITY_MODEL);

                modelArrayMetadataValid =
                    IsPlausiblePointer(modelBegin) &&
                    IsPlausiblePointer(modelEnd) &&
                    modelEnd >= modelBegin &&
                    (modelEnd - modelBegin) <= _modelArrayScratch.Length &&
                    ((modelEnd - modelBegin) & 7L) == 0 &&
                    modelEnd > modelBegin;

                if (traceEvidence)
                    RuntimeDiagnostics.SkeletonEvidence(
                        $"MODEL_ARRAY_METADATA entity=0x{entity.Ptr:X} begin=0x{modelBegin:X} end=0x{modelEnd:X} " +
                        $"bytes={(IsPlausiblePointer(modelBegin) && IsPlausiblePointer(modelEnd) && modelEnd >= modelBegin ? modelEnd - modelBegin : -1)} " +
                        $"valid={(modelArrayMetadataValid ? 1 : 0)} maxBytes={_modelArrayScratch.Length}");

                if (modelArrayMetadataValid)
                {
                    int bytes = (int)(modelEnd - modelBegin);
                    modelArrayReadSucceeded = _mem.ReadBytesQuiet(
                        modelBegin,
                        _modelArrayScratch,
                        0,
                        bytes);

                    if (modelArrayReadSucceeded)
                    {
                        int count = bytes / 8;
                        if (traceEvidence)
                            RuntimeDiagnostics.SkeletonEvidence(
                                $"MODEL_ARRAY_READ entity=0x{entity.Ptr:X} bytes={bytes} candidates={count} " +
                                $"candidateTraceLimit={MAX_MODEL_ARRAY_EVIDENCE_CANDIDATES}");
                        for (int i = 0; i < count; i++)
                        {
                            modelArrayCandidates++;
                            long candidate = BitConverter.ToInt64(_modelArrayScratch, i * 8);
                            bool traceCandidate = traceEvidence && i < MAX_MODEL_ARRAY_EVIDENCE_CANDIDATES;
                            if (traceCandidate)
                                RuntimeDiagnostics.SkeletonEvidence(
                                    $"MODEL_ARRAY_CANDIDATE entity=0x{entity.Ptr:X} index={i} " +
                                    $"slot=0x{modelBegin + i * 8L:X} value=0x{candidate:X}");
                            if (!TryAcceptModelRoot(candidate, entity, out long candidateRoot, traceCandidate, $"MODEL_ARRAY[{i}]"))
                                continue;

                            modelArrayAccepted++;
                            model = candidate;
                            rootNode = candidateRoot;
                            if (traceEvidence)
                                RuntimeDiagnostics.SkeletonEvidence(
                                    $"RESOLVE_TERMINAL entity=0x{entity.Ptr:X} reason=ENTITY_MODEL_ARRAY_RESOLVED " +
                                    $"index={i} model=0x{model:X} root=0x{rootNode:X} " +
                                    $"arrayCandidates={modelArrayCandidates} arrayAccepted={modelArrayAccepted}");
                            return true;
                        }
                    }
                }
            }
            else if (traceEvidence)
            {
                RuntimeDiagnostics.SkeletonEvidence(
                    $"ENTITY_MODEL_BLOCK entity=0x{entity.Ptr:X} read=0 fieldBase=0x{entity.Ptr + ENTITY_MODEL:X} bytes={_entityModelScratch.Length}");
            }

            var queue = new Queue<(long Ptr, int Depth, long Parent, int ParentOffset)>();
            var visited = new HashSet<long>();
            queue.Enqueue((b8, 0, 0, -1));
            visited.Add(b8);

            float bestDistance = float.MaxValue;

            while (queue.Count > 0 && graphExpanded < RESOLVE_MAX_OBJECTS)
            {
                var item = queue.Dequeue();
                if (item.Depth > RESOLVE_MAX_DEPTH || !IsFollowablePointer(item.Ptr))
                    continue;

                if (!_mem.ReadBytesQuiet(item.Ptr, _resolveScratch, 0, _resolveScratch.Length))
                {
                    graphReadFailures++;
                    if (traceEvidence)
                        RuntimeDiagnostics.SkeletonEvidence(
                            $"GRAPH_READ_FAIL entity=0x{entity.Ptr:X} object=0x{item.Ptr:X} depth={item.Depth} " +
                            $"parent=0x{item.Parent:X} parentSlot={(item.ParentOffset >= 0 ? $"0x{item.ParentOffset:X}" : "root")}");
                    continue;
                }

                graphExpanded++;
                long vt = BitConverter.ToInt64(_resolveScratch, 0);
                bool exactModelVtable = vt == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;
                if (traceEvidence)
                    RuntimeDiagnostics.SkeletonEvidence(
                        $"GRAPH_OBJECT entity=0x{entity.Ptr:X} depth={item.Depth} object=0x{item.Ptr:X} " +
                        $"parent=0x{item.Parent:X} parentSlot={(item.ParentOffset >= 0 ? $"0x{item.ParentOffset:X}" : "root")} " +
                        $"vtable=0x{vt:X} vtableRva={(vt >= _mem.BaseAddress ? $"0x{vt - _mem.BaseAddress:X}" : "below-module")} " +
                        $"exactModelVtable={(exactModelVtable ? 1 : 0)}");
                if (exactModelVtable)
                {
                    graphModelCandidates++;
                    long candidateRoot = BitConverter.ToInt64(_resolveScratch, MODEL_SPACE_NODE);
                    if (traceEvidence)
                        RuntimeDiagnostics.SkeletonEvidence(
                            $"B8_MODEL_CANDIDATE entity=0x{entity.Ptr:X} model=0x{item.Ptr:X} " +
                            $"root38=0x{candidateRoot:X} depth={item.Depth} parent=0x{item.Parent:X} parentSlot=0x{item.ParentOffset:X}");
                    if (TryAcceptRoot(candidateRoot, item.Ptr, entity, out float distance, traceEvidence, "B8_GRAPH"))
                    {
                        if (distance < bestDistance)
                        {
                            bestDistance = distance;
                            model = item.Ptr;
                            rootNode = candidateRoot;
                        }
                    }
                }

                if (item.Depth >= RESOLVE_MAX_DEPTH)
                    continue;

                // The first qword of a polymorphic native object is its vtable, not a
                // child-object pointer. Avoid enqueuing it as a new graph node.
                bool parentHasImageVtable = _mem.IsMainModuleAddress(vt);
                for (int i = 0; i < _resolveScratch.Length / 8; i++)
                {
                    if (i == 0 && parentHasImageVtable)
                    {
                        graphVtableSlotsSkipped++;
                        continue;
                    }

                    long child = BitConverter.ToInt64(_resolveScratch, i * 8);
                    if (!IsFollowablePointer(child))
                        continue;
                    if (_mem.IsMainModuleAddress(child))
                    {
                        graphModuleImagePointersSkipped++;
                        continue;
                    }
                    if (visited.Contains(child))
                        continue;

                    if (visited.Count < RESOLVE_MAX_OBJECTS)
                    {
                        visited.Add(child);
                        queue.Enqueue((child, item.Depth + 1, item.Ptr, i * 8));
                        continue;
                    }

                    // The expansion cap limits queued/read objects, not the remainder of
                    // the current object's in-bounds qword scan. At the cap, probe only
                    // direct child vtables for the exact native ModelSkeletal type so a
                    // candidate later in this object's fields is not silently skipped.
                    long childVtable = _mem.ReadLong(child, "DYN.graph_cap_model_vtable");
                    if (childVtable != _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA)
                        continue;

                    graphModelCandidates++;
                    long candidateRoot = _mem.ReadLong(child + MODEL_SPACE_NODE, "DYN.graph_cap_model_root");
                    if (traceEvidence)
                        RuntimeDiagnostics.SkeletonEvidence(
                            $"GRAPH_CAP_MODEL_CANDIDATE entity=0x{entity.Ptr:X} model=0x{child:X} " +
                            $"root38=0x{candidateRoot:X} depth={item.Depth + 1} parent=0x{item.Ptr:X} " +
                            $"parentSlot=0x{i * 8:X}");
                    if (TryAcceptRoot(candidateRoot, child, entity, out float candidateDistance,
                            traceEvidence, "B8_GRAPH_CAP_FRONTIER") && candidateDistance < bestDistance)
                    {
                        bestDistance = candidateDistance;
                        model = child;
                        rootNode = candidateRoot;
                    }
                }
            }

            if (model != 0 && rootNode != 0)
            {
                if (traceEvidence)
                    RuntimeDiagnostics.SkeletonEvidence(
                        $"RESOLVE_TERMINAL entity=0x{entity.Ptr:X} reason=B8_GRAPH_RESOLVED " +
                        $"model=0x{model:X} root=0x{rootNode:X} arrayCandidates={modelArrayCandidates} " +
                        $"arrayAccepted={modelArrayAccepted} graphExpanded={graphExpanded} " +
                        $"graphModelCandidates={graphModelCandidates} graphReadFailures={graphReadFailures}");
                RuntimeDiagnostics.SkeletonModelDiscoveryTerminal(
                    "B8_GRAPH_RESOLVED",
                    entity.Ptr,
                    b8,
                    directModel,
                    modelBegin,
                    modelEnd,
                    modelArrayCandidates,
                    modelArrayAccepted,
                    graphExpanded,
                    graphModelCandidates,
                    graphReadFailures);
                TraceModelRootNeighborhood(entity, model, rootNode, "B8_GRAPH");
                return true;
            }

            string terminalReason;
            if (graphModelCandidates == 0)
            {
                terminalReason = "B8_GRAPH_NO_MODEL";
            }
            else
            {
                terminalReason = "B8_GRAPH_MODEL_NO_ACCEPTED_ROOT";
            }

            if (traceEvidence)
                RuntimeDiagnostics.SkeletonEvidence(
                    $"RESOLVE_TERMINAL entity=0x{entity.Ptr:X} reason={terminalReason} " +
                    $"entityModelBlockRead={(entityModelBlockRead ? 1 : 0)} directModel=0x{directModel:X} " +
                    $"arrayMetadataValid={(modelArrayMetadataValid ? 1 : 0)} arrayRead={(modelArrayReadSucceeded ? 1 : 0)} " +
                    $"modelBegin=0x{modelBegin:X} modelEnd=0x{modelEnd:X} arrayCandidates={modelArrayCandidates} " +
                    $"arrayAccepted={modelArrayAccepted} graphExpanded={graphExpanded} " +
                    $"graphModelCandidates={graphModelCandidates} graphReadFailures={graphReadFailures}");

            RuntimeDiagnostics.SkeletonModelDiscoveryTerminal(
                terminalReason,
                entity.Ptr,
                b8,
                directModel,
                modelBegin,
                modelEnd,
                modelArrayCandidates,
                modelArrayAccepted,
                graphExpanded,
                graphModelCandidates,
                graphReadFailures);

            failureReason = terminalReason;

            // The ordinary resolver evidence sink is not active in the runtime overlay.
            // Capture a separate, bounded diagnostic replay only after a real lookup
            // fails, so the evidence budget is spent on unresolved entities rather than
            // on the first two entities that happen to resolve successfully.
            if (BeginFailedResolverTrace(entity))
            {
                TraceFailedResolverGraph(
                    entity,
                    b8,
                    terminalReason,
                    directModel,
                    modelBegin,
                    modelEnd,
                    entityModelBlockRead,
                    modelArrayMetadataValid,
                    modelArrayReadSucceeded,
                    modelArrayCandidates,
                    modelArrayAccepted,
                    graphExpanded,
                    graphModelCandidates,
                    graphReadFailures,
                    graphVtableSlotsSkipped,
                    graphModuleImagePointersSkipped);
            }

            return false;
        }

        private bool BeginFailedResolverTrace(EntityData entity)
        {
            if (!DiscoveryTraceEnabled || entity == null || entity.Ptr == 0)
                return false;

            lock (_resolverEvidenceSync)
            {
                if (_failedResolverTraceEntities.Contains(entity.Ptr) ||
                    _failedResolverTraceEntities.Count >= MAX_FAILED_RESOLVER_TRACE_ENTITIES)
                    return false;

                _failedResolverTraceEntities.Add(entity.Ptr);
                return true;
            }
        }

        private void TraceFailedResolverGraph(
            EntityData entity,
            long b8,
            string terminalReason,
            long directModel,
            long modelBegin,
            long modelEnd,
            bool entityModelBlockRead,
            bool modelArrayMetadataValid,
            bool modelArrayReadSucceeded,
            int modelArrayCandidates,
            int modelArrayAccepted,
            int graphExpanded,
            int graphModelCandidates,
            int graphReadFailures,
            int graphVtableSlotsSkipped,
            int graphModuleImagePointersSkipped)
        {
            WriteDiscoveryTrace(
                $"FAILED_RESOLVER_BEGIN entity=0x{entity.Ptr:X} entityId=0x{entity.EntityId:X8} " +
                $"xyz=({entity.X:F3},{entity.Y:F3},{entity.Z:F3}) b8=0x{b8:X} " +
                $"terminalReason={terminalReason} resolverExpanded={graphExpanded} " +
                $"resolverModelCandidates={graphModelCandidates} resolverReadFailures={graphReadFailures} " +
                $"resolverVtableSlotsSkipped={graphVtableSlotsSkipped} " +
                $"resolverModuleImagePointersSkipped={graphModuleImagePointersSkipped} " +
                $"depthLimit={RESOLVE_MAX_DEPTH} objectLimit={RESOLVE_MAX_OBJECTS} " +
                $"objectBytes=0x{RESOLVE_OBJECT_BYTES:X}");

            WriteDiscoveryTrace(
                $"FAILED_ENTITY_MODEL_FIELDS entity=0x{entity.Ptr:X} read={ (entityModelBlockRead ? 1 : 0) } " +
                $"directModel=0x{directModel:X} modelBegin=0x{modelBegin:X} modelEnd=0x{modelEnd:X} " +
                $"arrayBytes={(IsPlausiblePointer(modelBegin) && IsPlausiblePointer(modelEnd) && modelEnd >= modelBegin ? modelEnd - modelBegin : -1)} " +
                $"arrayMetadataValid={(modelArrayMetadataValid ? 1 : 0)} arrayRead={(modelArrayReadSucceeded ? 1 : 0)} " +
                $"arrayCandidates={modelArrayCandidates} arrayAccepted={modelArrayAccepted}");

            TraceFailedModelCandidate(entity, "ENTITY+0xD8", directModel);

            if (modelArrayReadSucceeded && modelArrayMetadataValid &&
                modelEnd >= modelBegin && ((modelEnd - modelBegin) & 7L) == 0)
            {
                int count = Math.Min((int)((modelEnd - modelBegin) / 8), _modelArrayScratch.Length / 8);
                int firstSample = Math.Min(count, 24);
                for (int i = 0; i < firstSample; i++)
                {
                    long candidate = BitConverter.ToInt64(_modelArrayScratch, i * 8);
                    long candidateVtable = IsFollowablePointer(candidate)
                        ? _mem.ReadLong(candidate, "DYN.failtrace_array_vtable") : 0;
                    WriteDiscoveryTrace(
                        $"FAILED_MODEL_ARRAY_SLOT entity=0x{entity.Ptr:X} index={i} " +
                        $"slot=0x{modelBegin + i * 8L:X} value=0x{candidate:X} " +
                        $"vtable=0x{candidateVtable:X} exactModel={(candidateVtable == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA ? 1 : 0)}");
                    if (candidateVtable == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA)
                        TraceFailedModelCandidate(entity, $"ENTITY_MODEL_ARRAY[{i}]", candidate);
                }

                if (count > firstSample)
                {
                    int tailStart = Math.Max(firstSample, count - 8);
                    for (int i = tailStart; i < count; i++)
                    {
                        long candidate = BitConverter.ToInt64(_modelArrayScratch, i * 8);
                        long candidateVtable = IsFollowablePointer(candidate)
                            ? _mem.ReadLong(candidate, "DYN.failtrace_array_tail_vtable") : 0;
                        WriteDiscoveryTrace(
                            $"FAILED_MODEL_ARRAY_TAIL_SLOT entity=0x{entity.Ptr:X} index={i} " +
                            $"slot=0x{modelBegin + i * 8L:X} value=0x{candidate:X} " +
                            $"vtable=0x{candidateVtable:X} exactModel={(candidateVtable == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA ? 1 : 0)}");
                        if (candidateVtable == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA)
                            TraceFailedModelCandidate(entity, $"ENTITY_MODEL_ARRAY[{i}]", candidate);
                    }
                }
            }

            if (!IsFollowablePointer(b8))
            {
                WriteDiscoveryTrace(
                    $"FAILED_GRAPH_ABORT entity=0x{entity.Ptr:X} b8=0x{b8:X} reason=GRAPH_ANCHOR_INVALID");
                WriteDiscoveryTrace(
                    $"FAILED_RESOLVER_END entity=0x{entity.Ptr:X} terminalReason={terminalReason}");
                FlushDiscoveryTrace();
                return;
            }

            var queue = new Queue<(long Ptr, int Depth, long Parent, int ParentOffset)>();
            var visited = new HashSet<long> { b8 };
            var loggedModels = new HashSet<long>();
            queue.Enqueue((b8, 0, 0, -1));
            byte[] scratch = new byte[RESOLVE_OBJECT_BYTES];
            int expanded = 0;
            int readFailures = 0;
            int exactModels = 0;
            int capFrontierModels = 0;
            int capFrontierProbes = 0;
            int detailedModelCandidates = 0;
            int vtableSlotsSkipped = 0;
            int moduleImagePointersSkipped = 0;
            bool capFrontierBudgetExhausted = false;
            long expectedModelVtable = _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;

            while (queue.Count > 0 && expanded < RESOLVE_MAX_OBJECTS)
            {
                var item = queue.Dequeue();
                if (item.Depth > RESOLVE_MAX_DEPTH || !IsFollowablePointer(item.Ptr))
                    continue;

                if (!_mem.ReadBytesQuiet(item.Ptr, scratch, 0, scratch.Length))
                {
                    readFailures++;
                    WriteDiscoveryTrace(
                        $"FAILED_GRAPH_READ_FAIL entity=0x{entity.Ptr:X} object=0x{item.Ptr:X} " +
                        $"depth={item.Depth} parent=0x{item.Parent:X} parentSlot=" +
                        (item.ParentOffset >= 0 ? $"0x{item.ParentOffset:X}" : "root"));
                    continue;
                }

                expanded++;
                long vtable = BitConverter.ToInt64(scratch, 0);
                bool exactModel = vtable == expectedModelVtable;
                WriteDiscoveryTrace(
                    $"FAILED_GRAPH_OBJECT entity=0x{entity.Ptr:X} seq={expanded} ptr=0x{item.Ptr:X} " +
                    $"depth={item.Depth} parent=0x{item.Parent:X} parentSlot=" +
                    (item.ParentOffset >= 0 ? $"0x{item.ParentOffset:X}" : "root") +
                    $" vtable=0x{vtable:X} vtableRva={(vtable >= _mem.BaseAddress ? $"0x{vtable - _mem.BaseAddress:X}" : "below-module")} " +
                    $"exactModel={(exactModel ? 1 : 0)}");

                if (exactModel)
                {
                    exactModels++;
                    if (loggedModels.Add(item.Ptr))
                    {
                        if (detailedModelCandidates < MAX_FAILED_TRACE_MODEL_DETAILS)
                        {
                            TraceFailedModelCandidate(entity, $"B8_GRAPH(depth={item.Depth},parent=0x{item.Parent:X},slot={(item.ParentOffset >= 0 ? $"0x{item.ParentOffset:X}" : "root")})", item.Ptr);
                            detailedModelCandidates++;
                        }
                        else
                        {
                            WriteDiscoveryTrace(
                                $"FAILED_MODEL_CANDIDATE_DETAIL_SKIPPED entity=0x{entity.Ptr:X} model=0x{item.Ptr:X} " +
                                $"reason=DETAIL_LIMIT limit={MAX_FAILED_TRACE_MODEL_DETAILS}");
                        }
                    }
                }

                if (item.Depth >= RESOLVE_MAX_DEPTH)
                    continue;

                bool parentHasImageVtable = _mem.IsMainModuleAddress(vtable);
                for (int i = 0; i < scratch.Length / 8; i++)
                {
                    if (i == 0 && parentHasImageVtable)
                    {
                        vtableSlotsSkipped++;
                        continue;
                    }

                    long child = BitConverter.ToInt64(scratch, i * 8);
                    if (!IsFollowablePointer(child))
                        continue;
                    if (_mem.IsMainModuleAddress(child))
                    {
                        moduleImagePointersSkipped++;
                        continue;
                    }
                    if (visited.Contains(child))
                        continue;

                    if (visited.Count < RESOLVE_MAX_OBJECTS)
                    {
                        visited.Add(child);
                        queue.Enqueue((child, item.Depth + 1, item.Ptr, i * 8));
                        continue;
                    }

                    // Probe a bounded subset of the resolver's cap frontier for detailed
                    // evidence. This diagnostic-only cap prevents a trace from multiplying
                    // the live resolver's potentially large frontier-read cost.
                    if (capFrontierProbes >= MAX_FAILED_TRACE_FRONTIER_PROBES)
                    {
                        capFrontierBudgetExhausted = true;
                        continue;
                    }
                    capFrontierProbes++;
                    long childVtable = _mem.ReadLong(child, "DYN.failtrace_cap_model_vtable");
                    if (childVtable != expectedModelVtable)
                        continue;

                    capFrontierModels++;
                    if (loggedModels.Add(child))
                    {
                        if (detailedModelCandidates < MAX_FAILED_TRACE_MODEL_DETAILS)
                        {
                            TraceFailedModelCandidate(entity, $"B8_CAP_FRONTIER(parent=0x{item.Ptr:X},slot=0x{i * 8:X})", child);
                            detailedModelCandidates++;
                        }
                        else
                        {
                            WriteDiscoveryTrace(
                                $"FAILED_MODEL_CANDIDATE_DETAIL_SKIPPED entity=0x{entity.Ptr:X} model=0x{child:X} " +
                                $"reason=DETAIL_LIMIT limit={MAX_FAILED_TRACE_MODEL_DETAILS}");
                        }
                    }
                }
            }

            WriteDiscoveryTrace(
                $"FAILED_GRAPH_SUMMARY entity=0x{entity.Ptr:X} expanded={expanded} visited={visited.Count} " +
                $"readFailures={readFailures} exactModelObjects={exactModels} capFrontierModelCandidates={capFrontierModels} " +
                $"capFrontierProbes={capFrontierProbes} capFrontierProbeLimit={MAX_FAILED_TRACE_FRONTIER_PROBES} " +
                $"capFrontierBudgetExhausted={(capFrontierBudgetExhausted ? 1 : 0)} " +
                $"vtableSlotsSkipped={vtableSlotsSkipped} moduleImagePointersSkipped={moduleImagePointersSkipped} " +
                $"detailedModelCandidates={detailedModelCandidates} modelDetailLimit={MAX_FAILED_TRACE_MODEL_DETAILS} " +
                $"queueRemaining={queue.Count} liveResolverLimitsUnchanged=1");
            WriteDiscoveryTrace(
                $"FAILED_RESOLVER_END entity=0x{entity.Ptr:X} terminalReason={terminalReason}");
            FlushDiscoveryTrace();
        }

        private void FlushDiscoveryTrace()
        {
            lock (_traceSync)
            {
                try
                {
                    _skeletonTraceWriter?.Flush();
                    _traceLinesSinceFlush = 0;
                }
                catch
                {
                    // Diagnostic flush failures must not affect live resolver behavior.
                }
            }
        }

        private void TraceFailedModelCandidate(EntityData entity, string path, long model)
        {
            long expectedModelVtable = _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;
            if (!IsFollowablePointer(model))
            {
                WriteDiscoveryTrace(
                    $"FAILED_MODEL_CANDIDATE entity=0x{entity.Ptr:X} path={path} model=0x{model:X} " +
                    "accepted=0 reason=POINTER_INVALID");
                return;
            }

            long modelVtable = _mem.ReadLong(model, "DYN.failtrace_model_vtable");
            if (modelVtable != expectedModelVtable)
            {
                WriteDiscoveryTrace(
                    $"FAILED_MODEL_CANDIDATE entity=0x{entity.Ptr:X} path={path} model=0x{model:X} " +
                    $"vtable=0x{modelVtable:X} expectedVtable=0x{expectedModelVtable:X} " +
                    "accepted=0 reason=MODEL_VTABLE_MISMATCH");
                return;
            }

            long root = _mem.ReadLong(model + MODEL_SPACE_NODE, "DYN.failtrace_model_root");
            if (!IsFollowablePointer(root))
            {
                WriteDiscoveryTrace(
                    $"FAILED_MODEL_CANDIDATE entity=0x{entity.Ptr:X} path={path} model=0x{model:X} " +
                    $"vtable=0x{modelVtable:X} root38=0x{root:X} accepted=0 reason=ROOT_POINTER_INVALID");
                return;
            }

            long rootVtable = _mem.ReadLong(root, "DYN.failtrace_root_vtable");
            long rootOwner = _mem.ReadLong(root + SPACE_MODEL, "DYN.failtrace_root_owner");
            bool transformValid = TrySelectTransformSource(
                root, entity.X, entity.Y, entity.Z, float.MaxValue,
                out TransformSource transformSource, out float rootX, out float rootY,
                out float rootZ, out _);
            float distance = transformValid
                ? Distance(entity.X, entity.Y, entity.Z, rootX, rootY, rootZ)
                : float.MaxValue;

            long anim = _mem.ReadLong(model + MODEL_SKELETAL_ANIM, "DYN.failtrace_anim");
            long animVtable = IsFollowablePointer(anim)
                ? _mem.ReadLong(anim, "DYN.failtrace_anim_vtable") : 0;
            long animOwner = IsFollowablePointer(anim)
                ? _mem.ReadLong(anim + SKELETAL_ANIM_MODEL_BACKLINK, "DYN.failtrace_anim_owner") : 0;
            int boneCount = -1;
            if (IsFollowablePointer(anim))
            {
                byte[] countBytes = new byte[sizeof(int)];
                if (_mem.ReadBytesQuiet(anim + SKELETAL_ANIM_BONE_COUNT, countBytes, 0, countBytes.Length))
                    boneCount = BitConverter.ToInt32(countBytes, 0);
            }

            WriteDiscoveryTrace(
                $"FAILED_MODEL_CANDIDATE entity=0x{entity.Ptr:X} path={path} model=0x{model:X} " +
                $"vtable=0x{modelVtable:X} root38=0x{root:X} rootVtable=0x{rootVtable:X} " +
                $"rootOwner40=0x{rootOwner:X} ownerMatches={(rootOwner == model ? 1 : 0)} " +
                $"rootVtableMatches={(rootVtable == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA ? 1 : 0)} " +
                $"transformValid={(transformValid ? 1 : 0)} transformSource={(transformValid ? transformSource.ToString() : "NONE")} " +
                $"rootXYZ={(transformValid ? $"({rootX:F3},{rootY:F3},{rootZ:F3})" : "n/a")} " +
                $"targetDistance={(transformValid ? distance.ToString("F3", System.Globalization.CultureInfo.InvariantCulture) : "n/a")} " +
                $"withinLegacy64UnitGate={(transformValid && float.IsFinite(distance) && distance <= MAX_LEGACY_ROOT_TARGET_DISTANCE ? 1 : 0)} " +
                $"withinNative8UnitGate={(transformValid && float.IsFinite(distance) && distance <= MAX_NATIVE_ROOT_TARGET_DISTANCE ? 1 : 0)} " +
                $"anim=0x{anim:X} animVtable=0x{animVtable:X} animOwnerCF0=0x{animOwner:X} " +
                $"animOwnerMatches={(animOwner == model ? 1 : 0)} boneCount={boneCount}");
        }

        private void TraceModelRootNeighborhood(EntityData entity, long model, long root, string source)
        {
            if (!DiscoveryTraceEnabled)
                return;

            // Diagnostic budget: trace at most two distinct targets and sixteen objects
            // per target. Stage 30 highlighted MODEL+0x3E8 -> +0x618, so probe that path
            // first and do not fan out across every enemy's object graph every few seconds.
            // This is evidence collection only: candidates still must pass hierarchy and
            // relative-motion verification before the renderer can receive a skeleton.
            lock (_resolverEvidenceSync)
            {
                if (_tracedModelRoots.Contains((model, root)) ||
                    _modelPathTraceEntities.Contains(entity.Ptr) ||
                    _modelPathTraceEntities.Count >= MAX_MODEL_PATH_TRACE_ENTITIES)
                    return;
                _tracedModelRoots.Add((model, root));
                _modelPathTraceEntities.Add(entity.Ptr);
            }

            WriteDiscoveryTrace(
                $"ROOT_NEIGHBORHOOD_BEGIN source={source} entity=0x{entity.Ptr:X} entityId=0x{entity.EntityId:X8} " +
                $"target=({entity.X:F3},{entity.Y:F3},{entity.Z:F3}) model=0x{model:X} root=0x{root:X} " +
                $"modelVtable=0x{_mem.ReadLong(model, "DYN.trace_model_vtable"):X} " +
                $"modelPlus3E8=0x{_mem.ReadLong(model + 0x3E8, "DYN.trace_model_3e8"):X} " +
                $"rootVtable=0x{_mem.ReadLong(root, "DYN.trace_root_vtable"):X} " +
                $"rootPlus40=0x{_mem.ReadLong(root + SPACE_MODEL, "DYN.trace_root_owner"):X}");

            var stack = new Stack<(long Ptr, int Depth, string Path, int[] Offsets)>();
            var visited = new HashSet<long>();
            stack.Push((root, 0, "ROOT", NODE_EDGES));
            stack.Push((model, 0, "MODEL", MODEL_EVIDENCE_OFFSETS));
            visited.Add(model);
            visited.Add(root);
            int expanded = 0;
            const int NEIGHBORHOOD_OBJECT_LIMIT = 16;
            while (stack.Count > 0 && expanded < NEIGHBORHOOD_OBJECT_LIMIT)
            {
                var item = stack.Pop();
                expanded++;
                TraceEvidenceObject(entity, item.Ptr, item.Path);
                if (_focusedTraceTracks.TryGetValue((entity.Ptr, item.Ptr), out FocusedTraceTrack track))
                {
                    track.ModelPtr = model;
                    track.RootPtr = root;
                    track.Path = item.Path;
                }
                if (item.Depth >= 2)
                    continue;

                if (item.Ptr == model && item.Depth == 0)
                {
                    // Do not fan out through all model evidence offsets. The next capture
                    // needs the previously observed +0x3E8 branch, specifically its +0x618
                    // child, plus the already-resolved target-owned root path below.
                    long priorityChild = _mem.ReadLong(item.Ptr + 0x3E8, "DYN.trace_child_priority_3e8");
                    if (IsFollowablePointer(priorityChild) && visited.Add(priorityChild))
                        stack.Push((priorityChild, item.Depth + 1,
                            $"{item.Path}+0x3E8->0x{priorityChild:X}", NODE_EDGES));
                    continue;
                }

                // Stack order is intentional: push +0x18, +0x318, then +0x618 so the
                // historically observed +0x618 branch is examined first.
                foreach (int offset in item.Offsets)
                {
                    long child = _mem.ReadLong(item.Ptr + offset, "DYN.trace_child");
                    if (!IsFollowablePointer(child) || !visited.Add(child))
                        continue;
                    stack.Push((child, item.Depth + 1,
                        $"{item.Path}+0x{offset:X}->0x{child:X}", NODE_EDGES));
                }
            }

            WriteDiscoveryTrace(
                $"ROOT_NEIGHBORHOOD_END model=0x{model:X} root=0x{root:X} expanded={expanded} " +
                $"priorityPath=MODEL+0x3E8->+0x618 note=pointer candidates are not accepted as bones unless hierarchy and motion checks pass");
        }

        private void TraceEvidenceObject(EntityData entity, long ptr, string path)
        {
            long vtable = _mem.ReadLong(ptr, "DYN.trace_object_vtable");
            long owner = _mem.ReadLong(ptr + SPACE_MODEL, "DYN.trace_object_owner");
            bool hasAnyTransform = TrySelectTransformSource(
                ptr, entity.X, entity.Y, entity.Z, float.MaxValue,
                out TransformSource anySource, out float anyX, out float anyY, out float anyZ, out _);

            string transform = hasAnyTransform
                ? $"{anySource} xyz=({anyX:F3},{anyY:F3},{anyZ:F3}) targetDistance={Distance(entity.X, entity.Y, entity.Z, anyX, anyY, anyZ):F3}"
                : "NONE";
            bool strictSpaceNode = vtable == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA;
            bool strictModel = vtable == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;
            WriteDiscoveryTrace(
                $"GRAPH_OBJECT path={path} ptr=0x{ptr:X} vtable=0x{vtable:X} " +
                $"strictModel={(strictModel ? 1 : 0)} strictSpaceNode={(strictSpaceNode ? 1 : 0)} " +
                $"plus40=0x{owner:X} transform={transform}");

            // Only perform a second transform probe and register motion candidates on the
            // one historically useful branch. Other sibling pointers are one-pass evidence,
            // not additional trackers; this keeps RPM traffic bounded.
            bool focusedPath = path.IndexOf("MODEL+0x3E8", StringComparison.Ordinal) >= 0;
            TransformSource localSource = default;
            float localX = 0, localY = 0, localZ = 0;
            bool hasLocalTransform = false;
            if (focusedPath)
            {
                hasLocalTransform = TrySelectTransformSource(
                    ptr, entity.X, entity.Y, entity.Z, MAX_ROOT_NODE_RADIUS,
                    out localSource, out localX, out localY, out localZ, out _);
                RegisterFocusedTraceCandidate(
                    entity, ptr, path, localSource, localX, localY, localZ, hasLocalTransform);
            }

            if (focusedPath && _focusedPathConsoleRecords < 12)
            {
                float localDistance = hasLocalTransform
                    ? Distance(entity.X, entity.Y, entity.Z, localX, localY, localZ)
                    : float.MaxValue;
                Console.WriteLine(
                    $"  [STAGE53][MODEL-PATH] path={path} ptr=0x{ptr:X} vtable=0x{vtable:X} " +
                    $"owner=0x{owner:X} strictSpaceNode={(strictSpaceNode ? 1 : 0)} " +
                    $"transform={(hasLocalTransform ? localSource.ToString() : "INVALID")} " +
                    $"targetDistance={(hasLocalTransform ? localDistance.ToString("F3", System.Globalization.CultureInfo.InvariantCulture) : "N/A")} " +
                    $"targetLocal={(hasLocalTransform ? 1 : 0)}");
                _focusedPathConsoleRecords++;
            }
        }

        private void RegisterFocusedTraceCandidate(
            EntityData entity,
            long ptr,
            string path,
            TransformSource source,
            float x,
            float y,
            float z,
            bool hasTransform)
        {
            if (!hasTransform || _focusedTraceTracks.Count >= FOCUSED_TRACE_MAX_CANDIDATES)
                return;

            float distance = Distance(entity.X, entity.Y, entity.Z, x, y, z);
            if (!float.IsFinite(distance) || distance > MAX_ROOT_NODE_RADIUS)
                return;

            var key = (entity.Ptr, ptr);
            if (_focusedTraceTracks.ContainsKey(key))
                return;

            _focusedTraceTracks.Add(key, new FocusedTraceTrack
            {
                EntityPtr = entity.Ptr,
                ModelPtr = 0,
                RootPtr = 0,
                NodePtr = ptr,
                Path = path,
                StartedMs = Environment.TickCount64,
                Source = source,
            });
            WriteDiscoveryTrace(
                $"MOTION_TRACK_REGISTER entity=0x{entity.Ptr:X} node=0x{ptr:X} path={path} " +
                $"initialDistance={distance:F3} samplesTarget={FOCUSED_TRACE_SAMPLE_LIMIT}");
        }

        private void SampleFocusedTraceCandidates(List<EntityData> entities, long nowMs)
        {
            if (_focusedTraceTracks.Count == 0 || nowMs < _nextFocusedTraceSampleMs)
                return;

            _nextFocusedTraceSampleMs = nowMs + FOCUSED_TRACE_SAMPLE_INTERVAL_MS;
            foreach (FocusedTraceTrack track in _focusedTraceTracks.Values)
            {
                if (track.Complete)
                    continue;

                EntityData entity = null;
                for (int i = 0; i < entities.Count; i++)
                {
                    if (entities[i] != null && entities[i].Ptr == track.EntityPtr)
                    {
                        entity = entities[i];
                        break;
                    }
                }

                if (entity == null)
                    continue;

                track.Samples++;
                bool valid = TrySelectTransformSource(
                    track.NodePtr, entity.X, entity.Y, entity.Z, MAX_ROOT_NODE_RADIUS,
                    out TransformSource source, out float x, out float y, out float z, out _);
                if (valid)
                {
                    float distance = Distance(entity.X, entity.Y, entity.Z, x, y, z);
                    if (float.IsFinite(distance))
                    {
                        track.ValidSamples++;
                        if (distance < track.MinTargetDistance)
                            track.MinTargetDistance = distance;

                        float relativeX = x - entity.X;
                        float relativeY = y - entity.Y;
                        float relativeZ = z - entity.Z;
                        if (!track.HasPrevious)
                        {
                            track.FirstX = x; track.FirstY = y; track.FirstZ = z;
                            track.FirstRelativeX = relativeX;
                            track.FirstRelativeY = relativeY;
                            track.FirstRelativeZ = relativeZ;
                            track.HasPrevious = true;
                        }
                        else
                        {
                            float nodeStep = Distance(
                                track.PreviousX, track.PreviousY, track.PreviousZ, x, y, z);
                            float relativeStep = Distance(
                                track.PreviousRelativeX, track.PreviousRelativeY, track.PreviousRelativeZ,
                                relativeX, relativeY, relativeZ);
                            if (float.IsFinite(nodeStep))
                            {
                                track.TotalNodeStep += nodeStep;
                                if (nodeStep > track.MaxNodeStep) track.MaxNodeStep = nodeStep;
                            }
                            if (float.IsFinite(relativeStep))
                            {
                                track.TotalRelativeStep += relativeStep;
                                if (relativeStep > track.MaxRelativeStep) track.MaxRelativeStep = relativeStep;
                            }
                        }

                        track.PreviousX = x; track.PreviousY = y; track.PreviousZ = z;
                        track.PreviousRelativeX = relativeX;
                        track.PreviousRelativeY = relativeY;
                        track.PreviousRelativeZ = relativeZ;
                        track.Source = source;
                    }
                }

                bool complete = track.Samples >= FOCUSED_TRACE_SAMPLE_LIMIT ||
                                nowMs - track.StartedMs >= FOCUSED_TRACE_MAX_AGE_MS;
                if (complete || track.Samples % FOCUSED_TRACE_REPORT_INTERVAL == 0)
                {
                    WriteDiscoveryTrace(
                        $"MOTION_TRACK_PROGRESS entity=0x{track.EntityPtr:X} node=0x{track.NodePtr:X} " +
                        $"sample={track.Samples} valid={track.ValidSamples} source={track.Source} " +
                        $"minTargetDistance={(track.MinTargetDistance == float.MaxValue ? -1f : track.MinTargetDistance):F3} " +
                        $"totalNodeStep={track.TotalNodeStep:F3} maxNodeStep={track.MaxNodeStep:F3} " +
                        $"totalTargetRelativeStep={track.TotalRelativeStep:F3} " +
                        $"maxTargetRelativeStep={track.MaxRelativeStep:F3}");
                }

                if (complete)
                {
                    track.Complete = true;
                    string verdict = track.NodePtr == track.RootPtr
                        ? "ROOT_ANCHOR_ONLY_NOT_A_BONE"
                        : (track.ValidSamples >= 30 &&
                           track.MinTargetDistance <= MAX_ROOT_NODE_RADIUS &&
                           track.TotalRelativeStep >= ARTICULATION_TOTAL_RELATIVE_MOTION
                            ? "TARGET_RELATIVE_MOTION_CANDIDATE_NOT_YET_A_BONE"
                            : "NO_ARTICULATED_MOTION_PROOF");
                    WriteDiscoveryTrace(
                        $"MOTION_TRACK_RESULT entity=0x{track.EntityPtr:X} model=0x{track.ModelPtr:X} " +
                        $"root=0x{track.RootPtr:X} node=0x{track.NodePtr:X} path={track.Path} " +
                        $"samples={track.Samples} valid={track.ValidSamples} " +
                        $"minTargetDistance={(track.MinTargetDistance == float.MaxValue ? -1f : track.MinTargetDistance):F3} " +
                        $"totalNodeStep={track.TotalNodeStep:F3} totalTargetRelativeStep={track.TotalRelativeStep:F3} " +
                        $"verdict={verdict}");
                }
            }
        }

        private void WriteDiscoveryTrace(string message)
        {
            if (!DiscoveryTraceEnabled || string.IsNullOrEmpty(message))
                return;

            lock (_traceSync)
            {
                if (_traceDisposed)
                    return;
                try
                {
                    if (_skeletonTraceWriter == null)
                    {
                        string path = Path.Combine(Environment.CurrentDirectory, "SKELETON_DISCOVERY_TRACE.txt");
                        _skeletonTraceWriter = new StreamWriter(
                            new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.ReadWrite))
                        {
                            AutoFlush = false,
                        };
                        _skeletonTraceWriter.WriteLine("ROS64Hack focused skeleton discovery trace");
                        _skeletonTraceWriter.WriteLine($"Started={DateTime.Now:O}");
                        _skeletonTraceWriter.WriteLine($"ProcessBase=0x{_mem.BaseAddress:X}");
                        _skeletonTraceWriter.WriteLine($"WorkingDirectory={Environment.CurrentDirectory}");
                        Console.WriteLine($"  [DYN-SKEL][TRACE-FILE] {Path.GetFullPath(path)}");
                    }
                    _skeletonTraceWriter.WriteLine($"{DateTime.Now:O} {message}");
                    if (++_traceLinesSinceFlush >= 16)
                    {
                        _skeletonTraceWriter.Flush();
                        _traceLinesSinceFlush = 0;
                    }
                }
                catch (Exception ex)
                {
                    try { Console.WriteLine($"[DYN-SKEL][TRACE-WRITE-FAILED] {ex.GetType().Name}: {ex.Message}"); }
                    catch { }
                }
            }
        }

        private bool TryAcceptModelRoot(
            long model,
            EntityData entity,
            out long root,
            bool traceEvidence = false,
            string source = "UNKNOWN")
        {
            root = 0;
            if (!IsFollowablePointer(model))
            {
                if (traceEvidence)
                    RuntimeDiagnostics.SkeletonEvidence(
                        $"MODEL_CANDIDATE source={source} entity=0x{entity.Ptr:X} model=0x{model:X} " +
                        "accepted=0 reason=MODEL_INVALID pointerCheck=failed");
                RuntimeDiagnostics.SkeletonResolveRejected("MODEL_INVALID", entity.Ptr);
                return false;
            }

            long vtable = _mem.ReadLong(model, "DYN.model_vtable");
            long expectedVtable = _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;
            if (vtable != expectedVtable)
            {
                if (traceEvidence)
                    RuntimeDiagnostics.SkeletonEvidence(
                        $"MODEL_CANDIDATE source={source} entity=0x{entity.Ptr:X} model=0x{model:X} " +
                        $"vtable=0x{vtable:X} vtableRva={(vtable >= _mem.BaseAddress ? $"0x{vtable - _mem.BaseAddress:X}" : "below-module")} " +
                        $"expectedVtable=0x{expectedVtable:X} accepted=0 reason=MODEL_VTABLE_MISMATCH");
                RuntimeDiagnostics.SkeletonResolveRejected("MODEL_VTABLE_MISMATCH", entity.Ptr);
                return false;
            }

            root = _mem.ReadLong(model + MODEL_SPACE_NODE, "DYN.model_root");
            bool accepted = TryAcceptRoot(root, model, entity, out float distance, traceEvidence, source);
            if (traceEvidence)
                RuntimeDiagnostics.SkeletonEvidence(
                    $"MODEL_CANDIDATE source={source} entity=0x{entity.Ptr:X} model=0x{model:X} " +
                    $"vtable=0x{vtable:X} root38=0x{root:X} accepted={(accepted ? 1 : 0)} " +
                    $"distance={(accepted ? distance.ToString("F3", System.Globalization.CultureInfo.InvariantCulture) : "n/a")} " +
                    $"reason={(accepted ? "ACCEPTED" : "ROOT_CHECK_REJECTED")}");
            return accepted;
        }

        private bool TryAcceptRoot(
            long root,
            long model,
            EntityData entity,
            out float distance,
            bool traceEvidence = false,
            string source = "UNKNOWN")
        {
            distance = float.MaxValue;
            if (!IsFollowablePointer(root) || !IsFollowablePointer(model))
            {
                string reason = !IsFollowablePointer(root) ? "ROOT_INVALID" : "MODEL_INVALID";
                if (traceEvidence)
                    RuntimeDiagnostics.SkeletonEvidence(
                        $"ROOT_CHECK source={source} entity=0x{entity.Ptr:X} model=0x{model:X} " +
                        $"root=0x{root:X} accepted=0 reason={reason}");
                if (!IsFollowablePointer(root))
                    RuntimeDiagnostics.SkeletonResolveRejected("ROOT_INVALID", entity.Ptr);
                if (!IsFollowablePointer(model))
                    RuntimeDiagnostics.SkeletonResolveRejected("MODEL_INVALID", entity.Ptr);
                return false;
            }

            long rootModel = _mem.ReadLong(root + SPACE_MODEL, "DYN.root_model");
            if (rootModel != model)
            {
                if (traceEvidence)
                {
                    long rootVtable = _mem.ReadLong(root, "DYN.evidence_root_vtable");
                    RuntimeDiagnostics.SkeletonEvidence(
                        $"ROOT_CHECK source={source} entity=0x{entity.Ptr:X} model=0x{model:X} root=0x{root:X} " +
                        $"rootVtable=0x{rootVtable:X} rootPlus40=0x{rootModel:X} accepted=0 reason=ROOT_MODEL_MISMATCH");
                }
                RuntimeDiagnostics.SkeletonResolveRejected("ROOT_MODEL_MISMATCH", entity.Ptr);
                return false;
            }

            if (!TrySelectTransformSource(root, entity.X, entity.Y, entity.Z,
                    MAX_NATIVE_ROOT_TARGET_DISTANCE, out TransformSource transformSource,
                    out float x, out float y, out float z, out bool hadTooFarTransform))
            {
                string reason = hadTooFarTransform ? "ROOT_DISTANCE_REJECT" : "ROOT_TRANSFORM_INVALID";
                if (traceEvidence)
                {
                    long rootVtable = _mem.ReadLong(root, "DYN.evidence_root_vtable");
                    RuntimeDiagnostics.SkeletonEvidence(
                        $"ROOT_CHECK source={source} entity=0x{entity.Ptr:X} model=0x{model:X} root=0x{root:X} " +
                        $"rootVtable=0x{rootVtable:X} rootPlus40=0x{rootModel:X} accepted=0 reason={reason} " +
                        $"hadTooFarTransform={(hadTooFarTransform ? 1 : 0)}");
                }
                RuntimeDiagnostics.SkeletonResolveRejected(reason, entity.Ptr);
                return false;
            }

            distance = Distance(entity.X, entity.Y, entity.Z, x, y, z);
            if (!float.IsFinite(distance) || distance > MAX_NATIVE_ROOT_TARGET_DISTANCE)
            {
                if (traceEvidence)
                {
                    long rootVtable = _mem.ReadLong(root, "DYN.evidence_root_vtable");
                    RuntimeDiagnostics.SkeletonEvidence(
                        $"ROOT_CHECK source={source} entity=0x{entity.Ptr:X} model=0x{model:X} root=0x{root:X} " +
                        $"rootVtable=0x{rootVtable:X} rootPlus40=0x{rootModel:X} accepted=0 reason=ROOT_DISTANCE_REJECT " +
                        $"transformSource={transformSource} xyz=({x:F3},{y:F3},{z:F3}) targetDistance={distance:F3}");
                }
                RuntimeDiagnostics.SkeletonResolveRejected("ROOT_DISTANCE_REJECT", entity.Ptr);
                return false;
            }

            long expectedRootVtable = _mem.BaseAddress + SPACE_NODE_VTABLE_RVA;
            long observedRootVtable = _mem.ReadLong(root, "DYN.native_root_candidate_vtable");
            if (observedRootVtable != expectedRootVtable)
            {
                if (traceEvidence)
                    RuntimeDiagnostics.SkeletonEvidence(
                        $"ROOT_CHECK source={source} entity=0x{entity.Ptr:X} model=0x{model:X} root=0x{root:X} " +
                        $"rootVtable=0x{observedRootVtable:X} expectedRootVtable=0x{expectedRootVtable:X} " +
                        "accepted=0 reason=ROOT_VTABLE_MISMATCH");
                RuntimeDiagnostics.SkeletonResolveRejected("ROOT_INVALID", entity.Ptr);
                return false;
            }

            // Filter non-character attachments before choosing the closest model/root.
            // Otherwise a nearer one-bone weapon model can win root selection and cause
            // the later full hierarchy build to fail without considering the valid body rig.
            if (!HasNativeBoneRigCandidate(model, root, entity))
            {
                if (traceEvidence)
                    RuntimeDiagnostics.SkeletonEvidence(
                        $"ROOT_CHECK source={source} entity=0x{entity.Ptr:X} model=0x{model:X} root=0x{root:X} " +
                        "accepted=0 reason=NATIVE_BONE_RIG_INVALID");
                RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_BUILD_FAILED", entity.Ptr);
                return false;
            }

            if (traceEvidence)
            {
                RuntimeDiagnostics.SkeletonEvidence(
                    $"ROOT_CHECK source={source} entity=0x{entity.Ptr:X} model=0x{model:X} root=0x{root:X} " +
                    $"rootVtable=0x{observedRootVtable:X} rootPlus40=0x{rootModel:X} accepted=1 reason=ACCEPTED " +
                    $"transformSource={transformSource} xyz=({x:F3},{y:F3},{z:F3}) targetDistance={distance:F3}");
            }
            return true;
        }

        private bool HasNativeBoneRigCandidate(long model, long rootNode, EntityData entity)
        {
            long expectedModelVtable = _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;
            long expectedAnimVtable = _mem.BaseAddress + SKELETAL_ANIM_VTABLE_RVA;
            if (!IsFollowablePointer(model) ||
                _mem.ReadLong(model, "DYN.rig_candidate_model_vtable") != expectedModelVtable)
                return false;

            long anim = _mem.ReadLong(model + MODEL_SKELETAL_ANIM, "DYN.rig_candidate_anim");
            if (!IsFollowablePointer(anim) ||
                _mem.ReadLong(anim, "DYN.rig_candidate_anim_vtable") != expectedAnimVtable ||
                _mem.ReadLong(anim + SKELETAL_ANIM_MODEL_BACKLINK, "DYN.rig_candidate_anim_owner") != model)
                return false;

            byte[] countBytes = new byte[sizeof(ushort)];
            if (!_mem.ReadBytesQuiet(anim + SKELETAL_ANIM_BONE_COUNT, countBytes, 0, countBytes.Length))
                return false;
            int count = BitConverter.ToUInt16(countBytes, 0);
            if (count < MIN_ARTICULATED_NODES || count > SKELETON_MAX_NODES)
                return false;

            byte[] hierarchy = new byte[count * BONE_HIERARCHY_RECORD_BYTES];
            if (!_mem.ReadBytesQuiet(anim + SKELETAL_ANIM_HIERARCHY, hierarchy, 0, hierarchy.Length))
                return false;

            var parents = new byte[count];
            var siblings = new byte[count];
            var children = new byte[count];
            int hierarchyRoot = -1;
            int rootCount = 0;
            for (int bone = 0; bone < count; bone++)
            {
                int offset = bone * BONE_HIERARCHY_RECORD_BYTES;
                byte parent = hierarchy[offset];
                byte sibling = hierarchy[offset + 1];
                byte child = hierarchy[offset + 2];
                parents[bone] = parent;
                siblings[bone] = sibling;
                children[bone] = child;

                if (parent == byte.MaxValue)
                {
                    hierarchyRoot = bone;
                    rootCount++;
                }
                else if (parent >= count || parent == bone)
                {
                    return false;
                }
                if ((sibling != byte.MaxValue && (sibling >= count || sibling == bone)) ||
                    (child != byte.MaxValue && (child >= count || child == bone)))
                    return false;
            }
            if (rootCount != 1 || hierarchyRoot < 0)
                return false;

            var seen = new bool[count];
            var stack = new Stack<(int Bone, int Parent)>();
            stack.Push((hierarchyRoot, -1));
            int visited = 0;
            while (stack.Count > 0)
            {
                var item = stack.Pop();
                if (item.Bone < 0 || item.Bone >= count || seen[item.Bone])
                    return false;
                if (item.Parent < 0)
                {
                    if (parents[item.Bone] != byte.MaxValue)
                        return false;
                }
                else if (parents[item.Bone] != item.Parent)
                {
                    return false;
                }

                seen[item.Bone] = true;
                visited++;
                var childChain = new HashSet<int>();
                var directChildren = new List<int>();
                int child = children[item.Bone];
                while (child != byte.MaxValue)
                {
                    if (child < 0 || child >= count || !childChain.Add(child) ||
                        parents[child] != item.Bone)
                        return false;
                    directChildren.Add(child);
                    child = siblings[child];
                }
                for (int i = directChildren.Count - 1; i >= 0; i--)
                    stack.Push((directChildren[i], item.Bone));
            }
            if (visited != count)
                return false;

            long matrixTable = _mem.ReadLong(anim + SKELETAL_ANIM_BONE_MATRICES,
                "DYN.rig_candidate_matrix_table");
            int matrixBytes = count * BONE_MATRIX_BYTES;
            if (!IsFollowablePointer(matrixTable))
                return false;
            byte[] matrices = new byte[matrixBytes];
            if (!_mem.ReadBytesQuiet(matrixTable, matrices, 0, matrixBytes))
                return false;

            byte[] rootWorld = new byte[MATRIX_BYTES];
            if (!_mem.ReadBytesQuiet(rootNode + SPACE_WORLD_MATRIX, rootWorld, 0, rootWorld.Length) ||
                !IsFiniteAffineMatrix(rootWorld, 0))
                return false;

            float rootLocalX = BitConverter.ToSingle(matrices, hierarchyRoot * BONE_MATRIX_BYTES + 0x30);
            float rootLocalY = BitConverter.ToSingle(matrices, hierarchyRoot * BONE_MATRIX_BYTES + 0x34);
            float rootLocalZ = BitConverter.ToSingle(matrices, hierarchyRoot * BONE_MATRIX_BYTES + 0x38);
            TransformModelPoint(rootWorld, rootLocalX, rootLocalY, rootLocalZ,
                out float boneRootX, out float boneRootY, out float boneRootZ);
            float boneRootDistance = Distance(entity.X, entity.Y, entity.Z,
                boneRootX, boneRootY, boneRootZ);
            if (!IsValidCoordinate(boneRootX) || !IsValidCoordinate(boneRootY) ||
                !IsValidCoordinate(boneRootZ) || !float.IsFinite(boneRootDistance) ||
                boneRootDistance > MAX_NATIVE_ROOT_TARGET_DISTANCE)
                return false;

            int validNearRootBones = 0;
            for (int bone = 0; bone < count; bone++)
            {
                int offset = bone * BONE_MATRIX_BYTES;
                if (!IsFiniteAffineMatrix(matrices, offset))
                    return false;
                float localX = BitConverter.ToSingle(matrices, offset + 0x30);
                float localY = BitConverter.ToSingle(matrices, offset + 0x34);
                float localZ = BitConverter.ToSingle(matrices, offset + 0x38);
                if (!IsValidCoordinate(localX) || !IsValidCoordinate(localY) || !IsValidCoordinate(localZ))
                    return false;

                TransformModelPoint(rootWorld, localX, localY, localZ,
                    out float worldX, out float worldY, out float worldZ);
                float rootDistance = Distance(boneRootX, boneRootY, boneRootZ, worldX, worldY, worldZ);
                if (float.IsFinite(rootDistance) && rootDistance <= MAX_ROOT_NODE_RADIUS)
                    validNearRootBones++;
            }
            return validNearRootBones >= MIN_ARTICULATED_NODES;
        }

        private bool TryBuildNativeBoneHierarchy(
            long rootNode,
            long model,
            long rootVtable,
            EntityData entity,
            out CachedNode[] result,
            out long skeletalAnim,
            out long boneMatrixTable,
            out int boneCount)
        {
            result = Array.Empty<CachedNode>();
            skeletalAnim = 0;
            boneMatrixTable = 0;
            boneCount = 0;

            long expectedModelVtable = _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;
            long expectedNodeVtable = _mem.BaseAddress + SPACE_NODE_VTABLE_RVA;
            long expectedAnimVtable = _mem.BaseAddress + SKELETAL_ANIM_VTABLE_RVA;
            if (!IsFollowablePointer(model) ||
                _mem.ReadLong(model, "DYN.bone_model_vtable") != expectedModelVtable ||
                !IsFollowablePointer(rootNode) || rootVtable != expectedNodeVtable ||
                _mem.ReadLong(rootNode, "DYN.bone_root_vtable") != expectedNodeVtable ||
                _mem.ReadLong(rootNode + SPACE_MODEL, "DYN.bone_root_owner") != model ||
                _mem.ReadLong(model + MODEL_SPACE_NODE, "DYN.bone_model_root") != rootNode)
            {
                RuntimeDiagnostics.SkeletonResolveRejected("ROOT_MODEL_MISMATCH", entity.Ptr);
                return false;
            }

            if (!TryReadRootWorldMatrix(rootNode, entity, MAX_NATIVE_ROOT_TARGET_DISTANCE,
                    out float rootX, out float rootY, out float rootZ))
            {
                RuntimeDiagnostics.SkeletonResolveRejected("ROOT_DISTANCE_REJECT", entity.Ptr);
                return false;
            }

            skeletalAnim = _mem.ReadLong(model + MODEL_SKELETAL_ANIM, "DYN.skeletal_anim");
            if (!IsFollowablePointer(skeletalAnim) ||
                _mem.ReadLong(skeletalAnim, "DYN.skeletal_anim_vtable") != expectedAnimVtable ||
                _mem.ReadLong(skeletalAnim + SKELETAL_ANIM_MODEL_BACKLINK, "DYN.skeletal_anim_model") != model)
            {
                RuntimeDiagnostics.SkeletonResolveRejected("MODEL_INVALID", entity.Ptr);
                return false;
            }

            byte[] countBytes = new byte[sizeof(ushort)];
            if (!_mem.ReadBytesQuiet(skeletalAnim + SKELETAL_ANIM_BONE_COUNT,
                    countBytes, 0, countBytes.Length))
            {
                RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_BUILD_FAILED", entity.Ptr);
                return false;
            }

            boneCount = BitConverter.ToUInt16(countBytes, 0);
            if (boneCount < MIN_ARTICULATED_NODES || boneCount > SKELETON_MAX_NODES)
            {
                RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_TOO_SMALL", entity.Ptr);
                return false;
            }

            int hierarchyBytes = boneCount * BONE_HIERARCHY_RECORD_BYTES;
            int matrixBytes = boneCount * BONE_MATRIX_BYTES;
            if (!_mem.ReadBytesQuiet(skeletalAnim + SKELETAL_ANIM_HIERARCHY,
                    _boneHierarchyScratch, 0, hierarchyBytes))
            {
                RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_BUILD_FAILED", entity.Ptr);
                return false;
            }

            boneMatrixTable = _mem.ReadLong(
                skeletalAnim + SKELETAL_ANIM_BONE_MATRICES, "DYN.skeletal_bone_matrix_table");
            if (!IsFollowablePointer(boneMatrixTable) ||
                !_mem.ReadBytesQuiet(boneMatrixTable, _boneMatrixScratch, 0, matrixBytes))
            {
                RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_BUILD_FAILED", entity.Ptr);
                return false;
            }

            var parentByBone = new byte[boneCount];
            var nextSiblingByBone = new byte[boneCount];
            var firstChildByBone = new byte[boneCount];
            int hierarchyRoot = -1;
            int rootCount = 0;
            for (int bone = 0; bone < boneCount; bone++)
            {
                int offset = bone * BONE_HIERARCHY_RECORD_BYTES;
                byte parent = _boneHierarchyScratch[offset];
                byte nextSibling = _boneHierarchyScratch[offset + 1];
                byte firstChild = _boneHierarchyScratch[offset + 2];
                parentByBone[bone] = parent;
                nextSiblingByBone[bone] = nextSibling;
                firstChildByBone[bone] = firstChild;

                if (parent == byte.MaxValue)
                {
                    hierarchyRoot = bone;
                    rootCount++;
                }
                else if (parent >= boneCount || parent == bone)
                {
                    RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_BUILD_FAILED", entity.Ptr);
                    return false;
                }
                if ((nextSibling != byte.MaxValue && (nextSibling >= boneCount || nextSibling == bone)) ||
                    (firstChild != byte.MaxValue && (firstChild >= boneCount || firstChild == bone)))
                {
                    RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_BUILD_FAILED", entity.Ptr);
                    return false;
                }

                int matrixOffset = bone * BONE_MATRIX_BYTES;
                if (!IsFiniteAffineMatrix(_boneMatrixScratch, matrixOffset))
                {
                    RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_BUILD_FAILED", entity.Ptr);
                    return false;
                }

                float localX = BitConverter.ToSingle(_boneMatrixScratch, matrixOffset + 0x30);
                float localY = BitConverter.ToSingle(_boneMatrixScratch, matrixOffset + 0x34);
                float localZ = BitConverter.ToSingle(_boneMatrixScratch, matrixOffset + 0x38);
                if (!IsValidCoordinate(localX) || !IsValidCoordinate(localY) || !IsValidCoordinate(localZ))
                {
                    RuntimeDiagnostics.SkeletonResolveRejected("ROOT_TRANSFORM_INVALID", entity.Ptr);
                    return false;
                }
            }

            if (rootCount != 1 || hierarchyRoot < 0)
            {
                RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_BUILD_FAILED", entity.Ptr);
                return false;
            }

            float localRootX = BitConverter.ToSingle(_boneMatrixScratch, hierarchyRoot * BONE_MATRIX_BYTES + 0x30);
            float localRootY = BitConverter.ToSingle(_boneMatrixScratch, hierarchyRoot * BONE_MATRIX_BYTES + 0x34);
            float localRootZ = BitConverter.ToSingle(_boneMatrixScratch, hierarchyRoot * BONE_MATRIX_BYTES + 0x38);
            TransformModelPoint(_rootWorldMatrixScratch, localRootX, localRootY, localRootZ,
                out float boneRootX, out float boneRootY, out float boneRootZ);
            float boneRootDistance = Distance(entity.X, entity.Y, entity.Z, boneRootX, boneRootY, boneRootZ);
            if (!IsValidCoordinate(boneRootX) || !IsValidCoordinate(boneRootY) ||
                !IsValidCoordinate(boneRootZ) || !float.IsFinite(boneRootDistance) ||
                boneRootDistance > MAX_NATIVE_ROOT_TARGET_DISTANCE)
            {
                RuntimeDiagnostics.SkeletonResolveRejected("ROOT_DISTANCE_REJECT", entity.Ptr);
                return false;
            }

            // The native layout is a rooted child/sibling graph: +0x32 parent,
            // +0x33 next sibling, +0x34 first child. Never scan SpaceNode qwords for bones.
            var boneOrder = new List<(int Bone, int ParentBone)>(boneCount);
            var indexByBone = new int[boneCount];
            var seen = new bool[boneCount];
            Array.Fill(indexByBone, -1);
            var stack = new Stack<(int Bone, int ParentBone)>();
            stack.Push((hierarchyRoot, -1));

            while (stack.Count > 0)
            {
                var current = stack.Pop();
                int bone = current.Bone;
                if (bone < 0 || bone >= boneCount || seen[bone])
                {
                    RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_BUILD_FAILED", entity.Ptr);
                    return false;
                }
                if (current.ParentBone < 0)
                {
                    if (parentByBone[bone] != byte.MaxValue)
                    {
                        RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_BUILD_FAILED", entity.Ptr);
                        return false;
                    }
                }
                else if (parentByBone[bone] != current.ParentBone)
                {
                    RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_BUILD_FAILED", entity.Ptr);
                    return false;
                }

                seen[bone] = true;
                indexByBone[bone] = boneOrder.Count;
                boneOrder.Add((bone, current.ParentBone));

                var children = new List<int>();
                var siblingChain = new HashSet<int>();
                int child = firstChildByBone[bone];
                while (child != byte.MaxValue)
                {
                    if (child < 0 || child >= boneCount || !siblingChain.Add(child) ||
                        parentByBone[child] != bone)
                    {
                        RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_BUILD_FAILED", entity.Ptr);
                        return false;
                    }
                    children.Add(child);
                    child = nextSiblingByBone[child];
                }

                for (int i = children.Count - 1; i >= 0; i--)
                    stack.Push((children[i], bone));
            }

            if (boneOrder.Count != boneCount)
            {
                RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_BUILD_FAILED", entity.Ptr);
                return false;
            }

            var nodes = new CachedNode[boneCount];
            for (int nodeIndex = 0; nodeIndex < boneOrder.Count; nodeIndex++)
            {
                var item = boneOrder[nodeIndex];
                int parentIndex = item.ParentBone < 0 ? -1 : indexByBone[item.ParentBone];
                if (item.ParentBone >= 0 && (parentIndex < 0 || parentIndex >= nodeIndex))
                {
                    RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_BUILD_FAILED", entity.Ptr);
                    return false;
                }

                nodes[nodeIndex] = new CachedNode
                {
                    Ptr = boneMatrixTable + (item.Bone * BONE_MATRIX_BYTES),
                    Vtable = expectedAnimVtable,
                    BoneIndex = item.Bone,
                    ParentIndex = parentIndex,
                    Source = TransformSource.SkeletalBoneMatrix,
                };
            }

            if (nodes.Length < MIN_ARTICULATED_NODES || nodes[0].BoneIndex != hierarchyRoot)
            {
                RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_TOO_SMALL", entity.Ptr);
                return false;
            }

            // A rooted, complete native skeleton hierarchy is the verification criterion.
            // Requiring bones to change position across frames incorrectly rejects valid idle poses.
            result = nodes;
            return true;
        }

        private bool TryReadRootWorldMatrix(
            long rootNode,
            EntityData entity,
            float maxDistance,
            out float x,
            out float y,
            out float z)
        {
            x = y = z = 0f;
            if (!_mem.ReadBytesQuiet(rootNode + SPACE_WORLD_MATRIX,
                    _rootWorldMatrixScratch, 0, _rootWorldMatrixScratch.Length) ||
                !IsFiniteAffineMatrix(_rootWorldMatrixScratch, 0) ||
                !TryDecodeMatrixTranslation(_rootWorldMatrixScratch, 0, out x, out y, out z))
                return false;

            float distance = Distance(entity.X, entity.Y, entity.Z, x, y, z);
            return float.IsFinite(distance) && distance <= maxDistance;
        }

        private bool ValidateCachedNativeBoneHierarchy(ResolutionCache cached, EntityData entity)
        {
            if (_mem.ReadLong(cached.RootNode, "DYN.native_root_vtable") !=
                    _mem.BaseAddress + SPACE_NODE_VTABLE_RVA ||
                _mem.ReadLong(cached.RootNode + SPACE_MODEL, "DYN.native_root_owner") != cached.Model)
                return false;

            if (!TryReadRootWorldMatrix(cached.RootNode, entity, MAX_NATIVE_ROOT_TARGET_DISTANCE,
                    out _, out _, out _))
                return false;

            long anim = _mem.ReadLong(cached.Model + MODEL_SKELETAL_ANIM, "DYN.validate_skeletal_anim");
            if (anim != cached.SkeletalAnim ||
                _mem.ReadLong(anim, "DYN.validate_skeletal_anim_vtable") !=
                    _mem.BaseAddress + SKELETAL_ANIM_VTABLE_RVA ||
                _mem.ReadLong(anim + SKELETAL_ANIM_MODEL_BACKLINK, "DYN.validate_skeletal_anim_owner") != cached.Model)
                return false;

            byte[] countBytes = new byte[sizeof(ushort)];
            if (!_mem.ReadBytesQuiet(anim + SKELETAL_ANIM_BONE_COUNT, countBytes, 0, countBytes.Length))
                return false;
            if (BitConverter.ToUInt16(countBytes, 0) != cached.BoneCount)
                return false;

            return _mem.ReadLong(anim + SKELETAL_ANIM_BONE_MATRICES, "DYN.validate_bone_matrix_table") ==
                   cached.BoneMatrixTable;
        }

        private static bool IsFiniteAffineMatrix(byte[] buffer, int offset)
        {
            if (buffer == null || offset < 0 || offset + MATRIX_BYTES > buffer.Length)
                return false;

            for (int i = 0; i < 16; i++)
                if (!float.IsFinite(BitConverter.ToSingle(buffer, offset + i * 4)))
                    return false;

            return MathF.Abs(BitConverter.ToSingle(buffer, offset + 0x0C)) <= 0.01f &&
                   MathF.Abs(BitConverter.ToSingle(buffer, offset + 0x1C)) <= 0.01f &&
                   MathF.Abs(BitConverter.ToSingle(buffer, offset + 0x2C)) <= 0.01f &&
                   MathF.Abs(BitConverter.ToSingle(buffer, offset + 0x3C) - 1f) <= 0.01f;
        }

        private static void TransformModelPoint(
            byte[] rootWorldMatrix,
            float localX,
            float localY,
            float localZ,
            out float worldX,
            out float worldY,
            out float worldZ)
        {
            // Native matrices are row-major affine transforms with translation in row 3.
            worldX = localX * BitConverter.ToSingle(rootWorldMatrix, 0x00) +
                     localY * BitConverter.ToSingle(rootWorldMatrix, 0x10) +
                     localZ * BitConverter.ToSingle(rootWorldMatrix, 0x20) +
                     BitConverter.ToSingle(rootWorldMatrix, 0x30);
            worldY = localX * BitConverter.ToSingle(rootWorldMatrix, 0x04) +
                     localY * BitConverter.ToSingle(rootWorldMatrix, 0x14) +
                     localZ * BitConverter.ToSingle(rootWorldMatrix, 0x24) +
                     BitConverter.ToSingle(rootWorldMatrix, 0x34);
            worldZ = localX * BitConverter.ToSingle(rootWorldMatrix, 0x08) +
                     localY * BitConverter.ToSingle(rootWorldMatrix, 0x18) +
                     localZ * BitConverter.ToSingle(rootWorldMatrix, 0x28) +
                     BitConverter.ToSingle(rootWorldMatrix, 0x38);
        }

        private bool TryBuildCachedHierarchy(
            long rootNode,
            long model,
            long rootVtable,
            EntityData entity,
            out CachedNode[] result)
        {
            result = Array.Empty<CachedNode>();

            var queue = new Queue<(long Ptr, int ParentIndex, int Depth)>();
            var visited = new HashSet<long>();
            var nodes = new List<CachedNode>(32);
            long strictSpaceNodeVtable = _mem.BaseAddress + SPACE_NODE_VTABLE_RVA;
            bool rootReadFailed = false;
            bool traceHierarchy = BeginHierarchyTrace(entity);

            if (traceHierarchy)
                WriteHierarchyTrace(
                    $"HIERARCHY_BEGIN entity=0x{entity.Ptr:X} entityId=0x{entity.EntityId:X8} " +
                    $"model=0x{model:X} root=0x{rootNode:X} rootVtable=0x{rootVtable:X} " +
                    $"strictSpaceNodeVtable=0x{strictSpaceNodeVtable:X} " +
                    $"entityXYZ=({entity.X:F3},{entity.Y:F3},{entity.Z:F3}) " +
                    $"probeEdges=0x18,0x318,0x618 " +
                    $"enqueueOnlyMatchingVtableAndLocalTransform=1 " +
                    $"maxNodes={SKELETON_MAX_NODES} maxDepth={SKELETON_MAX_DEPTH}");

            queue.Enqueue((rootNode, -1, 0));
            visited.Add(rootNode);

            while (queue.Count > 0 && visited.Count <= SKELETON_MAX_NODES)
            {
                var item = queue.Dequeue();
                if (item.Depth > SKELETON_MAX_DEPTH || !IsFollowablePointer(item.Ptr))
                    continue;

                if (!_mem.ReadBytesQuiet(item.Ptr, _nodeScratch, 0, _nodeScratch.Length))
                {
                    if (traceHierarchy)
                        WriteHierarchyTrace(
                            $"HIERARCHY_OBJECT entity=0x{entity.Ptr:X} depth={item.Depth} " +
                            $"ptr=0x{item.Ptr:X} parentIndex={item.ParentIndex} read=0");
                    if (item.Ptr == rootNode)
                    {
                        rootReadFailed = true;
                        RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_BUILD_FAILED", entity.Ptr);
                    }
                    continue;
                }

                long vt = BitConverter.ToInt64(_nodeScratch, 0);
                bool typeMatch = item.Ptr == rootNode || vt == rootVtable || vt == strictSpaceNodeVtable;
                long owner = BitConverter.ToInt64(_nodeScratch, SPACE_MODEL);
                bool transformValid = TrySelectTransformSourceFromBuffer(
                    _nodeScratch,
                    entity.X, entity.Y, entity.Z,
                    MAX_ROOT_NODE_RADIUS,
                    out TransformSource source,
                    out float x, out float y, out float z,
                    out _);
                float targetDistance = transformValid
                    ? Distance(entity.X, entity.Y, entity.Z, x, y, z)
                    : float.MaxValue;
                bool ownerMatches = owner == model;
                bool local = transformValid && float.IsFinite(targetDistance) &&
                             targetDistance <= MAX_ROOT_NODE_RADIUS;

                int acceptedParent = -1;
                bool accepted = false;
                int acceptedIndex = -1;
                if (typeMatch && transformValid && (item.Ptr == rootNode || ownerMatches || local))
                {
                    acceptedParent = nodes.Count;
                    acceptedIndex = nodes.Count;
                    accepted = true;
                    nodes.Add(new CachedNode
                    {
                        Ptr = item.Ptr,
                        Vtable = vt,
                        ParentIndex = item.ParentIndex,
                        Source = source,
                        X = x,
                        Y = y,
                        Z = z,
                        PositionValid = true,
                    });
                }

                long edge18 = BitConverter.ToInt64(_nodeScratch, 0x018);
                long edge318 = BitConverter.ToInt64(_nodeScratch, 0x318);
                long edge618 = BitConverter.ToInt64(_nodeScratch, 0x618);
                if (traceHierarchy)
                {
                    string transformText = transformValid
                        ? $"{source}:({x:F3},{y:F3},{z:F3}) distance={targetDistance:F3}"
                        : "INVALID";
                    WriteHierarchyTrace(
                        $"HIERARCHY_OBJECT entity=0x{entity.Ptr:X} depth={item.Depth} ptr=0x{item.Ptr:X} " +
                        $"parentIndex={item.ParentIndex} vtable=0x{vt:X} typeMatch={(typeMatch ? 1 : 0)} " +
                        $"owner=0x{owner:X} ownerMatches={(ownerMatches ? 1 : 0)} transform={transformText} " +
                        $"local={(local ? 1 : 0)} accepted={(accepted ? 1 : 0)} acceptedIndex={acceptedIndex} " +
                        $"edge18=0x{edge18:X} edge318=0x{edge318:X} edge618=0x{edge618:X}");
                }

                if (item.Depth >= SKELETON_MAX_DEPTH)
                    continue;

                // Stage 48 disproved the +0x18-only rule: all three traced roots pointed
                // there to the same object with a different vtable, while one root's +0x318
                // contained another plausible node address. Probe all historically observed
                // slots, but never recurse through arbitrary wrappers. Each edge must resolve
                // to a readable object with the exact root/SpaceNode vtable and a target-local
                // transform before it is enqueued.
                if (!typeMatch)
                {
                    if (traceHierarchy)
                        WriteHierarchyTrace(
                            $"HIERARCHY_TRAVERSE_SKIPPED entity=0x{entity.Ptr:X} " +
                            $"ptr=0x{item.Ptr:X} vtable=0x{vt:X} " +
                            "reason=UNRECOGNIZED_VTABLE");
                    continue;
                }

                int nextParent = acceptedParent >= 0 ? acceptedParent : item.ParentIndex;
                foreach (int edgeOffset in NODE_EDGES)
                {
                    long child = BitConverter.ToInt64(_nodeScratch, edgeOffset);
                    if (!IsFollowablePointer(child) || visited.Contains(child))
                        continue;

                    if (!_mem.ReadBytesQuiet(child, _edgeProbeScratch, 0, _edgeProbeScratch.Length))
                    {
                        if (traceHierarchy)
                            WriteHierarchyTrace(
                                $"HIERARCHY_EDGE entity=0x{entity.Ptr:X} parent=0x{item.Ptr:X} " +
                                $"offset=0x{edgeOffset:X} child=0x{child:X} read=0 " +
                                "reason=CHILD_READ_FAILED");
                        continue;
                    }

                    long childVtable = BitConverter.ToInt64(_edgeProbeScratch, 0);
                    long childOwner = BitConverter.ToInt64(_edgeProbeScratch, SPACE_MODEL);
                    bool childTypeMatch = childVtable == rootVtable || childVtable == strictSpaceNodeVtable;
                    bool childTransformValid = TrySelectTransformSourceFromBuffer(
                        _edgeProbeScratch,
                        entity.X, entity.Y, entity.Z,
                        MAX_ROOT_NODE_RADIUS,
                        out TransformSource childSource,
                        out float childX, out float childY, out float childZ,
                        out _);
                    float childDistance = childTransformValid
                        ? Distance(entity.X, entity.Y, entity.Z, childX, childY, childZ)
                        : float.MaxValue;
                    bool childLocal = childTransformValid && float.IsFinite(childDistance) &&
                                      childDistance <= MAX_ROOT_NODE_RADIUS;
                    bool childAcceptedForTraversal = childTypeMatch && childLocal;

                    if (traceHierarchy)
                    {
                        string childTransformText = childTransformValid
                            ? $"{childSource}:({childX:F3},{childY:F3},{childZ:F3}) distance={childDistance:F3}"
                            : "INVALID";
                        WriteHierarchyTrace(
                            $"HIERARCHY_EDGE entity=0x{entity.Ptr:X} parent=0x{item.Ptr:X} " +
                            $"offset=0x{edgeOffset:X} child=0x{child:X} vtable=0x{childVtable:X} " +
                            $"owner=0x{childOwner:X} typeMatch={(childTypeMatch ? 1 : 0)} " +
                            $"transform={childTransformText} accepted={(childAcceptedForTraversal ? 1 : 0)} " +
                            $"reason={(childAcceptedForTraversal ? "ENQUEUE" : (!childTypeMatch ? "VTABLE_MISMATCH" : "NOT_TARGET_LOCAL"))}");
                    }

                    if (!childAcceptedForTraversal)
                        continue;

                    visited.Add(child);
                    queue.Enqueue((child, nextParent, item.Depth + 1));
                    if (visited.Count >= SKELETON_MAX_NODES)
                        break;
                }
            }

            if (traceHierarchy)
                WriteHierarchyTrace(
                    $"HIERARCHY_RESULT entity=0x{entity.Ptr:X} model=0x{model:X} root=0x{rootNode:X} " +
                    $"visited={visited.Count} acceptedNodes={nodes.Count} rootReadFailed={(rootReadFailed ? 1 : 0)} " +
                    $"multiNode={(nodes.Count >= 2 && nodes[0].Ptr == rootNode ? 1 : 0)} " +
                    $"articulationMinimum={MIN_ARTICULATED_NODES} " +
                    $"reason={(nodes.Count < 2 || nodes[0].Ptr != rootNode ? "HIERARCHY_TOO_SMALL" : "CANDIDATES_CACHED_NOT_YET_VERIFIED")}");

            if (nodes.Count < 2 || nodes[0].Ptr != rootNode)
            {
                if (!rootReadFailed)
                    RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_TOO_SMALL", entity.Ptr);
                return false;
            }

            result = nodes.ToArray();
            return true;
        }

        private bool BeginResolverEvidence(EntityData entity, long b8)
        {
            if (entity == null || entity.Ptr == 0)
                return false;

            lock (_resolverEvidenceSync)
            {
                if (_resolverEvidenceEntities.Contains(entity.Ptr) ||
                    _resolverEvidenceEntities.Count >= MAX_RESOLVER_EVIDENCE_ENTITIES)
                    return false;

                _resolverEvidenceEntities.Add(entity.Ptr);
                return true;
            }
        }

        private bool BeginHierarchyTrace(EntityData entity)
        {
            if (!DiscoveryTraceEnabled || entity == null || entity.Ptr == 0)
                return false;

            lock (_resolverEvidenceSync)
            {
                if (_hierarchyTraceEntities.Contains(entity.Ptr) ||
                    _hierarchyTraceEntities.Count >= MAX_HIERARCHY_TRACE_ENTITIES)
                    return false;

                _hierarchyTraceEntities.Add(entity.Ptr);
                return true;
            }
        }

        private void WriteHierarchyTrace(string message)
        {
            Console.WriteLine("  [DYN-SKEL][HIERARCHY-TRACE] " + message);
            WriteDiscoveryTrace(message);
        }

        private bool ValidateCachedRoot(ResolutionCache cached, EntityData entity)
        {
            if (!IsFollowablePointer(cached.Model))
            {
                RuntimeDiagnostics.SkeletonResolveRejected("MODEL_INVALID", entity.Ptr);
                return false;
            }

            if (!IsFollowablePointer(cached.RootNode))
            {
                RuntimeDiagnostics.SkeletonResolveRejected("ROOT_INVALID", entity.Ptr);
                return false;
            }

            if (_mem.ReadLong(cached.Model, "DYN.validate_model_vtable") !=
                _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA)
            {
                RuntimeDiagnostics.SkeletonResolveRejected("MODEL_VTABLE_MISMATCH", entity.Ptr);
                return false;
            }

            long root = _mem.ReadLong(cached.Model + MODEL_SPACE_NODE, "DYN.validate_root");
            if (root != cached.RootNode)
            {
                RuntimeDiagnostics.SkeletonResolveRejected("ROOT_INVALID", entity.Ptr);
                return false;
            }

            if (_mem.ReadLong(root + SPACE_MODEL, "DYN.validate_root_model") != cached.Model)
            {
                RuntimeDiagnostics.SkeletonResolveRejected("ROOT_MODEL_MISMATCH", entity.Ptr);
                return false;
            }

            if (cached.SkeletalBoneHierarchy)
            {
                if (!ValidateCachedNativeBoneHierarchy(cached, entity))
                {
                    RuntimeDiagnostics.SkeletonResolveRejected("HIERARCHY_BUILD_FAILED", entity.Ptr);
                    return false;
                }
                return true;
            }

            if (!TryReadWorldPositionBySource(
                    root,
                    cached.Nodes.Length > 0 ? cached.Nodes[0].Source : TransformSource.Translation178,
                    entity.X, entity.Y, entity.Z,
                    MAX_LEGACY_ROOT_TARGET_DISTANCE,
                    out float x, out float y, out float z))
            {
                RuntimeDiagnostics.SkeletonResolveRejected("ROOT_TRANSFORM_INVALID", entity.Ptr);
                return false;
            }

            float distance = Distance(entity.X, entity.Y, entity.Z, x, y, z);
            if (!float.IsFinite(distance) || distance > MAX_LEGACY_ROOT_TARGET_DISTANCE)
            {
                RuntimeDiagnostics.SkeletonResolveRejected("ROOT_DISTANCE_REJECT", entity.Ptr);
                return false;
            }

            return true;
        }

        private bool SampleNativeBonePose(
            EntityData entity,
            ResolutionCache cache,
            out string failureReason)
        {
            failureReason = null;
            int nodeCount = cache.Nodes.Length;
            if (nodeCount < MIN_ARTICULATED_NODES || nodeCount != cache.BoneCount ||
                nodeCount > SKELETON_MAX_NODES)
                return SampleFailure(out failureReason, "NODE_COUNT_INVALID",
                    $"nodes={nodeCount} bones={cache.BoneCount}");

            if (!_mem.ReadBytesQuiet(cache.RootNode + SPACE_WORLD_MATRIX,
                    _rootWorldMatrixScratch, 0, _rootWorldMatrixScratch.Length))
                return SampleFailure(out failureReason, "ROOT_MATRIX_READ_FAILED");
            if (!IsFiniteAffineMatrix(_rootWorldMatrixScratch, 0))
                return SampleFailure(out failureReason, "ROOT_MATRIX_INVALID");
            if (!_mem.ReadBytesQuiet(cache.BoneMatrixTable,
                    _boneMatrixScratch, 0, nodeCount * BONE_MATRIX_BYTES))
                return SampleFailure(out failureReason, "BONE_MATRIX_TABLE_READ_FAILED",
                    $"table=0x{cache.BoneMatrixTable:X} bytes={nodeCount * BONE_MATRIX_BYTES}");

            if (!TryDecodeMatrixTranslation(_rootWorldMatrixScratch, 0,
                    out float sceneRootX, out float sceneRootY, out float sceneRootZ))
                return SampleFailure(out failureReason, "ROOT_TRANSLATION_DECODE_FAILED");
            float sceneRootDistance = Distance(entity.X, entity.Y, entity.Z,
                sceneRootX, sceneRootY, sceneRootZ);
            if (!float.IsFinite(sceneRootDistance) || sceneRootDistance > MAX_NATIVE_ROOT_TARGET_DISTANCE)
                return SampleFailure(out failureReason, "ROOT_DISTANCE_REJECT",
                    $"sceneRootDistance={sceneRootDistance:F2} limit={MAX_NATIVE_ROOT_TARGET_DISTANCE:F1}");

            float boneRootX = 0f, boneRootY = 0f, boneRootZ = 0f;
            for (int i = 0; i < nodeCount; i++)
            {
                CachedNode node = cache.Nodes[i];
                if (node.BoneIndex < 0 || node.BoneIndex >= cache.BoneCount)
                    return SampleFailure(out failureReason, "BONE_INDEX_INVALID",
                        $"node={i} boneIndex={node.BoneIndex} boneCount={cache.BoneCount}");

                int matrixOffset = node.BoneIndex * BONE_MATRIX_BYTES;
                if (!IsFiniteAffineMatrix(_boneMatrixScratch, matrixOffset))
                    return SampleFailure(out failureReason, "BONE_MATRIX_INVALID",
                        $"node={i} boneIndex={node.BoneIndex}");

                float localX = BitConverter.ToSingle(_boneMatrixScratch, matrixOffset + 0x30);
                float localY = BitConverter.ToSingle(_boneMatrixScratch, matrixOffset + 0x34);
                float localZ = BitConverter.ToSingle(_boneMatrixScratch, matrixOffset + 0x38);
                TransformModelPoint(_rootWorldMatrixScratch, localX, localY, localZ,
                    out float worldX, out float worldY, out float worldZ);
                if (!IsValidCoordinate(worldX) || !IsValidCoordinate(worldY) || !IsValidCoordinate(worldZ))
                    return SampleFailure(out failureReason, "BONE_WORLD_COORDINATE_INVALID",
                        $"node={i} boneIndex={node.BoneIndex}");

                node.X = worldX;
                node.Y = worldY;
                node.Z = worldZ;
                node.PositionValid = true;
                if (i == 0)
                {
                    boneRootX = worldX;
                    boneRootY = worldY;
                    boneRootZ = worldZ;
                }
            }

            float boneRootDistance = Distance(entity.X, entity.Y, entity.Z,
                boneRootX, boneRootY, boneRootZ);
            if (!float.IsFinite(boneRootDistance) || boneRootDistance > MAX_NATIVE_ROOT_TARGET_DISTANCE)
                return SampleFailure(out failureReason, "BONE_ROOT_DISTANCE_REJECT",
                    $"boneRootDistance={boneRootDistance:F2} limit={MAX_NATIVE_ROOT_TARGET_DISTANCE:F1}");

            int validNodes = 0;
            for (int i = 0; i < nodeCount; i++)
            {
                CachedNode node = cache.Nodes[i];
                float rootDistance = Distance(boneRootX, boneRootY, boneRootZ, node.X, node.Y, node.Z);
                if (!float.IsFinite(rootDistance) || rootDistance > MAX_ROOT_NODE_RADIUS)
                {
                    node.PositionValid = false;
                    continue;
                }
                validNodes++;
            }
            if (validNodes < MIN_ARTICULATED_NODES)
                return SampleFailure(out failureReason, "TOO_FEW_VALID_BONES",
                    $"validNodes={validNodes} minimum={MIN_ARTICULATED_NODES} total={nodeCount}");

            bool havePreviousEntity = cache.LastEntityValid;
            float entityDx = havePreviousEntity ? entity.X - cache.LastEntityX : 0f;
            float entityDy = havePreviousEntity ? entity.Y - cache.LastEntityY : 0f;
            float entityDz = havePreviousEntity ? entity.Z - cache.LastEntityZ : 0f;
            cache.SampleCount++;

            for (int i = 1; i < nodeCount; i++)
            {
                CachedNode node = cache.Nodes[i];
                if (!node.PositionValid)
                    continue;

                if (node.HasPrevious && havePreviousEntity)
                {
                    float relativeDx = (node.X - node.PreviousX) - entityDx;
                    float relativeDy = (node.Y - node.PreviousY) - entityDy;
                    float relativeDz = (node.Z - node.PreviousZ) - entityDz;
                    node.TotalRelativeMotion += Distance(0f, 0f, 0f,
                        relativeDx, relativeDy, relativeDz);
                }

                node.PreviousX = node.X;
                node.PreviousY = node.Y;
                node.PreviousZ = node.Z;
                node.HasPrevious = true;
            }

            cache.LastEntityX = entity.X;
            cache.LastEntityY = entity.Y;
            cache.LastEntityZ = entity.Z;
            cache.LastEntityValid = true;
            // Verified native bone metadata and a finite, target-local pose table are the
            // acceptance criteria. An idle character is still a valid skeleton.
            cache.SkeletonVerified = true;
            failureReason = null;
            return true;
        }

        private static bool SampleFailure(out string failureReason, string code, string details = null)
        {
            failureReason = string.IsNullOrWhiteSpace(details) ? code : $"{code} {details}";
            return false;
        }

        private bool SamplePose(EntityData entity, ResolutionCache cache, out string failureReason)
        {
            failureReason = "LEGACY_SAMPLE_FAILED";
            if (cache.SkeletalBoneHierarchy)
                return SampleNativeBonePose(entity, cache, out failureReason);

            _samplePageCount = 0;

            int nodeCount = Math.Min(cache.Nodes.Length, SKELETON_MAX_NODES);
            for (int i = 0; i < nodeCount; i++)
            {
                long nodePtr = cache.Nodes[i].Ptr;
                if (!IsFollowablePointer(nodePtr))
                {
                    _samplePageForNode[i] = -1;
                    _samplePageOffsetForNode[i] = 0;
                    continue;
                }

                long pageBase = nodePtr & PAGE_MASK;
                int pageIndex = FindOrAddSamplePage(pageBase);
                _samplePageForNode[i] = pageIndex;
                _samplePageOffsetForNode[i] = (int)(nodePtr & (PAGE_SIZE - 1));
            }

            for (int page = 0; page < _samplePageCount; page++)
            {
                if (_mem.ReadBytesQuiet(_samplePageBases[page], _samplePageBuffers[page], 0, PAGE_SIZE))
                    continue;

                _samplePageBases[page] = 0;
            }

            bool rootValid = false;
            float rootX = 0f, rootY = 0f, rootZ = 0f;

            for (int i = 0; i < nodeCount; i++)
            {
                CachedNode node = cache.Nodes[i];
                if (!TryReadSampledTranslation(i, node.Ptr, node.Source, out float x, out float y, out float z))
                {
                    node.PositionValid = false;
                    continue;
                }

                node.X = x;
                node.Y = y;
                node.Z = z;
                node.PositionValid = true;

                if (i == 0)
                {
                    rootX = x;
                    rootY = y;
                    rootZ = z;
                    rootValid = true;
                }
            }

            if (!rootValid)
            {
                failureReason = "LEGACY_ROOT_POSITION_UNAVAILABLE";
                return false;
            }

            float rootEntityDistance = Distance(entity.X, entity.Y, entity.Z, rootX, rootY, rootZ);
            if (!float.IsFinite(rootEntityDistance) || rootEntityDistance > MAX_LEGACY_ROOT_TARGET_DISTANCE)
            {
                failureReason = $"LEGACY_ROOT_DISTANCE_REJECT distance={rootEntityDistance:F2}";
                return false;
            }

            int validNodes = 0;
            for (int i = 0; i < nodeCount; i++)
            {
                CachedNode node = cache.Nodes[i];
                if (!node.PositionValid)
                    continue;

                float rootDistance = Distance(rootX, rootY, rootZ, node.X, node.Y, node.Z);
                if (!float.IsFinite(rootDistance) || rootDistance > MAX_ROOT_NODE_RADIUS)
                {
                    node.PositionValid = false;
                    continue;
                }

                validNodes++;
            }

            if (validNodes < 2)
            {
                failureReason = $"LEGACY_TOO_FEW_VALID_NODES validNodes={validNodes}";
                return false;
            }

            bool havePreviousEntity = cache.LastEntityValid;
            float entityDx = havePreviousEntity ? entity.X - cache.LastEntityX : 0f;
            float entityDy = havePreviousEntity ? entity.Y - cache.LastEntityY : 0f;
            float entityDz = havePreviousEntity ? entity.Z - cache.LastEntityZ : 0f;

            cache.SampleCount++;
            for (int i = 1; i < nodeCount; i++)
            {
                CachedNode node = cache.Nodes[i];
                if (!node.PositionValid)
                    continue;

                if (node.HasPrevious && havePreviousEntity)
                {
                    float dx = node.X - node.PreviousX;
                    float dy = node.Y - node.PreviousY;
                    float dz = node.Z - node.PreviousZ;
                    float relativeDx = dx - entityDx;
                    float relativeDy = dy - entityDy;
                    float relativeDz = dz - entityDz;
                    float relativeStep = Distance(0f, 0f, 0f, relativeDx, relativeDy, relativeDz);

                    node.TotalRelativeMotion += relativeStep;
                }

                node.PreviousX = node.X;
                node.PreviousY = node.Y;
                node.PreviousZ = node.Z;
                node.HasPrevious = true;
            }

            cache.LastEntityX = entity.X;
            cache.LastEntityY = entity.Y;
            cache.LastEntityZ = entity.Z;
            cache.LastEntityValid = true;

            int relativeMovingNodes = CountRelativeMovingNodes(cache);
            if (!cache.SkeletonVerified &&
                cache.SampleCount >= MIN_ARTICULATION_SAMPLES &&
                validNodes >= MIN_ARTICULATED_NODES &&
                relativeMovingNodes >= MIN_ARTICULATED_NODES)
            {
                cache.SkeletonVerified = true;
                Console.WriteLine(
                    $"  [DYN-SKEL][ARTICULATION-VERIFIED] nodes={validNodes} " +
                    $"relativeMoving={relativeMovingNodes} samples={cache.SampleCount}");
            }

            failureReason = null;
            return true;
        }

        public void Dispose()
        {
            lock (_traceSync)
            {
                if (_traceDisposed)
                    return;
                _traceDisposed = true;
                try
                {
                    _skeletonTraceWriter?.Flush();
                    _skeletonTraceWriter?.Dispose();
                }
                catch { }
                finally
                {
                    _skeletonTraceWriter = null;
                    _traceLinesSinceFlush = 0;
                }
            }
        }

        private static int CountRelativeMovingNodes(ResolutionCache cache)
        {
            int count = 0;
            for (int i = 1; i < cache.Nodes.Length; i++)
            {
                CachedNode node = cache.Nodes[i];
                if (!node.PositionValid || !node.HasPrevious)
                    continue;

                if (node.TotalRelativeMotion >= ARTICULATION_TOTAL_RELATIVE_MOTION)
                    count++;
                else if (node.TotalRelativeMotion >= ARTICULATION_RELATIVE_STEP && cache.SampleCount >= MIN_ARTICULATION_SAMPLES)
                    count++;
            }

            return count;
        }

        private int FindOrAddSamplePage(long pageBase)
        {
            for (int i = 0; i < _samplePageCount; i++)
            {
                if (_samplePageBases[i] == pageBase)
                    return i;
            }

            if (_samplePageCount >= MAX_SAMPLE_PAGES)
                return -1;

            int index = _samplePageCount++;
            _samplePageBases[index] = pageBase;
            return index;
        }

        private bool TryReadSampledTranslation(
            int nodeIndex,
            long nodePtr,
            TransformSource source,
            out float x,
            out float y,
            out float z)
        {
            x = y = z = 0f;
            if (nodeIndex < 0 || nodeIndex >= SKELETON_MAX_NODES || !IsFollowablePointer(nodePtr))
                return false;

            int pageIndex = _samplePageForNode[nodeIndex];
            int nodePageOffset = _samplePageOffsetForNode[nodeIndex];

            if (pageIndex >= 0 && pageIndex < _samplePageCount && _samplePageBases[pageIndex] != 0)
            {
                byte[] page = _samplePageBuffers[pageIndex];

                if (source == TransformSource.WorldMatrix148)
                {
                    const int size = MATRIX_BYTES;
                    if (nodePageOffset <= PAGE_SIZE - SPACE_WORLD_MATRIX - size)
                    {
                        int offset = nodePageOffset + SPACE_WORLD_MATRIX;
                        if (TryDecodeMatrixTranslation(page, offset, out x, out y, out z))
                            return true;
                    }
                }
                else
                {
                    const int size = 12;
                    if (nodePageOffset <= PAGE_SIZE - SPACE_WORLD_TRANSLATION - size)
                    {
                        int offset = nodePageOffset + SPACE_WORLD_TRANSLATION;
                        x = BitConverter.ToSingle(page, offset + 0);
                        y = BitConverter.ToSingle(page, offset + 4);
                        z = BitConverter.ToSingle(page, offset + 8);
                        if (IsValidCoordinate(x) && IsValidCoordinate(y) && IsValidCoordinate(z))
                            return true;
                    }
                }
            }

            return TryReadWorldPositionBySource(
                nodePtr, source, 0f, 0f, 0f, MAX_COORD,
                out x, out y, out z);
        }

        private bool TrySelectTransformSource(
            long node,
            float targetX,
            float targetY,
            float targetZ,
            float maxDistance,
            out TransformSource source,
            out float x,
            out float y,
            out float z,
            out bool hadTooFarTransform)
        {
            source = TransformSource.Translation178;
            x = y = z = 0f;
            hadTooFarTransform = false;

            if (!_mem.ReadBytesQuiet(node, _nodeScratch, 0, _nodeScratch.Length))
                return false;

            return TrySelectTransformSourceFromBuffer(
                _nodeScratch, targetX, targetY, targetZ, maxDistance,
                out source, out x, out y, out z,
                out hadTooFarTransform);
        }

        private static bool TrySelectTransformSourceFromBuffer(
            byte[] buffer,
            float targetX,
            float targetY,
            float targetZ,
            float maxDistance,
            out TransformSource source,
            out float x,
            out float y,
            out float z,
            out bool hadTooFarTransform)
        {
            source = TransformSource.Translation178;
            x = y = z = 0f;
            hadTooFarTransform = false;

            bool matrixValid = TryDecodeMatrixTranslation(
                buffer, SPACE_WORLD_MATRIX, out float mx, out float my, out float mz);
            if (matrixValid)
            {
                float d = Distance(targetX, targetY, targetZ, mx, my, mz);
                if (float.IsFinite(d) && d <= maxDistance)
                {
                    source = TransformSource.WorldMatrix148;
                    x = mx;
                    y = my;
                    z = mz;
                    return true;
                }
                if (float.IsFinite(d))
                    hadTooFarTransform = true;
            }

            int translationEnd = SPACE_WORLD_TRANSLATION + 12;
            if (translationEnd <= buffer.Length)
            {
                float tx = BitConverter.ToSingle(buffer, SPACE_WORLD_TRANSLATION + 0);
                float ty = BitConverter.ToSingle(buffer, SPACE_WORLD_TRANSLATION + 4);
                float tz = BitConverter.ToSingle(buffer, SPACE_WORLD_TRANSLATION + 8);
                if (IsValidCoordinate(tx) && IsValidCoordinate(ty) && IsValidCoordinate(tz))
                {
                    float d = Distance(targetX, targetY, targetZ, tx, ty, tz);
                    if (float.IsFinite(d) && d <= maxDistance)
                    {
                        source = TransformSource.Translation178;
                        x = tx;
                        y = ty;
                        z = tz;
                        return true;
                    }
                    if (float.IsFinite(d))
                        hadTooFarTransform = true;
                }
            }

            return false;
        }

        private bool TryReadWorldPositionBySource(
            long node,
            TransformSource source,
            float targetX,
            float targetY,
            float targetZ,
            float maxDistance,
            out float x,
            out float y,
            out float z)
        {
            x = y = z = 0f;

            if (source == TransformSource.WorldMatrix148)
            {
                byte[] matrix = new byte[MATRIX_BYTES];
                if (_mem.ReadBytesQuiet(node + SPACE_WORLD_MATRIX, matrix, 0, matrix.Length) &&
                    TryDecodeMatrixTranslation(matrix, 0, out x, out y, out z))
                {
                    if (maxDistance >= MAX_COORD ||
                        Distance(targetX, targetY, targetZ, x, y, z) <= maxDistance)
                        return true;
                }
            }
            else
            {
                byte[] translation = new byte[12];
                if (_mem.ReadBytesQuiet(node + SPACE_WORLD_TRANSLATION, translation, 0, translation.Length))
                {
                    x = BitConverter.ToSingle(translation, 0);
                    y = BitConverter.ToSingle(translation, 4);
                    z = BitConverter.ToSingle(translation, 8);
                    if (IsValidCoordinate(x) && IsValidCoordinate(y) && IsValidCoordinate(z) &&
                        (maxDistance >= MAX_COORD || Distance(targetX, targetY, targetZ, x, y, z) <= maxDistance))
                        return true;
                }
            }

            return false;
        }

        private static bool TryDecodeMatrixTranslation(
            byte[] buffer,
            int offset,
            out float x,
            out float y,
            out float z)
        {
            x = y = z = 0f;
            if (buffer == null || offset < 0 || offset + MATRIX_BYTES > buffer.Length)
                return false;

            for (int i = 0; i < 16; i++)
            {
                float value = BitConverter.ToSingle(buffer, offset + (i * 4));
                if (!float.IsFinite(value))
                    return false;
            }

            x = BitConverter.ToSingle(buffer, offset + 0x30);
            y = BitConverter.ToSingle(buffer, offset + 0x34);
            z = BitConverter.ToSingle(buffer, offset + 0x38);
            float w = BitConverter.ToSingle(buffer, offset + 0x3C);

            return IsValidCoordinate(x) && IsValidCoordinate(y) && IsValidCoordinate(z) &&
                   float.IsFinite(w) && MathF.Abs(w) > 0.0001f;
        }

        private static bool IsFollowablePointer(long ptr) =>
            ptr >= 0x10000 && ptr < 0x0000800000000000L;

        private static bool IsPlausiblePointer(long ptr) => IsFollowablePointer(ptr);

        private static bool IsValidCoordinate(float value) =>
            float.IsFinite(value) && MathF.Abs(value) <= MAX_COORD;

        private static float Distance(
            float ax, float ay, float az,
            float bx, float by, float bz)
        {
            float dx = ax - bx;
            float dy = ay - by;
            float dz = az - bz;
            return MathF.Sqrt(dx * dx + dy * dy + dz * dz);
        }
    }

    public struct SkeletonSegment
    {
        public PointF Parent;
        public PointF Child;

        // Native table indices are carried only for opt-in rig-mapping diagnostics.
        public int ParentBoneIndex;
        public int ChildBoneIndex;
        public bool ParentIsHierarchyRoot;
    }
}

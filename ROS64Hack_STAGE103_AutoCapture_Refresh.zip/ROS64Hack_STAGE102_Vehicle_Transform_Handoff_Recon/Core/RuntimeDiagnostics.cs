using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using ROS64Hack.Engine;

namespace ROS64Hack.Core
{
    /// <summary>
    /// Low-overhead runtime instrumentation. Hot-path methods only increment counters.
    /// One compact summary is emitted approximately once per second.
    /// </summary>
    public static class RuntimeDiagnostics
    {
        public static readonly bool Enabled = true;

        private static long _rpmCalls;
        private static long _rpmFailures;
        private static long _entityNodes;
        private static long _entityAccepted;
        private static long _entityCoordRejected;
        private static long _entityPtrRejected;
        private static long _entityZeroLike;
        private static long _calibrationCalls;
        private static long _calibrationAmbiguous;
        private static long _cameraValid;
        private static long _cameraInvalid;
        private static long _espCameraRejected;
        private static long _espRangeRejected;
        private static long _w2sCalls;
        private static long _w2sProjected;
        private static long _w2sBehind;
        private static long _w2sBounds;
        private static long _aimbotTicks;
        private static long _aimbotKeyDown;
        private static long _aimbotShiftDown;
        private static long _readLoops;
        private static long _drawLoops;
        private static long _skeletonLoops;
        private static long _readSkips;
        private static long _drawSkips;
        private static long _skeletonSkips;
        private static long _readTimeUs;
        private static long _drawTimeUs;
        private static long _skeletonLoopTimeUs;
        private static long _skeletonResolved;
        private static long _skeletonSamples;
        private static long _skeletonNodes;
        private static long _skeletonRelativeMovingNodes;
        private static long _skeletonVerified;
        private static long _skeletonSampleTimeUs;

        private static long _skeletonRejectB8Invalid;
        private static long _skeletonRejectModelInvalid;
        private static long _skeletonRejectModelVtableMismatch;
        private static long _skeletonRejectRootInvalid;
        private static long _skeletonRejectRootModelMismatch;
        private static long _skeletonRejectRootTransformInvalid;
        private static long _skeletonRejectRootDistance;
        private static long _skeletonRejectHierarchyBuildFailed;
        private static long _skeletonRejectHierarchyTooSmall;

        private static long _skeletonDiscoveryEntityModelBlockReadFailed;
        private static long _skeletonDiscoveryModelArrayMetadataInvalid;
        private static long _skeletonDiscoveryModelArrayReadFailed;
        private static long _skeletonDiscoveryModelArrayNoAcceptedRoot;
        private static long _skeletonDiscoveryB8GraphNoModel;
        private static long _skeletonDiscoveryB8GraphModelNoAcceptedRoot;
        private static long _skeletonDiscoveryB8GraphResolved;

        private static long _skeletonDiscoveryLogEntityModelBlockReadFailed;
        private static long _skeletonDiscoveryLogModelArrayMetadataInvalid;
        private static long _skeletonDiscoveryLogModelArrayReadFailed;
        private static long _skeletonDiscoveryLogModelArrayNoAcceptedRoot;
        private static long _skeletonDiscoveryLogB8GraphNoModel;
        private static long _skeletonDiscoveryLogB8GraphModelNoAcceptedRoot;
        private static long _skeletonDiscoveryLogB8GraphResolved;

        private static long _skeletonRejectLogB8Invalid;
        private static long _skeletonRejectLogModelInvalid;
        private static long _skeletonRejectLogModelVtableMismatch;
        private static long _skeletonRejectLogRootInvalid;
        private static long _skeletonRejectLogRootModelMismatch;
        private static long _skeletonRejectLogRootTransformInvalid;
        private static long _skeletonRejectLogRootDistance;
        private static long _skeletonRejectLogHierarchyBuildFailed;
        private static long _skeletonRejectLogHierarchyTooSmall;

        private static long _windowStart = Stopwatch.GetTimestamp();

        // Optional sink connected only while the forensic capture file is active.
        // The normal resolver does no detailed logging when this sink is null.
        private static Action<string> _skeletonEvidenceSink;

        public static bool SkeletonEvidenceCaptureActive => Volatile.Read(ref _skeletonEvidenceSink) != null;

        public static void SetSkeletonEvidenceSink(Action<string> sink)
        {
            Interlocked.Exchange(ref _skeletonEvidenceSink, sink);
        }

        public static void SkeletonEvidence(string message)
        {
            if (!Enabled || string.IsNullOrEmpty(message))
                return;

            Action<string> sink = Volatile.Read(ref _skeletonEvidenceSink);
            if (sink == null)
                return;

            try { sink(message); } catch { }
        }

        public static void RpmCall()
        {
            if (Enabled) Interlocked.Increment(ref _rpmCalls);
        }

        public static void ReadFailure(long address, int requested, int actual, int win32Error, string tag)
        {
            if (Enabled) Interlocked.Increment(ref _rpmFailures);
        }

        public static void EntityNode(long node, long entityPtr, ulong obType, float x, float y, float z)
        {
            if (!Enabled) return;
            Interlocked.Increment(ref _entityNodes);

            if (entityPtr == 0)
                Interlocked.Increment(ref _entityPtrRejected);

            if (!float.IsFinite(x) || !float.IsFinite(y) || !float.IsFinite(z))
                Interlocked.Increment(ref _entityCoordRejected);

            if (MathF.Abs(x) < 0.001f && MathF.Abs(y) < 0.001f && MathF.Abs(z) < 0.001f)
                Interlocked.Increment(ref _entityZeroLike);
        }

        public static void EntityAccepted() => Interlocked.Increment(ref _entityAccepted);

        public static void Calibration(long entityCount, int distinctTypes, int maxCount, bool accepted)
        {
            if (!Enabled) return;
            Interlocked.Increment(ref _calibrationCalls);
            if (distinctTypes > 1 && maxCount <= 1)
                Interlocked.Increment(ref _calibrationAmbiguous);
        }

        public static void Camera(long ptr, in CameraData cam, bool valid, string reason)
        {
            if (!Enabled) return;
            if (valid) Interlocked.Increment(ref _cameraValid);
            else Interlocked.Increment(ref _cameraInvalid);
        }

        public static void LocalPlayer(long ptr, ulong obType, float x, float y, float z)
        {
        }

        public static void EspCameraRejected() => Interlocked.Increment(ref _espCameraRejected);
        public static void EspRangeRejected() => Interlocked.Increment(ref _espRangeRejected);

        public static void EspRangeSample(
            long entityPtr,
            float ex, float ey, float ez,
            in CameraData cam,
            float distance, float maxRange,
            bool rejected)
        {
        }

        public static void W2S(
            long entityPtr,
            float wx, float wy, float wz,
            float vx, float vy, float vz,
            float sx, float sy,
            string reason)
        {
            if (!Enabled) return;
            Interlocked.Increment(ref _w2sCalls);
            switch (reason)
            {
                case "PROJECTED": Interlocked.Increment(ref _w2sProjected); break;
                case "BEHIND":    Interlocked.Increment(ref _w2sBehind); break;
                case "BOUNDS":    Interlocked.Increment(ref _w2sBounds); break;
            }
        }

        public static void Aimbot(
            bool enabled,
            System.Windows.Forms.Keys configuredKey,
            bool keyDown,
            bool shiftDown,
            int entities)
        {
            if (!Enabled) return;
            Interlocked.Increment(ref _aimbotTicks);
            if (keyDown) Interlocked.Increment(ref _aimbotKeyDown);
            if (shiftDown) Interlocked.Increment(ref _aimbotShiftDown);
        }

        public static void ReadLoopSkipped() => Interlocked.Increment(ref _readSkips);
        public static void DrawLoopSkipped() => Interlocked.Increment(ref _drawSkips);
        public static void SkeletonLoopSkipped() => Interlocked.Increment(ref _skeletonSkips);

        public static void ReadLoopCompleted(double elapsedMs)
        {
            if (!Enabled) return;
            Interlocked.Increment(ref _readLoops);
            Interlocked.Add(ref _readTimeUs, (long)Math.Max(0, elapsedMs * 1000.0));
        }

        public static void DrawLoopCompleted(double elapsedMs)
        {
            if (!Enabled) return;
            Interlocked.Increment(ref _drawLoops);
            Interlocked.Add(ref _drawTimeUs, (long)Math.Max(0, elapsedMs * 1000.0));
        }

        public static void SkeletonLoopCompleted(double elapsedMs)
        {
            if (!Enabled) return;
            Interlocked.Increment(ref _skeletonLoops);
            Interlocked.Add(ref _skeletonLoopTimeUs, (long)Math.Max(0, elapsedMs * 1000.0));
        }

        public static void SkeletonResolved(int nodeCount)
        {
            if (!Enabled) return;
            Interlocked.Increment(ref _skeletonResolved);
            Interlocked.Add(ref _skeletonNodes, Math.Max(0, nodeCount));
        }

        public static void SkeletonResolveRejected(string reason, long entityPtr)
        {
            if (!Enabled) return;

            switch (reason)
            {
                case "B8_INVALID":
                    Interlocked.Increment(ref _skeletonRejectB8Invalid);
                    if (Interlocked.Increment(ref _skeletonRejectLogB8Invalid) <= 2)
                        Console.WriteLine($"  [DYN-SKEL][REJECT] reason=B8_INVALID entity=0x{entityPtr:X}");
                    break;
                case "MODEL_INVALID":
                    Interlocked.Increment(ref _skeletonRejectModelInvalid);
                    if (Interlocked.Increment(ref _skeletonRejectLogModelInvalid) <= 2)
                        Console.WriteLine($"  [DYN-SKEL][REJECT] reason=MODEL_INVALID entity=0x{entityPtr:X}");
                    break;
                case "MODEL_VTABLE_MISMATCH":
                    Interlocked.Increment(ref _skeletonRejectModelVtableMismatch);
                    if (Interlocked.Increment(ref _skeletonRejectLogModelVtableMismatch) <= 2)
                        Console.WriteLine($"  [DYN-SKEL][REJECT] reason=MODEL_VTABLE_MISMATCH entity=0x{entityPtr:X}");
                    break;
                case "ROOT_INVALID":
                    Interlocked.Increment(ref _skeletonRejectRootInvalid);
                    if (Interlocked.Increment(ref _skeletonRejectLogRootInvalid) <= 2)
                        Console.WriteLine($"  [DYN-SKEL][REJECT] reason=ROOT_INVALID entity=0x{entityPtr:X}");
                    break;
                case "ROOT_MODEL_MISMATCH":
                    Interlocked.Increment(ref _skeletonRejectRootModelMismatch);
                    if (Interlocked.Increment(ref _skeletonRejectLogRootModelMismatch) <= 2)
                        Console.WriteLine($"  [DYN-SKEL][REJECT] reason=ROOT_MODEL_MISMATCH entity=0x{entityPtr:X}");
                    break;
                case "ROOT_TRANSFORM_INVALID":
                    Interlocked.Increment(ref _skeletonRejectRootTransformInvalid);
                    if (Interlocked.Increment(ref _skeletonRejectLogRootTransformInvalid) <= 2)
                        Console.WriteLine($"  [DYN-SKEL][REJECT] reason=ROOT_TRANSFORM_INVALID entity=0x{entityPtr:X}");
                    break;
                case "ROOT_DISTANCE_REJECT":
                    Interlocked.Increment(ref _skeletonRejectRootDistance);
                    if (Interlocked.Increment(ref _skeletonRejectLogRootDistance) <= 2)
                        Console.WriteLine($"  [DYN-SKEL][REJECT] reason=ROOT_DISTANCE_REJECT entity=0x{entityPtr:X}");
                    break;
                case "HIERARCHY_BUILD_FAILED":
                    Interlocked.Increment(ref _skeletonRejectHierarchyBuildFailed);
                    if (Interlocked.Increment(ref _skeletonRejectLogHierarchyBuildFailed) <= 2)
                        Console.WriteLine($"  [DYN-SKEL][REJECT] reason=HIERARCHY_BUILD_FAILED entity=0x{entityPtr:X}");
                    break;
                case "HIERARCHY_TOO_SMALL":
                    Interlocked.Increment(ref _skeletonRejectHierarchyTooSmall);
                    if (Interlocked.Increment(ref _skeletonRejectLogHierarchyTooSmall) <= 2)
                        Console.WriteLine($"  [DYN-SKEL][REJECT] reason=HIERARCHY_TOO_SMALL entity=0x{entityPtr:X}");
                    break;
            }
        }

        public static void SkeletonModelDiscoveryTerminal(
            string reason,
            long entityPtr,
            long b8,
            long directModel,
            long modelBegin,
            long modelEnd,
            int modelArrayCandidates,
            int modelArrayAccepted,
            int graphExpanded,
            int graphModelCandidates,
            int graphReadFailures)
        {
            if (!Enabled) return;

            long logIndex;
            switch (reason)
            {
                case "ENTITY_MODEL_BLOCK_READ_FAILED":
                    Interlocked.Increment(ref _skeletonDiscoveryEntityModelBlockReadFailed);
                    logIndex = Interlocked.Increment(ref _skeletonDiscoveryLogEntityModelBlockReadFailed);
                    break;
                case "MODEL_ARRAY_METADATA_INVALID":
                    Interlocked.Increment(ref _skeletonDiscoveryModelArrayMetadataInvalid);
                    logIndex = Interlocked.Increment(ref _skeletonDiscoveryLogModelArrayMetadataInvalid);
                    break;
                case "MODEL_ARRAY_READ_FAILED":
                    Interlocked.Increment(ref _skeletonDiscoveryModelArrayReadFailed);
                    logIndex = Interlocked.Increment(ref _skeletonDiscoveryLogModelArrayReadFailed);
                    break;
                case "MODEL_ARRAY_NO_ACCEPTED_ROOT":
                    Interlocked.Increment(ref _skeletonDiscoveryModelArrayNoAcceptedRoot);
                    logIndex = Interlocked.Increment(ref _skeletonDiscoveryLogModelArrayNoAcceptedRoot);
                    break;
                case "B8_GRAPH_NO_MODEL":
                    Interlocked.Increment(ref _skeletonDiscoveryB8GraphNoModel);
                    logIndex = Interlocked.Increment(ref _skeletonDiscoveryLogB8GraphNoModel);
                    break;
                case "B8_GRAPH_MODEL_NO_ACCEPTED_ROOT":
                    Interlocked.Increment(ref _skeletonDiscoveryB8GraphModelNoAcceptedRoot);
                    logIndex = Interlocked.Increment(ref _skeletonDiscoveryLogB8GraphModelNoAcceptedRoot);
                    break;
                case "B8_GRAPH_RESOLVED":
                    Interlocked.Increment(ref _skeletonDiscoveryB8GraphResolved);
                    logIndex = Interlocked.Increment(ref _skeletonDiscoveryLogB8GraphResolved);
                    break;
                default:
                    return;
            }

            if (logIndex <= 2)
            {
                Console.WriteLine(
                    $"  [DYN-SKEL][DISCOVERY-END] reason={reason} entity=0x{entityPtr:X} " +
                    $"b8=0x{b8:X} directModel=0x{directModel:X} " +
                    $"modelBegin=0x{modelBegin:X} modelEnd=0x{modelEnd:X} " +
                    $"arrayCandidates={modelArrayCandidates} arrayAccepted={modelArrayAccepted} " +
                    $"graphExpanded={graphExpanded} graphModelCandidates={graphModelCandidates} " +
                    $"graphReadFailures={graphReadFailures}");
            }
        }

        public static void SkeletonSample(
            int nodeCount,
            int relativeMovingNodes,
            bool verified,
            double elapsedMs)
        {
            if (!Enabled) return;
            Interlocked.Increment(ref _skeletonSamples);
            Interlocked.Add(ref _skeletonNodes, Math.Max(0, nodeCount));
            Interlocked.Add(ref _skeletonRelativeMovingNodes, Math.Max(0, relativeMovingNodes));
            if (verified)
                Interlocked.Increment(ref _skeletonVerified);
            Interlocked.Add(ref _skeletonSampleTimeUs, (long)Math.Max(0, elapsedMs * 1000.0));
        }

        private static long Take(ref long value) => Interlocked.Exchange(ref value, 0);

        public static void Frame(in CameraData cam, List<EntityData> entities)
        {
            if (!Enabled) return;

            long now = Stopwatch.GetTimestamp();
            long start = Interlocked.Read(ref _windowStart);
            long elapsed = now - start;
            if (elapsed < Stopwatch.Frequency) return;
            if (Interlocked.CompareExchange(ref _windowStart, now, start) != start) return;

            int visible = 0;
            int enemies = 0;
            foreach (EntityData e in entities)
            {
                if (e?.IsEnemy == true) enemies++;
                if (e?.IsEnemy == true && e.OnScreen) visible++;
            }

            long rpmCalls = Take(ref _rpmCalls);
            long rpmFail = Take(ref _rpmFailures);
            long nodes = Take(ref _entityNodes);
            long accepted = Take(ref _entityAccepted);
            long coordReject = Take(ref _entityCoordRejected);
            long ptrReject = Take(ref _entityPtrRejected);
            long zeroLike = Take(ref _entityZeroLike);
            long calCalls = Take(ref _calibrationCalls);
            long calAmbiguous = Take(ref _calibrationAmbiguous);
            long camValidReads = Take(ref _cameraValid);
            long camInvalidReads = Take(ref _cameraInvalid);
            long espCamReject = Take(ref _espCameraRejected);
            long espRangeReject = Take(ref _espRangeRejected);
            long w2s = Take(ref _w2sCalls);
            long projected = Take(ref _w2sProjected);
            long behind = Take(ref _w2sBehind);
            long bounds = Take(ref _w2sBounds);
            long aimTicks = Take(ref _aimbotTicks);
            long aimDown = Take(ref _aimbotKeyDown);
            long shiftDown = Take(ref _aimbotShiftDown);
            long readLoops = Take(ref _readLoops);
            long drawLoops = Take(ref _drawLoops);
            long skeletonLoops = Take(ref _skeletonLoops);
            long readSkips = Take(ref _readSkips);
            long drawSkips = Take(ref _drawSkips);
            long skeletonSkips = Take(ref _skeletonSkips);
            long readTimeUs = Take(ref _readTimeUs);
            long drawTimeUs = Take(ref _drawTimeUs);
            long skeletonLoopTimeUs = Take(ref _skeletonLoopTimeUs);
            long skeletonResolved = Take(ref _skeletonResolved);
            long skeletonSamples = Take(ref _skeletonSamples);
            long skeletonNodes = Take(ref _skeletonNodes);
            long skeletonRelativeMoving = Take(ref _skeletonRelativeMovingNodes);
            long skeletonVerified = Take(ref _skeletonVerified);
            long skeletonSampleTimeUs = Take(ref _skeletonSampleTimeUs);
            long skeletonRejectB8Invalid = Take(ref _skeletonRejectB8Invalid);
            long skeletonRejectModelInvalid = Take(ref _skeletonRejectModelInvalid);
            long skeletonRejectModelVtableMismatch = Take(ref _skeletonRejectModelVtableMismatch);
            long skeletonRejectRootInvalid = Take(ref _skeletonRejectRootInvalid);
            long skeletonRejectRootModelMismatch = Take(ref _skeletonRejectRootModelMismatch);
            long skeletonRejectRootTransformInvalid = Take(ref _skeletonRejectRootTransformInvalid);
            long skeletonRejectRootDistance = Take(ref _skeletonRejectRootDistance);
            long skeletonRejectHierarchyBuildFailed = Take(ref _skeletonRejectHierarchyBuildFailed);
            long skeletonRejectHierarchyTooSmall = Take(ref _skeletonRejectHierarchyTooSmall);
            long skeletonDiscoveryEntityModelBlockReadFailed = Take(ref _skeletonDiscoveryEntityModelBlockReadFailed);
            long skeletonDiscoveryModelArrayMetadataInvalid = Take(ref _skeletonDiscoveryModelArrayMetadataInvalid);
            long skeletonDiscoveryModelArrayReadFailed = Take(ref _skeletonDiscoveryModelArrayReadFailed);
            long skeletonDiscoveryModelArrayNoAcceptedRoot = Take(ref _skeletonDiscoveryModelArrayNoAcceptedRoot);
            long skeletonDiscoveryB8GraphNoModel = Take(ref _skeletonDiscoveryB8GraphNoModel);
            long skeletonDiscoveryB8GraphModelNoAcceptedRoot = Take(ref _skeletonDiscoveryB8GraphModelNoAcceptedRoot);
            long skeletonDiscoveryB8GraphResolved = Take(ref _skeletonDiscoveryB8GraphResolved);

            double avgReadMs = readLoops > 0 ? readTimeUs / 1000.0 / readLoops : 0.0;
            double avgDrawMs = drawLoops > 0 ? drawTimeUs / 1000.0 / drawLoops : 0.0;
            double avgSkeletonLoopMs = skeletonLoops > 0 ? skeletonLoopTimeUs / 1000.0 / skeletonLoops : 0.0;
            double avgSkeletonSampleMs = skeletonSamples > 0 ? skeletonSampleTimeUs / 1000.0 / skeletonSamples : 0.0;

            Console.WriteLine(
                $"  [DIAG][SUMMARY] read/s={readLoops} draw/s={drawLoops} " +
                $"skelLoop/s={skeletonLoops} readSkip/s={readSkips} " +
                $"drawSkip/s={drawSkips} skelSkip/s={skeletonSkips} " +
                $"avgReadMs={avgReadMs:F2} avgDrawMs={avgDrawMs:F2} " +
                $"avgSkelLoopMs={avgSkeletonLoopMs:F2} avgSkelSampleMs={avgSkeletonSampleMs:F2} " +
                $"rpm/s={rpmCalls} rpmFail/s={rpmFail} " +
                $"cam/s={camValidReads} camBad/s={camInvalidReads} " +
                $"entities={entities.Count} enemies={enemies} visible={visible} " +
                $"nodes/s={nodes} accepted/s={accepted} " +
                $"w2s/s={w2s} projected/s={projected} behind/s={behind} bounds/s={bounds} " +
                $"rangeReject/s={espRangeReject} aim/s={aimTicks} shift/s={shiftDown} " +
                $"skelResolved/s={skeletonResolved} skelSamples/s={skeletonSamples} " +
                $"skelNodes/s={skeletonNodes} skelMoving/s={skeletonRelativeMoving} " +
                $"skelVerified/s={skeletonVerified} " +
                $"skelRejects=" +
                $"B8_INVALID:{skeletonRejectB8Invalid}," +
                $"MODEL_INVALID:{skeletonRejectModelInvalid}," +
                $"MODEL_VTABLE_MISMATCH:{skeletonRejectModelVtableMismatch}," +
                $"ROOT_INVALID:{skeletonRejectRootInvalid}," +
                $"ROOT_MODEL_MISMATCH:{skeletonRejectRootModelMismatch}," +
                $"ROOT_TRANSFORM_INVALID:{skeletonRejectRootTransformInvalid}," +
                $"ROOT_DISTANCE_REJECT:{skeletonRejectRootDistance}," +
                $"HIERARCHY_BUILD_FAILED:{skeletonRejectHierarchyBuildFailed}," +
                $"HIERARCHY_TOO_SMALL:{skeletonRejectHierarchyTooSmall} " +
                $"skelDiscovery=" +
                $"ENTITY_MODEL_BLOCK_READ_FAILED:{skeletonDiscoveryEntityModelBlockReadFailed}," +
                $"MODEL_ARRAY_METADATA_INVALID:{skeletonDiscoveryModelArrayMetadataInvalid}," +
                $"MODEL_ARRAY_READ_FAILED:{skeletonDiscoveryModelArrayReadFailed}," +
                $"MODEL_ARRAY_NO_ACCEPTED_ROOT:{skeletonDiscoveryModelArrayNoAcceptedRoot}," +
                $"B8_GRAPH_NO_MODEL:{skeletonDiscoveryB8GraphNoModel}," +
                $"B8_GRAPH_MODEL_NO_ACCEPTED_ROOT:{skeletonDiscoveryB8GraphModelNoAcceptedRoot}," +
                $"B8_GRAPH_RESOLVED:{skeletonDiscoveryB8GraphResolved}");
        }
    }
}

# ROS64Hack — audited source package

## Project overview

This is a Windows-only .NET 8 x64 executable using Windows Forms and unsafe code. The SDK-style project uses implicit C# file inclusion; it declares no third-party package or project references. The entry point is `Program.Main`.

`Program.Main` initializes WinForms, opens a diagnostic attach log, waits for the `ros64` process, attaches through `Core/Mem.cs`, performs memory/camera sanity reads, and runs the overlay. `Overlay/HackOverlay.cs` coordinates three timer-driven paths: entity/camera reads, skeleton sampling, and drawing. The Stage 84 source requests entity/camera snapshots and paint invalidation every 8 ms, while skeleton sampling remains at 33 ms; Windows Forms and DWM still control actual presentation cadence. Drawing consumes published snapshots rather than performing remote-memory reads in `OnPaint`.

## Current architecture

| Path | Responsibility |
|---|---|
| `Program.cs` | Process wait/attach startup, attach diagnostics, and overlay launch. |
| `Core/Mem.cs` | Process attachment and remote-memory read helpers. |
| `Core/Offsets.cs` | Executable offsets and layout constants. |
| `Core/DynamicSkeletonReader.cs` | Runtime native-bone resolution, validation, caching, and pose sampling. |
| `Core/RuntimeDiagnostics.cs` | Compact runtime counters and diagnostic summaries. |
| `Core/SkeletonCoverageTrace.cs` | Optional per-entity skeleton coverage tracing. |
| `Core/Stage78BoundedNodeHierarchyRecon.cs` | Legacy, bounded, read-only reconstruction capture; optional and disabled unless explicitly enabled. |
| `Core/WorldToScreen.cs` | World-to-screen projection. |
| `Engine/Camera.cs` | Camera discovery, validation, and camera-state sampling. |
| `Engine/EntityData.cs` / `Engine/EntityLoop.cs` / `Engine/PlayerReader.cs` | Entity representation, entity enumeration, and local-player reads. |
| `Features/ESP.cs` / `Features/Aimbot.cs` / `Features/NoClip.cs` | Overlay display and gameplay feature implementations. |
| `Features/EntityClassifier.cs` / `Features/Settings.cs` | Entity classification and feature settings. |
| `Overlay/HackOverlay.cs` / `Overlay/MenuForm.cs` | Overlay lifecycle, timers, snapshot publication, drawing, and menu UI. |

The retired numbered diagnostic classes were not called from any other C# source file. Their notes, validation reports, and supplied historical source dumps are retained in `HISTORY.md`; their source files are not part of this build. `Stage78BoundedNodeHierarchyRecon` is retained because the overlay can start it when its opt-in environment switch is set.

## Native-bone reader notes

The current `DynamicSkeletonReader.cs` contains a native `SkeletalAnim` path. It follows `ModelSkeletal +0x660` to `SkeletalAnim`, validates the model/animation relationship, reads the bone count at `+0x30`, four-byte parent/next-sibling/first-child records starting at `+0x32`, and 64-byte model-space matrices through the pointer at `+0xCE0`. It validates the reciprocal model backlink and uses the owning root `SpaceNode` world matrix for world-space bone positions. `Engine/EntityData.cs` provides capacity for up to 96 rendered segments.

The included native-bone audit records cite one static minidump and native machine-code inspection. This is structural evidence for that captured executable, not a claim of live runtime correctness across builds. Run a Windows build and controlled live test before treating rendered animation as verified.

## Runtime environment switches

The following variables are read by the current source. Set them before launching the executable.

- `ROS64HACK_SKELETON_COVERAGE=1` enables per-entity skeleton coverage output; it is disabled by default.
- `ROS64HACK_SKELETON_DISCOVERY_TRACE=1` enables detailed resolver/graph/hierarchy tracing and extra sampling; it adds remote-memory reads and file/console I/O and is disabled by default.
- `ROS64HACK_STAGE78_RECON=1` enables the expensive legacy Stage 78 reconstruction capture; it is disabled by default.
- `ROS64HACK_SKELETON_BONE_INDEX_DIAGNOSTICS=1` overlays native bone-table indices for one fully in-viewport skeleton only; keep it unset during normal play because labels are diagnostic-only. See `SKELETON_BONE_INDEX_DIAGNOSTICS.md`.

The active build marker is `ROS64HACK_STAGE98_NATIVE_ROOT_ASSOCIATION_GUARD`, and the overlay logs `[STAGE98][OVERLAY-MARKER]`. Use these markers to confirm that the intended source package was built and launched.

## Build and verification

On Windows with the .NET 8 SDK, from the `ROS64Hack` directory:

```cmd
dotnet clean
dotnet build -c Release
```

This audit environment did not provide `dotnet`, `csc`, `mcs`, `mono`, or `msbuild`, so compilation could not be performed here. Static source and package integrity checks were run; they are not substitutes for a Windows Release build or live ROS Legacy validation. No test project is included in the archive.

See `HISTORY.md` for the consolidated historical records and `CODEBASE_AUDIT.md` for the evidence trail, removed-module inventory, changes, and verification status.


## Stage 84 — higher-frequency snapshots and camera recovery

- Entity/camera sampling and paint invalidation are scheduled at 8 ms instead of 16 ms; the skeleton memory sampler remains at 33 ms. This raises the requested snapshot cadence, but is not a guarantee of 125 FPS or frame-perfect presentation.
- After repeated invalid reads from the active camera, recovery keeps the last coherent camera data/pointer as continuity evidence and immediately attempts to revalidate it. If it remains invalid, the existing candidate pool is reconsidered; failed pool selection retries after 50 ms instead of 500 ms.
- This paragraph describes the earlier Stage 84 state. It is superseded by the Stage 88 exclusion-only filter below; Stage 88 still requires Windows build and in-game visual verification.
- Verification limit: this environment lacks the .NET 8 SDK/compiler and a live ROS64 process. Static/source/package checks are possible here; Windows Release compilation and live latency measurements remain required.

## Stage 88 — Small-subtree exclusion filter

Stage 88 restores the original validated parent-child hierarchy draw path. It does not create
replacement links or guess anatomical bone IDs. The renderer omits the entity-root connector
and compact side subtrees that branch off at junctions; all remaining lines correspond to existing edges
in the validated native hierarchy. Screen-top tracer lines are off by default because they are
separate ESP lines, not skeleton segments. Enable them from the TRACERS menu toggle if needed.

The skeleton uses a 2.5 px royal-blue pen with rounded caps. Stage 86's geometric edge selection,
16 ms skeleton request, and experimental timer-resolution request are not used. See
`STAGE89_VALIDATION_REPORT.txt` for verification boundaries and CMD commands.



## Stage 89 — Pelvic skirt branch exclusion

Stage 89 adds one targeted, exclusion-only rule based on the supplied Stage 88 edge map. It detects a pelvic-like junction from hierarchy topology and 3D subtree geometry: at least five child branches, a branch reaching the upper/head extreme, and at least one reaching the lower/foot extreme (the two legs may split one level below). Short intermediate sibling branches at that junction are excluded as entire existing subtrees. The filter does not hard-code bone indices and never creates/reconnects edges.

The expected startup marker is `ROS64HACK_STAGE89_PELVIC_SKIRT_EXCLUSION`. See `STAGE89_VALIDATION_REPORT.txt` for the exact evidence and unverified runtime limits.


## Stage 91 — Dynamic head circle and neck clip

Stage 91 keeps Stage 89's existing parent-child skeleton and pelvic exclusions. It detects the compact upper head cluster from the current projected native pose, replaces only that cluster's drawn edges with a circle, and clips the original incoming edge at the circle perimeter so the lower neck segment remains visible. It does not rewrite bone matrices, hierarchy relationships, or bone indices.

For a focused CMD run:

```cmd
set ROS64HACK_SKELETON_COVERAGE=1
set ROS64HACK_SKELETON_EDGE_TRACE=1
set ROS64HACK_SKELETON_BONE_INDEX_DIAGNOSTICS=1
bin\Release\net8.0-windows\ROS64Hack.exe
```

The current startup marker must read `ROS64HACK_STAGE98_NATIVE_ROOT_ASSOCIATION_GUARD`. The generated `STAGE98_SKELETON_EDGE_TRACE.txt` records `headTipBone`, `headEntryBone`, `neckBaseBone`, node parent links, and the visible-segment bounds for the single selected actor. Cyan bone-index labels are drawn only for that same actor. Bone indices remain pose/model evidence, not universal semantic names.


## Stage 92 — World-space head-cluster center

Stage 92 computes the compact head cluster's centroid in 3D world space, then projects it with the current camera snapshot. This avoids deriving the circle center from a screen-space bounding box, which can drift as perspective changes. Radius is recalculated from the projected cluster width with tighter scaling and padding. The detected `headTipBone` remains a pose-specific inference, not a verified universal semantic Head-bone ID.


## Stage 97 — Focused, in-viewport bone diagnostics

Stage 96's capture selected a skeleton whose 64 projected nodes all had X coordinates between 1340.3 and 1382.1 in a 1280-pixel-wide viewport. The loose entity clipping gate allowed that target to consume the one-shot trace even though none of its edges was actually inside the viewport. Stage 97 requires at least two-thirds of surviving skeleton segments (and at least six) to have both endpoints inside the viewport, with a minimum 12-pixel vertical extent, before selecting the diagnostic target. The same entity receives cyan bone-index labels, preventing labels from all visible actors from being stacked together.

Stage 97 does not change native offsets, matrix stride, transforms, hierarchy traversal, pruning thresholds, or ordinary skeleton drawing. It is a diagnostic-selection correction, not a claim that the anatomical topology is fixed. A clean Stage 97 edge map plus a focused screenshot is required before adjusting bone links.


## Stage 98 — native rig-to-entity association guard

The Stage 97 on-screen trace now reports a coherent viewport-bounded edge map, but the native root-to-entity acceptance limit was still 64 world units. That is too permissive for selecting an actor-owned native rig in a crowded scene. Stage 98 introduces a separate 8-unit maximum for native SpaceNode root and native hierarchy-root association, applies it during resolver acceptance, hierarchy construction, cache validation, and pose sampling, and leaves the legacy node-reader fallback at 64 units. Discovery diagnostics report both `withinLegacy64UnitGate` and `withinNative8UnitGate`.

The native bone matrix stride, translation fields, hierarchy-record layout, transform math, and topology pruning remain unchanged. This is a conservative association guard; rejection rates and the live silhouette must be checked in a Windows build before calling it a verified in-game fix.

For the Stage 98 association capture, also enable `ROS64HACK_SKELETON_DISCOVERY_TRACE=1`. This writes `SKELETON_DISCOVERY_TRACE.txt` with model-root candidate distances and both legacy/native gate outcomes, at the cost of extra remote reads and I/O; do not use that run to benchmark frame timing.

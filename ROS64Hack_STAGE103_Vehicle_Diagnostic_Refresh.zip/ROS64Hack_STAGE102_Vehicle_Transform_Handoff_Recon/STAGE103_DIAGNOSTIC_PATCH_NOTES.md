# Stage 103 — Vehicle diagnostic capture refresh

Based on source package commit `27c6180eba14f160d9f8ca51e33746d61a048483`. Only `Core/Stage102VehicleTransitionRecon.cs` and this notes file differ from the source archive. Entity enumeration, ESP, aimbot, skeleton rendering, camera logic, and game-memory writes were not changed.

## Diagnostic changes
- Optional `ROS64HACK_VEHICLE_TARGET_ID` pins capture to a visible enemy entity ID. Use hex with prefix, e.g. `0x00155FDD`. If that ID is absent, capture waits and logs; it will not silently select another target. If unset, the existing most-moved fallback remains.
- Records actual association-sample intervals, processing duration, over-budget work, and final min/average/max cadence. The configured 250 ms timer is no longer treated as proof of 250 ms actual sampling.
- Adds movement-state transition events and expands the per-sample trace with entity pointer, ID, measured interval, motion state, and marker.
- Optional `ROS64HACK_VEHICLE_MARKER_FILE` lets an operator annotate visible entry/travel/exit moments. The file must contain exactly one value: `NONE`, `ENTERING`, `INSIDE`, `EXITING`, or `EXITED`. Change it during the capture; the next poll logs the marker timestamp.
- Automatic occupancy is explicitly `UNAVAILABLE`. Markers are manual annotations, not game-derived vehicle telemetry. No unverified vehicle offset or transform is promoted to authoritative.

## Run on Windows

From the executable working directory, set these in the same command prompt:

```bat
set ROS64HACK_VEHICLE_RECON=1
set ROS64HACK_VEHICLE_TARGET_ID=0x00155FDD
set ROS64HACK_VEHICLE_MARKER_FILE=C:\Temp\vehicle_marker.txt
echo NONE>C:\Temp\vehicle_marker.txt
bin\Release\net8.0-windows\ROS64Hack.exe
```

Replace the sample ID with the entity ID for the enemy actually entering the vehicle. Do not assume the automatically selected Stage 102 ID was the occupant. Use another command prompt to overwrite the marker file at observed transitions, for example `echo ENTERING>C:\Temp\vehicle_marker.txt`, then `INSIDE`, `EXITING`, and `EXITED`.

If no specific entity ID is known, omit the target-ID environment variable and inspect the logged target candidates. The automatic fallback can still select an unrelated moving entity, so those results remain inconclusive unless the ID matches the observed occupant.

## Validation status
- Required source replacements and diagnostic token checks: PASS.
- All 50 rebuilt ZIP entry payloads and CRC-32 values validated.
- .NET 8 compilation: NOT RUN in this environment.
- Live vehicle entry/exit capture: NOT RUN here.
- This is diagnostic instrumentation, not a verified occupant-transform handoff fix.

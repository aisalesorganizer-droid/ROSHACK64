# Stage 104 — Bounded, per-entity transform correlation

This is a diagnostic-only continuation of Stage 103. It removes manual entity-ID and vehicle-marker requirements.

## Run
1. Extract this ZIP.
2. Open `ROS64Hack_STAGE102_Vehicle_Transform_Handoff_Recon`.
3. Double-click `RUN_STAGE104_AUTO_CAPTURE.bat`.
4. Reproduce the vehicle entry, travel and exit issue during the capture.
5. Send `STAGE102_VEHICLE_TRANSITION_RECON.txt` back for analysis.

The launcher builds the included `ROS64Hack.csproj` in Release mode, enables the vehicle diagnostic and starts the rebuilt executable. It clears both manual target-ID and marker-file environment variables. The .NET 8 SDK is required.

## What changes
- The all-enemy entity snapshot remains automatically sampled at its existing high-cadence read path for a 120-second window.
- Deep transform work is round-robin bounded per timed callback: at most four candidate roots, twelve transform probes, one focused root and eight focused nodes.
- Candidate-root motion is compared with that candidate's own observation interval rather than incorrectly using the target's most recent per-tick movement.
- Every sampled candidate/probe/node transform is matched against all recently observed enemy entity origins and any valid projected neck-world positions.
- A transform is only counted as moving during a stationary entity interval when the entity's continuous stationary span covers the transform's entire previous-to-current sampling interval.
- Per-entity skeleton validity, projected segment count, neck-world validity, neck movement and stationary transitions are recorded against the same entity IDs.
- The prior summary that counted asynchronous probe movement as if it coincided with the selected target's stationary period is disabled.

## Key Stage 104 records
`[STAGE104][SAMPLE-BUDGET]`, `[STAGE104][ENTITY-SKELETON-STATE]`, `[STAGE104][ENTITY-ROOT-STATIONARY-NECK-MOVE]`, `[STAGE104][TRANSFORM-MOTION-DURING-ENTITY-STATIONARITY]`, and `[STAGE104][FINAL][ENTITY-TRANSFORM-MATCH]`.

## Limitations and validation
The entity origin and projected neck are still obtained from the normal overlay entity snapshot, not an independent authoritative game transform. These measurements cannot establish a vehicle occupancy field by themselves and are not a claimed occupant-transform fix. The source has passed static patch/package checks, but compilation and a live in-game capture have not been run in this environment.

@echo off
setlocal
cd /d "%~dp0"
title ROS64Hack Stage 104 Automatic Vehicle Diagnostic

echo ============================================================
echo ROS64Hack Stage 104 - Bounded Per-Entity Capture
echo ============================================================
echo No manual enemy ID or vehicle marker file is required.
echo All visible entity IDs are captured automatically.
echo.

where dotnet >nul 2>nul
if errorlevel 1 goto NoDotnet

echo [1/2] Building Release configuration...
dotnet build "%~dp0ROS64Hack.csproj" --configuration Release
if errorlevel 1 goto BuildFailed

set "ROS64HACK_VEHICLE_RECON=1"
set "ROS64HACK_VEHICLE_TARGET_ID="
set "ROS64HACK_VEHICLE_MARKER_FILE="

echo.
echo [2/2] Starting diagnostic capture...
echo Reproduce the vehicle enter, travel, and exit sequence.
echo Log: %~dp0STAGE102_VEHICLE_TRANSITION_RECON.txt
echo.
"%~dp0bin\Release\net8.0-windows\ROS64Hack.exe"
set "APP_EXIT_CODE=%ERRORLEVEL%"

echo.
echo Application exited with code %APP_EXIT_CODE%.
echo Send STAGE102_VEHICLE_TRANSITION_RECON.txt for analysis.
pause
exit /b %APP_EXIT_CODE%

:NoDotnet
echo ERROR: .NET SDK was not found. Install the .NET 8 SDK, then run this file again.
pause
exit /b 9009

:BuildFailed
echo ERROR: Build failed. Copy the complete build output before closing this window.
pause
exit /b 1

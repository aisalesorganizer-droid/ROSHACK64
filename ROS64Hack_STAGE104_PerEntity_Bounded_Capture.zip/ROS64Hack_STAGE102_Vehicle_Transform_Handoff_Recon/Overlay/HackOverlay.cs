using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using ROS64Hack.Core;
using ROS64Hack.Engine;
using ROS64Hack.Features;

namespace ROS64Hack.Overlay
{
    /// <summary>
    /// Full-screen transparent overlay window.
    ///
    /// THREADING MODEL:
    ///   ReadLoop      -> camera + entity snapshot requested every 8 ms (~125 Hz)
    ///   SkeletonLoop  -> remote-memory skeleton discovery/pose sampling independently
    ///   DrawLoop      -> aimbot/noclip + repaint request every 8 ms (~125 Hz requested)
    ///   OnPaint       -> consumes only the immutable published snapshot; zero RPM
    /// Actual presentation cadence is controlled by WinForms/DWM and the display/game cadence.
    ///
    /// The critical Stage 33 bottleneck was skeleton RPM work blocking ReadLoop for
    /// roughly 140-350 ms. That work is now isolated to SkeletonLoop, so entity/camera
    /// snapshots are no longer delayed by cold skeleton resolution or page reads.
    /// </summary>
    public class HackOverlay : Form
    {
        [DllImport("user32.dll")]
        private static extern IntPtr FindWindow(string cls, string title);

        [DllImport("user32.dll")]
        private static extern bool GetClientRect(IntPtr hWnd, out RECT rc);

        [DllImport("user32.dll")]
        private static extern bool ClientToScreen(IntPtr hWnd, ref POINT pt);

        [DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
        [DllImport("user32.dll")]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll")]
        private static extern bool SetLayeredWindowAttributes(
            IntPtr hwnd, uint crKey, byte bAlpha, uint dwFlags);

        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(int vKey);

        private const int GWL_EXSTYLE = -20;
        private const int VK_RBUTTON = 0x02;
        private const int WS_EX_LAYERED = 0x00080000;
        private const int WS_EX_TRANSPARENT = 0x00000020;
        private const int WS_EX_TOPMOST = 0x00000008;
        private const uint LWA_COLORKEY = 0x00000001;

        // Poll current entity/camera state faster than a 60 Hz timer so 90/120/144 Hz
        // displays can receive fresher snapshots. WinForms/DWM still determine actual
        // presentation cadence; this is a lower sampling interval, not a frame-lock.
        private const int READ_PERIOD_MS = 8;
        private const int DRAW_PERIOD_MS = 8;
        private const int SKELETON_PERIOD_MS = 33;
        private const int WINDOW_RESNAP_READS = 120;

        // A failed entity/camera read must not erase a coherent frame immediately,
        // but no consumer may continue drawing it indefinitely. Once this age is
        // exceeded, all consumers fall back to the empty snapshot until a fresh read
        // succeeds. This bounds visual staleness without blocking the UI thread.
        private const double SNAPSHOT_MAX_AGE_MS = 75.0;

        [StructLayout(LayoutKind.Sequential)]
        private struct RECT { public int Left, Top, Right, Bottom; }
        [StructLayout(LayoutKind.Sequential)]
        private struct POINT { public int X, Y; }

        private sealed class OverlaySnapshot
        {
            public static readonly OverlaySnapshot Empty =
                new OverlaySnapshot(new List<EntityData>(0), default, null,
                    Offsets.DEFAULT_SCREEN_W, Offsets.DEFAULT_SCREEN_H, 0, 0);

            public readonly List<EntityData> Entities;
            public readonly CameraData Camera;
            public readonly EntityData LocalPlayer;
            public readonly float ScreenW;
            public readonly float ScreenH;
            public readonly int ScreenOriginX;
            public readonly int ScreenOriginY;
            public readonly long PublishedTicks;

            public OverlaySnapshot(
                List<EntityData> entities,
                in CameraData camera,
                EntityData localPlayer,
                float screenW,
                float screenH,
                int screenOriginX,
                int screenOriginY,
                long publishedTicks = 0)
            {
                Entities = entities;
                Camera = camera;
                LocalPlayer = localPlayer;
                ScreenW = screenW;
                ScreenH = screenH;
                ScreenOriginX = screenOriginX;
                ScreenOriginY = screenOriginY;
                PublishedTicks = publishedTicks;
            }
        }

        private readonly Mem _mem;
        private readonly Camera _camera;
        private readonly PlayerReader _player;
        private readonly EntityLoop _entities;
        private readonly Stage78BoundedNodeHierarchyRecon _stage78BoundedNodeHierarchyRecon;
        private readonly DynamicSkeletonReader _dynamicSkeleton;
        private readonly Stage102VehicleTransitionRecon _stage102VehicleRecon;
        private readonly bool _stage78ReconEnabled;
        private readonly bool _stage102VehicleReconEnabled;

        private MenuForm _menu;
        private OverlaySnapshot _snapshot = OverlaySnapshot.Empty;

        private float _screenW = Offsets.DEFAULT_SCREEN_W;
        private float _screenH = Offsets.DEFAULT_SCREEN_H;

        private System.Threading.Timer _drawTimer;
        private System.Threading.Timer _readTimer;
        private System.Threading.Timer _skeletonTimer;

        private bool _menuVisible;
        private bool _insertWas;
        private bool _deleteWas;
        private bool _running = true;

        private int _readBusy;
        private int _drawBusy;
        private int _skeletonBusy;
        private int _paintPending;
        private int _snapFrameCounter;

        private long _scopeProbePtr;
        private float _scopeProbeLastSX;
        private float _scopeProbeLastSY;
        private float _scopeProbeLastX;
        private float _scopeProbeLastY;
        private float _scopeProbeLastZ;
        private bool _scopeProbeHasLast;
        private long _scopeProbeLastTicks;
        private int _scopeProbeCount;

        private static readonly string[] GAME_WINDOW_TITLES =
            { "ROS Legacy", "Rules of Survival", "ROS", "ros64" };

        public HackOverlay(Mem mem)
        {
            _mem = mem ?? throw new ArgumentNullException(nameof(mem));
            _camera = new Camera(mem);
            _player = new PlayerReader(mem);
            _entities = new EntityLoop(mem, _player);
            _stage78BoundedNodeHierarchyRecon = new Stage78BoundedNodeHierarchyRecon(mem);
            _dynamicSkeleton = new DynamicSkeletonReader(mem);
            _stage102VehicleRecon = new Stage102VehicleTransitionRecon(mem);
            _stage102VehicleReconEnabled = string.Equals(
                Environment.GetEnvironmentVariable("ROS64HACK_VEHICLE_RECON"),
                "1",
                StringComparison.Ordinal);
            _stage78ReconEnabled = string.Equals(
                Environment.GetEnvironmentVariable("ROS64HACK_STAGE78_RECON"),
                "1",
                StringComparison.Ordinal);

            ConfigureForm();
        }

        private void ConfigureForm()
        {
            Text = "";
            FormBorderStyle = FormBorderStyle.None;
            BackColor = Color.Black;
            TransparencyKey = Color.Black;
            TopMost = true;
            ShowInTaskbar = false;
            DoubleBuffered = true;
            Bounds = Screen.PrimaryScreen.Bounds;
        }

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ExStyle |= WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOPMOST;
                return cp;
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            SetWindowLong(Handle, GWL_EXSTYLE,
                GetWindowLong(Handle, GWL_EXSTYLE)
                | WS_EX_LAYERED | WS_EX_TRANSPARENT);
            SetLayeredWindowAttributes(Handle, 0x000000, 0, LWA_COLORKEY);

            _camera.Acquire();
            _entities.Calibrate();
            SnapToGameWindow();

            Console.WriteLine("[STAGE101][OVERLAY-MARKER] source=SYNTHETIC_CONTRACT_NATIVE_EDGE_RENDER+FINITE_PROJECTION+OFFSCREEN_VERTEX_CLIP+8_UNIT_NATIVE_EDGE_GUARD+1_5_UNIT_ROOT_FLOOR_GUARD+2PX_NATIVE_HEAD_MARKER+SCALED_HEAD_CANDIDATE_CORRIDOR+ENTITY_ID_DEDUP+POSE_ENTITY_ID_GUARD+NATIVE_PARENT_CHILD_HIERARCHY+PELVIC_SKIRT_EXCLUSION+DYNAMIC_NECK_WITH_LEGACY_FALLBACK");
            Console.WriteLine($"[STAGE101][CADENCE] entityCameraRead={READ_PERIOD_MS}ms paintRequest={DRAW_PERIOD_MS}ms skeletonSample={SKELETON_PERIOD_MS}ms; presentation remains OS/display scheduled.");
            Console.WriteLine("[STAGE101][DIAGNOSTICS] per-entity coverage: ROS64HACK_SKELETON_COVERAGE=1; focused bone labels: ROS64HACK_SKELETON_BONE_INDEX_DIAGNOSTICS=1; viewport-gated edge map: ROS64HACK_SKELETON_EDGE_TRACE=1; expensive discovery trace: ROS64HACK_SKELETON_DISCOVERY_TRACE=1.");
            Console.WriteLine($"[STAGE101][STAGE78-RECON] enabled={(_stage78ReconEnabled ? 1 : 0)} env=ROS64HACK_STAGE78_RECON (set to 1 to run the expensive legacy recon)");
            Console.WriteLine($"[STAGE102][VEHICLE-RECON] enabled={(_stage102VehicleReconEnabled ? 1 : 0)} env=ROS64HACK_VEHICLE_RECON (set to 1 for bounded 60-second transform-handoff capture)");

            if (_stage78ReconEnabled)
                _stage78BoundedNodeHierarchyRecon.Start();
            if (_stage102VehicleReconEnabled)
                _stage102VehicleRecon.Start();

            _readTimer = new System.Threading.Timer(ReadLoop, null, 0, READ_PERIOD_MS);
            _drawTimer = new System.Threading.Timer(DrawLoop, null, 0, DRAW_PERIOD_MS);
            _skeletonTimer = new System.Threading.Timer(SkeletonLoop, null, 250, SKELETON_PERIOD_MS);
        }

        private void ReadLoop(object _)
        {
            if (!_running)
                return;

            if (Interlocked.Exchange(ref _readBusy, 1) != 0)
            {
                RuntimeDiagnostics.ReadLoopSkipped();
                return;
            }

            long started = System.Diagnostics.Stopwatch.GetTimestamp();
            try
            {
                long emPtr = _mem.Read<long>(_mem.BaseAddress + Offsets.EM_STATIC_PTR, "OVERLAY.EM");
                if (emPtr == 0)
                {
                    RetainCoherentSnapshotOnReadFailure();
                    return;
                }

                EntityData local = _player.ReadPlayer(emPtr);
                float px = local?.X ?? 0f;
                float py = local?.Y ?? 0f;
                float pz = local?.Z ?? 0f;

                bool adsDown = (GetAsyncKeyState(VK_RBUTTON) & 0x8000) != 0;

                if (!_camera.Update(px, py, pz, adsDown))
                {
                    RetainCoherentSnapshotOnReadFailure();
                    return;
                }

                CameraData cam = _camera.Data;
                long knownPlayerPtr = local?.Ptr ?? 0;
                List<EntityData> list = _entities.Enumerate(
                    emPtr, knownPlayerPtr, local?.EntityId ?? 0u);

                float screenW = Volatile.Read(ref _screenW);
                float screenH = Volatile.Read(ref _screenH);

                ESP.UpdateProjection(list, cam, screenW, screenH);

                // Skeleton RPM work is intentionally absent from this loop. The latest
                // verified world-space pose is projected here against this exact camera
                // snapshot, which keeps the box/camera path independent of skeleton RPM.
                _dynamicSkeleton.ApplyLatest(list, cam, screenW, screenH);

                // Stage 104 samples this read snapshot after the current skeleton metadata is applied.
                if (_stage102VehicleReconEnabled)
                    _stage102VehicleRecon.ObserveSnapshot(list);

                if (_stage78ReconEnabled)
                    _stage78BoundedNodeHierarchyRecon.ObserveSnapshot(list);

                ScopeProjectionProbe(list, cam, adsDown, screenW, screenH);

                Interlocked.Exchange(
                    ref _snapshot,
                    new OverlaySnapshot(list, cam, local, screenW, screenH,
                        Location.X, Location.Y, System.Diagnostics.Stopwatch.GetTimestamp()));

                _snapFrameCounter++;
                if (_snapFrameCounter >= WINDOW_RESNAP_READS)
                {
                    _snapFrameCounter = 0;
                    SnapToGameWindow();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(
                    $"  [DIAG][READ-LOOP-EXCEPTION] {ex.GetType().Name}: {ex.Message}");
                RetainCoherentSnapshotOnReadFailure();
            }
            finally
            {
                RuntimeDiagnostics.ReadLoopCompleted(
                    (System.Diagnostics.Stopwatch.GetTimestamp() - started) * 1000.0 /
                    System.Diagnostics.Stopwatch.Frequency);
                Volatile.Write(ref _readBusy, 0);
            }
        }

        private void SkeletonLoop(object _)
        {
            if (!_running)
                return;

            if (Interlocked.Exchange(ref _skeletonBusy, 1) != 0)
            {
                RuntimeDiagnostics.SkeletonLoopSkipped();
                return;
            }

            long started = System.Diagnostics.Stopwatch.GetTimestamp();
            try
            {
                OverlaySnapshot snapshot = ReadFreshSnapshot();
                if (snapshot.Entities.Count == 0 || !snapshot.Camera.IsValid)
                    return;

                var targets = new List<EntityData>(snapshot.Entities.Count);
                foreach (EntityData source in snapshot.Entities)
                {
                    if (source?.IsEnemy != true)
                        continue;

                    targets.Add(new EntityData
                    {
                        Ptr = source.Ptr,
                        ObType = source.ObType,
                        IsEnemy = true,
                        IsLocalPlayer = false,
                        EntityId = source.EntityId,
                        X = source.X,
                        Y = source.Y,
                        Z = source.Z,
                        Distance = source.Distance,
                        OnScreen = source.OnScreen,
                    });
                }

                _dynamicSkeleton.Update(targets);
            }
            catch (Exception ex)
            {
                Console.WriteLine(
                    $"  [DIAG][SKELETON-LOOP-EXCEPTION] {ex.GetType().Name}: {ex.Message}");
            }
            finally
            {
                RuntimeDiagnostics.SkeletonLoopCompleted(
                    (System.Diagnostics.Stopwatch.GetTimestamp() - started) * 1000.0 /
                    System.Diagnostics.Stopwatch.Frequency);
                Volatile.Write(ref _skeletonBusy, 0);
            }
        }

        private void RetainCoherentSnapshotOnReadFailure()
        {
            // Keep the last coherent snapshot for brief torn/unreadable RPM reads.
            // ReadFreshSnapshot enforces a strict age limit for sampling, logic, and
            // drawing; after the limit, consumers use Empty instead of stale data.
        }

        private OverlaySnapshot ReadFreshSnapshot()
        {
            OverlaySnapshot snapshot = Volatile.Read(ref _snapshot);
            if (snapshot == null || snapshot.PublishedTicks == 0)
                return OverlaySnapshot.Empty;

            double ageMs = (System.Diagnostics.Stopwatch.GetTimestamp() - snapshot.PublishedTicks)
                * 1000.0 / System.Diagnostics.Stopwatch.Frequency;
            return double.IsFinite(ageMs) && ageMs >= 0.0 && ageMs <= SNAPSHOT_MAX_AGE_MS
                ? snapshot
                : OverlaySnapshot.Empty;
        }

        private void ScopeProjectionProbe(
            List<EntityData> entities,
            in CameraData cam,
            bool adsDown,
            float screenW,
            float screenH)
        {
            if (!adsDown || !cam.IsValid)
                return;

            long now = System.Diagnostics.Stopwatch.GetTimestamp();
            if (_scopeProbeLastTicks != 0 &&
                (now - _scopeProbeLastTicks) * 1000.0 /
                System.Diagnostics.Stopwatch.Frequency < 500.0)
                return;

            _scopeProbeLastTicks = now;
            _scopeProbeCount++;

            EntityData target = null;
            float best = float.MaxValue;
            float cx = screenW * 0.5f;
            float cy = screenH * 0.5f;

            if (_scopeProbePtr != 0)
            {
                foreach (EntityData e in entities)
                {
                    if (e?.IsEnemy != true || e.Ptr != _scopeProbePtr)
                        continue;

                    if (e.FootProjected)
                        target = e;
                    break;
                }
            }

            if (target == null)
            {
                foreach (EntityData e in entities)
                {
                    if (e?.IsEnemy != true || !e.FootProjected)
                        continue;

                    float dx = e.FootSX - cx;
                    float dy = e.FootSY - cy;
                    float d2 = dx * dx + dy * dy;
                    if (d2 < best)
                    {
                        best = d2;
                        target = e;
                    }
                }

                if (target != null)
                    _scopeProbeHasLast = false;
            }

            float aspect = screenH > 1f ? screenW / screenH : 1f;
            float ar = (cam.XFocal > 0.3f && cam.XFocal < 10f)
                ? cam.YFocal / cam.XFocal
                : cam.YFocal / aspect;

            if (target == null)
            {
                Console.WriteLine(
                    $"  [W2S][ADS-PROBE] n={_scopeProbeCount} target=NONE " +
                    $"YF={cam.YFocal:F5} XF={cam.XFocal:F5} ar={ar:F5}");
                _scopeProbePtr = 0;
                _scopeProbeHasLast = false;
                return;
            }

            float sx0 = target.FootSX;
            float sy0 = target.FootSY;

            const float HeadHeight = 21.5f;
            bool headOk = WorldToScreen.Project(
                target.X, target.Y + HeadHeight, target.Z,
                cam, screenW, screenH,
                out float hsx, out float hsy, target.Ptr);

            float dxw = 0f;
            float dyw = 0f;
            float dzw = 0f;
            float dsx = 0f;
            float dsy = 0f;
            if (_scopeProbeHasLast && _scopeProbePtr == target.Ptr)
            {
                dxw = target.X - _scopeProbeLastX;
                dyw = target.Y - _scopeProbeLastY;
                dzw = target.Z - _scopeProbeLastZ;
                dsx = sx0 - _scopeProbeLastSX;
                dsy = sy0 - _scopeProbeLastSY;
            }

            float vx = (target.X - cam.PosX) * cam.RightX +
                       (target.Y - cam.PosY) * cam.RightY +
                       (target.Z - cam.PosZ) * cam.RightZ;
            float vy = (target.X - cam.PosX) * cam.UpX +
                       (target.Y - cam.PosY) * cam.UpY +
                       (target.Z - cam.PosZ) * cam.UpZ;
            float vz = (target.X - cam.PosX) * cam.FwdX +
                       (target.Y - cam.PosY) * cam.FwdY +
                       (target.Z - cam.PosZ) * cam.FwdZ;

            Console.WriteLine(
                $"  [W2S][ADS-PROBE] n={_scopeProbeCount} ptr=0x{target.Ptr:X} " +
                $"world=({target.X:F2},{target.Y:F2},{target.Z:F2}) " +
                $"view=({vx:F2},{vy:F2},{vz:F2}) " +
                $"foot=({sx0:F2},{sy0:F2}) headOk={(headOk ? 1 : 0)} " +
                $"head=({hsx:F2},{hsy:F2}) YF={cam.YFocal:F5} XF={cam.XFocal:F5} " +
                $"ar={ar:F5} dWorld=({dxw:F2},{dyw:F2},{dzw:F2}) " +
                $"dScreen=({dsx:F2},{dsy:F2})");

            _scopeProbePtr = target.Ptr;
            _scopeProbeLastX = target.X;
            _scopeProbeLastY = target.Y;
            _scopeProbeLastZ = target.Z;
            _scopeProbeLastSX = sx0;
            _scopeProbeLastSY = sy0;
            _scopeProbeHasLast = true;
        }

        private void DrawLoop(object _)
        {
            if (!_running)
                return;

            if (Interlocked.Exchange(ref _drawBusy, 1) != 0)
            {
                RuntimeDiagnostics.DrawLoopSkipped();
                return;
            }

            long started = System.Diagnostics.Stopwatch.GetTimestamp();
            try
            {
                bool insertNow = (GetAsyncKeyState((int)Keys.Insert) & 0x8000) != 0;
                if (insertNow && !_insertWas && !IsDisposed)
                    BeginInvoke((Action)ToggleMenu);
                _insertWas = insertNow;

                bool deleteNow = (GetAsyncKeyState((int)Keys.Delete) & 0x8000) != 0;
                if (deleteNow && !_deleteWas)
                {
                    _running = false;
                    if (!IsDisposed)
                        BeginInvoke((Action)ExitHack);
                }
                _deleteWas = deleteNow;

                OverlaySnapshot snapshot = ReadFreshSnapshot();
                Aimbot.Tick(
                    snapshot.Entities,
                    snapshot.Camera,
                    snapshot.ScreenW,
                    snapshot.ScreenH,
                    snapshot.ScreenOriginX,
                    snapshot.ScreenOriginY);

                if (snapshot.LocalPlayer != null)
                    NoClip.Tick(_mem, snapshot.LocalPlayer, snapshot.Camera);

                RuntimeDiagnostics.Frame(snapshot.Camera, snapshot.Entities);

                if (!IsDisposed && Interlocked.Exchange(ref _paintPending, 1) == 0)
                    BeginInvoke((Action)Invalidate);
            }
            finally
            {
                RuntimeDiagnostics.DrawLoopCompleted(
                    (System.Diagnostics.Stopwatch.GetTimestamp() - started) * 1000.0 /
                    System.Diagnostics.Stopwatch.Frequency);
                Volatile.Write(ref _drawBusy, 0);
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Volatile.Write(ref _paintPending, 0);

            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.InterpolationMode = InterpolationMode.NearestNeighbor;
            g.Clear(Color.Black);

            OverlaySnapshot snapshot = ReadFreshSnapshot();
            ESP.Draw(
                g,
                snapshot.Entities,
                snapshot.Camera,
                snapshot.ScreenW,
                snapshot.ScreenH);
        }

        private void SnapToGameWindow()
        {
            IntPtr hwnd = IntPtr.Zero;
            foreach (string title in GAME_WINDOW_TITLES)
            {
                hwnd = FindWindow(null, title);
                if (hwnd != IntPtr.Zero)
                    break;
            }

            if (hwnd == IntPtr.Zero || !GetClientRect(hwnd, out RECT rc))
                return;

            var origin = new POINT();
            ClientToScreen(hwnd, ref origin);

            int w = rc.Right - rc.Left;
            int h = rc.Bottom - rc.Top;
            if (w < 100 || h < 100)
                return;

            Volatile.Write(ref _screenW, w);
            Volatile.Write(ref _screenH, h);

            if (!IsDisposed)
            {
                BeginInvoke((Action)(() =>
                {
                    if (!IsDisposed)
                        SetBounds(origin.X, origin.Y, w, h);
                }));
            }
        }

        private void ToggleMenu()
        {
            if (!_menuVisible || _menu == null || _menu.IsDisposed)
            {
                _menu = new MenuForm();
                _menu.Show();
                _menuVisible = true;
            }
            else
            {
                _menu.Hide();
                _menuVisible = false;
            }
        }

        private void ExitHack()
        {
            _running = false;
            _drawTimer?.Dispose();
            _readTimer?.Dispose();
            _skeletonTimer?.Dispose();
            _stage78BoundedNodeHierarchyRecon?.Dispose();
            _stage102VehicleRecon?.Dispose();
            _dynamicSkeleton?.Dispose();
            _mem?.Dispose();

            if (!IsDisposed)
                BeginInvoke((Action)Application.Exit);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _running = false;
            _drawTimer?.Dispose();
            _readTimer?.Dispose();
            _skeletonTimer?.Dispose();
            _stage78BoundedNodeHierarchyRecon?.Dispose();
            _stage102VehicleRecon?.Dispose();
            _dynamicSkeleton?.Dispose();
            base.OnFormClosing(e);
        }
    }
}

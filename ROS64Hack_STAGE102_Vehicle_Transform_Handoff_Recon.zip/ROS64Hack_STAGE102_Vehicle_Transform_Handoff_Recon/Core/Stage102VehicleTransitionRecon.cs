using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using ROS64Hack.Engine;

namespace ROS64Hack.Core
{
    /// <summary>
    /// Stage 102 preserves bounded target/root recon while adding a read-only time series
    /// for possible stale-position and transform-handoff behavior. Raw large BGA jumps
    /// remain visible even when excluded from the plausible-motion association heuristic.
    /// Transform probes are measurements only; no probe is assumed to be a vehicle or bone.
    ///
    /// No process-wide scan, memory writes, renderer changes, or DynamicSkeletonReader
    /// changes are performed.
    /// </summary>
    public sealed class Stage102VehicleTransitionRecon : IDisposable
    {
        private const int BGA_ID = 0x018;
        private const long MODEL_SKELETAL_VTABLE_RVA = 0x001C1ACE0;
        private const long SPACE_NODE_VTABLE_RVA = 0x001C137C8;
        private const int MODEL_SPACE_NODE = 0x038;
        private const int SPACE_MODEL = 0x040;
        private const int SPACE_WORLD_MATRIX = 0x148;
        private const int SPACE_WORLD_TRANSLATION = 0x178;
        private const int MATRIX_BYTES = 0x40;

        private const int SAMPLE_COUNT = 240;
        private const int SAMPLE_INTERVAL_MS = 250;
        private const int INITIAL_DELAY_MS = 500;
        private const int PRE_SAMPLE_DELAY_MS = 1000;
        private const int TARGET_SELECTION_SAMPLE_INTERVAL_MS = 250;
        private const int TARGET_SELECTION_WINDOW_MS = 4000;
        private const int TARGET_SELECTION_TIMEOUT_MS = 15000;
        private const int TARGET_SELECTION_STALE_MS = 1000;
        private const int MIN_TARGET_SELECTION_SAMPLES = 8;
        private const int MIN_TARGET_SELECTION_MOVING_TRANSITIONS = 3;
        private const float MAX_TARGET_SELECTION_STEP = 256f;
        private const float MAX_ASSOCIATION_TARGET_STEP = 256f;
        private const int BGA_READ_BYTES = 0x1000;
        private const int OBJECT_READ_BYTES = 0x1000;
        private const int ROOT_CENSUS_BYTES = 0x2000;
        private const int MAX_FOCUSED_ROOT_CANDIDATES = 4;
        private const int MAX_FOCUSED_NODES_PER_ROOT = 64;
        private const int MAX_FOCUSED_EDGES_PER_ROOT = 256;
        private const int MAX_FOCUSED_DEPTH = 3;
        private const int MAX_DISCOVERY_ATTEMPTS = 8;
        private const int MAX_FIRST_HOP_OBJECTS = 48;
        private const int MAX_NESTED_OBJECTS_PER_ATTEMPT = 192;
        private const int MAX_NESTED_DEPTH = 3;
        private const int MAX_TRANSFORM_PROBES = 192;
        private const int MAX_GENERIC_TRANSFORM_PROBES = 64;
        private const float BGA_STATIONARY_THRESHOLD = 0.10f;
        private const float PROBE_MOVEMENT_THRESHOLD = 0.50f;
        private const int MIN_STATIONARY_SAMPLES_FOR_HANDOFF = 4;
        private const long SNAPSHOT_STALE_MS = 1000;
        private const float SNAPSHOT_DIVERGENCE_THRESHOLD = 1.0f;
        private const int MAX_QUEUED_POINTERS = 4096;
        private const long IMAGE_SIZE = 0x05AEA000;
        private const int MAX_MODEL_CANDIDATES = 64;
        private const int MAX_SCENE_ANCHORS = 12;
        private const int MAX_SCENE_NODES = 64;
        private const int MAX_SCENE_EDGES = 512;
        private const int MAX_HIERARCHY_DEPTH = 6;
        private const int MAX_CHILD_POINTER_CHECKS = OBJECT_READ_BYTES / 8;
        private const float MAX_WORLD_COORD = 50000f;
        private const float ROOT_STEP_THRESHOLD = 0.05f;
        private const float TARGET_MOVEMENT_THRESHOLD = 0.5f;
        private const float MAX_NEAR_TARGET_DISTANCE = 128f;
        private const float MAX_NEAR_TARGET_DIAGNOSTIC_DISTANCE = 256f;
        private const int MIN_ASSOCIATION_MOVING_OBSERVATIONS = 20;
        private const float MIN_ASSOCIATION_RATIO = 0.80f;
        private const float MAX_ASSOCIATION_MEAN_DISTANCE = 64f;

        private readonly Mem _mem;
        private readonly object _sync = new();
        private readonly byte[] _bgaScratch = new byte[BGA_READ_BYTES];
        private readonly byte[] _objectScratch = new byte[OBJECT_READ_BYTES];
        private readonly byte[] _rootCensusScratch = new byte[ROOT_CENSUS_BYTES];
        private readonly byte[] _ptrScratch = new byte[8];
        private readonly byte[] _transformScratch = new byte[MATRIX_BYTES];
        private readonly byte[] _translationScratch = new byte[12];
        private readonly Dictionary<long, CandidateRecord> _candidates = new();
        private readonly Dictionary<(long Ptr, uint EntityId), TargetMotionRecord> _targetMotionRecords = new();
        private readonly Dictionary<long, SceneNodeRecord> _sceneNodes = new();
        private readonly Dictionary<long, TransformProbeRecord> _transformProbes = new();
        private readonly List<CandidateRecord> _focusedRootCandidates = new();
        private readonly HashSet<long> _sceneScanned = new();
        private readonly HashSet<(long Parent, long Child, int Offset)> _sceneEdgeKeys = new();
        private readonly Queue<PointerWorkItem> _nestedQueue = new();
        private readonly HashSet<long> _nestedQueued = new();
        private readonly HashSet<long> _nestedScanned = new();

        private StreamWriter _writer;
        private System.Threading.Timer _timer;
        private int _started;
        private int _disposed;
        private int _timerBusy;
        private int _sample;
        private bool _targetLocked;
        private bool _discoveryComplete;
        private bool _captureComplete;
        private bool _samplingDelayScheduled;
        private bool _waitForTargetLogged;
        private long _targetSelectionStartedMs;
        private long _lastTargetSelectionSampleMs;
        private long _lastTargetSelectionWaitLogMs;
        private string _targetSelectionMethod = "NOT_SELECTED";
        private int _targetSelectionSamples;
        private int _targetSelectionTransitions;
        private int _targetSelectionOutliers;
        private double _targetSelectionPlausibleStep;
        private int _targetOutlierTransitions;

        // Latest independently published entity snapshot for the locked BGA. This is
        // compared with the raw BGA fields at every timed diagnostic sample.
        private bool _latestSnapshotPresent;
        private long _latestSnapshotPtr;
        private uint _latestSnapshotId;
        private float _latestSnapshotX, _latestSnapshotY, _latestSnapshotZ;
        private long _latestSnapshotTicks;
        private int _snapshotSeenSamples;
        private int _snapshotMissingSamples;
        private int _snapshotDivergenceSamples;
        private long _associationStartMs;
        private int _targetStationaryRun;
        private int _targetStationarySamples;
        private int _targetStationaryEpisodes;
        private int _largeRawJumpTransitions;
        private float _largestRawJump;
        private int _genericTransformProbeCount;

        private long _targetPtr;
        private uint _targetId;
        private int _discoveryAttempts;
        private int _discoveryObjectsInspected;
        private int _firstHopObjectsOnLastAttempt;
        private int _nextPointerSweepOffset;
        private int _directModelCandidates;
        private int _nestedObjectsOnLastAttempt;
        private int _nestedObjectsTotalRead;
        private int _nestedReadFailures;
        private int _scenePointerReferences;
        private int _sceneAnchorsScanned;
        private int _targetLostSamples;
        private int _targetIdMismatchSamples;
        private int _targetMotionTransitions;
        private float _targetTotalStep;
        private float _previousTargetX;
        private float _previousTargetY;
        private float _previousTargetZ;
        private bool _hasPreviousTarget;

        private sealed class SceneNodeRecord
        {
            public long Ptr;
            public long Owner;
            public int Depth;
            public string FirstPath;
        }

        private sealed class TransformProbeRecord
        {
            public long Ptr;
            public long Vtable;
            public string Path;
            public int Priority;
            public int ValidSamples;
            public int InvalidSamples;
            public int MovingTransitions;
            public int MovesWhileBgaStationary;
            public int SamplesWhileBgaStationary;
            public float TotalStep;
            public float MaxStep;
            public float MinTargetDistance = float.MaxValue;
            public float MaxTargetDistance;
            public double TargetDistanceSum;
            public float LastStep;
            public float LastDistance = float.NaN;
            public string LastSource = "NONE";
            public bool HasPrevious;
            public float PreviousX, PreviousY, PreviousZ;
        }

        private sealed class TargetMotionRecord
        {
            public long Ptr;
            public uint EntityId;
            public int Samples;
            public int MovingTransitions;
            public int OutlierSteps;
            public double PlausibleTotalStep;
            public long LastSeenMs;
            public bool HasPrevious;
            public float PreviousX, PreviousY, PreviousZ;
        }

        private sealed class PointerWorkItem
        {
            public long Ptr;
            public int Depth;
            public string Path;
        }

        private sealed class CandidateRecord
        {
            public long ModelPtr;
            public long RootPtr;
            public string Path;
            public bool FromBgaClosure;
            public long SourceNodePtr;
            public float DiscoveryDistance = float.NaN;

            public int StructurallyValidSamples;
            public int StructurallyInvalidSamples;
            public int ValidTransformSamples;
            public int Near128Samples;
            public int Near256Samples;
            public int TargetMovingObservations;
            public int RelativeStableWhileTargetMoves;
            public int CoMotionSamples;

            public float MinDistance = float.MaxValue;
            public float MaxDistance;
            public double DistanceSum;
            public float TotalRootStep;
            public float TotalRelativeStep;
            public float MaxRelativeStep;
            public float LastDistance = float.NaN;

            public bool HasPrevious;
            public float PreviousX;
            public float PreviousY;
            public float PreviousZ;
            public float PreviousRx;
            public float PreviousRy;
            public float PreviousRz;
            public readonly Dictionary<long, FocusedNodeRecord> FocusedNodes = new();
            public readonly List<FocusedEdgeRecord> FocusedEdges = new();
            public readonly HashSet<(long Source, long Target, int Offset)> FocusedEdgeKeys = new();
        }

        private sealed class FocusedNodeRecord
        {
            public long NodePtr;
            public long OwnerPtr;
            public int Depth;
            public string FirstPath;
            public int StructuralValidSamples;
            public int StructuralInvalidSamples;
            public int OwnerMatchesCandidateSamples;
            public int OwnerIsModelSamples;
            public int ValidTransformSamples;
            public int TargetMovingObservations;
            public int StableRelativeToTargetWhileMoving;
            public int CoMotionSamples;
            public float MinTargetDistance = float.MaxValue;
            public float MaxTargetDistance;
            public double TargetDistanceSum;
            public float TotalNodeStep;
            public float TotalTargetRelativeStep;
            public float TotalRootRelativeStep;
            public float MaxTargetRelativeStep;
            public float MaxRootRelativeStep;
            public bool HasPrevious;
            public float PreviousX, PreviousY, PreviousZ;
            public float PreviousTargetRx, PreviousTargetRy, PreviousTargetRz;
            public float PreviousRootRx, PreviousRootRy, PreviousRootRz;
        }

        private sealed class FocusedEdgeRecord
        {
            public long SourcePtr;
            public long TargetPtr;
            public int Offset;
            public int Depth;
            public string Role;
            public string Path;
        }

        public Stage102VehicleTransitionRecon(Mem mem)
        {
            _mem = mem ?? throw new ArgumentNullException(nameof(mem));
        }

        public void Start()
        {
            if (Interlocked.Exchange(ref _started, 1) != 0)
                return;

            try
            {
                string path = Path.Combine(Environment.CurrentDirectory, "STAGE102_VEHICLE_TRANSITION_RECON.txt");
                _writer = new StreamWriter(
                    new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.ReadWrite))
                {
                    AutoFlush = false,
                };

                Write("============================================================");
                Write("STAGE 102 — VEHICLE-TRANSITION AND TRANSFORM-HANDOFF RECON");
                Write("============================================================");
                Write($"[STAGE102][CONFIG] samples={SAMPLE_COUNT} intervalMs={SAMPLE_INTERVAL_MS} sampleSeconds={SAMPLE_COUNT * SAMPLE_INTERVAL_MS / 1000.0:F1} preSampleDelayMs={PRE_SAMPLE_DELAY_MS}");
                Write($"[STAGE102][CONFIG] ModelSkeletalVtable=0x{_mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA:X} SpaceNodeVtable=0x{_mem.BaseAddress + SPACE_NODE_VTABLE_RVA:X}");
                Write("[STAGE102][POLICY] processWideScan=0 memoryWrites=0 rendererChanges=0 DynamicSkeletonReaderChanges=0 anatomicalWinner=0");
                Write($"[STAGE102][BUDGET] discoveryAttempts={MAX_DISCOVERY_ATTEMPTS} firstHopObjectsPerAttempt={MAX_FIRST_HOP_OBJECTS} nestedObjectsPerAttempt={MAX_NESTED_OBJECTS_PER_ATTEMPT} nestedDepth={MAX_NESTED_DEPTH} maxQueuedPointers={MAX_QUEUED_POINTERS} modelCandidates={MAX_MODEL_CANDIDATES} sceneAnchors={MAX_SCENE_ANCHORS} sceneNodes={MAX_SCENE_NODES} sceneEdges={MAX_SCENE_EDGES} sceneDepth={MAX_HIERARCHY_DEPTH} focusedRoots={MAX_FOCUSED_ROOT_CANDIDATES} rootCensusBytes=0x{ROOT_CENSUS_BYTES:X} focusedNodesPerRoot={MAX_FOCUSED_NODES_PER_ROOT} focusedEdgesPerRoot={MAX_FOCUSED_EDGES_PER_ROOT} focusedDepth={MAX_FOCUSED_DEPTH}");
                Write("[STAGE102][DISCOVERY-ORDER] priorityBgaOffsets=+0x0A8,+0x0B8,+0x128,+0x130,+0x048,+0x648; useful target routes first, high-fanout +0x648 last; aligned BGA pointer sweep; bounded nested closure; no fixed runtime object addresses");
                Write("[STAGE102][PURPOSE] retain Stage 66 root association and capture raw BGA, entity-snapshot, and discovered transform time series to test stale-position / transform-handoff hypotheses");
                Write($"[STAGE102][HANDOFF-CONFIG] samples={SAMPLE_COUNT} durationSeconds={SAMPLE_COUNT * SAMPLE_INTERVAL_MS / 1000.0:F1} stationaryThreshold={BGA_STATIONARY_THRESHOLD:F2} minimumStationarySamples={MIN_STATIONARY_SAMPLES_FOR_HANDOFF} probeMoveThreshold={PROBE_MOVEMENT_THRESHOLD:F2} snapshotStaleMs={SNAPSHOT_STALE_MS} snapshotDivergenceThreshold={SNAPSHOT_DIVERGENCE_THRESHOLD:F2} maxTransformProbes={MAX_TRANSFORM_PROBES} maxGenericProbes={MAX_GENERIC_TRANSFORM_PROBES}");
                Write($"[STAGE102][FILE] {Path.GetFullPath(path)}");
                Write("[STAGE102][CAPTURE-STARTED] observing valid enemies before locking the most consistently moving target; any large raw BGA jump is logged, not erased from the trace");
                Write("------------------------------------------------------------");

                _timer = new System.Threading.Timer(TimerTick, null, INITIAL_DELAY_MS, SAMPLE_INTERVAL_MS);
            }
            catch (Exception ex)
            {
                SafeConsole($"[STAGE102][START-FAILED] {ex.GetType().Name}: {ex.Message}");
            }
        }

        public void ObserveSnapshot(List<EntityData> enemies)
        {
            if (Volatile.Read(ref _disposed) != 0 ||
                Volatile.Read(ref _started) == 0 ||
                enemies == null)
                return;

            long now = Environment.TickCount64;
            lock (_sync)
            {
                if (_targetLocked)
                {
                    EntityData lockedSnapshot = enemies.FirstOrDefault(e => e != null && e.Ptr == _targetPtr);
                    _latestSnapshotPresent = lockedSnapshot != null;
                    if (lockedSnapshot != null)
                    {
                        _latestSnapshotPtr = lockedSnapshot.Ptr;
                        _latestSnapshotId = lockedSnapshot.EntityId;
                        _latestSnapshotX = lockedSnapshot.X;
                        _latestSnapshotY = lockedSnapshot.Y;
                        _latestSnapshotZ = lockedSnapshot.Z;
                        _latestSnapshotTicks = now;
                    }
                    return;
                }

                if (_targetSelectionStartedMs == 0)
                {
                    _targetSelectionStartedMs = now;
                    _lastTargetSelectionSampleMs = now - TARGET_SELECTION_SAMPLE_INTERVAL_MS;
                    Write("[STAGE102][TARGET-SELECTION-START] sampling all valid enemy snapshots before locking; choose by plausible motion, not list order");
                }

                if (now - _lastTargetSelectionSampleMs < TARGET_SELECTION_SAMPLE_INTERVAL_MS)
                    return;
                _lastTargetSelectionSampleMs = now;

                foreach (EntityData enemy in enemies)
                {
                    if (enemy?.IsEnemy != true ||
                        !IsPtr(enemy.Ptr) || enemy.EntityId == 0 ||
                        !IsValidCoordinate(enemy.X) ||
                        !IsValidCoordinate(enemy.Y) ||
                        !IsValidCoordinate(enemy.Z))
                        continue;

                    var key = (enemy.Ptr, enemy.EntityId);
                    if (!_targetMotionRecords.TryGetValue(key, out TargetMotionRecord record))
                    {
                        record = new TargetMotionRecord { Ptr = enemy.Ptr, EntityId = enemy.EntityId };
                        _targetMotionRecords[key] = record;
                    }

                    record.LastSeenMs = now;
                    record.Samples++;
                    if (record.HasPrevious)
                    {
                        float step = Distance(record.PreviousX, record.PreviousY, record.PreviousZ,
                            enemy.X, enemy.Y, enemy.Z);
                        if (float.IsFinite(step) && step >= TARGET_MOVEMENT_THRESHOLD && step <= MAX_TARGET_SELECTION_STEP)
                        {
                            record.MovingTransitions++;
                            record.PlausibleTotalStep += step;
                        }
                        else if (float.IsFinite(step) && step > MAX_TARGET_SELECTION_STEP)
                        {
                            record.OutlierSteps++;
                        }
                    }

                    record.PreviousX = enemy.X;
                    record.PreviousY = enemy.Y;
                    record.PreviousZ = enemy.Z;
                    record.HasPrevious = true;
                }

                long elapsedMs = now - _targetSelectionStartedMs;
                List<TargetMotionRecord> live = _targetMotionRecords.Values
                    .Where(r => now - r.LastSeenMs <= TARGET_SELECTION_STALE_MS &&
                                r.Samples >= MIN_TARGET_SELECTION_SAMPLES)
                    .ToList();

                bool activeTargetFound = elapsedMs >= TARGET_SELECTION_WINDOW_MS &&
                    live.Any(r => r.MovingTransitions >= MIN_TARGET_SELECTION_MOVING_TRANSITIONS);
                bool selectionTimedOut = elapsedMs >= TARGET_SELECTION_TIMEOUT_MS;
                if (!activeTargetFound && !selectionTimedOut)
                    return;

                TargetMotionRecord selected = live
                    .OrderByDescending(r => r.MovingTransitions)
                    .ThenByDescending(r => r.PlausibleTotalStep)
                    .ThenByDescending(r => r.Samples)
                    .ThenBy(r => r.EntityId)
                    .FirstOrDefault();

                if (selected == null)
                {
                    if (now - _lastTargetSelectionWaitLogMs >= 2000)
                    {
                        _lastTargetSelectionWaitLogMs = now;
                        Write($"[STAGE102][TARGET-SELECTION-WAIT] elapsedMs={elapsedMs} validTrackedTargets={_targetMotionRecords.Count} no currently visible target has {MIN_TARGET_SELECTION_SAMPLES}+ samples");
                    }
                    return;
                }

                _targetPtr = selected.Ptr;
                _targetId = selected.EntityId;
                _targetSelectionMethod = activeTargetFound ? "MOST_MOVED_TARGET" : "BEST_AVAILABLE_TIMEOUT_FALLBACK";
                _targetSelectionSamples = selected.Samples;
                _targetSelectionTransitions = selected.MovingTransitions;
                _targetSelectionOutliers = selected.OutlierSteps;
                _targetSelectionPlausibleStep = selected.PlausibleTotalStep;
                _targetLocked = true;

                Write($"[STAGE102][TARGET-LOCK] bga=0x{_targetPtr:X} id=0x{_targetId:X8} selectionMethod={_targetSelectionMethod} preselectionSamples={_targetSelectionSamples} plausibleMovingTransitions={_targetSelectionTransitions} plausibleTotalStep={_targetSelectionPlausibleStep:F3} outlierSteps={_targetSelectionOutliers} elapsedMs={elapsedMs}");
                int rank = 0;
                foreach (TargetMotionRecord item in _targetMotionRecords.Values
                    .Where(r => now - r.LastSeenMs <= TARGET_SELECTION_STALE_MS)
                    .OrderByDescending(r => r.MovingTransitions)
                    .ThenByDescending(r => r.PlausibleTotalStep)
                    .ThenByDescending(r => r.Samples)
                    .Take(5))
                {
                    rank++;
                    Write($"[STAGE102][TARGET-SELECTION-CANDIDATE] rank={rank} bga=0x{item.Ptr:X} id=0x{item.EntityId:X8} samples={item.Samples} plausibleMovingTransitions={item.MovingTransitions} plausibleTotalStep={item.PlausibleTotalStep:F3} outlierSteps={item.OutlierSteps}");
                }
                Write("[STAGE102][TARGET-SELECTION-VERDICT] the selected enemy had the strongest plausible movement history available; this does not prove any candidate is a skeletal bone hierarchy");
            }
        }

        private void TimerTick(object state)
        {
            if (Volatile.Read(ref _disposed) != 0 || _captureComplete)
                return;
            if (Interlocked.Exchange(ref _timerBusy, 1) != 0)
                return;

            try
            {
                if (!_targetLocked)
                {
                    if (!_waitForTargetLogged)
                    {
                        Write("[STAGE102][WAIT] no live enemy target snapshot yet");
                        _waitForTargetLogged = true;
                    }
                    return;
                }

                if (!_discoveryComplete)
                {
                    _discoveryAttempts++;
                    bool found = RunDiscoveryPass();
                    if (found)
                    {
                        _discoveryComplete = true;
                        _hasPreviousTarget = false;
                        foreach (CandidateRecord c in _candidates.Values)
                            ResetCandidateSampling(c);

                        PrepareFocusedRootCensuses();
                        Write($"[STAGE102][DISCOVERY-COMPLETE] attempts={_discoveryAttempts} candidates={_candidates.Count} sceneNodes={_sceneNodes.Count} pointerReferences={_scenePointerReferences} focusedRoots={_focusedRootCandidates.Count}");
                        Write("[STAGE102][PREPARE] sampling begins in 1 second; the selected target is an enemy entity, not the local player");
                        Write("[STAGE102][MOTION-PROTOCOL] keep the selected enemy visible and moving where possible; movement by the local player does not count as target movement");
                        _samplingDelayScheduled = true;
                        _timer?.Change(PRE_SAMPLE_DELAY_MS, SAMPLE_INTERVAL_MS);
                        return;
                    }

                    if (_discoveryAttempts >= MAX_DISCOVERY_ATTEMPTS)
                    {
                        Write($"[STAGE102][DISCOVERY-EXHAUSTED] attempts={_discoveryAttempts} noCandidatePool=1 objectsInspectedLastAttempt={_firstHopObjectsOnLastAttempt}; stopping instead of repeating an unbounded scan");
                        EmitFinal("NO_CANDIDATE_POOL");
                        CompleteCapture();
                    }
                    return;
                }

                if (_samplingDelayScheduled)
                {
                    _samplingDelayScheduled = false;
                    Write("[STAGE102][ASSOCIATION-SAMPLING-START]");
                }

                if (_sample >= SAMPLE_COUNT)
                {
                    EmitFinal("SAMPLE_WINDOW_COMPLETE");
                    CompleteCapture();
                    return;
                }

                RunAssociationSample();
                _sample++;
                if (_sample >= SAMPLE_COUNT)
                {
                    EmitFinal("SAMPLE_WINDOW_COMPLETE");
                    CompleteCapture();
                }
            }
            catch (Exception ex)
            {
                Write($"[STAGE102][EXCEPTION] sample={_sample} {ex.GetType().Name}: {ex.Message}");
            }
            finally
            {
                Volatile.Write(ref _timerBusy, 0);
            }
        }

        private bool RunDiscoveryPass()
        {
            if (!TryReadTarget(out uint liveId, out float tx, out float ty, out float tz))
            {
                Write($"[STAGE102][DISCOVERY-RETRY] attempt={_discoveryAttempts} reason=lockedBgaUnreadable");
                return false;
            }

            if (liveId != _targetId)
            {
                _targetIdMismatchSamples++;
                Write($"[STAGE102][TARGET-ID-MISMATCH] locked=0x{_targetId:X8} live=0x{liveId:X8} attempt={_discoveryAttempts}");
                return false;
            }

            var directCandidates = new Dictionary<long, CandidateRecord>();
            var scannedFirstHop = new HashSet<long>();
            int firstHopObjects = 0;

            // The earlier captures found useful target-reachable model paths under BGA+0x0A8
            // and BGA+0x0B8. Inspect those roots before the high-fanout BGA+0x648 branch.
            // All pointer values are read at runtime; no process-specific address is embedded.
            int[] priorityOffsets = { 0x0A8, 0x0B8, 0x128, 0x130, 0x048, 0x648 };
            foreach (int offset in priorityOffsets)
            {
                if (firstHopObjects >= MAX_FIRST_HOP_OBJECTS)
                    break;
                long pointer = ReadPtr(_targetPtr + offset);
                Write($"[STAGE102][PRIORITY-SEED] bgaOffset=+0x{offset:X3} ptr=0x{pointer:X}");
                InspectFirstHopObject(pointer, $"BGA+0x{offset:X3}", tx, ty, tz,
                    directCandidates, scannedFirstHop, ref firstHopObjects);
            }

            int sweepStartOffset = _nextPointerSweepOffset;
            if (_mem.ReadBytesQuiet(_targetPtr, _bgaScratch, 0, _bgaScratch.Length))
            {
                var seenBgaPointers = new HashSet<long>();
                int slotCount = _bgaScratch.Length / 8;
                for (int checks = 0; checks < slotCount; checks++)
                {
                    int offset = (sweepStartOffset + checks * 8) % _bgaScratch.Length;
                    if (firstHopObjects >= MAX_FIRST_HOP_OBJECTS)
                    {
                        _nextPointerSweepOffset = offset;
                        break;
                    }

                    long pointer = ReadQword(_bgaScratch, offset);
                    _nextPointerSweepOffset = (offset + 8) % _bgaScratch.Length;
                    if (!IsPtr(pointer) || !seenBgaPointers.Add(pointer) || scannedFirstHop.Contains(pointer))
                        continue;

                    InspectFirstHopObject(pointer, $"BGA+0x{offset:X3}", tx, ty, tz,
                        directCandidates, scannedFirstHop, ref firstHopObjects);
                }
            }

            int nestedThisAttempt = ProcessNestedPointerQueue(tx, ty, tz, directCandidates);
            _nestedObjectsOnLastAttempt = nestedThisAttempt;
            _firstHopObjectsOnLastAttempt = firstHopObjects;
            _discoveryObjectsInspected += firstHopObjects + nestedThisAttempt;
            _directModelCandidates = directCandidates.Count;
            Write($"[STAGE102][DISCOVERY-SCAN] attempt={_discoveryAttempts} sweepStart=+0x{sweepStartOffset:X3} sweepNext=+0x{_nextPointerSweepOffset:X3} bgaSeedObjects={firstHopObjects} nestedObjects={nestedThisAttempt} queuedPending={_nestedQueue.Count} directOrNestedModels={directCandidates.Count} cumulativeObjects={_discoveryObjectsInspected}");

            if (directCandidates.Count == 0)
                return false;

            _candidates.Clear();
            _sceneNodes.Clear();
            _sceneScanned.Clear();
            _sceneEdgeKeys.Clear();
            _scenePointerReferences = 0;

            foreach (CandidateRecord candidate in directCandidates.Values)
                AddCandidate(candidate);

            // Stage 63 scanned only the nearest four direct candidates. That missed
            // useful provenance paths such as the previously productive BGA+0x0B8
            // closure. Stage 102 takes one candidate per known BGA path first, then
            // fills the remaining bounded anchor budget by distance.
            string[] preferredPathTokens =
            {
                "BGA+0x0A8", "BGA+0x0B8", "BGA+0x128", "BGA+0x130",
                "BGA+0x048", "BGA+0x648", "BGA+0x298", "BGA+0x118"
            };
            var anchors = new List<CandidateRecord>();
            var anchorModels = new HashSet<long>();
            foreach (string token in preferredPathTokens)
            {
                CandidateRecord routeCandidate = directCandidates.Values
                    .Where(c => !string.IsNullOrEmpty(c.Path) && c.Path.Contains(token, StringComparison.Ordinal))
                    .OrderBy(c => float.IsFinite(c.DiscoveryDistance) ? c.DiscoveryDistance : float.MaxValue)
                    .ThenBy(c => c.ModelPtr)
                    .FirstOrDefault();
                if (routeCandidate != null && anchorModels.Add(routeCandidate.ModelPtr))
                    anchors.Add(routeCandidate);
                if (anchors.Count >= MAX_SCENE_ANCHORS)
                    break;
            }

            foreach (CandidateRecord candidate in directCandidates.Values
                .OrderBy(c => float.IsFinite(c.DiscoveryDistance) ? c.DiscoveryDistance : float.MaxValue)
                .ThenBy(c => c.ModelPtr))
            {
                if (anchors.Count >= MAX_SCENE_ANCHORS)
                    break;
                if (anchorModels.Add(candidate.ModelPtr))
                    anchors.Add(candidate);
            }
            Write($"[STAGE102][SCENE-ANCHOR-PLAN] directCandidates={directCandidates.Count} selectedAnchors={anchors.Count} cap={MAX_SCENE_ANCHORS} policy=one-per-priority-path-then-nearest; tokens={string.Join(",", preferredPathTokens)}");

            foreach (CandidateRecord anchor in anchors)
            {
                if (_sceneNodes.Count >= MAX_SCENE_NODES)
                    break;
                _sceneAnchorsScanned++;
                Write($"[STAGE102][SCENE-ANCHOR] index={_sceneAnchorsScanned} model=0x{anchor.ModelPtr:X} root=0x{anchor.RootPtr:X} distance={FormatDistance(anchor.DiscoveryDistance)} directPath={anchor.Path}");
                ScanSceneClosure(anchor, tx, ty, tz);
            }

            Write($"[STAGE102][SCENE-SUMMARY] scannedAnchors={Math.Min(_sceneAnchorsScanned, MAX_SCENE_ANCHORS)} exactSpaceNodes={_sceneNodes.Count} pointerReferences={_scenePointerReferences} uniqueModelCandidates={_candidates.Count}");
            foreach (CandidateRecord candidate in _candidates.Values
                .OrderBy(c => float.IsFinite(c.DiscoveryDistance) ? c.DiscoveryDistance : float.MaxValue)
                .ThenBy(c => c.ModelPtr))
            {
                RegisterTransformProbe(candidate.ModelPtr, ReadPtr(candidate.ModelPtr), candidate.Path + "::Model", 3);
                RegisterTransformProbe(candidate.RootPtr, ReadPtr(candidate.RootPtr), candidate.Path + "::RootSpaceNode", 4);
                Write($"[STAGE102][CANDIDATE-BASELINE] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} discoveryDistance={FormatDistance(candidate.DiscoveryDistance)} fromBgaClosure={(candidate.FromBgaClosure ? 1 : 0)} sourceNode=0x{candidate.SourceNodePtr:X} path={candidate.Path}");
            }

            Write("[STAGE102][CANDIDATE-POOL-READY] no candidate was selected; every candidate root enters the same association window");
            return _candidates.Count > 0;
        }

        private void InspectFirstHopObject(
            long firstHopPtr,
            string sourceLabel,
            float tx,
            float ty,
            float tz,
            Dictionary<long, CandidateRecord> directCandidates,
            HashSet<long> scannedFirstHop,
            ref int firstHopObjects)
        {
            if (!IsPtr(firstHopPtr) || !scannedFirstHop.Add(firstHopPtr) ||
                firstHopObjects >= MAX_FIRST_HOP_OBJECTS)
                return;

            firstHopObjects++;
            long firstHopVtable = ReadPtr(firstHopPtr);
            RegisterTransformProbe(firstHopPtr, firstHopVtable, sourceLabel,
                firstHopVtable == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA ? 4 :
                firstHopVtable == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA ? 3 : 1);
            if (firstHopObjects <= 24)
                Write($"[STAGE102][FIRST-HOP] source={sourceLabel} ptr=0x{firstHopPtr:X} vtable=0x{firstHopVtable:X}");

            if (TryValidateModelCandidate(firstHopPtr, sourceLabel, tx, ty, tz, true, 0,
                out CandidateRecord directCandidate))
            {
                AddCandidateToDictionary(directCandidates, directCandidate);
                Write($"[STAGE102][DIRECT-MODEL-HIT] model=0x{directCandidate.ModelPtr:X} root=0x{directCandidate.RootPtr:X} distance={FormatDistance(directCandidate.DiscoveryDistance)} path={sourceLabel}");
                return;
            }

            if (!_mem.ReadBytesQuiet(firstHopPtr, _objectScratch, 0, _objectScratch.Length))
                return;

            // This object's full field block has already been inspected as a BGA seed;
            // do not process it a second time if a nested pointer cycles back to it.
            _nestedScanned.Add(firstHopPtr);

            long modelVtable = _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;
            long spaceNodeVtable = _mem.BaseAddress + SPACE_NODE_VTABLE_RVA;
            var localChildren = new HashSet<long>();
            for (int offset = 0, checks = 0;
                 offset + 8 <= _objectScratch.Length && checks < MAX_CHILD_POINTER_CHECKS;
                 offset += 8, checks++)
            {
                long child = ReadQword(_objectScratch, offset);
                if (!IsPtr(child) || child == firstHopPtr || !localChildren.Add(child))
                    continue;

                long childVtable = ReadPtr(child);
                string childPath = $"{sourceLabel}->0x{firstHopPtr:X}+0x{offset:X3}";
                if (childVtable == modelVtable &&
                    TryValidateModelCandidate(child, childPath, tx, ty, tz, true, 0,
                        out CandidateRecord candidate))
                {
                    AddCandidateToDictionary(directCandidates, candidate);
                    Write($"[STAGE102][MODEL-HIT][BGA-OBJECT] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} distance={FormatDistance(candidate.DiscoveryDistance)} path={candidate.Path}");
                }
                else if (childVtable == spaceNodeVtable)
                {
                    RegisterTransformProbe(child, childVtable, childPath, 4);
                    long owner = ReadPtr(child + SPACE_MODEL);
                    if (TryValidateModelCandidate(owner, $"{childPath}->SpaceNodeOwner", tx, ty, tz,
                        true, child, out CandidateRecord ownerCandidate))
                    {
                        AddCandidateToDictionary(directCandidates, ownerCandidate);
                        Write($"[STAGE102][MODEL-HIT][SPACE-NODE-OWNER] model=0x{ownerCandidate.ModelPtr:X} root=0x{ownerCandidate.RootPtr:X} sourceNode=0x{child:X} distance={FormatDistance(ownerCandidate.DiscoveryDistance)} path={ownerCandidate.Path}");
                    }
                }

                // Exact executable-image vtables are high-priority nested objects. Small
                // sentinel/container records (vtable 1) are also followed, but the global
                // pending/scan budgets prevent a broad or unbounded walk.
                if (ShouldQueueNestedPointer(childVtable) && offset + 8 <= _objectScratch.Length)
                    QueueNestedPointer(child, 1, childPath);
            }
        }

        private int ProcessNestedPointerQueue(
            float tx,
            float ty,
            float tz,
            Dictionary<long, CandidateRecord> directCandidates)
        {
            int processed = 0;
            long modelVtable = _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA;
            long spaceNodeVtable = _mem.BaseAddress + SPACE_NODE_VTABLE_RVA;

            while (_nestedQueue.Count > 0 && processed < MAX_NESTED_OBJECTS_PER_ATTEMPT)
            {
                PointerWorkItem item = _nestedQueue.Dequeue();
                if (item == null || item.Depth > MAX_NESTED_DEPTH || !IsPtr(item.Ptr) ||
                    !_nestedScanned.Add(item.Ptr))
                    continue;

                if (!_mem.ReadBytesQuiet(item.Ptr, _objectScratch, 0, _objectScratch.Length))
                {
                    _nestedReadFailures++;
                    if (_nestedReadFailures <= 24)
                        Write($"[STAGE102][NESTED-READ-FAILED] ptr=0x{item.Ptr:X} depth={item.Depth} path={item.Path}");
                    continue;
                }

                processed++;
                long objectVtable = ReadQword(_objectScratch, 0);
                RegisterTransformProbe(item.Ptr, objectVtable, item.Path,
                    objectVtable == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA ? 4 :
                    objectVtable == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA ? 3 : 1);
                if (processed <= 24 || objectVtable == modelVtable || objectVtable == spaceNodeVtable)
                    Write($"[STAGE102][NESTED-OBJECT] ptr=0x{item.Ptr:X} depth={item.Depth} vtable=0x{objectVtable:X} path={item.Path}");

                if (objectVtable == modelVtable &&
                    TryValidateModelCandidate(item.Ptr, item.Path, tx, ty, tz, true, 0,
                        out CandidateRecord selfCandidate))
                {
                    AddCandidateToDictionary(directCandidates, selfCandidate);
                    Write($"[STAGE102][MODEL-HIT][NESTED-OBJECT] model=0x{selfCandidate.ModelPtr:X} root=0x{selfCandidate.RootPtr:X} distance={FormatDistance(selfCandidate.DiscoveryDistance)} path={selfCandidate.Path}");
                }
                else if (objectVtable == spaceNodeVtable)
                {
                    RegisterTransformProbe(item.Ptr, objectVtable, item.Path, 4);
                    long owner = ReadQword(_objectScratch, SPACE_MODEL);
                    if (TryValidateModelCandidate(owner, $"{item.Path}->SpaceNodeOwner", tx, ty, tz,
                        true, item.Ptr, out CandidateRecord ownerCandidate))
                    {
                        AddCandidateToDictionary(directCandidates, ownerCandidate);
                        Write($"[STAGE102][MODEL-HIT][NESTED-SPACE-NODE-OWNER] model=0x{ownerCandidate.ModelPtr:X} root=0x{ownerCandidate.RootPtr:X} sourceNode=0x{item.Ptr:X} distance={FormatDistance(ownerCandidate.DiscoveryDistance)} path={ownerCandidate.Path}");
                    }
                }

                var localChildren = new HashSet<long>();
                for (int offset = 0, checks = 0;
                     offset + 8 <= _objectScratch.Length && checks < MAX_CHILD_POINTER_CHECKS;
                     offset += 8, checks++)
                {
                    long child = ReadQword(_objectScratch, offset);
                    if (!IsPtr(child) || child == item.Ptr || !localChildren.Add(child))
                        continue;

                    long childVtable = ReadPtr(child);
                    string childPath = $"{item.Path}/+0x{offset:X3}";
                    if (childVtable == modelVtable &&
                        TryValidateModelCandidate(child, childPath, tx, ty, tz, true, 0,
                            out CandidateRecord candidate))
                    {
                        AddCandidateToDictionary(directCandidates, candidate);
                        Write($"[STAGE102][MODEL-HIT][NESTED-FIELD] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} distance={FormatDistance(candidate.DiscoveryDistance)} path={candidate.Path}");
                    }
                    else if (childVtable == spaceNodeVtable)
                    {
                        RegisterTransformProbe(child, childVtable, childPath, 4);
                        long owner = ReadPtr(child + SPACE_MODEL);
                        if (TryValidateModelCandidate(owner, $"{childPath}->SpaceNodeOwner", tx, ty, tz,
                            true, child, out CandidateRecord ownerCandidate))
                        {
                            AddCandidateToDictionary(directCandidates, ownerCandidate);
                            Write($"[STAGE102][MODEL-HIT][NESTED-OWNER] model=0x{ownerCandidate.ModelPtr:X} root=0x{ownerCandidate.RootPtr:X} sourceNode=0x{child:X} distance={FormatDistance(ownerCandidate.DiscoveryDistance)} path={ownerCandidate.Path}");
                        }
                    }

                    if (item.Depth < MAX_NESTED_DEPTH && ShouldQueueNestedPointer(childVtable))
                        QueueNestedPointer(child, item.Depth + 1, childPath);
                }
            }

            _nestedObjectsTotalRead += processed;
            Write($"[STAGE102][NESTED-CLOSURE] processedThisAttempt={processed} totalObjectsRead={_nestedObjectsTotalRead} uniquePointersSeen={_nestedScanned.Count} pending={_nestedQueue.Count} queuedCap={MAX_QUEUED_POINTERS} maxDepth={MAX_NESTED_DEPTH} readFailures={_nestedReadFailures} modelCandidates={directCandidates.Count}");
            return processed;
        }

        private bool ShouldQueueNestedPointer(long vtable)
        {
            if (vtable == 1)
                return true;

            long baseAddress = _mem.BaseAddress;
            return vtable >= baseAddress && vtable < baseAddress + IMAGE_SIZE;
        }

        private void QueueNestedPointer(long ptr, int depth, string path)
        {
            if (!IsPtr(ptr) || depth > MAX_NESTED_DEPTH || _nestedQueued.Contains(ptr) ||
                _nestedScanned.Contains(ptr) || _nestedQueued.Count >= MAX_QUEUED_POINTERS)
                return;

            _nestedQueued.Add(ptr);
            _nestedQueue.Enqueue(new PointerWorkItem { Ptr = ptr, Depth = depth, Path = path });
        }

        private bool TryValidateModelCandidate(
            long modelPtr,
            string path,
            float tx,
            float ty,
            float tz,
            bool fromBgaClosure,
            long sourceNodePtr,
            out CandidateRecord candidate)
        {
            candidate = null;
            if (!IsPtr(modelPtr))
                return false;

            long modelVtable = ReadPtr(modelPtr);
            if (modelVtable != _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA)
                return false;

            long root = ReadPtr(modelPtr + MODEL_SPACE_NODE);
            if (!IsPtr(root))
                return false;
            long rootVtable = ReadPtr(root);
            if (rootVtable != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA ||
                ReadPtr(root + SPACE_MODEL) != modelPtr)
                return false;

            float distance = float.NaN;
            if (TryReadNodeTransform(root, tx, ty, tz,
                out _, out _, out _, out _, out float d))
                distance = d;

            RegisterTransformProbe(modelPtr, modelVtable, path + "::Model", 3);
            RegisterTransformProbe(root, rootVtable, path + "::RootSpaceNode", 4);

            candidate = new CandidateRecord
            {
                ModelPtr = modelPtr,
                RootPtr = root,
                Path = path,
                FromBgaClosure = fromBgaClosure,
                SourceNodePtr = sourceNodePtr,
                DiscoveryDistance = distance,
            };
            return true;
        }

        private void ScanSceneClosure(CandidateRecord anchor, float tx, float ty, float tz)
        {
            var queue = new Queue<(long Ptr, int Depth, string Path)>();
            queue.Enqueue((anchor.RootPtr, 0, $"ANCHOR-0x{anchor.ModelPtr:X}"));

            while (queue.Count > 0 && _sceneNodes.Count < MAX_SCENE_NODES)
            {
                (long ptr, int depth, string path) = queue.Dequeue();
                if (!IsPtr(ptr) || depth > MAX_HIERARCHY_DEPTH || !_sceneScanned.Add(ptr))
                    continue;
                if (!_mem.ReadBytesQuiet(ptr, _objectScratch, 0, _objectScratch.Length))
                    continue;
                long vtable = ReadQword(_objectScratch, 0);
                if (vtable != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA)
                    continue;

                long owner = ReadQword(_objectScratch, SPACE_MODEL);
                if (!_sceneNodes.ContainsKey(ptr))
                {
                    _sceneNodes[ptr] = new SceneNodeRecord { Ptr = ptr, Owner = owner, Depth = depth, FirstPath = path };
                    RegisterTransformProbe(ptr, vtable, path, 4);
                    AddOwnerModelCandidate(ptr, tx, ty, tz);
                }

                for (int offset = 0, checks = 0;
                     offset + 8 <= _objectScratch.Length && checks < MAX_CHILD_POINTER_CHECKS &&
                     _sceneEdgeKeys.Count < MAX_SCENE_EDGES;
                     offset += 8, checks++)
                {
                    long child = ReadQword(_objectScratch, offset);
                    if (!IsPtr(child) || child == ptr || ReadPtr(child) != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA)
                        continue;

                    _scenePointerReferences++;
                    if (_sceneEdgeKeys.Add((ptr, child, offset)) && _scenePointerReferences <= 120)
                        Write($"[STAGE102][SCENE-POINTER-REFERENCE] from=0x{ptr:X} offset=+0x{offset:X} to=0x{child:X} owner=0x{ReadPtr(child + SPACE_MODEL):X} depth={depth}");

                    AddOwnerModelCandidate(child, tx, ty, tz);
                    if (!_sceneNodes.ContainsKey(child) && _sceneNodes.Count < MAX_SCENE_NODES && depth + 1 <= MAX_HIERARCHY_DEPTH)
                    {
                        _sceneNodes[child] = new SceneNodeRecord
                        {
                            Ptr = child,
                            Owner = ReadPtr(child + SPACE_MODEL),
                            Depth = depth + 1,
                            FirstPath = $"{path}/+0x{offset:X}",
                        };
                        RegisterTransformProbe(child, ReadPtr(child), $"{path}/+0x{offset:X}", 4);
                        queue.Enqueue((child, depth + 1, $"{path}/+0x{offset:X}"));
                    }
                }
            }
        }

        private void AddOwnerModelCandidate(long nodePtr, float tx, float ty, float tz)
        {
            long owner = ReadPtr(nodePtr + SPACE_MODEL);
            if (!IsPtr(owner) || ReadPtr(owner) != _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA)
                return;

            long root = ReadPtr(owner + MODEL_SPACE_NODE);
            if (!ValidateModelRoot(owner, root, out _, out _, out _))
                return;

            float distance = float.NaN;
            if (TryReadNodeTransform(root, tx, ty, tz,
                out _, out _, out _, out _, out float measuredDistance))
                distance = measuredDistance;

            AddCandidate(new CandidateRecord
            {
                ModelPtr = owner,
                RootPtr = root,
                Path = $"OWNER-OF-SPACE-NODE-0x{nodePtr:X}",
                FromBgaClosure = false,
                SourceNodePtr = nodePtr,
                DiscoveryDistance = distance,
            });
        }

        private void AddCandidate(CandidateRecord candidate)
        {
            if (candidate == null || !IsPtr(candidate.ModelPtr) || !IsPtr(candidate.RootPtr))
                return;

            if (_candidates.TryGetValue(candidate.ModelPtr, out CandidateRecord existing))
            {
                if (candidate.FromBgaClosure && !existing.FromBgaClosure)
                {
                    existing.FromBgaClosure = true;
                    existing.SourceNodePtr = candidate.SourceNodePtr;
                    existing.Path = candidate.Path;
                    if (float.IsFinite(candidate.DiscoveryDistance))
                        existing.DiscoveryDistance = candidate.DiscoveryDistance;
                }
                else if (!float.IsFinite(existing.DiscoveryDistance) && float.IsFinite(candidate.DiscoveryDistance))
                {
                    existing.DiscoveryDistance = candidate.DiscoveryDistance;
                }
                return;
            }

            if (_candidates.Count >= MAX_MODEL_CANDIDATES)
            {
                Write($"[STAGE102][CANDIDATE-DROPPED] reason=poolCap model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X}");
                return;
            }
            _candidates[candidate.ModelPtr] = candidate;
        }

        private static void AddCandidateToDictionary(Dictionary<long, CandidateRecord> candidates, CandidateRecord candidate)
        {
            if (candidate == null)
                return;
            if (!candidates.TryGetValue(candidate.ModelPtr, out CandidateRecord existing) ||
                (!float.IsFinite(existing.DiscoveryDistance) && float.IsFinite(candidate.DiscoveryDistance)))
                candidates[candidate.ModelPtr] = candidate;
        }

        private bool ValidateModelRoot(long modelPtr, long rootPtr,
            out long modelVtable, out long rootVtable, out long rootOwner)
        {
            modelVtable = ReadPtr(modelPtr);
            rootVtable = ReadPtr(rootPtr);
            rootOwner = ReadPtr(rootPtr + SPACE_MODEL);
            return IsPtr(modelPtr) && IsPtr(rootPtr) &&
                   modelVtable == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA &&
                   rootVtable == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA &&
                   rootOwner == modelPtr;
        }

        private void RunAssociationSample()
        {
            if (_associationStartMs == 0)
                _associationStartMs = Environment.TickCount64;

            if (!TryReadTarget(out uint liveId, out float tx, out float ty, out float tz))
            {
                _targetLostSamples++;
                Write($"[STAGE102][SAMPLE] n={_sample + 1}/{SAMPLE_COUNT} targetRead=0 candidates={_candidates.Count}");
                return;
            }

            if (liveId != _targetId)
            {
                _targetIdMismatchSamples++;
                Write($"[STAGE102][BGA-TRACE-ID-MISMATCH] n={_sample + 1}/{SAMPLE_COUNT} elapsedMs={Environment.TickCount64 - _associationStartMs} bga=0x{_targetPtr:X} lockedId=0x{_targetId:X8} liveId=0x{liveId:X8} liveXYZ=({tx:F3},{ty:F3},{tz:F3}); coordinate sample rejected from association metrics but raw values preserved in log");
                return;
            }

            float targetStep = 0f;
            if (_hasPreviousTarget)
            {
                targetStep = Distance(_previousTargetX, _previousTargetY, _previousTargetZ, tx, ty, tz);
                if (float.IsFinite(targetStep))
                {
                    _targetTotalStep += targetStep;
                    if (targetStep >= TARGET_MOVEMENT_THRESHOLD && targetStep <= MAX_ASSOCIATION_TARGET_STEP)
                        _targetMotionTransitions++;
                    else if (targetStep > MAX_ASSOCIATION_TARGET_STEP)
                    {
                        _targetOutlierTransitions++;
                        Write($"[STAGE102][TARGET-STEP-OUTLIER] n={_sample + 1}/{SAMPLE_COUNT} targetStep={targetStep:F3} maxPlausibleStep={MAX_ASSOCIATION_TARGET_STEP:F3}; excluded from association motion counts");
                    }
                }
            }
            string stepClass;
            if (!_hasPreviousTarget)
                stepClass = "INITIAL";
            else if (targetStep < BGA_STATIONARY_THRESHOLD)
                stepClass = "STATIONARY";
            else if (targetStep > MAX_ASSOCIATION_TARGET_STEP)
            {
                stepClass = "LARGE_JUMP_INCLUDED_IN_RAW_TRACE";
                _largeRawJumpTransitions++;
                _largestRawJump = MathF.Max(_largestRawJump, targetStep);
            }
            else if (targetStep >= TARGET_MOVEMENT_THRESHOLD)
                stepClass = "PLAUSIBLE_MOVE";
            else
                stepClass = "SMALL_MOVE";

            bool hadPreviousTarget = _hasPreviousTarget;
            if (hadPreviousTarget && targetStep < BGA_STATIONARY_THRESHOLD)
            {
                _targetStationaryRun++;
                _targetStationarySamples++;
                if (_targetStationaryRun == MIN_STATIONARY_SAMPLES_FOR_HANDOFF)
                {
                    _targetStationaryEpisodes++;
                    Write($"[STAGE102][BGA-STATIONARY-EPISODE] n={_sample + 1} runLength={_targetStationaryRun} threshold={BGA_STATIONARY_THRESHOLD:F2} xyz=({tx:F3},{ty:F3},{tz:F3})");
                }
            }
            else
            {
                if (hadPreviousTarget && targetStep >= BGA_STATIONARY_THRESHOLD && _targetStationaryRun >= MIN_STATIONARY_SAMPLES_FOR_HANDOFF)
                    Write($"[STAGE102][BGA-STATIONARY-EPISODE-END] n={_sample + 1} priorRunLength={_targetStationaryRun} exitStep={targetStep:F3} exitClass={stepClass}");
                _targetStationaryRun = 0;
            }

            float snapshotX = float.NaN, snapshotY = float.NaN, snapshotZ = float.NaN;
            uint snapshotId = 0;
            long snapshotAgeMs = long.MaxValue;
            bool snapshotValid = false;
            lock (_sync)
            {
                snapshotAgeMs = _latestSnapshotTicks > 0 ? Math.Max(0, Environment.TickCount64 - _latestSnapshotTicks) : long.MaxValue;
                snapshotValid = _latestSnapshotPresent && _latestSnapshotPtr == _targetPtr &&
                    snapshotAgeMs <= SNAPSHOT_STALE_MS &&
                    IsValidCoordinate(_latestSnapshotX) && IsValidCoordinate(_latestSnapshotY) && IsValidCoordinate(_latestSnapshotZ);
                if (snapshotValid)
                {
                    snapshotX = _latestSnapshotX;
                    snapshotY = _latestSnapshotY;
                    snapshotZ = _latestSnapshotZ;
                    snapshotId = _latestSnapshotId;
                    _snapshotSeenSamples++;
                    float divergence = Distance(tx, ty, tz, snapshotX, snapshotY, snapshotZ);
                    if (divergence >= SNAPSHOT_DIVERGENCE_THRESHOLD)
                        _snapshotDivergenceSamples++;
                }
                else
                {
                    _snapshotMissingSamples++;
                }
            }
            float snapshotDistance = snapshotValid ? Distance(tx, ty, tz, snapshotX, snapshotY, snapshotZ) : float.NaN;
            long elapsedMs = _associationStartMs == 0 ? 0 : Environment.TickCount64 - _associationStartMs;
            Write($"[STAGE102][BGA-TRACE] n={_sample + 1}/{SAMPLE_COUNT} elapsedMs={elapsedMs} id=0x{liveId:X8} xyz=({tx:F3},{ty:F3},{tz:F3}) deltaStep={targetStep:F3} stepClass={stepClass} stationaryRun={_targetStationaryRun} totalRawStep={_targetTotalStep:F3} entitySnapshotValid={(snapshotValid ? 1 : 0)} snapshotId=0x{snapshotId:X8} snapshotAgeMs={(snapshotAgeMs == long.MaxValue ? -1 : snapshotAgeMs)} snapshotXYZ=({FormatCoordinate(snapshotX)},{FormatCoordinate(snapshotY)},{FormatCoordinate(snapshotZ)}) snapshotDistance={FormatDistance(snapshotDistance)} snapshotDiverges={(snapshotValid && snapshotDistance >= SNAPSHOT_DIVERGENCE_THRESHOLD ? 1 : 0)}");

            _previousTargetX = tx;
            _previousTargetY = ty;
            _previousTargetZ = tz;
            _hasPreviousTarget = true;

            int validCandidates = 0;
            int near128Candidates = 0;
            int near256Candidates = 0;
            int stableRelativeCandidates = 0;

            foreach (CandidateRecord candidate in _candidates.Values.OrderBy(c => c.ModelPtr))
            {
                bool structural = ValidateModelRoot(candidate.ModelPtr, candidate.RootPtr,
                    out long modelVtable, out long rootVtable, out long owner);
                if (structural)
                    candidate.StructurallyValidSamples++;
                else
                {
                    candidate.StructurallyInvalidSamples++;
                    if (_sample < 3 || (_sample + 1) % 10 == 0)
                        Write($"[STAGE102][CANDIDATE-STRUCTURE] n={_sample + 1} model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} valid=0 modelVtable=0x{modelVtable:X} rootVtable=0x{rootVtable:X} rootOwner=0x{owner:X}");
                    continue;
                }

                if (!TryReadNodeTransform(candidate.RootPtr, tx, ty, tz,
                    out float x, out float y, out float z, out string source, out float distance))
                    continue;

                candidate.ValidTransformSamples++;
                candidate.MinDistance = MathF.Min(candidate.MinDistance, distance);
                candidate.MaxDistance = MathF.Max(candidate.MaxDistance, distance);
                candidate.DistanceSum += distance;
                candidate.LastDistance = distance;
                if (distance <= MAX_NEAR_TARGET_DISTANCE)
                {
                    candidate.Near128Samples++;
                    near128Candidates++;
                }
                if (distance <= MAX_NEAR_TARGET_DIAGNOSTIC_DISTANCE)
                {
                    candidate.Near256Samples++;
                    near256Candidates++;
                }
                validCandidates++;

                float rx = x - tx;
                float ry = y - ty;
                float rz = z - tz;
                float rootStep = 0f;
                float relativeStep = 0f;
                if (candidate.HasPrevious)
                {
                    rootStep = Distance(candidate.PreviousX, candidate.PreviousY, candidate.PreviousZ, x, y, z);
                    relativeStep = Distance(candidate.PreviousRx, candidate.PreviousRy, candidate.PreviousRz, rx, ry, rz);
                    if (float.IsFinite(rootStep))
                        candidate.TotalRootStep += rootStep;
                    if (float.IsFinite(relativeStep))
                    {
                        candidate.TotalRelativeStep += relativeStep;
                        candidate.MaxRelativeStep = MathF.Max(candidate.MaxRelativeStep, relativeStep);
                    }

                    if (IsPlausibleTargetMotion(targetStep))
                    {
                        candidate.TargetMovingObservations++;
                        float stableLimit = MathF.Max(1.0f, targetStep * 0.25f);
                        if (relativeStep <= stableLimit)
                        {
                            candidate.RelativeStableWhileTargetMoves++;
                            stableRelativeCandidates++;
                        }
                        if (rootStep >= ROOT_STEP_THRESHOLD && relativeStep <= MathF.Max(2.0f, targetStep * 0.5f))
                            candidate.CoMotionSamples++;
                    }
                }

                candidate.PreviousX = x;
                candidate.PreviousY = y;
                candidate.PreviousZ = z;
                candidate.PreviousRx = rx;
                candidate.PreviousRy = ry;
                candidate.PreviousRz = rz;
                candidate.HasPrevious = true;

                Write($"[STAGE102][ROOT-TRACE] n={_sample + 1}/{SAMPLE_COUNT} model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} source={source} rootXYZ=({x:F3},{y:F3},{z:F3}) targetXYZ=({tx:F3},{ty:F3},{tz:F3}) targetStep={targetStep:F3} rootStep={rootStep:F3} relativeStep={relativeStep:F3} distance={distance:F3} relative=({rx:F3},{ry:F3},{rz:F3}) path={candidate.Path}");
            }

            SampleTransformProbes(tx, ty, tz, targetStep, stepClass, elapsedMs);
            SampleFocusedNodeTransforms(tx, ty, tz, targetStep);
            Write($"[STAGE102][SAMPLE] n={_sample + 1}/{SAMPLE_COUNT} targetId=0x{liveId:X8} targetXYZ=({tx:F3},{ty:F3},{tz:F3}) targetStep={targetStep:F3} targetTotalStep={_targetTotalStep:F3} movingTransitions={_targetMotionTransitions} validCandidates={validCandidates} within128={near128Candidates} within256={near256Candidates} stableRelativeWhileMoving={stableRelativeCandidates}");
        }

        private void RegisterTransformProbe(long ptr, long vtable, string path, int priority)
        {
            if (!IsPtr(ptr) || !IsPtr(vtable))
                return;

            if (vtable != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA &&
                vtable != _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA &&
                (vtable < _mem.BaseAddress || vtable >= _mem.BaseAddress + IMAGE_SIZE))
                return;

            if (_transformProbes.TryGetValue(ptr, out TransformProbeRecord existing))
            {
                bool pathIsCandidateRoot = path != null && path.Contains("::RootSpaceNode", StringComparison.Ordinal);
                bool existingPathIsCandidateRoot = existing.Path != null && existing.Path.Contains("::RootSpaceNode", StringComparison.Ordinal);
                if (priority > existing.Priority || (pathIsCandidateRoot && !existingPathIsCandidateRoot))
                {
                    if (existing.Priority < 3 && priority >= 3)
                        _genericTransformProbeCount = Math.Max(0, _genericTransformProbeCount - 1);
                    existing.Priority = Math.Max(existing.Priority, priority);
                    existing.Vtable = vtable;
                    existing.Path = path;
                }
                return;
            }

            bool generic = priority < 3;
            bool isCandidateRoot = path != null && path.Contains("::RootSpaceNode", StringComparison.Ordinal);
            if (generic && _genericTransformProbeCount >= MAX_GENERIC_TRANSFORM_PROBES)
                return;
            if (_transformProbes.Count >= MAX_TRANSFORM_PROBES)
            {
                if (!isCandidateRoot)
                    return;

                // Preserve candidate model roots if the bounded probe table fills with
                // lower-value model/object/node probes. Never grow beyond the cap.
                TransformProbeRecord victim = _transformProbes.Values
                    .Where(p => p.Path == null || !p.Path.Contains("::RootSpaceNode", StringComparison.Ordinal))
                    .OrderBy(p => p.Priority)
                    .ThenByDescending(p => p.ValidSamples)
                    .FirstOrDefault();
                if (victim == null)
                    return;
                _transformProbes.Remove(victim.Ptr);
                if (victim.Priority < 3)
                    _genericTransformProbeCount = Math.Max(0, _genericTransformProbeCount - 1);
            }

            _transformProbes[ptr] = new TransformProbeRecord
            {
                Ptr = ptr,
                Vtable = vtable,
                Path = path ?? "UNKNOWN",
                Priority = priority,
            };
            if (generic)
                _genericTransformProbeCount++;
        }

        private void SampleTransformProbes(float tx, float ty, float tz, float targetStep, string stepClass, long elapsedMs)
        {
            foreach (TransformProbeRecord probe in _transformProbes.Values.OrderByDescending(p => p.Priority).ThenBy(p => p.Ptr))
            {
                if (!TryReadNodeTransform(probe.Ptr, tx, ty, tz,
                    out float x, out float y, out float z, out string source, out float distance))
                {
                    probe.InvalidSamples++;
                    continue;
                }

                probe.ValidSamples++;
                probe.LastDistance = distance;
                probe.MinTargetDistance = MathF.Min(probe.MinTargetDistance, distance);
                probe.MaxTargetDistance = MathF.Max(probe.MaxTargetDistance, distance);
                probe.TargetDistanceSum += distance;

                float probeStep = 0f;
                if (probe.HasPrevious)
                {
                    probeStep = Distance(probe.PreviousX, probe.PreviousY, probe.PreviousZ, x, y, z);
                    probe.LastStep = probeStep;
                    if (float.IsFinite(probeStep))
                    {
                        probe.TotalStep += probeStep;
                        probe.MaxStep = MathF.Max(probe.MaxStep, probeStep);
                        if (probeStep >= PROBE_MOVEMENT_THRESHOLD)
                            probe.MovingTransitions++;
                        if (_targetStationaryRun >= MIN_STATIONARY_SAMPLES_FOR_HANDOFF)
                        {
                            probe.SamplesWhileBgaStationary++;
                            if (probeStep >= PROBE_MOVEMENT_THRESHOLD)
                                probe.MovesWhileBgaStationary++;
                        }
                    }
                }

                bool likelyRelevantSample = _sample == 0 || (_sample + 1) % 10 == 0 ||
                    probeStep >= PROBE_MOVEMENT_THRESHOLD || targetStep > MAX_ASSOCIATION_TARGET_STEP ||
                    _targetStationaryRun >= MIN_STATIONARY_SAMPLES_FOR_HANDOFF;
                if (likelyRelevantSample)
                {
                    Write($"[STAGE102][TRANSFORM-PROBE] n={_sample + 1}/{SAMPLE_COUNT} elapsedMs={elapsedMs} ptr=0x{probe.Ptr:X} vtable=0x{probe.Vtable:X} priority={probe.Priority} source={source} xyz=({x:F3},{y:F3},{z:F3}) step={probeStep:F3} stepClass={stepClass} distanceToBga={distance:F3} bgaStationaryRun={_targetStationaryRun} movedWhileBgaStationary={(probeStep >= PROBE_MOVEMENT_THRESHOLD && _targetStationaryRun >= MIN_STATIONARY_SAMPLES_FOR_HANDOFF ? 1 : 0)} path={probe.Path}");
                }

                probe.PreviousX = x;
                probe.PreviousY = y;
                probe.PreviousZ = z;
                probe.HasPrevious = true;
            }
        }

        private void PrepareFocusedRootCensuses()
        {
            _focusedRootCandidates.Clear();

            List<CandidateRecord> nearCandidates = _candidates.Values
                .Where(c => float.IsFinite(c.DiscoveryDistance) && c.DiscoveryDistance <= MAX_NEAR_TARGET_DISTANCE)
                .OrderBy(c => c.DiscoveryDistance)
                .ThenBy(c => c.ModelPtr)
                .ToList();

            var selected = new List<CandidateRecord>();
            var selectedModels = new HashSet<long>();

            void AddSelection(CandidateRecord candidate)
            {
                if (candidate == null || selected.Count >= MAX_FOCUSED_ROOT_CANDIDATES ||
                    !selectedModels.Add(candidate.ModelPtr))
                    return;
                selected.Add(candidate);
            }

            foreach (CandidateRecord candidate in nearCandidates)
                AddSelection(candidate);

            int nearSelected = selected.Count;
            if (selected.Count < MAX_FOCUSED_ROOT_CANDIDATES)
            {
                IEnumerable<CandidateRecord> fallbackCandidates = _candidates.Values
                    .Where(c => c != null && !selectedModels.Contains(c.ModelPtr))
                    .OrderByDescending(c => c.SourceNodePtr != 0)
                    .ThenByDescending(c => !string.IsNullOrEmpty(c.Path) &&
                        c.Path.Contains("BGA+0x0B8", StringComparison.Ordinal))
                    .ThenByDescending(c => c.FromBgaClosure)
                    .ThenBy(c => float.IsFinite(c.DiscoveryDistance) ? c.DiscoveryDistance : float.MaxValue)
                    .ThenBy(c => c.ModelPtr);

                foreach (CandidateRecord candidate in fallbackCandidates)
                {
                    AddSelection(candidate);
                    if (selected.Count >= MAX_FOCUSED_ROOT_CANDIDATES)
                        break;
                }
            }

            Write($"[STAGE102][FOCUSED-ROOTS] candidatesWithin128AtDiscovery={nearCandidates.Count} proximitySelected={nearSelected} selected={selected.Count} cap={MAX_FOCUSED_ROOT_CANDIDATES} selectionPolicy=near-first,SpaceNode-owner provenance,BGA+0x0B8 provenance,then distance; fallback roots are provisional only");
            if (selected.Count == 0)
            {
                Write("[STAGE102][FOCUSED-ROOT-CENSUS-SKIPPED] reason=no structurally discovered model/root candidates");
                return;
            }

            foreach (CandidateRecord candidate in selected)
            {
                string selectionReason = float.IsFinite(candidate.DiscoveryDistance) &&
                    candidate.DiscoveryDistance <= MAX_NEAR_TARGET_DISTANCE
                    ? "WITHIN128_AT_DISCOVERY"
                    : candidate.SourceNodePtr != 0
                        ? "SPACE_NODE_OWNER_FALLBACK"
                        : (!string.IsNullOrEmpty(candidate.Path) &&
                           candidate.Path.Contains("BGA+0x0B8", StringComparison.Ordinal))
                            ? "BGA_0B8_PROVENANCE_FALLBACK"
                            : "BOUNDED_DISTANCE_FALLBACK";

                if (!ValidateModelRoot(candidate.ModelPtr, candidate.RootPtr, out long modelVtable, out long rootVtable, out long owner))
                {
                    Write($"[STAGE102][FOCUSED-ROOT-REJECTED] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} selectionReason={selectionReason} modelVtable=0x{modelVtable:X} rootVtable=0x{rootVtable:X} owner=0x{owner:X}");
                    continue;
                }

                _focusedRootCandidates.Add(candidate);
                Write($"[STAGE102][FOCUSED-ROOT-PROVISIONAL] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} discoveryDistance={FormatDistance(candidate.DiscoveryDistance)} selectionReason={selectionReason} path={candidate.Path}; provisional only, no association winner accepted");
                ScanModelFieldsForFocusedNodes(candidate);

                var queue = new Queue<(long Node, int Depth, string Path)>();
                var visited = new HashSet<long>();
                queue.Enqueue((candidate.RootPtr, 0, "PROVISIONAL-MODEL-ROOT"));
                foreach (FocusedNodeRecord seededNode in candidate.FocusedNodes.Values.ToList())
                    queue.Enqueue((seededNode.NodePtr, seededNode.Depth, seededNode.FirstPath));

                while (queue.Count > 0)
                {
                    var work = queue.Dequeue();
                    if (work.Depth > MAX_FOCUSED_DEPTH || !IsPtr(work.Node) || !visited.Add(work.Node))
                        continue;
                    if (!_mem.ReadBytesQuiet(work.Node, _rootCensusScratch, 0, _rootCensusScratch.Length))
                    {
                        Write($"[STAGE102][FOCUSED-NODE-READ-FAIL] model=0x{candidate.ModelPtr:X} node=0x{work.Node:X} depth={work.Depth} path={work.Path}");
                        continue;
                    }
                    long nodeVtable = ReadQword(_rootCensusScratch, 0);
                    if (nodeVtable != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA)
                    {
                        Write($"[STAGE102][FOCUSED-NODE-REJECTED] node=0x{work.Node:X} vtable=0x{nodeVtable:X} depth={work.Depth} path={work.Path}");
                        continue;
                    }

                    long nodeOwner = ReadQword(_rootCensusScratch, SPACE_MODEL);
                    Write($"[STAGE102][FOCUSED-NODE-SCAN] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} node=0x{work.Node:X} depth={work.Depth} owner=0x{nodeOwner:X} ownerMatchesModel={(nodeOwner == candidate.ModelPtr ? 1 : 0)} path={work.Path}");
                    int exactRefs = 0;
                    for (int offset = 0, checks = 0;
                         offset + 8 <= _rootCensusScratch.Length && checks < MAX_CHILD_POINTER_CHECKS &&
                         candidate.FocusedEdges.Count < MAX_FOCUSED_EDGES_PER_ROOT;
                         offset += 8, checks++)
                    {
                        long child = ReadQword(_rootCensusScratch, offset);
                        if (!IsPtr(child) || child == work.Node || ReadPtr(child) != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA)
                            continue;

                        exactRefs++;
                        AddFocusedEdge(candidate, work.Node, child, offset, work.Depth, "SPACE-NODE-FIELD-REFERENCE", $"{work.Path}/+0x{offset:X}");
                        if (child == candidate.RootPtr)
                            continue;
                        bool added = AddFocusedNode(candidate, child, work.Depth + 1, $"{work.Path}/+0x{offset:X}");
                        if (added && work.Depth + 1 <= MAX_FOCUSED_DEPTH && !visited.Contains(child))
                            queue.Enqueue((child, work.Depth + 1, $"{work.Path}/+0x{offset:X}"));
                    }
                    Write($"[STAGE102][FOCUSED-NODE-SUMMARY] node=0x{work.Node:X} depth={work.Depth} exactSpaceNodeRefs={exactRefs} cumulativeNodes={candidate.FocusedNodes.Count} cumulativeRefs={candidate.FocusedEdges.Count}");
                }

                Write($"[STAGE102][FOCUSED-ROOT-CENSUS-COMPLETE] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} selectionReason={selectionReason} nonRootNodes={candidate.FocusedNodes.Count} exactReferences={candidate.FocusedEdges.Count} nodeCap={MAX_FOCUSED_NODES_PER_ROOT} edgeCap={MAX_FOCUSED_EDGES_PER_ROOT} depthCap={MAX_FOCUSED_DEPTH}");
            }
        }

        private void ScanModelFieldsForFocusedNodes(CandidateRecord candidate)
        {
            if (!_mem.ReadBytesQuiet(candidate.ModelPtr, _rootCensusScratch, 0, _rootCensusScratch.Length))
            {
                Write($"[STAGE102][MODEL-FIELD-CENSUS-FAIL] model=0x{candidate.ModelPtr:X} bytes=0x{ROOT_CENSUS_BYTES:X}");
                return;
            }
            long modelVtable = ReadQword(_rootCensusScratch, 0);
            if (modelVtable != _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA)
            {
                Write($"[STAGE102][MODEL-FIELD-CENSUS-REJECTED] model=0x{candidate.ModelPtr:X} vtable=0x{modelVtable:X}");
                return;
            }

            int exactRefs = 0;
            for (int offset = 0; offset + 8 <= _rootCensusScratch.Length && candidate.FocusedEdges.Count < MAX_FOCUSED_EDGES_PER_ROOT; offset += 8)
            {
                long node = ReadQword(_rootCensusScratch, offset);
                if (!IsPtr(node) || ReadPtr(node) != _mem.BaseAddress + SPACE_NODE_VTABLE_RVA)
                    continue;
                exactRefs++;
                if (node == candidate.RootPtr)
                {
                    Write($"[STAGE102][MODEL-ROOT-REFERENCE] model=0x{candidate.ModelPtr:X} offset=+0x{offset:X} root=0x{node:X} expectedRootOffset={(offset == MODEL_SPACE_NODE ? 1 : 0)}");
                    continue;
                }

                AddFocusedEdge(candidate, candidate.ModelPtr, node, offset, 0, "MODEL-FIELD-REFERENCE", $"MODEL+0x{offset:X}");
                bool added = AddFocusedNode(candidate, node, 1, $"MODEL+0x{offset:X}");
                // The discovered model-field node is seeded into the bounded queue after the model census.
                if (added)
                    Write($"[STAGE102][MODEL-REFERENCED-NODE] model=0x{candidate.ModelPtr:X} offset=+0x{offset:X} node=0x{node:X} owner=0x{ReadPtr(node + SPACE_MODEL):X}");
            }
            Write($"[STAGE102][MODEL-FIELD-CENSUS] model=0x{candidate.ModelPtr:X} bytes=0x{ROOT_CENSUS_BYTES:X} exactSpaceNodeRefs={exactRefs} rootOffset038=0x{ReadPtr(candidate.ModelPtr + MODEL_SPACE_NODE):X}");
        }

        private bool AddFocusedNode(CandidateRecord candidate, long nodePtr, int depth, string path)
        {
            if (nodePtr == candidate.RootPtr || !IsPtr(nodePtr))
                return false;
            if (candidate.FocusedNodes.ContainsKey(nodePtr))
                return false;
            if (candidate.FocusedNodes.Count >= MAX_FOCUSED_NODES_PER_ROOT)
                return false;

            candidate.FocusedNodes[nodePtr] = new FocusedNodeRecord
            {
                NodePtr = nodePtr,
                OwnerPtr = ReadPtr(nodePtr + SPACE_MODEL),
                Depth = depth,
                FirstPath = path,
            };
            return true;
        }

        private void AddFocusedEdge(CandidateRecord candidate, long source, long target, int offset, int depth, string role, string path)
        {
            if (candidate.FocusedEdges.Count >= MAX_FOCUSED_EDGES_PER_ROOT ||
                !candidate.FocusedEdgeKeys.Add((source, target, offset)))
                return;

            candidate.FocusedEdges.Add(new FocusedEdgeRecord
            {
                SourcePtr = source,
                TargetPtr = target,
                Offset = offset,
                Depth = depth,
                Role = role,
                Path = path,
            });
            long owner = ReadPtr(target + SPACE_MODEL);
            Write($"[STAGE102][FOCUSED-SPACE-NODE-REFERENCE] model=0x{candidate.ModelPtr:X} source=0x{source:X} offset=+0x{offset:X} target=0x{target:X} targetOwner=0x{owner:X} targetOwnerMatchesCandidate={(owner == candidate.ModelPtr ? 1 : 0)} role={role} depth={depth} path={path}; reference only, not yet classified as a bone edge");
        }

        private void SampleFocusedNodeTransforms(float tx, float ty, float tz, float targetStep)
        {
            foreach (CandidateRecord candidate in _focusedRootCandidates)
            {
                if (!ValidateModelRoot(candidate.ModelPtr, candidate.RootPtr, out _, out _, out _))
                {
                    if (_sample == 0 || (_sample + 1) % 10 == 0)
                        Write($"[STAGE102][FOCUSED-ROOT-STRUCTURE] n={_sample + 1} model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} valid=0; focused-node transforms skipped for this root");
                    continue;
                }
                if (!TryReadNodeTransform(candidate.RootPtr, tx, ty, tz,
                    out float rootX, out float rootY, out float rootZ, out _, out _))
                    continue;

                foreach (FocusedNodeRecord node in candidate.FocusedNodes.Values.OrderBy(n => n.Depth).ThenBy(n => n.NodePtr))
                {
                    long nodeVtable = ReadPtr(node.NodePtr);
                    long owner = ReadPtr(node.NodePtr + SPACE_MODEL);
                    if (nodeVtable == _mem.BaseAddress + SPACE_NODE_VTABLE_RVA)
                    {
                        node.StructuralValidSamples++;
                        if (owner == candidate.ModelPtr)
                            node.OwnerMatchesCandidateSamples++;
                        if (IsPtr(owner) && ReadPtr(owner) == _mem.BaseAddress + MODEL_SKELETAL_VTABLE_RVA)
                            node.OwnerIsModelSamples++;
                    }
                    else
                    {
                        node.StructuralInvalidSamples++;
                        if (_sample == 0 || (_sample + 1) % 10 == 0)
                            Write($"[STAGE102][FOCUSED-NODE-STRUCTURE] n={_sample + 1} node=0x{node.NodePtr:X} valid=0 vtable=0x{nodeVtable:X} owner=0x{owner:X} path={node.FirstPath}");
                        continue;
                    }

                    if (!TryReadNodeTransform(node.NodePtr, tx, ty, tz,
                        out float x, out float y, out float z, out string source, out float distance))
                        continue;

                    node.ValidTransformSamples++;
                    node.MinTargetDistance = MathF.Min(node.MinTargetDistance, distance);
                    node.MaxTargetDistance = MathF.Max(node.MaxTargetDistance, distance);
                    node.TargetDistanceSum += distance;
                    float targetRx = x - tx, targetRy = y - ty, targetRz = z - tz;
                    float rootRx = x - rootX, rootRy = y - rootY, rootRz = z - rootZ;
                    float nodeStep = 0f, targetRelativeStep = 0f, rootRelativeStep = 0f;
                    if (node.HasPrevious)
                    {
                        nodeStep = Distance(node.PreviousX, node.PreviousY, node.PreviousZ, x, y, z);
                        targetRelativeStep = Distance(node.PreviousTargetRx, node.PreviousTargetRy, node.PreviousTargetRz, targetRx, targetRy, targetRz);
                        rootRelativeStep = Distance(node.PreviousRootRx, node.PreviousRootRy, node.PreviousRootRz, rootRx, rootRy, rootRz);
                        if (float.IsFinite(nodeStep)) node.TotalNodeStep += nodeStep;
                        if (float.IsFinite(targetRelativeStep))
                        {
                            node.TotalTargetRelativeStep += targetRelativeStep;
                            node.MaxTargetRelativeStep = MathF.Max(node.MaxTargetRelativeStep, targetRelativeStep);
                        }
                        if (float.IsFinite(rootRelativeStep))
                        {
                            node.TotalRootRelativeStep += rootRelativeStep;
                            node.MaxRootRelativeStep = MathF.Max(node.MaxRootRelativeStep, rootRelativeStep);
                        }
                        if (IsPlausibleTargetMotion(targetStep))
                        {
                            node.TargetMovingObservations++;
                            if (targetRelativeStep <= MathF.Max(1.0f, targetStep * 0.25f))
                                node.StableRelativeToTargetWhileMoving++;
                            if (nodeStep >= ROOT_STEP_THRESHOLD && targetRelativeStep <= MathF.Max(2.0f, targetStep * 0.5f))
                                node.CoMotionSamples++;
                        }
                    }

                    node.PreviousX = x; node.PreviousY = y; node.PreviousZ = z;
                    node.PreviousTargetRx = targetRx; node.PreviousTargetRy = targetRy; node.PreviousTargetRz = targetRz;
                    node.PreviousRootRx = rootRx; node.PreviousRootRy = rootRy; node.PreviousRootRz = rootRz;
                    node.HasPrevious = true;

                    if (_sample == 0 || (_sample + 1) % 5 == 0)
                    {
                        Write($"[STAGE102][FOCUSED-NODE-SAMPLE] n={_sample + 1}/{SAMPLE_COUNT} model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} node=0x{node.NodePtr:X} depth={node.Depth} owner=0x{owner:X} ownerMatchesCandidate={(owner == candidate.ModelPtr ? 1 : 0)} source={source} targetDistance={distance:F3} rootDistance={Distance(x, y, z, rootX, rootY, rootZ):F3} nodeStep={nodeStep:F3} targetRelativeStep={targetRelativeStep:F3} rootRelativeStep={rootRelativeStep:F3} relativeToTarget=({targetRx:F3},{targetRy:F3},{targetRz:F3}) relativeToRoot=({rootRx:F3},{rootRy:F3},{rootRz:F3}) path={node.FirstPath}");
                    }
                }
            }
        }

        private bool AssociationPatternStrong(CandidateRecord c)
        {
            float meanDistance = AverageDistance(c);
            int moving = c.TargetMovingObservations;
            return c.StructurallyValidSamples >= (int)(SAMPLE_COUNT * MIN_ASSOCIATION_RATIO) &&
                   c.ValidTransformSamples >= (int)(SAMPLE_COUNT * MIN_ASSOCIATION_RATIO) &&
                   c.Near128Samples >= (int)(SAMPLE_COUNT * MIN_ASSOCIATION_RATIO) &&
                   moving >= MIN_ASSOCIATION_MOVING_OBSERVATIONS &&
                   c.RelativeStableWhileTargetMoves >= Math.Ceiling(moving * MIN_ASSOCIATION_RATIO) &&
                   c.CoMotionSamples >= Math.Ceiling(moving * MIN_ASSOCIATION_RATIO) &&
                   float.IsFinite(meanDistance) && meanDistance <= MAX_ASSOCIATION_MEAN_DISTANCE &&
                   c.MaxDistance <= MAX_NEAR_TARGET_DISTANCE;
        }

        private void EmitFocusedRootResults()
        {
            if (_focusedRootCandidates.Count == 0)
            {
                Write("[STAGE102][FINAL][ROOT-HIERARCHY] status=NOT_RUN reason=no candidate root was within 128 units at discovery");
                Write("[STAGE102][FINAL][VERDICT] targetAssociationPattern=UNCONFIRMED anatomicalHierarchyProven=0");
                return;
            }

            int qualifiedRoots = 0;
            foreach (CandidateRecord candidate in _focusedRootCandidates)
            {
                bool qualified = AssociationPatternStrong(candidate);
                if (qualified) qualifiedRoots++;
                Write($"[STAGE102][FINAL][ROOT-ASSOCIATION] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} associationPattern={(qualified ? 1 : 0)} discoveryDistance={FormatDistance(candidate.DiscoveryDistance)} validStructure={candidate.StructurallyValidSamples}/{SAMPLE_COUNT} validTransforms={candidate.ValidTransformSamples}/{SAMPLE_COUNT} near128={candidate.Near128Samples}/{SAMPLE_COUNT} movingObservations={candidate.TargetMovingObservations} stableRelative={candidate.RelativeStableWhileTargetMoves} coMotion={candidate.CoMotionSamples} meanDistance={FormatDistance(AverageDistance(candidate))} maxDistance={FormatDistance(candidate.MaxDistance)} nodes={candidate.FocusedNodes.Count} references={candidate.FocusedEdges.Count}");

                foreach (FocusedNodeRecord node in candidate.FocusedNodes.Values.OrderBy(n => n.Depth).ThenBy(n => n.NodePtr))
                {
                    float meanDistance = node.ValidTransformSamples > 0 ? (float)(node.TargetDistanceSum / node.ValidTransformSamples) : float.NaN;
                    Write($"[STAGE102][FINAL][NODE] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} node=0x{node.NodePtr:X} depth={node.Depth} owner=0x{node.OwnerPtr:X} ownerMatchesCandidateSamples={node.OwnerMatchesCandidateSamples} ownerIsModelSamples={node.OwnerIsModelSamples} structureValid={node.StructuralValidSamples} structureInvalid={node.StructuralInvalidSamples} validTransforms={node.ValidTransformSamples} targetMovingObservations={node.TargetMovingObservations} stableRelativeToTarget={node.StableRelativeToTargetWhileMoving} coMotion={node.CoMotionSamples} minDistance={(node.MinTargetDistance == float.MaxValue ? "N/A" : node.MinTargetDistance.ToString("F3", CultureInfo.InvariantCulture))} meanDistance={FormatDistance(meanDistance)} maxDistance={FormatDistance(node.MaxTargetDistance)} totalNodeStep={node.TotalNodeStep:F3} totalTargetRelativeStep={node.TotalTargetRelativeStep:F3} totalRootRelativeStep={node.TotalRootRelativeStep:F3} maxTargetRelativeStep={node.MaxTargetRelativeStep:F3} maxRootRelativeStep={node.MaxRootRelativeStep:F3} path={node.FirstPath}");
                }
                foreach (FocusedEdgeRecord edge in candidate.FocusedEdges)
                    Write($"[STAGE102][FINAL][REFERENCE] model=0x{candidate.ModelPtr:X} root=0x{candidate.RootPtr:X} source=0x{edge.SourcePtr:X} offset=+0x{edge.Offset:X} target=0x{edge.TargetPtr:X} role={edge.Role} depth={edge.Depth} path={edge.Path}");
            }

            Write($"[STAGE102][FINAL][ROOT-HIERARCHY] focusedRoots={_focusedRootCandidates.Count} associationPatternQualifiedRoots={qualifiedRoots} directAndNestedExactReferences={_focusedRootCandidates.Sum(c => c.FocusedEdges.Count)} anatomicalHierarchyProven=0");
            Write("[STAGE102][FINAL][VERDICT] associationPattern qualifies a target-associated root for further inspection only; exact SpaceNode pointer references are not semantic bone edges and do not prove anatomical hierarchy");
        }

        private void ResetCandidateSampling(CandidateRecord candidate)
        {
            candidate.StructurallyValidSamples = 0;
            candidate.StructurallyInvalidSamples = 0;
            candidate.ValidTransformSamples = 0;
            candidate.Near128Samples = 0;
            candidate.Near256Samples = 0;
            candidate.TargetMovingObservations = 0;
            candidate.RelativeStableWhileTargetMoves = 0;
            candidate.CoMotionSamples = 0;
            candidate.MinDistance = float.MaxValue;
            candidate.MaxDistance = 0f;
            candidate.DistanceSum = 0;
            candidate.TotalRootStep = 0f;
            candidate.TotalRelativeStep = 0f;
            candidate.MaxRelativeStep = 0f;
            candidate.LastDistance = float.NaN;
            candidate.HasPrevious = false;
        }

        private bool TryReadTarget(out uint id, out float x, out float y, out float z)
        {
            id = 0;
            x = y = z = 0f;
            if (!IsPtr(_targetPtr) || !_mem.ReadBytesQuiet(_targetPtr + BGA_ID, _bgaScratch, 0, 0x30))
                return false;

            id = BitConverter.ToUInt32(_bgaScratch, 0);
            x = BitConverter.ToSingle(_bgaScratch, 4);
            y = BitConverter.ToSingle(_bgaScratch, 8);
            z = BitConverter.ToSingle(_bgaScratch, 12);
            return IsValidCoordinate(x) && IsValidCoordinate(y) && IsValidCoordinate(z);
        }

        private bool TryReadNodeTransform(long node, float targetX, float targetY, float targetZ,
            out float x, out float y, out float z, out string source, out float targetDistance)
        {
            x = y = z = 0f;
            source = "INVALID";
            targetDistance = float.NaN;
            if (!IsPtr(node))
                return false;

            if (_mem.ReadBytesQuiet(node + SPACE_WORLD_MATRIX, _transformScratch, 0, MATRIX_BYTES) &&
                TryDecodeMatrixTranslation(_transformScratch, out float mx, out float my, out float mz))
            {
                x = mx;
                y = my;
                z = mz;
                source = "WorldMatrix148";
                targetDistance = Distance(targetX, targetY, targetZ, x, y, z);
                return float.IsFinite(targetDistance);
            }

            if (_mem.ReadBytesQuiet(node + SPACE_WORLD_TRANSLATION, _translationScratch, 0, _translationScratch.Length))
            {
                float tx = BitConverter.ToSingle(_translationScratch, 0);
                float ty = BitConverter.ToSingle(_translationScratch, 4);
                float tz = BitConverter.ToSingle(_translationScratch, 8);
                if (IsValidCoordinate(tx) && IsValidCoordinate(ty) && IsValidCoordinate(tz))
                {
                    x = tx;
                    y = ty;
                    z = tz;
                    source = "Translation178";
                    targetDistance = Distance(targetX, targetY, targetZ, x, y, z);
                    return float.IsFinite(targetDistance);
                }
            }
            return false;
        }

        private static bool TryDecodeMatrixTranslation(byte[] bytes, out float x, out float y, out float z)
        {
            x = y = z = 0f;
            if (bytes == null || bytes.Length < MATRIX_BYTES)
                return false;
            for (int i = 0; i < 16; i++)
            {
                if (!float.IsFinite(BitConverter.ToSingle(bytes, i * 4)))
                    return false;
            }

            x = BitConverter.ToSingle(bytes, 0x30);
            y = BitConverter.ToSingle(bytes, 0x34);
            z = BitConverter.ToSingle(bytes, 0x38);
            float w = BitConverter.ToSingle(bytes, 0x3C);
            return IsValidCoordinate(x) && IsValidCoordinate(y) && IsValidCoordinate(z) &&
                   float.IsFinite(w) && MathF.Abs(w) > 0.0001f;
        }

        private long ReadPtr(long address)
        {
            if (!IsPtr(address))
                return 0;
            return _mem.ReadBytesQuiet(address, _ptrScratch, 0, 8)
                ? BitConverter.ToInt64(_ptrScratch, 0)
                : 0;
        }

        private static long ReadQword(byte[] bytes, int offset) =>
            bytes != null && offset >= 0 && offset + 8 <= bytes.Length
                ? BitConverter.ToInt64(bytes, offset)
                : 0;

        private static bool IsPtr(long value) =>
            value >= 0x10000 && value < 0x0000800000000000L && (value & 0x7L) == 0;

        private static bool IsValidCoordinate(float value) =>
            float.IsFinite(value) && MathF.Abs(value) <= MAX_WORLD_COORD;

        private static float Distance(float ax, float ay, float az, float bx, float by, float bz)
        {
            float dx = bx - ax;
            float dy = by - ay;
            float dz = bz - az;
            return MathF.Sqrt(dx * dx + dy * dy + dz * dz);
        }

        private static string FormatDistance(float value) =>
            float.IsFinite(value) ? value.ToString("F3", CultureInfo.InvariantCulture) : "N/A";

        private static string FormatCoordinate(float value) =>
            float.IsFinite(value) ? value.ToString("F3", CultureInfo.InvariantCulture) : "N/A";

        private void EmitFinal(string status)
        {
            Write("");
            Write("============================================================");
            Write("[STAGE102][FINAL][RESULT]");
            Write("============================================================");
            Write($"[STAGE102][FINAL][STATUS] {status}");
            Write($"[STAGE102][FINAL][TARGET] bga=0x{_targetPtr:X} id=0x{_targetId:X8} selectionMethod={_targetSelectionMethod} preselectionSamples={_targetSelectionSamples} preselectionMovingTransitions={_targetSelectionTransitions} preselectionPlausibleStep={_targetSelectionPlausibleStep:F3} preselectionOutlierSteps={_targetSelectionOutliers} targetLostSamples={_targetLostSamples} targetIdMismatchSamples={_targetIdMismatchSamples} targetMotionTransitions={_targetMotionTransitions} targetOutlierTransitions={_targetOutlierTransitions} targetTotalStep={_targetTotalStep:F3}");
            Write($"[STAGE102][FINAL][DISCOVERY] attempts={_discoveryAttempts} objectsInspected={_discoveryObjectsInspected} lastAttemptBgaObjects={_firstHopObjectsOnLastAttempt} lastAttemptNestedObjects={_nestedObjectsOnLastAttempt} totalNestedObjectsRead={_nestedObjectsTotalRead} uniqueNestedPointersSeen={_nestedScanned.Count} pendingNested={_nestedQueue.Count} nestedReadFailures={_nestedReadFailures} directOrNestedModels={_directModelCandidates} sceneAnchors={_sceneAnchorsScanned} sceneNodes={_sceneNodes.Count} pointerReferences={_scenePointerReferences} candidatePool={_candidates.Count}");
            Write("[STAGE102][FINAL][RANKING-POLICY] measurement-order-only; no automatic candidate acceptance; order=relativeStableWhileTargetMoves-desc,near128Samples-desc,validTransforms-desc,totalRelativeStep-asc,meanDistance-asc");

            int rank = 0;
            foreach (CandidateRecord c in _candidates.Values
                .OrderByDescending(c => c.RelativeStableWhileTargetMoves)
                .ThenByDescending(c => c.Near128Samples)
                .ThenByDescending(c => c.ValidTransformSamples)
                .ThenBy(c => float.IsFinite(AverageDistance(c)) ? c.TotalRelativeStep : float.MaxValue)
                .ThenBy(c => float.IsFinite(AverageDistance(c)) ? AverageDistance(c) : float.MaxValue)
                .ThenBy(c => c.ModelPtr))
            {
                rank++;
                string minDistance = c.MinDistance == float.MaxValue
                    ? "N/A"
                    : c.MinDistance.ToString("F3", CultureInfo.InvariantCulture);
                float meanDistance = AverageDistance(c);
                Write($"[STAGE102][FINAL][CANDIDATE] rank={rank} model=0x{c.ModelPtr:X} root=0x{c.RootPtr:X} fromBgaClosure={(c.FromBgaClosure ? 1 : 0)} sourceNode=0x{c.SourceNodePtr:X} path={c.Path} discoveryDistance={FormatDistance(c.DiscoveryDistance)} finalDistance={FormatDistance(c.LastDistance)} minDistance={minDistance} maxDistance={FormatDistance(c.MaxDistance)} meanDistance={FormatDistance(meanDistance)} structureValid={c.StructurallyValidSamples} structureInvalid={c.StructurallyInvalidSamples} validTransforms={c.ValidTransformSamples} near128={c.Near128Samples} near256={c.Near256Samples} targetMovingObservations={c.TargetMovingObservations} stableRelativeWhileTargetMoves={c.RelativeStableWhileTargetMoves} coMotion={c.CoMotionSamples} totalRootStep={c.TotalRootStep:F3} totalRelativeStep={c.TotalRelativeStep:F3} maxRelativeStep={c.MaxRelativeStep:F3}");
            }

            if (string.Equals(status, "NO_CANDIDATE_POOL", StringComparison.Ordinal))
            {
                Write("[STAGE102][FINAL][VERDICT] targetMovementSufficient=NOT_SAMPLED targetAssociationPattern=UNCONFIRMED anatomicalHierarchyProven=0 reason=no candidate pool was discovered; association sampling never started");
            }
            else
            {
                bool movementObserved = _targetMotionTransitions >= MIN_ASSOCIATION_MOVING_OBSERVATIONS;
                Write($"[STAGE102][FINAL][VERDICT] targetMovementSufficient={(movementObserved ? 1 : 0)} requiredMovingTransitions={MIN_ASSOCIATION_MOVING_OBSERVATIONS} targetTotalStep={_targetTotalStep:F3} movingTransitions={_targetMotionTransitions} candidateRootAssociationIsMeasurementOnly=1 anatomicalHierarchyProven=0");
            }
            Write($"[STAGE102][FINAL][BGA-TRACE-SUMMARY] stationarySamples={_targetStationarySamples} stationaryEpisodes={_targetStationaryEpisodes} currentStationaryRun={_targetStationaryRun} largeRawJumpTransitions={_largeRawJumpTransitions} largestRawJump={_largestRawJump:F3} snapshotValidSamples={_snapshotSeenSamples} snapshotMissingOrStaleSamples={_snapshotMissingSamples} snapshotDivergenceSamples={_snapshotDivergenceSamples} snapshotDivergenceThreshold={SNAPSHOT_DIVERGENCE_THRESHOLD:F2} snapshotComparison=rawBgaVsOverlayEntityDataCopyNotIndependentGameTransform");
            Write($"[STAGE102][FINAL][TRANSFORM-PROBE-SUMMARY] probes={_transformProbes.Count} genericProbes={_genericTransformProbeCount} maxProbes={MAX_TRANSFORM_PROBES} probesWithStationaryBgaMovement={_transformProbes.Values.Count(p => p.MovesWhileBgaStationary > 0)}");
            foreach (TransformProbeRecord probe in _transformProbes.Values
                .OrderByDescending(p => p.MovesWhileBgaStationary)
                .ThenByDescending(p => p.MovingTransitions)
                .ThenBy(p => p.Ptr))
            {
                float meanDistance = probe.ValidSamples > 0 ? (float)(probe.TargetDistanceSum / probe.ValidSamples) : float.NaN;
                Write($"[STAGE102][FINAL][TRANSFORM-PROBE] ptr=0x{probe.Ptr:X} vtable=0x{probe.Vtable:X} priority={probe.Priority} validSamples={probe.ValidSamples} invalidSamples={probe.InvalidSamples} movingTransitions={probe.MovingTransitions} movesWhileBgaStationary={probe.MovesWhileBgaStationary} samplesWhileBgaStationary={probe.SamplesWhileBgaStationary} totalStep={probe.TotalStep:F3} maxStep={probe.MaxStep:F3} minDistance={FormatDistance(probe.MinTargetDistance == float.MaxValue ? float.NaN : probe.MinTargetDistance)} meanDistance={FormatDistance(meanDistance)} maxDistance={FormatDistance(probe.MaxTargetDistance)} lastDistance={FormatDistance(probe.LastDistance)} path={probe.Path}");
            }
            bool rootHandoffPattern = _transformProbes.Values.Any(p =>
                p.Path != null && p.Path.Contains("::RootSpaceNode", StringComparison.Ordinal) && p.MovesWhileBgaStationary >= 2);
            bool genericHandoffPattern = _transformProbes.Values.Any(p => p.Priority < 3 && p.MovesWhileBgaStationary >= 2);
            bool anyProbeMovement = _transformProbes.Values.Any(p => p.MovesWhileBgaStationary >= 2);
            Write($"[STAGE102][FINAL][HANDOFF-PATTERN] candidateModelRootMovedDuringBgaStationarity={(rootHandoffPattern ? 1 : 0)} genericClosureObjectMovedDuringBgaStationarity={(genericHandoffPattern ? 1 : 0)} anyProbeIncludingNonRootSpaceNodesMovedDuringBgaStationarity={(anyProbeMovement ? 1 : 0)} minimumProbeMovements=2; these are candidate patterns only and do not prove a vehicle handoff");
            EmitFocusedRootResults();
            Write("[STAGE102][FINAL][NEXT] compare the selected enemy's BGA trace, entity snapshot, and transform probes against the real mount/dismount timing; do not change the renderer from this diagnostic alone");
            Write("============================================================");
            lock (_sync)
            {
                try { _writer?.Flush(); } catch { }
            }
        }

        private static bool IsPlausibleTargetMotion(float step) =>
            float.IsFinite(step) && step >= TARGET_MOVEMENT_THRESHOLD && step <= MAX_ASSOCIATION_TARGET_STEP;

        private static float AverageDistance(CandidateRecord candidate) =>
            candidate.ValidTransformSamples > 0
                ? (float)(candidate.DistanceSum / candidate.ValidTransformSamples)
                : float.NaN;

        private void CompleteCapture()
        {
            _captureComplete = true;
            try { _timer?.Change(Timeout.Infinite, Timeout.Infinite); } catch { }
        }

        private void Write(string message)
        {
            Console.WriteLine(message);
            lock (_sync)
            {
                try
                {
                    _writer?.WriteLine($"{DateTimeOffset.Now:O} {message}");
                    if (_writer != null && (message.Contains("[FINAL]", StringComparison.Ordinal) || _sample % 5 == 0))
                        _writer.Flush();
                }
                catch { }
            }
        }

        private static void SafeConsole(string message)
        {
            try { Console.WriteLine(message); } catch { }
        }

        public void Dispose()
        {
            if (Interlocked.Exchange(ref _disposed, 1) != 0)
                return;
            try { _timer?.Change(Timeout.Infinite, Timeout.Infinite); } catch { }
            try { _timer?.Dispose(); } catch { }
            lock (_sync)
            {
                try { _writer?.Flush(); } catch { }
                try { _writer?.Dispose(); } catch { }
                _writer = null;
            }
        }
    }
}

# Version 5 Release Notes

## Purpose

Version 5 adds deterministic randomized robustness checks to the standalone synthetic geometry harness. It builds on Version 4's known-answer camera/matrix contract tests and adds seeded property checks over generated inputs.

## Validation in the build environment

- Regression tests: **56/56 passed**.
- Version 4 coordinate contract audit: **14/14 checks passed**.
- Randomized robustness audit: **5/5 property checks passed**.
- Randomized test cases: **1,200/1,200 passed**.
- Default seed base: `20261013`; each check records its own derived seed in `results/robustness_audit.json` and `results/robustness_audit.txt`.
- Synthetic scene generation: **5/5 scenarios completed**, each with 19/19 known joints projected and 18/18 expected connections.
- Dependencies: Python standard library only.

## New randomized properties

1. A synthetic rigid model transform preserves distances between point pairs.
2. Translating the camera and scene together preserves screen coordinates and camera depth.
3. Positive camera-right and camera-up offsets move projected points in the declared screen directions.
4. Rendered parent-child edges exist only when both endpoints have valid projected positions.
5. Deliberate faults are attributed to the first rejecting pipeline stage, and downstream stages do not run after rejection.

## Run on Windows

From the extracted `stage100_synthetic_harness` folder:

```bat
run_tests.bat
run_harness.bat
```

Expected: 56 tests pass, five SVG scenes/reports generate, the coordinate audit reports 14/14 checks, and the robustness audit reports 1,200/1,200 property cases and 5/5 checks passing.

## Scope boundary

All data is synthetic and generated locally by the harness. These tests validate only the harness's documented mathematical contract. They do not infer or validate the matrix convention, data source, or rendering behavior of any other application. The uploaded Stage 100 source archive remains unchanged.

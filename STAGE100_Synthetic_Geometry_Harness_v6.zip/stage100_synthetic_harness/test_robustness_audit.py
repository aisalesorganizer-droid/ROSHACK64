import unittest

from robustness_audit import (
    check_edge_integrity,
    check_failure_stage_attribution,
    check_projection_axis_monotonicity,
    check_projection_translation_invariance,
    check_rigid_distance_invariance,
)


class DeterministicRobustnessTests(unittest.TestCase):
    def assert_check_passes(self, check):
        self.assertTrue(check["pass"], msg=f"{check['name']} failures: {check['first_failures']}")
        self.assertEqual(check["failed_cases"], 0)
        self.assertEqual(check["passed_cases"], check["cases"])

    def test_rigid_transforms_preserve_pairwise_distances(self):
        self.assert_check_passes(check_rigid_distance_invariance(cases=120, seed=31001))

    def test_translating_camera_and_scene_preserves_projected_coordinates(self):
        self.assert_check_passes(check_projection_translation_invariance(cases=100, seed=31002))

    def test_camera_basis_has_expected_screen_axis_directions(self):
        self.assert_check_passes(check_projection_axis_monotonicity(cases=100, seed=31003))

    def test_edges_never_connect_rejected_synthetic_joints(self):
        self.assert_check_passes(check_edge_integrity(cases=80, seed=31004))

    def test_failure_is_attributed_to_the_first_rejecting_stage(self):
        self.assert_check_passes(check_failure_stage_attribution(cases_per_fault=15, seed=31005))

    def test_fixed_seed_is_reproducible(self):
        first = check_rigid_distance_invariance(cases=40, seed=987654)
        second = check_rigid_distance_invariance(cases=40, seed=987654)
        self.assertEqual(first, second)


if __name__ == "__main__":
    unittest.main(verbosity=2)

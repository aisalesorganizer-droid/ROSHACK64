@echo off
py -3 -m unittest -v
if errorlevel 1 exit /b 1

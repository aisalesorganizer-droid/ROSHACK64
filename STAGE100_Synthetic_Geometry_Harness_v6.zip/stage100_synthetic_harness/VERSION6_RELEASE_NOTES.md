# Version 6 Release Notes

Version 6 adds targeted mutation / fault-injection checks to the standalone synthetic geometry harness. It preserves the Version 5 pipeline and adds test-only defective behavior probes to test whether explicit known-answer invariants detect them.

## Validation results
- 70/70 unit tests pass in the build environment.
- 14/14 matrix and camera contract checks pass.
- 1,200/1,200 deterministic randomized cases pass across five properties.
- 13/13 selected mutation probes are detected; zero selected probes survive.
- Five synthetic scenes are regenerated.

## New artifacts
- `mutation_audit.py`
- `test_mutation_audit.py`
- `results/mutation_audit.json`
- `results/mutation_audit.txt`

## Interpret with care
The 13/13 result is a targeted probe detection rate, not automatic source-level mutation coverage. This release only validates the harness's own synthetic math and render-data contract. It does not inspect or modify the original application or establish its implementation conventions.

## Next verification
Run `run_tests.bat` and `run_harness.bat` on Windows after extracting the ZIP into a new folder. Windows verification of Version 6 is pending.

"""Rendering-boundary tests for synthetic SVG output only."""
import math
import unittest
import xml.etree.ElementTree as ET

from synthetic_pipeline import (
    Camera,
    Joint,
    ProjectedPoint,
    Viewport,
    identity4,
    point_in_viewport,
    render_svg,
    run_pipeline,
    synthetic_rig,
    model_matrix,
)


class ViewportBoundaryTests(unittest.TestCase):
    def test_viewport_uses_inclusive_left_top_and_exclusive_right_bottom(self):
        viewport = Viewport(100, 80)
        self.assertTrue(point_in_viewport(ProjectedPoint(0.0, 0.0, 1.0), viewport))
        self.assertTrue(point_in_viewport(ProjectedPoint(99.999, 79.999, 1.0), viewport))
        self.assertFalse(point_in_viewport(ProjectedPoint(100.0, 20.0, 1.0), viewport))
        self.assertFalse(point_in_viewport(ProjectedPoint(20.0, 80.0, 1.0), viewport))
        self.assertFalse(point_in_viewport(ProjectedPoint(-0.001, 20.0, 1.0), viewport))
        self.assertFalse(point_in_viewport(ProjectedPoint(20.0, -0.001, 1.0), viewport))

    def test_both_offscreen_endpoints_can_form_a_clipped_crossing_segment(self):
        joints = [
            Joint("left_end", (-20.0, 0.0, 10.0), None),
            Joint("right_end", (20.0, 0.0, 10.0), "left_end"),
        ]
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0), vertical_fov_degrees=90.0)
        viewport = Viewport(100, 100)
        result = run_pipeline(joints, identity4(), camera, viewport)

        self.assertFalse(result.in_viewport["left_end"])
        self.assertFalse(result.in_viewport["right_end"])
        self.assertEqual(result.edges, [("left_end", "right_end")])
        svg = render_svg(result, viewport, "crossing segment")
        root = ET.fromstring(svg)
        self.assertIsNotNone(root.find(".//{http://www.w3.org/2000/svg}clipPath"))
        line = root.find(".//{http://www.w3.org/2000/svg}line[@x1='-50.000'][@x2='150.000']")
        self.assertIsNotNone(line, "the crossing line should remain in SVG and be clipped by the viewport")

    def test_title_with_xml_metacharacters_round_trips_safely(self):
        joints = [Joint("root", (0.0, 0.0, 5.0), None)]
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0))
        title = 'A&B <synthetic> "test"'
        result = run_pipeline(joints, identity4(), camera, Viewport(100, 100))
        svg = render_svg(result, Viewport(100, 100), title)
        root = ET.fromstring(svg)
        texts = [el.text for el in root.findall(".//{http://www.w3.org/2000/svg}text")]
        self.assertEqual(texts[0], title)

    def test_nearly_overlapping_joints_still_produce_valid_svg(self):
        joints = [
            Joint("a", (0.0010, 0.0, 10.0), None),
            Joint("b", (0.0011, 0.0, 10.0), "a"),
        ]
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0), vertical_fov_degrees=90.0)
        viewport = Viewport(100, 100)
        result = run_pipeline(joints, identity4(), camera, viewport)
        self.assertEqual(len(result.edges), 1)
        root = ET.fromstring(render_svg(result, viewport, "nearly overlapping"))
        self.assertIsNotNone(root.find(".//{http://www.w3.org/2000/svg}line"))

    def test_zero_length_edge_does_not_break_svg_generation(self):
        joints = [
            Joint("a", (0.0, 0.0, 10.0), None),
            Joint("b", (0.0, 0.0, 10.0), "a"),
        ]
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0))
        viewport = Viewport(100, 100)
        result = run_pipeline(joints, identity4(), camera, viewport)
        svg = render_svg(result, viewport, "zero length")
        root = ET.fromstring(svg)
        lines = root.findall(".//{http://www.w3.org/2000/svg}line")
        zero_length = [
            line for line in lines
            if line.attrib.get("x1") == line.attrib.get("x2")
            and line.attrib.get("y1") == line.attrib.get("y2")
        ]
        self.assertTrue(zero_length, "the coincident-joint edge should remain valid SVG")

    def test_minimum_head_ring_radius_is_preserved_for_small_projection(self):
        joints = synthetic_rig()
        camera = Camera((0.0, 1.0, 0.0), (0.0, 1.0, 1.0), far_plane=1000.0)
        viewport = Viewport(600, 800)
        result = run_pipeline(joints, model_matrix((0.0, 0.0, 500.0)), camera, viewport)
        svg = render_svg(result, viewport, "distant synthetic rig")
        root = ET.fromstring(svg)
        circles = root.findall(".//{http://www.w3.org/2000/svg}circle")
        rings = [c for c in circles if c.attrib.get("fill") == "none" and c.attrib.get("stroke") == "#ffd166"]
        self.assertEqual(len(rings), 1)
        self.assertGreaterEqual(float(rings[0].attrib["r"]), 2.0)
        self.assertTrue(math.isfinite(float(rings[0].attrib["cx"])))

    def test_one_pixel_viewport_generates_valid_svg(self):
        joints = [Joint("root", (0.0, 0.0, 5.0), None)]
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0))
        viewport = Viewport(1, 1)
        result = run_pipeline(joints, identity4(), camera, viewport)
        root = ET.fromstring(render_svg(result, viewport, "tiny viewport"))
        self.assertEqual(root.attrib["width"], "1")
        self.assertEqual(root.attrib["height"], "1")


if __name__ == "__main__":
    unittest.main(verbosity=2)

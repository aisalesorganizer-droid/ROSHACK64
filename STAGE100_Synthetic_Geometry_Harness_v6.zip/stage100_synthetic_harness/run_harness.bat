@echo off
py -3 synthetic_pipeline.py --output results
if errorlevel 1 exit /b 1
py -3 coordinate_contract_audit.py --output results
if errorlevel 1 exit /b 1
py -3 robustness_audit.py --output results
if errorlevel 1 exit /b 1
py -3 mutation_audit.py --output results
if errorlevel 1 exit /b 1

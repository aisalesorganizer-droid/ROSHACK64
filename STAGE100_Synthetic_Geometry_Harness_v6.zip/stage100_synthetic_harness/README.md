# Stage 100 Synthetic Geometry Pipeline

A small, dependency-free Python test harness for validating a **known, synthetic** 3D skeleton pipeline. It does not inspect other processes, read game memory, or use live-game/opponent data. It is deliberately separate from the uploaded Stage 100 source archive.

## What this gives us

The pipeline is divided into explicit stages:

1. **Source:** known joint coordinates, parent links, and a source-validity flag.
2. **Transform:** a documented 4×4 model matrix.
3. **Validate:** reject non-finite coordinates and preserve source validity.
4. **Project:** camera basis, near/far depth checks, and perspective projection.
5. **Render data:** connect only joints that both survived the earlier stages; output SVG for visual inspection.

The convention is explicitly set for this harness: row-major matrix storage, matrix multiplied by column-vector points, translation in the final column, +Y world-up, and a vertical field of view. This convention is a controlled test input, **not a claim about the original application's matrix convention**.

## Requirements

Python 3.10 or newer. No third-party packages are required.

## Run tests on Windows

Open Command Prompt in this folder and run:

```bat
py -3 -m unittest -v
```

Expected result: all 70 tests pass.

## Generate scenes and audit reports

Run `run_harness.bat` to generate the five synthetic scenes, the 14-check coordinate contract report, and the deterministic robustness report. The equivalent commands are:

```bat
py -3 synthetic_pipeline.py --output results
py -3 coordinate_contract_audit.py --output results
py -3 robustness_audit.py --output results
py -3 mutation_audit.py --output results
```

The results folder will contain SVG scenes and text/JSON reports for:

- a baseline camera and 1024×768 viewport;
- a model rotated 35 degrees;
- a camera yawed 25 degrees;
- a 1920×1080 viewport;
- a 600×800 portrait viewport.

Open the `.svg` files in a browser. Each scene includes a known skeleton, projected joint markers, a head marker, and diagnostic counts.

## Matrix and camera coordinate contract audit

`coordinate_contract_audit.py` compares explicit synthetic conventions using known-answer matrices and points. It checks row-major and column-major storage round trips, translation location, column-vector versus row-vector multiplication, affine invariants, a known 90-degree yaw, rotation/reflection determinant signs, camera basis orientation, screen-axis signs, behind-camera rejection, and homogeneous direction vectors (`w=0`).

Run it directly with:

```bat
py -3 coordinate_contract_audit.py --output results
```

It generates `results/matrix_convention_audit.json` and `results/matrix_convention_audit.txt`. A deliberate storage-order mismatch is included to show how a matrix can produce finite but wrong coordinates; the audit flags the mismatch using the affine invariant and known-answer result. Correct row-major and column-major serialization both produce the same logical transformation when the encoding and decoding order agree.

This audit is a contract test for the synthetic harness only. It does not infer the convention used by the original application and must not be used as proof of another application's matrix layout.

## Interpretation and limits

These tests verify the harness's math against known answers and confirm that invalid source joints do not get reintroduced merely because their coordinates are finite. Passing tests do **not** validate the original application's memory layout, matrix convention, game-specific data, or live rendering. Those are separate questions and must not be inferred from this synthetic harness.

## Stage-by-stage trace

`results/node_trace.json` contains one record per joint per scenario, including the source position, parent link, preserved source-validity flag, transformed world position, projected pixel coordinates/depth, viewport inclusion, rejection reason, and explicit `stage_status` for Source, Transform, Validate, Project, and Viewport. `results/run_report.json` also includes an `edge_trace` for every declared parent-child edge, including rejected edges and the reason they were not rendered.

## Adversarial / edge-case tests

The regression suite includes deliberately invalid inputs to verify failure attribution:

- non-finite source coordinates and `source_valid=False`;
- malformed transforms and invalid homogeneous W;
- finite transform inputs that overflow to non-finite world coordinates;
- points before/at the near plane and at the far plane;
- invalid FOV, near/far configuration, zero-size viewport, degenerate camera direction, and an up vector parallel to view direction;
- off-screen points that are successfully projected but classified outside the viewport;
- duplicate joint names, unknown parent references, and cyclic parent hierarchies;
- an invalid middle joint, verifying that edges are not drawn across rejected nodes;
- viewport boundary rules, segments crossing the viewport with both endpoints off-screen, SVG XML validity/escaping, nearly coincident joints, zero-length edges, one-pixel viewports, and minimum head-ring size at small projected scales.

A passing suite demonstrates that these controlled cases are attributed to the intended stage. It does not validate any third-party or live application's data source or coordinate conventions.


## Deterministic randomized robustness audit (Version 5)

`robustness_audit.py` runs seeded property checks against generated inputs. Its derived seeds are fixed, so the same code and seed repeat the same cases. It checks rigid-transform distance preservation, projection invariance when camera and scene are translated together, expected screen-axis directions, exact parent-child edge integrity when joints are rejected, and attribution of malformed inputs to the first rejecting stage.

Run it with:

```bat
py -3 robustness_audit.py --output results
py -3 mutation_audit.py --output results
```

The default run executes 1,200 deterministic randomized cases across five property checks and writes `results/robustness_audit.json` and `results/robustness_audit.txt`. These checks exercise only this harness's documented mathematical contract; they do not infer or validate conventions in other software.


## Targeted mutation / fault-injection audit (Version 6)

`mutation_audit.py` defines thirteen deliberately defective reference behaviors and checks whether a named known-answer invariant catches each one. Probes cover matrix convention mismatch, translation placement, rotation sign, screen-axis sign, omitted near/far depth gates, inclusive viewport boundary errors, dropped source-validity metadata, invented edges across a rejected joint, invalid homogeneous W fallback, non-finite projected output, and reversed camera-right basis.

Run with:

```bat
py -3 mutation_audit.py --output results
```

It writes `results/mutation_audit.json` and `results/mutation_audit.txt`. A result of 13/13 means all thirteen *selected probes* were detected by their corresponding oracle. This is not automatic source-level mutation testing and is not a general test-coverage percentage. It applies only to the synthetic coordinate/render-data contract, not to any external application's implementation.

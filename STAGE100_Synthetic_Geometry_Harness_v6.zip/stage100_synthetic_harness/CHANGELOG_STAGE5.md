# Changelog — Coordinate Contract Audit

## Added

- A standalone matrix/camera convention audit using only synthetic known-answer inputs.
- Separate helpers to serialize and decode logical 4×4 matrices in row-major and column-major storage order.
- Affine invariants distinguishing column-vector and row-vector conventions.
- Diagnostics for convention mismatch, homogeneous coordinates, handedness, camera basis, projection axis direction, and behind-camera rejection.
- Automated regression tests for these contracts.
- Windows `run_harness.bat` now generates both the synthetic scenes and the matrix/camera audit reports.

## Validation limits

The audit validates only its declared synthetic convention. It does not inspect, infer, or validate another application's memory layout or rendering pipeline. No source from the original Stage 100 project was modified.

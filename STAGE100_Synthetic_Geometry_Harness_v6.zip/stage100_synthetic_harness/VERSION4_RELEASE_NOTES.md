# Version 4 Release Notes

## Purpose

Version 4 adds a synthetic-only coordinate contract audit to the previously validated Version 3 harness. It explicitly tests how matrix storage order, multiplication side, translation placement, camera basis, handedness, projection axis direction, and homogeneous direction vectors behave under declared conventions.

## Validation performed in the build environment

- Regression suite: **50/50 passed**.
- Standalone matrix/camera coordinate audit: **14/14 checks passed**.
- Synthetic scene generation: **5/5 scenarios completed**; each projected 19/19 known joints and retained 18/18 expected edges.
- Package is independent of third-party Python packages.

## Run on Windows

From the extracted `stage100_synthetic_harness` folder:

```bat
run_tests.bat
run_harness.bat
```

Expected: 50 tests pass, five SVG scenes/reports generate, and the coordinate audit reports 14/14 checks passed.

## Scope boundary

All tests use generated known inputs. The audit is not evidence of the matrix convention or data correctness of the original application. The original Stage 100 source archive has not been modified.

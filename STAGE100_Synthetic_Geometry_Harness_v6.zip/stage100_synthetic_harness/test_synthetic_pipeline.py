import math
import unittest

from synthetic_pipeline import (
    Camera,
    Joint,
    PipelineError,
    Viewport,
    identity4,
    make_scenarios,
    model_matrix,
    point_in_viewport,
    project_point,
    run_pipeline,
    synthetic_rig,
    transform_point,
)


class TransformTests(unittest.TestCase):
    def test_identity_transform_preserves_point(self):
        self.assertEqual(transform_point(identity4(), (1.25, -2.0, 3.5)), (1.25, -2.0, 3.5))

    def test_translation_uses_final_column(self):
        m = model_matrix((4.0, 5.0, 6.0), 0.0)
        result = transform_point(m, (1.0, 2.0, 3.0))
        self.assertAlmostEqual(result[0], 5.0)
        self.assertAlmostEqual(result[1], 7.0)
        self.assertAlmostEqual(result[2], 9.0)

    def test_yaw_rotation_has_known_answer(self):
        m = model_matrix((0.0, 0.0, 0.0), 90.0)
        result = transform_point(m, (1.0, 0.0, 0.0))
        self.assertAlmostEqual(result[0], 0.0, places=7)
        self.assertAlmostEqual(result[1], 0.0, places=7)
        self.assertAlmostEqual(result[2], -1.0, places=7)

    def test_non_finite_transform_input_is_rejected(self):
        with self.assertRaises(PipelineError):
            transform_point(identity4(), (math.nan, 0.0, 1.0))


class ProjectionTests(unittest.TestCase):
    def setUp(self):
        self.camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0), vertical_fov_degrees=90.0)

    def test_point_on_forward_axis_projects_to_viewport_center(self):
        vp = Viewport(1000, 800)
        p = project_point((0.0, 0.0, 10.0), self.camera, vp)
        self.assertAlmostEqual(p.x, 500.0)
        self.assertAlmostEqual(p.y, 400.0)
        self.assertAlmostEqual(p.depth, 10.0)

    def test_projection_matches_known_offset(self):
        vp = Viewport(1000, 800)
        # Vertical FOV 90 degrees makes focal length = viewport height / 2 = 400.
        p = project_point((2.0, 2.0, 10.0), self.camera, vp)
        self.assertAlmostEqual(p.x, 580.0)
        self.assertAlmostEqual(p.y, 320.0)

    def test_same_aspect_ratio_scales_screen_coordinates(self):
        small = project_point((1.0, 0.5, 8.0), self.camera, Viewport(800, 600))
        large = project_point((1.0, 0.5, 8.0), self.camera, Viewport(1600, 1200))
        self.assertAlmostEqual(large.x, small.x * 2.0)
        self.assertAlmostEqual(large.y, small.y * 2.0)

    def test_point_behind_near_plane_is_rejected(self):
        with self.assertRaisesRegex(PipelineError, "depth range"):
            project_point((0.0, 0.0, 0.05), self.camera, Viewport(1000, 800))

    def test_exact_near_plane_boundary_is_rejected(self):
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0), near_plane=0.1, far_plane=100.0)
        with self.assertRaisesRegex(PipelineError, "depth range"):
            project_point((0.0, 0.0, 0.1), camera, Viewport(1000, 800))

    def test_exact_far_plane_boundary_is_rejected(self):
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0), near_plane=0.1, far_plane=100.0)
        with self.assertRaisesRegex(PipelineError, "depth range"):
            project_point((0.0, 0.0, 100.0), camera, Viewport(1000, 800))

    def test_zero_sized_viewport_is_rejected(self):
        with self.assertRaisesRegex(PipelineError, "positive"):
            project_point((0.0, 0.0, 1.0), self.camera, Viewport(0, 800))

    def test_invalid_fov_is_rejected(self):
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0), vertical_fov_degrees=0.0)
        with self.assertRaisesRegex(PipelineError, "field of view"):
            project_point((0.0, 0.0, 1.0), camera, Viewport(1000, 800))

    def test_invalid_near_far_order_is_rejected(self):
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0), near_plane=5.0, far_plane=2.0)
        with self.assertRaisesRegex(PipelineError, "near < far"):
            project_point((0.0, 0.0, 1.0), camera, Viewport(1000, 800))

    def test_degenerate_camera_direction_is_rejected(self):
        camera = Camera((1.0, 1.0, 1.0), (1.0, 1.0, 1.0))
        with self.assertRaisesRegex(PipelineError, "camera forward"):
            project_point((0.0, 0.0, 1.0), camera, Viewport(1000, 800))

    def test_up_vector_parallel_to_forward_is_rejected(self):
        camera = Camera((0.0, 0.0, 0.0), (0.0, 1.0, 0.0), up_hint=(0.0, 1.0, 0.0))
        with self.assertRaisesRegex(PipelineError, "camera right"):
            project_point((0.0, 0.0, 1.0), camera, Viewport(1000, 800))

    def test_offscreen_classification_is_separate_from_projection(self):
        vp = Viewport(1000, 800)
        p = project_point((100.0, 0.0, 10.0), self.camera, vp)
        self.assertFalse(point_in_viewport(p, vp))


class PipelineValidityTests(unittest.TestCase):
    def test_invalid_source_flag_is_not_overridden_by_finite_coordinates(self):
        joints = [
            Joint("root", (0.0, 0.0, 10.0), None),
            Joint("child", (0.0, 1.0, 10.0), "root", source_valid=False),
            Joint("grandchild", (0.0, 2.0, 10.0), "child"),
        ]
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0))
        result = run_pipeline(joints, identity4(), camera, Viewport(1000, 800))
        self.assertIn("root", result.projected)
        self.assertNotIn("child", result.projected)
        self.assertIn("grandchild", result.projected)  # independently valid points can still be projected
        self.assertEqual(result.edges, [])  # but the renderer must not bridge over the invalid parent
        self.assertEqual(result.rejected["child"], "source_rejected: source_valid_false")
        self.assertEqual(result.stage_status["child"]["source"], "rejected: source_valid_false")
        self.assertEqual(result.stage_status["root"]["project"], "passed")
        self.assertEqual(len(result.edge_trace), 2)
        self.assertTrue(all(not edge.rendered for edge in result.edge_trace))

    def test_non_finite_source_position_is_rejected_at_source_stage(self):
        joints = [Joint("bad", (math.nan, 0.0, 5.0), None)]
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0))
        result = run_pipeline(joints, identity4(), camera, Viewport(100, 100))
        self.assertEqual(result.rejected["bad"], "source_rejected: non_finite_source_position")
        self.assertEqual(result.stage_status["bad"]["transform"], "not_run")

    def test_malformed_matrix_is_attributed_to_transform_stage(self):
        malformed = identity4()[:3]
        joints = [Joint("root", (0.0, 0.0, 5.0), None)]
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0))
        result = run_pipeline(joints, malformed, camera, Viewport(100, 100))
        self.assertTrue(result.rejected["root"].startswith("transform_rejected:"))
        self.assertTrue(result.stage_status["root"]["transform"].startswith("rejected:"))
        self.assertEqual(result.stage_status["root"]["validate"], "not_run")

    def test_zero_homogeneous_w_is_attributed_to_transform_stage(self):
        invalid_w = (
            (1.0, 0.0, 0.0, 0.0),
            (0.0, 1.0, 0.0, 0.0),
            (0.0, 0.0, 1.0, 0.0),
            (0.0, 0.0, 0.0, 0.0),
        )
        joints = [Joint("root", (0.0, 0.0, 5.0), None)]
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0))
        result = run_pipeline(joints, invalid_w, camera, Viewport(100, 100))
        self.assertIn("invalid homogeneous W", result.rejected["root"])
        self.assertTrue(result.stage_status["root"]["transform"].startswith("rejected:"))

    def test_non_finite_transformed_world_position_is_validation_failure(self):
        huge = (
            (1e308, 0.0, 0.0, 0.0),
            (0.0, 1.0, 0.0, 0.0),
            (0.0, 0.0, 1.0, 0.0),
            (0.0, 0.0, 0.0, 1.0),
        )
        joints = [Joint("root", (2.0, 0.0, 5.0), None)]
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0))
        result = run_pipeline(joints, huge, camera, Viewport(100, 100))
        self.assertEqual(result.rejected["root"], "validation_rejected: non_finite_world_position")
        self.assertEqual(result.stage_status["root"]["transform"], "passed")
        self.assertIn("non_finite_world_position", result.stage_status["root"]["validate"])

    def test_projection_failure_is_distinct_from_transform_failure(self):
        joints = [Joint("root", (0.0, 0.0, 0.05), None)]
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0), near_plane=0.1)
        result = run_pipeline(joints, identity4(), camera, Viewport(100, 100))
        self.assertTrue(result.rejected["root"].startswith("projection_rejected:"))
        self.assertEqual(result.stage_status["root"]["transform"], "passed")
        self.assertEqual(result.stage_status["root"]["validate"], "passed")
        self.assertTrue(result.stage_status["root"]["project"].startswith("rejected:"))

    def test_offscreen_point_is_projected_but_marked_outside(self):
        joints = [Joint("root", (100.0, 0.0, 10.0), None)]
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0), vertical_fov_degrees=90.0)
        result = run_pipeline(joints, identity4(), camera, Viewport(100, 100))
        self.assertIn("root", result.projected)
        self.assertFalse(result.in_viewport["root"])
        self.assertEqual(result.stage_status["root"]["viewport"], "outside")

    def test_duplicate_joint_names_are_rejected(self):
        joints = [Joint("same", (0.0, 0.0, 5.0), None), Joint("same", (0.0, 1.0, 5.0), None)]
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0))
        with self.assertRaisesRegex(PipelineError, "unique"):
            run_pipeline(joints, identity4(), camera, Viewport(100, 100))

    def test_parent_cycle_is_rejected(self):
        joints = [
            Joint("a", (0.0, 0.0, 5.0), "b"),
            Joint("b", (0.0, 1.0, 5.0), "a"),
        ]
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0))
        with self.assertRaisesRegex(PipelineError, "cycle"):
            run_pipeline(joints, identity4(), camera, Viewport(100, 100))

    def test_complete_synthetic_rig_projects_and_builds_expected_edges(self):
        camera = Camera((0.0, 1.0, 0.0), (0.0, 1.0, 1.0))
        rig = synthetic_rig()
        result = run_pipeline(rig, model_matrix((0.0, 0.0, 12.0)), camera, Viewport(1024, 768))
        self.assertEqual(len(result.projected), len(rig))
        self.assertEqual(len(result.edges), len(rig) - 1)
        self.assertEqual(result.rejected, {})
        self.assertIn("head_center", result.projected)

    def test_all_camera_rotation_and_viewport_scenarios_are_valid(self):
        rig = synthetic_rig()
        for name, camera, viewport, transform in make_scenarios():
            with self.subTest(scenario=name):
                result = run_pipeline(rig, transform, camera, viewport)
                self.assertEqual(len(result.projected), len(rig))
                self.assertEqual(len(result.edges), len(rig) - 1)
                self.assertEqual(result.rejected, {})

    def test_camera_yaw_changes_projection_without_dropping_joints(self):
        rig = synthetic_rig()
        scenarios = make_scenarios()
        _, base_camera, base_viewport, base_transform = scenarios[0]
        _, yaw_camera, yaw_viewport, yaw_transform = scenarios[2]
        base = run_pipeline(rig, base_transform, base_camera, base_viewport)
        yawed = run_pipeline(rig, yaw_transform, yaw_camera, yaw_viewport)
        self.assertEqual(set(base.projected), set(yawed.projected))
        self.assertNotAlmostEqual(
            base.projected["left_shoulder"].x,
            yawed.projected["left_shoulder"].x,
            places=2,
        )

    def test_missing_parent_reference_fails_early(self):
        joints = [Joint("child", (0.0, 0.0, 1.0), "missing")]
        camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0))
        with self.assertRaises(PipelineError):
            run_pipeline(joints, identity4(), camera, Viewport(100, 100))


if __name__ == "__main__":
    unittest.main(verbosity=2)

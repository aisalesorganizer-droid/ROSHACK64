# Stage 7 Changelog — Targeted Mutation / Fault-Injection Audit

## Added
- `mutation_audit.py`: thirteen deliberately defective reference behaviors, each evaluated against a named known-answer oracle.
- `test_mutation_audit.py`: 14 unit tests covering the individual probes and the aggregate no-survivors condition.
- `results/mutation_audit.json` and `results/mutation_audit.txt`: machine-readable and plain-text report.
- `run_harness.bat` now runs the mutation audit after synthetic scenes, matrix/camera contract checks, and randomized robustness checks.

## Results in this build environment
- Unit tests: 70/70 passed.
- Matrix/camera contract: 14/14 passed.
- Seeded randomized property cases: 1,200/1,200 passed across 5 properties.
- Targeted mutants detected: 13/13; no surviving selected probes.
- Five synthetic scenes regenerated.

## Scope and limitations
The probes represent hand-selected defective behaviors and are tested against the standalone synthetic harness. They are not automatic mutations of production source, do not imply broad source coverage, and make no claims about the coordinate conventions or behavior of the original application. The original Stage 100 archive is untouched. Windows verification of Version 6 remains pending.

# Stage 3 Changes — Adversarial Synthetic Pipeline Verification

## Implemented

- Added explicit per-joint stage statuses for Source, Transform, Validate, Project, and Viewport.
- Added an edge trace for every parent-child connection, including the reason an edge was not emitted.
- Separated transform/W validation from post-transform world-coordinate finiteness validation, allowing failures to be attributed to the correct stage.
- Added early rejection for cyclic parent hierarchies.
- Expanded regression coverage from 14 to 29 tests.

## Added test coverage

- Source validity flag and non-finite source coordinates.
- Malformed transform matrix, invalid homogeneous W, and non-finite transformed world coordinates.
- Near-plane and far-plane boundaries.
- Invalid FOV and near/far configuration, zero-size viewport, degenerate camera direction, and parallel camera up vector.
- Off-screen points are preserved as projected points and classified as outside the viewport.
- Duplicate joint names, unknown parent references, and parent cycles.
- No rendered edge bridges over an invalid/unprojectable parent or child.

## Results in this package

- 29 regression tests passed.
- 5 nominal synthetic scene scenarios executed.
- 95 per-joint trace records written.
- 90 edge trace records written; all 90 nominal edges rendered.
- No unexpected rejection in the nominal scenarios.

## Limitations

This is a controlled synthetic implementation only. It does not read process memory, consume live-game data, modify the original project, or confirm the coordinate conventions of any external application. Windows execution remains to be run on the user's machine.


## Stage 4 — Renderer-boundary verification

- Added `test_renderer.py` with seven renderer/viewport boundary checks.
- Verified viewport boundary inclusivity, SVG clipping for a segment whose endpoints are both off-screen, safe XML title escaping, near-coincident and zero-length segments, tiny viewport generation, and minimum head-ring radius at a distant synthetic scale.
- The combined regression suite now contains 36 tests.

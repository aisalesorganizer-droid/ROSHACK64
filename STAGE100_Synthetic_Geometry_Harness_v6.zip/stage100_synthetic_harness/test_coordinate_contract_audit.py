import unittest

from coordinate_contract_audit import (
    affine_for_column_vector,
    affine_for_row_vector,
    decode_matrix,
    flatten_matrix,
    mat4_col_vector,
    row_vector_mat4,
    run_audit,
    transpose4,
)
from synthetic_pipeline import model_matrix, transform_point


class MatrixStorageContractTests(unittest.TestCase):
    def setUp(self):
        self.matrix = model_matrix((4.0, 5.0, 6.0), 0.0)
        self.point = (1.0, 2.0, 3.0)

    def test_row_major_storage_round_trip_preserves_logical_matrix(self):
        values = flatten_matrix(self.matrix, "row_major")
        self.assertEqual(decode_matrix(values, "row_major"), self.matrix)

    def test_column_major_storage_round_trip_preserves_logical_matrix(self):
        values = flatten_matrix(self.matrix, "column_major")
        self.assertEqual(decode_matrix(values, "column_major"), self.matrix)

    def test_consistent_storage_order_produces_same_world_point(self):
        row_decoded = decode_matrix(flatten_matrix(self.matrix, "row_major"), "row_major")
        col_decoded = decode_matrix(flatten_matrix(self.matrix, "column_major"), "column_major")
        expected = (5.0, 7.0, 9.0)
        self.assertEqual(transform_point(row_decoded, self.point), expected)
        self.assertEqual(transform_point(col_decoded, self.point), expected)

    def test_mismatched_storage_decode_fails_column_affine_invariant(self):
        values = flatten_matrix(self.matrix, "row_major")
        wrongly_decoded = decode_matrix(values, "column_major")
        self.assertFalse(affine_for_column_vector(wrongly_decoded))
        self.assertTrue(affine_for_row_vector(wrongly_decoded))

    def test_column_vector_convention_places_translation_in_final_column(self):
        self.assertTrue(affine_for_column_vector(self.matrix))
        self.assertFalse(affine_for_row_vector(self.matrix))
        result = mat4_col_vector(self.matrix, (*self.point, 1.0))
        self.assertEqual(result, (5.0, 7.0, 9.0, 1.0))

    def test_row_vector_convention_uses_transposed_affine_layout(self):
        row_layout = transpose4(self.matrix)
        self.assertTrue(affine_for_row_vector(row_layout))
        self.assertFalse(affine_for_column_vector(row_layout))
        result = row_vector_mat4((*self.point, 1.0), row_layout)
        self.assertEqual(result, (5.0, 7.0, 9.0, 1.0))

    def test_non_16_value_matrix_buffer_is_rejected(self):
        with self.assertRaises(ValueError):
            decode_matrix([0.0] * 15, "row_major")

    def test_unknown_storage_order_is_rejected(self):
        with self.assertRaises(ValueError):
            flatten_matrix(self.matrix, "diagonal_major")


class CoordinateContractKnownAnswerTests(unittest.TestCase):
    def test_positive_ninety_degree_yaw_matches_declared_right_handed_convention(self):
        result = transform_point(model_matrix((0.0, 0.0, 0.0), 90.0), (1.0, 0.0, 0.0))
        self.assertAlmostEqual(result[0], 0.0, places=7)
        self.assertAlmostEqual(result[1], 0.0, places=7)
        self.assertAlmostEqual(result[2], -1.0, places=7)

    def test_rotation_and_reflection_have_distinct_orientation_determinants(self):
        report = run_audit()
        by_name = {c["name"]: c for c in report["checks"]}
        self.assertTrue(by_name["rotation_preserves_right_handed_orientation"]["pass"])
        self.assertTrue(by_name["reflection_is_detected_by_negative_determinant"]["pass"])

    def test_camera_basis_and_projection_signs_match_contract(self):
        report = run_audit()
        by_name = {c["name"]: c for c in report["checks"]}
        self.assertTrue(by_name["camera_basis_matches_plus_z_forward_plus_y_up"]["pass"])
        self.assertTrue(by_name["projection_screen_axis_signs"]["pass"])

    def test_behind_camera_case_is_rejected(self):
        report = run_audit()
        by_name = {c["name"]: c for c in report["checks"]}
        self.assertTrue(by_name["point_behind_camera_is_rejected"]["pass"])

    def test_translation_does_not_affect_direction_vectors_with_w_zero(self):
        report = run_audit()
        by_name = {c["name"]: c for c in report["checks"]}
        check = by_name["translation_does_not_change_direction_vectors_when_w_is_zero"]
        self.assertTrue(check["pass"])
        self.assertEqual(check["actual_transformed_direction"], [1.0, 0.0, 0.0, 0.0])

    def test_all_coordinate_contract_report_checks_pass(self):
        report = run_audit()
        self.assertEqual(report["checks_passed"], report["checks_total"])
        self.assertGreaterEqual(report["checks_total"], 14)


if __name__ == "__main__":
    unittest.main(verbosity=2)

"""Deterministic randomized robustness audit for the synthetic geometry harness.

This module uses only generated inputs. It does not inspect external processes,
read game memory, or depend on any third-party packages.
"""
from __future__ import annotations

import argparse
import json
import math
import random
from pathlib import Path

from synthetic_pipeline import (
    Camera,
    Joint,
    PipelineError,
    Viewport,
    add,
    camera_basis,
    length,
    model_matrix,
    project_point,
    run_pipeline,
    sub,
    synthetic_rig,
    transform_point,
)

DEFAULT_SEED = 20261013


def _unit_forward(rng: random.Random) -> tuple[float, float, float]:
    # Keep pitch away from the singular up-vector configuration.
    yaw = math.radians(rng.uniform(-175.0, 175.0))
    pitch = math.radians(rng.uniform(-65.0, 65.0))
    cp = math.cos(pitch)
    return (math.sin(yaw) * cp, math.sin(pitch), math.cos(yaw) * cp)


def _camera_case(rng: random.Random) -> tuple[Camera, Viewport, float]:
    pos = (rng.uniform(-100.0, 100.0), rng.uniform(-30.0, 30.0), rng.uniform(-100.0, 100.0))
    forward = _unit_forward(rng)
    target = add(pos, forward)
    camera = Camera(
        pos,
        target,
        up_hint=(0.0, 1.0, 0.0),
        vertical_fov_degrees=rng.uniform(45.0, 110.0),
        near_plane=0.1,
        far_plane=2000.0,
    )
    viewport = Viewport(rng.randint(320, 2560), rng.randint(240, 1440))
    depth = rng.uniform(1.0, 500.0)
    return camera, viewport, depth


def _check(name: str, cases: int, failures: list[dict], seed: int) -> dict:
    return {
        "name": name,
        "seed": seed,
        "cases": cases,
        "passed_cases": cases - len(failures),
        "failed_cases": len(failures),
        "first_failures": failures[:5],
        "pass": not failures,
    }


def check_rigid_distance_invariance(cases: int = 300, seed: int = DEFAULT_SEED + 1) -> dict:
    rng = random.Random(seed)
    failures: list[dict] = []
    for index in range(cases):
        translation = (
            rng.uniform(-100.0, 100.0),
            rng.uniform(-100.0, 100.0),
            rng.uniform(-100.0, 100.0),
        )
        matrix = model_matrix(translation, rng.uniform(-180.0, 180.0))
        a = tuple(rng.uniform(-30.0, 30.0) for _ in range(3))
        b = tuple(rng.uniform(-30.0, 30.0) for _ in range(3))
        try:
            ta = transform_point(matrix, a)
            tb = transform_point(matrix, b)
            before = length(sub(a, b))
            after = length(sub(ta, tb))
            tolerance = 1e-8 * max(1.0, before)
            if not math.isfinite(after) or abs(before - after) > tolerance:
                failures.append({"case": index, "before": before, "after": after, "tolerance": tolerance})
        except Exception as exc:  # Captured as an audit failure, never silently ignored.
            failures.append({"case": index, "error": f"{type(exc).__name__}: {exc}"})
    return _check("rigid_transform_preserves_pairwise_distance", cases, failures, seed)


def check_projection_translation_invariance(cases: int = 200, seed: int = DEFAULT_SEED + 2) -> dict:
    rng = random.Random(seed)
    failures: list[dict] = []
    for index in range(cases):
        camera, viewport, depth = _camera_case(rng)
        right, up, forward = camera_basis(camera)
        center = add(camera.position, tuple(depth * value for value in forward))
        offset_x = rng.uniform(-0.6, 0.6) * depth
        offset_y = rng.uniform(-0.4, 0.4) * depth
        point = add(add(center, tuple(offset_x * value for value in right)), tuple(offset_y * value for value in up))
        delta = (rng.uniform(-100.0, 100.0), rng.uniform(-100.0, 100.0), rng.uniform(-100.0, 100.0))
        shifted_camera = Camera(
            add(camera.position, delta),
            add(camera.target, delta),
            camera.up_hint,
            camera.vertical_fov_degrees,
            camera.near_plane,
            camera.far_plane,
        )
        try:
            original = project_point(point, camera, viewport)
            shifted = project_point(add(point, delta), shifted_camera, viewport)
            differences = (
                abs(original.x - shifted.x),
                abs(original.y - shifted.y),
                abs(original.depth - shifted.depth),
            )
            if any(not math.isfinite(d) or d > 1e-7 for d in differences):
                failures.append({"case": index, "differences": list(differences)})
        except Exception as exc:
            failures.append({"case": index, "error": f"{type(exc).__name__}: {exc}"})
    return _check("camera_and_scene_translation_preserves_projection", cases, failures, seed)


def check_projection_axis_monotonicity(cases: int = 200, seed: int = DEFAULT_SEED + 3) -> dict:
    rng = random.Random(seed)
    failures: list[dict] = []
    for index in range(cases):
        camera, viewport, depth = _camera_case(rng)
        right, up, forward = camera_basis(camera)
        center = add(camera.position, tuple(depth * value for value in forward))
        delta = rng.uniform(0.05, min(2.0, depth * 0.1))
        try:
            base = project_point(center, camera, viewport)
            right_point = project_point(add(center, tuple(delta * value for value in right)), camera, viewport)
            up_point = project_point(add(center, tuple(delta * value for value in up)), camera, viewport)
            expected_x = viewport.width * 0.5
            expected_y = viewport.height * 0.5
            valid = (
                abs(base.x - expected_x) < 1e-7
                and abs(base.y - expected_y) < 1e-7
                and right_point.x > base.x
                and abs(right_point.y - base.y) < 1e-7
                and up_point.y < base.y
                and abs(up_point.x - base.x) < 1e-7
            )
            if not valid:
                failures.append({
                    "case": index,
                    "base": [base.x, base.y],
                    "right": [right_point.x, right_point.y],
                    "up": [up_point.x, up_point.y],
                    "viewport": [viewport.width, viewport.height],
                })
        except Exception as exc:
            failures.append({"case": index, "error": f"{type(exc).__name__}: {exc}"})
    return _check("camera_right_and_up_have_expected_screen_directions", cases, failures, seed)


def check_edge_integrity(cases: int = 200, seed: int = DEFAULT_SEED + 4) -> dict:
    rng = random.Random(seed)
    failures: list[dict] = []
    for index in range(cases):
        base = synthetic_rig()
        invalid_names: set[str] = set()
        joints: list[Joint] = []
        nan_name = rng.choice(base).name if index % 3 == 0 else None
        for joint in base:
            source_valid = rng.random() >= 0.18
            position = joint.position
            if joint.name == nan_name:
                position = (math.nan, position[1], position[2])
                invalid_names.add(joint.name)
            if not source_valid:
                invalid_names.add(joint.name)
            joints.append(Joint(joint.name, position, joint.parent, source_valid))

        matrix = model_matrix(
            (rng.uniform(-1.0, 1.0), rng.uniform(-0.2, 0.2), rng.uniform(12.0, 18.0)),
            rng.uniform(-180.0, 180.0),
        )
        camera = Camera((0.0, 1.0, 0.0), (0.0, 1.0, 1.0), vertical_fov_degrees=75.0)
        viewport = Viewport(1280, 720)
        try:
            result = run_pipeline(joints, matrix, camera, viewport)
            expected_edges = [
                (joint.parent, joint.name)
                for joint in joints
                if joint.parent is not None
                and joint.parent in result.projected
                and joint.name in result.projected
            ]
            if result.edges != expected_edges:
                failures.append({"case": index, "error": "edge list differs from projected-endpoint oracle"})
                continue
            for parent, child in result.edges:
                if parent in invalid_names or child in invalid_names:
                    failures.append({"case": index, "edge": [parent, child], "error": "edge connects a deliberately invalid joint"})
                    break
            for name, point in result.projected.items():
                if not all(math.isfinite(v) for v in (point.x, point.y, point.depth)):
                    failures.append({"case": index, "joint": name, "error": "non-finite projected coordinate"})
                    break
        except Exception as exc:
            failures.append({"case": index, "error": f"{type(exc).__name__}: {exc}"})
    return _check("render_edges_require_two_projected_endpoints", cases, failures, seed)


def check_failure_stage_attribution(cases_per_fault: int = 50, seed: int = DEFAULT_SEED + 5) -> dict:
    rng = random.Random(seed)
    fault_types = (
        "source_flag_false",
        "non_finite_source",
        "invalid_homogeneous_w",
        "non_finite_world_output",
        "outside_near_plane",
        "invalid_fov",
    )
    failures: list[dict] = []
    total = cases_per_fault * len(fault_types)
    case_index = 0
    for fault_type in fault_types:
        for _ in range(cases_per_fault):
            x = rng.uniform(-1.0, 1.0)
            y = rng.uniform(-1.0, 1.0)
            z = rng.uniform(0.02, 0.09) if fault_type == "outside_near_plane" else rng.uniform(2.0, 20.0)
            joint = Joint("probe", (x, y, z), None)
            matrix = model_matrix((0.0, 0.0, 0.0), rng.uniform(-180.0, 180.0))
            if fault_type == "outside_near_plane":
                # Keep the point depth unchanged so only the near-plane gate is tested.
                matrix = model_matrix((0.0, 0.0, 0.0), 0.0)
            camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0), near_plane=0.1, far_plane=1000.0)
            if fault_type == "source_flag_false":
                joint = Joint("probe", (x, y, z), None, False)
            elif fault_type == "non_finite_source":
                joint = Joint("probe", (math.nan, y, z), None, True)
            elif fault_type == "invalid_homogeneous_w":
                matrix = (
                    (0.0, 0.0, 0.0, 0.0),
                    (0.0, 0.0, 0.0, 0.0),
                    (0.0, 0.0, 0.0, 0.0),
                    (0.0, 0.0, 0.0, 0.0),
                )
            elif fault_type == "non_finite_world_output":
                joint = Joint("probe", (2.0, y, z), None, True)
                matrix = (
                    (1e308, 0.0, 0.0, 0.0),
                    (0.0, 1.0, 0.0, 0.0),
                    (0.0, 0.0, 1.0, 0.0),
                    (0.0, 0.0, 0.0, 1.0),
                )
            elif fault_type == "invalid_fov":
                camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0), vertical_fov_degrees=0.0)

            result = run_pipeline([joint], matrix, camera, Viewport(640, 480))
            status = result.stage_status["probe"]
            expected_stage = {
                "source_flag_false": "source",
                "non_finite_source": "source",
                "invalid_homogeneous_w": "transform",
                "non_finite_world_output": "validate",
                "outside_near_plane": "project",
                "invalid_fov": "project",
            }[fault_type]
            if not status[expected_stage].startswith("rejected:"):
                failures.append({
                    "case": case_index,
                    "fault_type": fault_type,
                    "expected_rejected_stage": expected_stage,
                    "actual_status": status,
                })
            else:
                # A stage rejection should prevent all subsequent stages from passing.
                later = {"source": ["transform", "validate", "project", "viewport"], "transform": ["transform", "validate", "project", "viewport"],
                         "validate": ["project", "viewport"], "project": ["viewport"]}
                stages_to_check = later.get(expected_stage, [])
                for stage in stages_to_check:
                    if status[stage] in ("passed", "inside", "outside"):
                        failures.append({
                            "case": case_index,
                            "fault_type": fault_type,
                            "error": f"downstream stage {stage} unexpectedly ran after {expected_stage} rejection",
                            "actual_status": status,
                        })
                        break
            case_index += 1
    return _check("faults_are_attributed_to_first_rejecting_stage", total, failures, seed)


def run_audit(output_dir: Path | None = None) -> dict:
    checks = [
        check_rigid_distance_invariance(),
        check_projection_translation_invariance(),
        check_projection_axis_monotonicity(),
        check_edge_integrity(),
        check_failure_stage_attribution(),
    ]
    report = {
        "title": "Stage 100 Synthetic Geometry — Deterministic Robustness Audit",
        "scope": "Synthetic-only; no external process, live game, or opponent data used.",
        "seed_base": DEFAULT_SEED,
        "randomization": "Each property has a fixed derived seed; identical code and seed reproduce identical inputs.",
        "cases_total": sum(c["cases"] for c in checks),
        "cases_passed": sum(c["passed_cases"] for c in checks),
        "failures_total": sum(c["failed_cases"] for c in checks),
        "checks_passed": sum(1 for c in checks if c["pass"]),
        "checks_total": len(checks),
        "checks": checks,
    }
    if output_dir is not None:
        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / "robustness_audit.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
        lines = [
            "STAGE 100 SYNTHETIC ROBUSTNESS AUDIT",
            "Scope: synthetic-only; no external process, live game, or opponent data used.",
            f"Seed base: {DEFAULT_SEED}",
            f"Property cases: {report['cases_passed']}/{report['cases_total']} passed",
            f"Property checks: {report['checks_passed']}/{report['checks_total']} passed",
            f"Failures: {report['failures_total']}",
            "",
        ]
        for check in checks:
            lines.append(
                f"{check['name']}: {check['passed_cases']}/{check['cases']} cases; "
                f"failed={check['failed_cases']}; seed={check['seed']}"
            )
            for failure in check["first_failures"]:
                lines.append(f"  FIRST FAILURE: {json.dumps(failure, sort_keys=True)}")
        (output_dir / "robustness_audit.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("results"), help="Directory for the JSON and text reports")
    args = parser.parse_args()
    report = run_audit(args.output)
    print(f"Robustness property cases: {report['cases_passed']}/{report['cases_total']} passed")
    print(f"Robustness property checks: {report['checks_passed']}/{report['checks_total']} passed")
    print(f"Failures: {report['failures_total']}")
    for check in report["checks"]:
        print(f"  {check['name']}: {check['passed_cases']}/{check['cases']}")
    if report["failures_total"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

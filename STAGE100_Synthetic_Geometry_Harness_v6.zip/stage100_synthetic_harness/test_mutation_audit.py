import unittest

from mutation_audit import run_audit


class TargetedMutationAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report = run_audit()
        cls.by_name = {item["name"]: item for item in cls.report["mutants"]}

    def assert_mutant_killed(self, name):
        self.assertIn(name, self.by_name)
        self.assertTrue(
            self.by_name[name]["killed"],
            msg=f"Mutant survived: {self.by_name[name]}",
        )

    def test_matrix_transpose_mutant_is_killed(self):
        self.assert_mutant_killed("matrix_transposed_without_matching_convention")

    def test_translation_row_mutant_is_killed(self):
        self.assert_mutant_killed("translation_moved_to_final_row_only")

    def test_yaw_sign_mutant_is_killed(self):
        self.assert_mutant_killed("yaw_rotation_sign_reversed")

    def test_screen_x_sign_mutant_is_killed(self):
        self.assert_mutant_killed("screen_x_sign_reversed")

    def test_screen_y_sign_mutant_is_killed(self):
        self.assert_mutant_killed("screen_y_sign_reversed")

    def test_near_plane_bypass_mutant_is_killed(self):
        self.assert_mutant_killed("near_plane_guard_removed")

    def test_far_plane_bypass_mutant_is_killed(self):
        self.assert_mutant_killed("far_plane_guard_removed")

    def test_viewport_boundary_mutant_is_killed(self):
        self.assert_mutant_killed("right_viewport_boundary_made_inclusive")

    def test_source_validity_mutant_is_killed(self):
        self.assert_mutant_killed("source_validity_flag_ignored")

    def test_invalid_edge_bridge_mutant_is_killed(self):
        self.assert_mutant_killed("edge_bridges_across_invalid_joint")

    def test_zero_homogeneous_w_mutant_is_killed(self):
        self.assert_mutant_killed("zero_homogeneous_w_falls_back_to_one")

    def test_non_finite_projection_mutant_is_killed(self):
        self.assert_mutant_killed("non_finite_projected_coordinates_not_rejected")

    def test_camera_basis_mutant_is_killed(self):
        self.assert_mutant_killed("camera_right_basis_cross_order_reversed")

    def test_all_targeted_mutants_are_killed(self):
        self.assertEqual(self.report["mutants_killed"], self.report["mutants_total"])
        self.assertEqual(self.report["mutants_survived"], 0)


if __name__ == "__main__":
    unittest.main()

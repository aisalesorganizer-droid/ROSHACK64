"""Targeted mutation probes for the standalone synthetic geometry pipeline.

Each mutant is a deliberately defective reference behavior, not a modification
of the production module. The audit asks whether a named known-answer invariant
would detect that defect. This is a targeted fault-injection audit, not a claim
of automated source-level mutation coverage.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Callable

from synthetic_pipeline import (
    Camera,
    Joint,
    PipelineError,
    ProjectedPoint,
    Viewport,
    camera_basis,
    cross,
    dot,
    model_matrix,
    point_in_viewport,
    project_point,
    run_pipeline,
    sub,
    transform_point,
)


def transpose4(matrix):
    return tuple(tuple(matrix[c][r] for c in range(4)) for r in range(4))


def _raw_project_no_depth_guard(point, camera, viewport):
    """Deliberately defective project function: no near/far depth gate."""
    right, up, forward = camera_basis(camera)
    relative = sub(point, camera.position)
    vx, vy, depth = dot(relative, right), dot(relative, up), dot(relative, forward)
    focal = (viewport.height * 0.5) / math.tan(math.radians(camera.vertical_fov_degrees) * 0.5)
    return ProjectedPoint(
        viewport.width * 0.5 + focal * vx / depth,
        viewport.height * 0.5 - focal * vy / depth,
        depth,
    )


def _raw_project_no_finite_guard(point, camera, viewport):
    """Deliberately defective project function: returns non-finite screen values."""
    right, up, forward = camera_basis(camera)
    relative = sub(point, camera.position)
    vx, vy, depth = dot(relative, right), dot(relative, up), dot(relative, forward)
    focal = (viewport.height * 0.5) / math.tan(math.radians(camera.vertical_fov_degrees) * 0.5)
    return ProjectedPoint(
        viewport.width * 0.5 + focal * vx / depth,
        viewport.height * 0.5 - focal * vy / depth,
        depth,
    )


def _wrong_translation_row_transform(point, translation):
    """Deliberately use row-vector translation placement with a column-vector consumer."""
    tx, ty, tz = translation
    bad_matrix = (
        (1.0, 0.0, 0.0, 0.0),
        (0.0, 1.0, 0.0, 0.0),
        (0.0, 0.0, 1.0, 0.0),
        (tx, ty, tz, 1.0),
    )
    return transform_point(bad_matrix, point)


def _wrong_inclusive_viewport(p: ProjectedPoint, viewport: Viewport) -> bool:
    """Deliberately include the exclusive right/bottom boundaries."""
    return 0.0 <= p.x <= viewport.width and 0.0 <= p.y <= viewport.height


def _wrong_source_flag_ignored(joint, model, camera, viewport):
    """Deliberately discard the source validity flag before using the pipeline."""
    forged = Joint(joint.name, joint.position, joint.parent, source_valid=True)
    return run_pipeline([forged], model, camera, viewport)


def _wrong_bridge_invalid_joint(joints, result):
    """Deliberately bridge a rejected middle node to its nearest visible ancestor."""
    by_name = {joint.name: joint for joint in joints}
    added = []
    for joint in joints:
        if joint.name in result.projected:
            continue
        ancestor = joint.parent
        while ancestor is not None and ancestor not in result.projected:
            ancestor = by_name[ancestor].parent
        # Mutant: connect the first visible descendant to the visible ancestor,
        # even though this is not a declared parent-child edge.
        for candidate in joints:
            if candidate.parent == joint.name and candidate.name in result.projected and ancestor is not None:
                added.append((ancestor, candidate.name))
    return added


def _wrong_zero_w_fallback(matrix, point):
    """Deliberately replace zero homogeneous W with 1 instead of rejecting."""
    x, y, z = point
    v = (x, y, z, 1.0)
    out = tuple(sum(matrix[r][c] * v[c] for c in range(4)) for r in range(4))
    w = out[3] if abs(out[3]) > 1e-12 else 1.0
    return (out[0] / w, out[1] / w, out[2] / w)


def _record(name: str, oracle: str, mutant_observation: str, killed: bool) -> dict:
    return {
        "name": name,
        "oracle": oracle,
        "mutant_observation": mutant_observation,
        "killed": bool(killed),
    }


def run_audit() -> dict:
    results: list[dict] = []
    point = (1.0, 2.0, 3.0)
    correct_translation = (4.0, 5.0, 6.0)
    expected = transform_point(model_matrix(correct_translation, 0.0), point)

    # 1. Mismatched matrix storage/multiplication convention (transpose a logical matrix).
    logical = model_matrix((2.0, 3.0, 4.0), 23.0)
    mutated = transpose4(logical)
    try:
        observed = transform_point(mutated, (0.6, 0.4, 2.0))
        good = transform_point(logical, (0.6, 0.4, 2.0))
        killed = any(abs(a - b) > 1e-6 for a, b in zip(observed, good))
        note = f"finite wrong point {observed}; known-answer point {good}"
    except PipelineError as exc:
        killed, note = True, f"mutation rejected by transform validation: {exc}"
    results.append(_record(
        "matrix_transposed_without_matching_convention",
        "transformed point must equal the logical matrix's known-answer point",
        note, killed))

    # 2. Translation stored in final row while still consumed as matrix * column vector.
    try:
        observed = _wrong_translation_row_transform(point, correct_translation)
        killed = any(abs(a - b) > 1e-6 for a, b in zip(observed, expected))
        note = f"observed={observed}; expected={expected}"
    except PipelineError as exc:
        killed, note = True, f"mutation rejected: {exc}"
    results.append(_record(
        "translation_moved_to_final_row_only",
        "translation (4,5,6) applied to (1,2,3) must produce (5,7,9)",
        note, killed))

    # 3. Reverse a known positive yaw rotation.
    good_rotation = model_matrix((0.0, 0.0, 0.0), 90.0)
    bad_rotation = model_matrix((0.0, 0.0, 0.0), -90.0)
    expected_rotation = transform_point(good_rotation, (1.0, 0.0, 0.0))
    observed_rotation = transform_point(bad_rotation, (1.0, 0.0, 0.0))
    killed = any(abs(a - b) > 1e-6 for a, b in zip(observed_rotation, expected_rotation))
    results.append(_record(
        "yaw_rotation_sign_reversed",
        "positive 90-degree yaw maps +X to the declared -Z direction",
        f"mutant={observed_rotation}; expected={expected_rotation}", killed))

    camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0), vertical_fov_degrees=90.0)
    viewport = Viewport(800, 600)
    center = project_point((0.0, 0.0, 10.0), camera, viewport)
    right_point = project_point((1.0, 0.0, 10.0), camera, viewport)
    up_point = project_point((0.0, 1.0, 10.0), camera, viewport)
    focal = (viewport.height * 0.5) / math.tan(math.radians(camera.vertical_fov_degrees) * 0.5)

    # 4. Reverse horizontal screen axis.
    right, up, forward = camera_basis(camera)
    rel = sub((1.0, 0.0, 10.0), camera.position)
    wrong_x = viewport.width * 0.5 - focal * dot(rel, right) / dot(rel, forward)
    killed = not (wrong_x > center.x)
    results.append(_record(
        "screen_x_sign_reversed",
        "a point in camera-right direction must project right of center",
        f"mutant_x={wrong_x}; center_x={center.x}; correct_x={right_point.x}", killed))

    # 5. Reverse vertical screen axis.
    rel = sub((0.0, 1.0, 10.0), camera.position)
    wrong_y = viewport.height * 0.5 + focal * dot(rel, up) / dot(rel, forward)
    killed = not (wrong_y < center.y)
    results.append(_record(
        "screen_y_sign_reversed",
        "a point in camera-up direction must project above screen center",
        f"mutant_y={wrong_y}; center_y={center.y}; correct_y={up_point.y}", killed))

    # 6. Remove near-plane rejection.
    near_camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0), near_plane=0.1, far_plane=100.0)
    near_point = (0.0, 0.0, 0.05)
    try:
        project_point(near_point, near_camera, viewport)
        correct_reject = False
    except PipelineError:
        correct_reject = True
    mutant_near = _raw_project_no_depth_guard(near_point, near_camera, viewport)
    killed = correct_reject and mutant_near.depth <= near_camera.near_plane
    results.append(_record(
        "near_plane_guard_removed",
        "a point at depth 0.05 is rejected when near plane is 0.1",
        f"mutant accepted depth={mutant_near.depth}", killed))

    # 7. Remove far-plane rejection.
    far_camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0), near_plane=0.1, far_plane=10.0)
    far_point = (0.0, 0.0, 15.0)
    try:
        project_point(far_point, far_camera, viewport)
        correct_reject = False
    except PipelineError:
        correct_reject = True
    mutant_far = _raw_project_no_depth_guard(far_point, far_camera, viewport)
    killed = correct_reject and mutant_far.depth >= far_camera.far_plane
    results.append(_record(
        "far_plane_guard_removed",
        "a point at depth 15 is rejected when far plane is 10",
        f"mutant accepted depth={mutant_far.depth}", killed))

    # 8. Make right/bottom viewport boundaries inclusive by mistake.
    boundary_point = ProjectedPoint(800.0, 300.0, 1.0)
    reference_inside = point_in_viewport(boundary_point, viewport)
    mutant_inside = _wrong_inclusive_viewport(boundary_point, viewport)
    killed = (not reference_inside) and mutant_inside
    results.append(_record(
        "right_viewport_boundary_made_inclusive",
        "x == viewport.width is outside the half-open viewport",
        f"reference_inside={reference_inside}; mutant_inside={mutant_inside}", killed))

    # 9. Ignore source-validity metadata even though coordinates are finite.
    invalid_joint = Joint("invalid_probe", (0.0, 0.0, 5.0), None, source_valid=False)
    reference = run_pipeline([invalid_joint], model_matrix(), camera, viewport)
    mutant = _wrong_source_flag_ignored(invalid_joint, model_matrix(), camera, viewport)
    killed = ("invalid_probe" not in reference.projected) and ("invalid_probe" in mutant.projected)
    results.append(_record(
        "source_validity_flag_ignored",
        "finite coordinates must not override source_valid=False",
        f"reference_projected={list(reference.projected)}; mutant_projected={list(mutant.projected)}", killed))

    # 10. Bridge from a visible ancestor across a rejected middle joint.
    joints = [
        Joint("root", (0.0, 0.0, 5.0), None, True),
        Joint("bad_middle", (0.0, 0.2, 5.0), "root", False),
        Joint("child", (0.1, 0.0, 5.0), "bad_middle", True),
    ]
    reference = run_pipeline(joints, model_matrix(), camera, viewport)
    mutant_added = _wrong_bridge_invalid_joint(joints, reference)
    killed = ("root", "child") not in reference.edges and ("root", "child") in mutant_added
    results.append(_record(
        "edge_bridges_across_invalid_joint",
        "rendering must preserve declared parent-child relationships and not invent a root-child edge",
        f"reference_edges={reference.edges}; mutant_added_edges={mutant_added}", killed))

    # 11. Accept zero homogeneous W by substituting 1.
    zero_matrix = tuple(tuple(0.0 for _ in range(4)) for _ in range(4))
    try:
        transform_point(zero_matrix, (1.0, 2.0, 3.0))
        reference_reject = False
    except PipelineError:
        reference_reject = True
    mutant_result = _wrong_zero_w_fallback(zero_matrix, (1.0, 2.0, 3.0))
    killed = reference_reject and all(math.isfinite(v) for v in mutant_result)
    results.append(_record(
        "zero_homogeneous_w_falls_back_to_one",
        "W == 0 must be rejected rather than replaced with a plausible value",
        f"reference_rejected={reference_reject}; mutant_result={mutant_result}", killed))

    # 12. Accept non-finite projected screen coordinates.
    huge_point = (1e308, 0.0, 1.0)
    try:
        project_point(huge_point, camera, viewport)
        reference_reject = False
    except (PipelineError, OverflowError, ValueError):
        reference_reject = True
    try:
        mutant_point = _raw_project_no_finite_guard(huge_point, camera, viewport)
        mutant_nonfinite = not all(math.isfinite(v) for v in (mutant_point.x, mutant_point.y, mutant_point.depth))
    except (OverflowError, ValueError, ZeroDivisionError):
        mutant_nonfinite = False
    killed = reference_reject and mutant_nonfinite
    results.append(_record(
        "non_finite_projected_coordinates_not_rejected",
        "projection must reject non-finite screen coordinates before renderer use",
        f"reference_rejected={reference_reject}; mutant_nonfinite={mutant_nonfinite}", killed))

    # 13. Reverse camera-right basis by crossing forward with up instead of up with forward.
    right_basis, _, forward_basis = camera_basis(camera)
    wrong_right = tuple(-v for v in right_basis)  # reversed cross-product order
    probe = (1.0, 0.0, 10.0)
    rel = sub(probe, camera.position)
    correct_camera_x = dot(rel, right_basis)
    mutant_camera_x = dot(rel, wrong_right)
    killed = (correct_camera_x > 0.0) and (mutant_camera_x < 0.0)
    results.append(_record(
        "camera_right_basis_cross_order_reversed",
        "world +X must align with camera-right in the baseline camera orientation",
        f"correct_camera_x={correct_camera_x}; mutant_camera_x={mutant_camera_x}; forward={forward_basis}", killed))

    return {
        "title": "Synthetic Pipeline Targeted Mutation / Fault-Injection Audit",
        "scope": "Standalone synthetic math and render-data only; no external process, game memory, or live application data used.",
        "method": "Thirteen deliberately defective reference behaviors were evaluated against named known-answer invariants. These are targeted mutation probes, not automatic source-code mutation testing.",
        "mutants_total": len(results),
        "mutants_killed": sum(item["killed"] for item in results),
        "mutants_survived": sum(not item["killed"] for item in results),
        "targeted_detection_rate_percent": round(100.0 * sum(item["killed"] for item in results) / max(1, len(results)), 2),
        "mutants": results,
        "interpretation": [
            "A mutant is killed when the corresponding known-answer oracle detects its deliberately wrong behavior.",
            "The detection rate applies only to these thirteen hand-selected probes; it is not a general test-coverage percentage or an automatic source mutation score.",
            "This audit validates the synthetic harness's stated contract. It does not identify or verify conventions used by any external application.",
        ],
    }


def write_report(output_dir: Path) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    report = run_audit()
    (output_dir / "mutation_audit.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    lines = [
        report["title"].upper(),
        report["scope"],
        report["method"],
        "",
        f"Targeted probes killed: {report['mutants_killed']}/{report['mutants_total']}",
        f"Targeted detection rate: {report['targeted_detection_rate_percent']:.2f}%",
        f"Surviving probes: {report['mutants_survived']}",
        "",
    ]
    for item in report["mutants"]:
        lines.append(f"{'KILLED' if item['killed'] else 'SURVIVED'}  {item['name']}")
        lines.append(f"  Oracle: {item['oracle']}")
        lines.append(f"  Observation: {item['mutant_observation']}")
    lines.extend(["", "Interpretation notes:", *[f"- {item}" for item in report["interpretation"]]])
    (output_dir / "mutation_audit.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("results"), help="Directory for audit reports")
    args = parser.parse_args()
    report = write_report(args.output)
    print(f"Targeted mutation audit: {report['mutants_killed']}/{report['mutants_total']} mutants killed")
    if report["mutants_survived"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

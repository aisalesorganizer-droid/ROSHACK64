"""Audit explicit matrix/camera conventions with synthetic known-answer inputs.

This script does not inspect or infer another application's matrices. It compares
self-contained conventions using known matrices, points, and camera vectors.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Sequence

from synthetic_pipeline import (
    Camera,
    PipelineError,
    Viewport,
    camera_basis,
    model_matrix,
    project_point,
    transform_point,
)

Matrix = tuple[tuple[float, float, float, float], ...]
Vector4 = tuple[float, float, float, float]


def flatten_matrix(matrix: Matrix, storage_order: str) -> tuple[float, ...]:
    """Serialize a logical matrix in row-major or column-major storage order."""
    if len(matrix) != 4 or any(len(row) != 4 for row in matrix):
        raise ValueError("Matrix must be 4x4")
    if storage_order == "row_major":
        return tuple(matrix[r][c] for r in range(4) for c in range(4))
    if storage_order == "column_major":
        return tuple(matrix[r][c] for c in range(4) for r in range(4))
    raise ValueError("storage_order must be 'row_major' or 'column_major'")


def decode_matrix(values: Sequence[float], storage_order: str) -> Matrix:
    """Decode 16 scalars using the stated storage order into logical rows."""
    if len(values) != 16:
        raise ValueError("A 4x4 matrix requires exactly 16 values")
    if storage_order == "row_major":
        return tuple(tuple(float(values[r * 4 + c]) for c in range(4)) for r in range(4))
    if storage_order == "column_major":
        return tuple(tuple(float(values[c * 4 + r]) for c in range(4)) for r in range(4))
    raise ValueError("storage_order must be 'row_major' or 'column_major'")


def mat4_col_vector(matrix: Matrix, vector: Vector4) -> Vector4:
    return tuple(sum(matrix[r][c] * vector[c] for c in range(4)) for r in range(4))  # type: ignore[return-value]


def row_vector_mat4(vector: Vector4, matrix: Matrix) -> Vector4:
    return tuple(sum(vector[r] * matrix[r][c] for r in range(4)) for c in range(4))  # type: ignore[return-value]


def affine_for_column_vector(matrix: Matrix, tolerance: float = 1e-9) -> bool:
    """Column-vector affine convention puts (0,0,0,1) in the final row."""
    return all(abs(matrix[3][i] - expected) <= tolerance
               for i, expected in enumerate((0.0, 0.0, 0.0, 1.0)))


def affine_for_row_vector(matrix: Matrix, tolerance: float = 1e-9) -> bool:
    """Row-vector affine convention puts (0,0,0,1) in the final column."""
    return all(abs(matrix[i][3] - expected) <= tolerance
               for i, expected in enumerate((0.0, 0.0, 0.0, 1.0)))


def transpose4(matrix: Matrix) -> Matrix:
    return tuple(tuple(matrix[c][r] for c in range(4)) for r in range(4))


def determinant3(matrix: Matrix) -> float:
    a, b, c = matrix[0][:3]
    d, e, f = matrix[1][:3]
    g, h, i = matrix[2][:3]
    return (a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g))


def almost_equal_vec(actual: Sequence[float], expected: Sequence[float], tol: float = 1e-8) -> bool:
    return len(actual) == len(expected) and all(
        math.isfinite(float(a)) and abs(float(a) - float(e)) <= tol
        for a, e in zip(actual, expected)
    )


def _homogeneous_divide(value: Vector4) -> tuple[float, float, float] | None:
    w = value[3]
    if not math.isfinite(w) or abs(w) <= 1e-12:
        return None
    out = (value[0] / w, value[1] / w, value[2] / w)
    if not all(math.isfinite(v) for v in out):
        return None
    return out


def run_audit() -> dict:
    point = (1.0, 2.0, 3.0)
    translation = (4.0, 5.0, 6.0)
    canonical = model_matrix(translation, 0.0)
    expected_world = (5.0, 7.0, 9.0)
    flat_row = flatten_matrix(canonical, "row_major")
    flat_col = flatten_matrix(canonical, "column_major")
    decoded_row = decode_matrix(flat_row, "row_major")
    decoded_col = decode_matrix(flat_col, "column_major")
    transposed_by_misdecode = decode_matrix(flat_row, "column_major")

    canonical_h = mat4_col_vector(canonical, (*point, 1.0))
    direction_result = mat4_col_vector(canonical, (1.0, 0.0, 0.0, 0.0))
    mismatch_h = mat4_col_vector(transposed_by_misdecode, (*point, 1.0))
    row_mismatch_h = row_vector_mat4((*point, 1.0), canonical)
    row_convention_matrix = transpose4(canonical)
    row_correct_h = row_vector_mat4((*point, 1.0), row_convention_matrix)

    yaw90 = model_matrix((0.0, 0.0, 0.0), 90.0)
    rotated_x = transform_point(yaw90, (1.0, 0.0, 0.0))
    camera = Camera((0.0, 0.0, 0.0), (0.0, 0.0, 1.0), up_hint=(0.0, 1.0, 0.0), vertical_fov_degrees=90.0)
    camera_right, camera_up, camera_forward = camera_basis(camera)
    viewport = Viewport(800, 600)
    center = project_point((0.0, 0.0, 10.0), camera, viewport)
    right_point = project_point((1.0, 0.0, 10.0), camera, viewport)
    up_point = project_point((0.0, 1.0, 10.0), camera, viewport)
    behind_rejected = False
    try:
        project_point((0.0, 0.0, -1.0), camera, viewport)
    except PipelineError:
        behind_rejected = True

    rotation_det = determinant3(yaw90)
    reflection: Matrix = (
        (-1.0, 0.0, 0.0, 0.0),
        (0.0, 1.0, 0.0, 0.0),
        (0.0, 0.0, 1.0, 0.0),
        (0.0, 0.0, 0.0, 1.0),
    )
    reflection_det = determinant3(reflection)

    checks = [
        {
            "name": "row_major_storage_round_trip",
            "pass": decoded_row == canonical,
            "expected": "decoded logical matrix equals source matrix",
            "actual": "equal" if decoded_row == canonical else "different",
        },
        {
            "name": "column_major_storage_round_trip",
            "pass": decoded_col == canonical,
            "expected": "decoded logical matrix equals source matrix",
            "actual": "equal" if decoded_col == canonical else "different",
        },
        {
            "name": "column_vector_translation_in_final_column",
            "pass": affine_for_column_vector(canonical) and almost_equal_vec(_homogeneous_divide(canonical_h) or (), expected_world),
            "expected_world": list(expected_world),
            "actual_homogeneous": list(canonical_h),
            "actual_world": list(_homogeneous_divide(canonical_h) or ()),
        },
        {
            "name": "storage_layout_mismatch_detected_by_affine_invariant",
            "pass": not affine_for_column_vector(transposed_by_misdecode),
            "expected": "misdecoded translation matrix fails column-vector affine invariant",
            "actual_affine_for_column_vectors": affine_for_column_vector(transposed_by_misdecode),
            "actual_final_row": list(transposed_by_misdecode[3]),
            "homogeneous_result_if_divided": list(_homogeneous_divide(mismatch_h) or ()),
        },
        {
            "name": "row_vector_convention_requires_translation_in_final_row",
            "pass": affine_for_row_vector(row_convention_matrix) and almost_equal_vec(_homogeneous_divide(row_correct_h) or (), expected_world),
            "expected_world": list(expected_world),
            "actual_homogeneous": list(row_correct_h),
            "actual_world": list(_homogeneous_divide(row_correct_h) or ()),
            "translation_location": "final row",
        },
        {
            "name": "wrong_multiplication_side_is_detectable",
            "pass": not affine_for_row_vector(canonical),
            "expected": "final-column translation matrix is not affine under row-vector convention",
            "actual_affine_for_row_vectors": affine_for_row_vector(canonical),
            "raw_row_vector_result": list(row_mismatch_h),
            "homogeneous_result_if_divided": list(_homogeneous_divide(row_mismatch_h) or ()),
        },
        {
            "name": "positive_90_degree_yaw_known_answer",
            "pass": almost_equal_vec(rotated_x, (0.0, 0.0, -1.0)),
            "expected_rotated_positive_x": [0.0, 0.0, -1.0],
            "actual": list(rotated_x),
        },
        {
            "name": "rotation_preserves_right_handed_orientation",
            "pass": abs(rotation_det - 1.0) <= 1e-8,
            "expected_determinant": 1.0,
            "actual_determinant": rotation_det,
        },
        {
            "name": "reflection_is_detected_by_negative_determinant",
            "pass": abs(reflection_det + 1.0) <= 1e-8,
            "expected_determinant": -1.0,
            "actual_determinant": reflection_det,
        },
        {
            "name": "camera_basis_matches_plus_z_forward_plus_y_up",
            "pass": all((almost_equal_vec(camera_right, (1.0, 0.0, 0.0)),
                          almost_equal_vec(camera_up, (0.0, 1.0, 0.0)),
                          almost_equal_vec(camera_forward, (0.0, 0.0, 1.0)))),
            "expected": {"right": [1.0, 0.0, 0.0], "up": [0.0, 1.0, 0.0], "forward": [0.0, 0.0, 1.0]},
            "actual": {"right": list(camera_right), "up": list(camera_up), "forward": list(camera_forward)},
        },
        {
            "name": "projection_screen_axis_signs",
            "pass": center.x == viewport.width / 2 and center.y == viewport.height / 2 and right_point.x > center.x and up_point.y < center.y,
            "expected": "forward point centers; +X moves right; +Y moves up on screen",
            "actual": {"center": [center.x, center.y], "right_point": [right_point.x, right_point.y], "up_point": [up_point.x, up_point.y]},
        },
        {
            "name": "point_behind_camera_is_rejected",
            "pass": behind_rejected,
            "expected_rejected": True,
            "actual_rejected": behind_rejected,
        },
        {
            "name": "same_logical_matrix_has_same_result_in_both_storage_orders",
            "pass": almost_equal_vec(transform_point(decoded_row, point), transform_point(decoded_col, point)),
            "row_major_world": list(transform_point(decoded_row, point)),
            "column_major_world": list(transform_point(decoded_col, point)),
        },
        {
            "name": "translation_does_not_change_direction_vectors_when_w_is_zero",
            "pass": almost_equal_vec(direction_result, (1.0, 0.0, 0.0, 0.0)),
            "expected_transformed_direction": [1.0, 0.0, 0.0, 0.0],
            "actual_transformed_direction": list(direction_result),
            "note": "homogeneous direction vectors use w=0, so translation must not affect them",
        },
    ]

    return {
        "title": "Synthetic Matrix and Camera Coordinate Contract Audit",
        "scope": "Synthetic-only; no external process, game memory, or live application data used.",
        "convention_under_test": {
            "matrix_storage": "row-major",
            "vector_operation": "matrix times column vector",
            "translation": "final column",
            "world_up": "+Y",
            "baseline_forward": "+Z",
            "camera_view_depth": "positive along forward",
            "screen_x": "increases to the right",
            "screen_y": "increases downward",
        },
        "checks_passed": sum(bool(item["pass"]) for item in checks),
        "checks_total": len(checks),
        "checks": checks,
        "interpretation": [
            "Row-major and column-major describe scalar storage order; either can encode the same logical matrix when decoded consistently.",
            "The vector multiplication side and translation location are a separate convention. They must be paired correctly.",
            "A convention mismatch can produce plausible finite values, so use known-answer points and affine invariants rather than finiteness alone.",
            "This audit verifies only its own declared synthetic convention. It cannot determine the convention used by another application.",
        ],
    }


def write_report(output_dir: Path) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    report = run_audit()
    (output_dir / "matrix_convention_audit.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    lines = [
        report["title"].upper(),
        report["scope"],
        "",
        "Declared convention: row-major storage; matrix × column vector; translation in final column; +Y up; +Z forward.",
        f"Checks: {report['checks_passed']}/{report['checks_total']} passed",
        "",
    ]
    for check in report["checks"]:
        lines.append(f"{'PASS' if check['pass'] else 'FAIL'}  {check['name']}")
        if not check["pass"]:
            lines.append(f"      details: {json.dumps(check, sort_keys=True)}")
    lines.extend(["", "Interpretation notes:", *[f"- {item}" for item in report["interpretation"]]])
    (output_dir / "matrix_convention_audit.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("results"), help="Directory for audit reports")
    args = parser.parse_args()
    report = write_report(args.output)
    print(f"Matrix/camera convention audit: {report['checks_passed']}/{report['checks_total']} checks passed")
    if report["checks_passed"] != report["checks_total"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
